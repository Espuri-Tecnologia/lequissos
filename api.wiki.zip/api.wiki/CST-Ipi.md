Listagem dos CSTs:

<table>
<tr><th>Código</th><th>ENUM</th><th>Tipo</th></tr>
<tr><td>00</td><td>ENTRADA_RECUPERACAO_CREDITO</td><td>Entrada</td></tr>
<tr><td>01</td><td>ENTRADA_TRIBUTO_ALIQUOTA_ZERO</td><td>Entrada</td></tr>
<tr><td>02</td><td>ENTRADA_ISENTA</td><td>Entrada</td></tr>
<tr><td>03</td><td>ENTRADA_NAO_TRIBUTADA</td><td>Entrada</td></tr>
<tr><td>04</td><td>ENTRADA_IMUNE</td><td>Entrada</td></tr>
<tr><td>05</td><td>ENTRADA_COM_SUSPENSAO</td><td>Entrada</td></tr>
<tr><td>49</td><td>OUTRAS_ENTRADAS</td><td>Entrada</td></tr>
<tr><td>50</td><td>SAIDA_TRIBUTADA</td><td>Saída</td></tr>
<tr><td>51</td><td>SAIDA_TRIBUTADA_ALIQUOTA_ZERO</td><td>Saída</td></tr>
<tr><td>52</td><td>SAIDA_ISENTA</td><td>Saída</td></tr>
<tr><td>53</td><td>SAIDA_NAO_TRIBUTADA</td><td>Saída</td></tr>
<tr><td>54</td><td>SAIDA_IMUNE</td><td>Saída</td></tr>
<tr><td>55</td><td>SAIDA_COM_SUSUPENSAO</td><td>Saída</td></tr>
<tr><td>99</td><td>OUTRAS_SAIDAS</td><td>Saída</td></tr>
</table>
