### URLs

> GET https://integrador.varejonline.com.br/apps/api/notas-mercadoria

> GET https://integrador.varejonline.com.br/apps/api/notas-mercadoria/:id

### Parâmetros

* **entidades:** [Veja como Funciona este Filtro](https://github.com/Varejonline/api/wiki/Filtro-de-Entidades)
* **inicio:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **quantidade:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **alteradoApos:** [Entenda a Coleta de Alterações](https://github.com/Varejonline/api/wiki/Filtro-de-Data-Alteração)
* **desde:** [Veja o Filtro de Datas](https://github.com/Varejonline/api/wiki/Filtro-de-Datas)
* **ate:** [Veja o Filtro de Datas](https://github.com/Varejonline/api/wiki/Filtro-de-Datas)
* **tipo:** Filtra as notas por tipo: ENTRADA, SAIDA (string)
* **operacaoMapa:** Filtra as notas por operação (string)
  * **Opções disponíveis**
    * DEVOLUCAO_VENDA: Retornará apenas notas fiscais vinculadas às operações de devolução de venda
    * DEVOLUCAO_COMPRA: Retornará apenas notas fiscais vinculadas às operações de devolução de compra
* **naoEscrituradas:** Indica se devem ser retornadas notas não escrituradas na consulta (boolean)
* **numeroNotaFiscal:** Permite que seja filtrado as notas com o número informado (Integer)
* **serieNotaFiscal:** Permite que sejam retornadas apenas notas da série informada (String)
* **status:** Permite que seja filtrado as notas pelo seu [status](https://github.com/Varejonline/api/wiki/Status-Documentos-Fiscais) (string)
* **idEntrada:** Permite buscar uma nota fiscal pelo [id da entrada](https://github.com/Varejonline/api/wiki/GET-entradas) no sistema (long)
* **idSaida:** Permite buscar uma nota fiscal pelo [id da saída](https://github.com/Varejonline/api/wiki/GET-saidas) no sistema (long)
* **orderBy:** Tipo da ordenação de resultados desejada (string)
  * **id**  ordenação crescente pelo id dos registros (Valor padrão caso não informado)
  * **notaFiscal.dataAlteracao** ordenação crescente pela data de alteração dos registros
  * **notaFiscal.dataCriacao** ordenação crescente pela data de criação dos registros
  * **identificacao.numeroNotaFiscal** ordenação crescente pelo número da nota fiscal
  * **identificacao.dataEmissao** ordenação crescente pela data de emissão da nota fiscal
  * **identificacao.dataSaidaEntrada** ordenação crescente pela data de saída ou entrada da nota fiscal
* **[integrados](https://github.com/Varejonline/api/wiki/Controle-de-registros-integrados):** Filtro de controle de integração de registros(boolean)
  * **1** retorna apenas registros já marcados como coletados pelo integrador
  * **0** retorna apenas registros não marcados como coletados pelo integrador
* **[integrador](https://github.com/Varejonline/api/wiki/Controle-de-registros-integrados):** Nome utilizado pelo integrador para registrar o registro como integrado (String)
* **cfops:** Retorna somente as notas que possuem ao menos um dos cfops informados (lista numérica separada por virgula)
* **chaves:** Retorna somente as notas cujo a chave esteja nesta lista (lista string separada por virgula)
* **modeloDocumentoFiscal:** [modelo](https://github.com/Varejonline/api/wiki/Modelos-de-Notas-Fiscais) do documento (lista string separada por virgula)

### Retorno

* **id:** id da nota (long)
* **tipo:** tipo da nota (string). Os valores possíveis são: ENTRADA e SAIDA
* **modelo:** [tipo](https://github.com/Varejonline/api/wiki/Tipo-de-Documentos-Fiscais) da nota fiscal.
* **modeloDocumentoFiscal:** [modelo](https://github.com/Varejonline/api/wiki/Modelos-de-Notas-Fiscais) do documento.
* **chave:** Chave de acesso do documento fiscal (string).
* **protocolo:** Protocolo de processamento do documento fiscal (string).
* **naturezaOperacao:** Texto do campo natureza da operação na nota fiscal (String).
* **dataAutorizacao:** Data da autorização do documento fiscal (dd-MM-yyyy).
* **horaAutorizacao:** Hora da autorização do documento fiscal (HH:mm:ss).
* **serie:** número de série associado com o documento da nota fiscal de mercadoria. (string)
* **numeroNotaFiscal:** número do documento fiscal da nota de mercadoria. (long)
* **data:** data de emissão da nota (string dd-mm-aaaa)
* **entidade:** [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) da nota (objeto complexo)
    * **id:** id da entidade (long)
    * **nome:** nome da entidade (string)
    * **documento:** documento da entidade (string)
* **remetente:** [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros) remetente da nota (objeto complexo)
    * **id:**  id do remetente (long)
    * **nome:** nome do remetente (string)
    * **documento:** documento do remetente (string)
* **destinatario:** [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros) destinatário da nota (objeto complexo)
    * **id:**  id do destinatário (long)
    * **nome:** nome do destinatário (string)
    * **documento:** documento do destinatário (string)
* **status:** [status](https://github.com/Varejonline/api/wiki/Status-Documentos-Fiscais) da nota (string).
* **escriturada:** [tipo](https://github.com/Varejonline/api/wiki/Tipos-de-Escrituração) de escrituração da nota.
* **valorTotal:** valor total da nota (decimal)
* **dataAlteracao:** data da última alteração da nota (string)
* **itens:** lista de itens da nota
   * **produto:** dados do produto (objeto complexo)
      * **id:** id da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos)
      * **descricao:** id da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos)
      * **codigoSistema:** Código Sistema da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos)
      * **codigoInterno:** Código Interno da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos)
      * **codigoBarras:** Código de Barras da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos)
   * **cfop:** código CFOP da operação (integer)
   * **quantidade:** quantidade do produto (decimal)
   * **valorUnitario:** valor unitário do produto na nota (decimal)
   * **valorFrete:** valor de frete do item (decimal)
   * **valorOutros:** outros valores do item (decimal)
   * **valorSeguro:** valor de seguro do item (decimal)
   * **valorTotal:** valor total do item (decimal)
   * **valorDesconto:** valor do desconto do item (decimal)
   * **valorIpiDevolvido:** valor do ipi devolvido (decimal)
   * **icms:** dados do ICMS aplicado ao item (segue a estrutura comum abaixo)
   * **cofins:** dados do COFINS aplicado ao item (segue a estrutura comum abaixo)
   * **pis:** dados do PIS aplicado ao item (segue a estrutura comum abaixo)
   * **ipi:** dados do IPI aplicado ao item (segue a estrutura comum abaixo)
   * **icmssn:** dados do ICMSSN aplicado ao item (segue a estrutura comum abaixo)
   * **icmsst:** dados do ICMSST aplicado ao item (segue a estrutura comum abaixo)
   * **sequencia:** número de sequência do item na nota (Long iniciando em 1)
   * **notaOrigemDevolucao:** Caso seja devolução, irá constar o número da nota fiscal de origem da venda (string)
 * **entradas:** lista com os [ids das entradas](https://github.com/Varejonline/api/wiki/GET-entradas) associadas à nota emitida.
 * **saidas:** lista com os [ids das saídas](https://github.com/Varejonline/api/wiki/GET-saidas) associadas à nota emitida.
* **transporte:** dados do transporte (objeto complexo)
   * **modalidade:** [modalidade](https://github.com/Varejonline/api/wiki/Modalidade-do-frete) do frete (string)
   * **especie:** tipo de carga (string)
   * **numero:** a numeração dos volumes transportados (string)
   * **marca:** a marca dos volumes transportados (string)
   * **quantidade:** quantidade de volumes transportados (long)
   * **codigoANTT:** código da Agência Nacional de Transportes Terrestres (string)
   * **placaVeiculo:** número da placa do veículo transportador (string)
   * **estadoVeiculo:**  nome do estado de registro do veículo (string)
   * **pesoBruto:** peso bruto dos produtos em kg (decimal)
   * **pesoLiquido:** peso líquido dos produtos em kg (decimal)
   * **transportador:** dados do [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros) transportador (objeto complexo)
      * **id:** id do transportador (long)
      * **nome:** nome do transportador (string)
      * **documento:** documento do transportador (string)
* **informacoesAdicionaisFisco:** Informações adicionais de interesse do Fisco (string)
* **informacoesAdicionais:** Informações adicionais (string)
* **destinatarioEndereco:** endereço do destinatário (objeto complexo)
  * **logradouro:** logradouro do endereço (string)
  * **numero:** número do endereço (string)
  * **complemento:** complemento do endereço (string)
  * **bairro:** bairro do endereço (string)
  * **cep:** CEP do endereço (string)
  * **cidade:** cidade do endereço (string)
  * **uf:** UF do endereço (string)
* **enderecoEntrega:** endereço de entrega das mercadorias (objeto complexo)
  * **logradouro:** logradouro do endereço (string)
  * **numero:** número do endereço (string)
  * **complemento:** complemento do endereço (string)
  * **bairro:** bairro do endereço (string)
  * **cep:** CEP do endereço (string)
  * **cidade:** cidade do endereço (string)
  * **uf:** UF do endereço (string)
 
Estrutura comum para tributos:
   * **base:** valor da base de cálculo do tributo (decimal)
   * **aliquota:** valor da alíquota aplicada (decimal)
   * **valor:** valor do tributo (decimal)
   * **cst:** código de situação tributária (string)

**Observações:** A nota sempre estará associada a (uma ou mais entradas) OU (uma ou mais saídas).

### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/notas-mercadoria

```javascript
[
   {
      "id":281,
      "tipo":"SAIDA",
      "modelo":"MERCADORIA",
      "modeloDocumentoFiscal":"NOTA_65",
      "chave":"41170605762499000198650030000413821298892995",
      "dataAutorizacao":"26-08-2012",
      "horaAutorizacao":"14:20:35",
      "serie":"100",
      "numeroNotaFiscal":9999,
      "data":"26-08-2012",
      "remetente": {
          "id": 6,
          "nome": "remetente",
          "documento": "00.000.000/0000-00"
      },
      "destinatario": {
          "id": 9,
          "nome": "destinatario",
          "documento": "000.000.000-00"
      },
      "entidade": {
          "id": 2,
          "nome": "Entidade teste",
          "documento": "00.000.000/0000-00"
      },
      "status":"EMITIDO",
      "escriturada":"ESCRITURADA_EXTERNO",
      "valorTotal":16622.20,
      "dataAlteracao":"15-10-2012",
      "entradas": [1]
      "itens":[
         {
            "produto": {
                "id":9342,
                "descricao":"BLUSA MALHA PRETA GG",
                "codigoSistema":"0001.0001",
                "codigoInterno":"",
                "codigoBarras":""
            },
            "cfop":5102,
            "quantidade":1000,
            "valorUnitario":14.00,
            "valorFrete":0,
            "valorOutros":0,
            "valorSeguro":0,
            "sequencia":1,
            "valorTotal":14000,
            "valorDesconto":0,
            "valorIpiDevolvido":0,
            "icms":{
               "base":14000,
               "valor":2520,
               "aliquota":18,
               "cst":"10"
            },
            "cofins":{
               "base":14000,
               "valor":420,
               "aliquota":3,
               "cst":"01"
            },
            "pis":{
               "base":14000,
               "valor":91,
               "aliquota":0.65,
               "cst":"01"
            },
            "ipi":{
               "base":14000,
               "valor":1400,
               "aliquota":10,
               "cst":"50"
            },
            "icmssn":{
               "base":0,
               "valor":0,
               "aliquota":0,
               "cst":"10"
            },
            "icmsst":{
               "base":20790,
               "valor":1222.2,
               "aliquota":18,
               "cst":"10"
            }
         }
      ],
      "transporte":{
         "modalidade":"EMITENTE",
         "especie":"caixa",
         "numero":"exemplo",
         "marca":"padrão",
         "quantidade":1,
         "estadoVeiculo":"São Paulo ",
         "codigoANTT":"exemplo",
         "placaVeiculo":"VUC-1234",
         "pesoBruto":10,
         "pesoLiquido":10,
         "transportador":{
            "id":999,
            "nome":"Transportadora Exemplo LTDA",
            "documento":"12.123.123/1234-12"
         }
      },
      "informacoesAdicionais": "Val. Aprox. dos Tributos F: R$ 2,10 (4,20%), E: R$ 3,83 (7,66%)\nFonte: IBPT\nValores totais do ICMS Interestadual: DIFAL da UF destino SP: R$1.91 + FCP R$0.00; DIFAL da UF Origem MS: R$0.00\r\nPED.: 1-25\r\n",
      "informacoesAdicionaisFisco": "Documentos associados a esta nota fiscal: 1-25."
   }
]
```

### URL de controle de registro integrado

> POST https://integrador.varejonline.com.br/apps/api/notas-mercadoria/registro/integracao/{integrador}

Onde {integrador} deve ser substituído pelo nome de integrador utilizado no controle de registros integrados

No corpo da mensagem, enviar um array com os ids a serem marcados como integrados pelo integrador: 

```javascript
{
    "objectIds": [
        1,
        2,
        ....
    ]
}
```