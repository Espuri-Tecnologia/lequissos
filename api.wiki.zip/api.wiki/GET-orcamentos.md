### URLs

> GET https://integrador.varejonline.com.br/apps/api/orcamentos

> GET https://integrador.varejonline.com.br/apps/api/orcamentos/:id

### Parâmetros

* **entidades:** [Veja como Funciona este Filtro](https://github.com/Varejonline/api/wiki/Filtro-de-Entidades)
* **inicio:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **quantidade:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **numeroPedidoCliente:** Número do pedido que originou o orçamento (Pedido de compra em software terceiro gerando orçamento de venda no ERP Varejonline)
* **desde:** [Veja o Filtro de Datas](https://github.com/Varejonline/api/wiki/Filtro-de-Datas)
* **ate:** [Veja o Filtro de Datas](https://github.com/Varejonline/api/wiki/Filtro-de-Datas)

### Retorno
  
* **id:** id do orçamento (long)
* **dataEmissao:** data de emissão do orçamento (string)
* **dataAlteracao:** última data de alteração do orçamento (string)
* **dataValidade:** data de validade do orçamento (string)  
* **status:** Status do Orçamento (string) APROVADO, AGUARDANDO_APROVACAO, NEGADO, VIROU_PEDIDO
* **idSaida:** Id da [saída](https://github.com/Varejonline/api/wiki/GET-saidas) gerada na efetivação da venda dos itens do orçamento.
* **idPedido:** Id do [pedido](https://github.com/Varejonline/api/wiki/GET-pedidos) gerado na efetivação da venda dos itens do orçamento.
* **plano:** [plano de pagamento](https://github.com/Varejonline/api/wiki/GET-planos-pagamento) utilizado no orçamento (string)
   * **id:** id do plano de pagamento
   * **descricao:** nome do plano de pagamento
* **entidade:** [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) à qual o orçamento pertence (objeto complexo)
    * **id:** id da entidade (long)
    * **nome:** nome da entidade (string)
    * **documento:** documento da entidade (string)
* **terceiro:** [cliente](https://github.com/Varejonline/api/wiki/GET-terceiros) associado ao orçamento (objeto complexo)
    * **id:**  id do cliente (long)
    * **nome:** nome do cliente (string)
    * **documento:** documento do cliente (string)
* **representante:** [vendedor](https://github.com/Varejonline/api/wiki/GET-representantes) associado ao orçamento (string)
   * **id:** id do vendedor
   * **nome:** nome do vendedor
   * **documento:** CPF do vendedor
* **itens:** lista de itens do orçamento, cada um contendo:
   * **id:** id do item no orçamento
   * **produto:**
     * **id:** id do produto
     * **codigoSistema:** código de sistema do produto.
     * **codigoInterno:** código interno do produto.
     * **codigoBarras:** código de barras do produto.
     * **descricao:** descrição do produto.
   * **quantidade:** quantidade orçada do produto (decimal)
   * **tabelaPrecoId:** [tabela de preço](https://github.com/Varejonline/api/wiki/GET-tabelas-preco) aplicada no orçamento do item (long)
   * **valorUnitario:** valor unitário do produto (decimal)
   * **valorDesconto:** valor do desconto concedido no produto (decimal)
   * **ordem:** ordem do item no orçamento (inteiro)
* **servicos:** lista de serviços do orçamento, cada um contendo:
   * **id:** id do item no orçamento
   * **servico:**
     * **id:** id do serviço (long)
     * **codigoSistema:** código de sistema do serviço (string)
     * **descricao:** descrição do serviço (string)
   * **quantidade:** quantidade orçada do serviço (decimal)
   * **valorUnitario:** valor unitário do serviço (decimal)
   * **valorDesconto:** valor do desconto concedido no produto (decimal)
   * **ordem:** ordem do item no orçamento (inteiro)
   * **tabelaPrecoId:** [tabela de preço](https://github.com/Varejonline/api/wiki/GET-tabelas-preco) aplicada no orçamento do item (long)
* **numeroOrcamento:** número do orçamento no sistema (string)
* **numeroPedidoCliente:** Número do pedido que originou o orçamento (string)
* **observacao:** observações incluídas no pedido (string)
* **valorFrete:** valor de frete do orçamento (decimal)
* **valorSeguro:** valor de seguro do orçamento (decimal)
* **valorOutros:** outros valores do orçamento (decimal)
* **vendaConsumidorFinal:** indicador de orçamento para cliente final (boolean)
* **reservarEstoque:** boolean indicando se o orçamento possui [reservas de estoque](https://github.com/Varejonline/api/wiki/GET-Reserva-Estoque)

* **origem:** origem da venda (ECOMMERCE, MARKETPLACE, LOJA_FISICA) (string)
* **tipo:** tipo da venda (NORMAL, SHIP_FROM_STORE, CLICK_COLLECT) (string)
* **intermediador:** intermediador da venda (informar id ou documento)
  * **id:** id do [intermediador](https://github.com/Varejonline/api/wiki/GET-terceiros) (long)
  * **documento:** documento do intermediador (string)
* **transporte:** dados de transporte
  * **modalidade:** modalidade do transporte (EMITENTE, DESTINATARIO_REMETENTE, TERCEIRO, PROPRIO_REMETENTE, PROPRIO_DESTINATARIO)
  * **transportador:**
    * **id:** id do [transportador](https://github.com/Varejonline/api/wiki/GET-terceiros) (long)
    * **documento:** documento do transportador (string)
  * **codigoANTT:** Código ANTT do transporte (string)
  * **placaVeiculo:** Placa do veiculo de transporte (string)
  * **estadoVeiculo:** Sigla do estado do veiculo de transporte (string)
  * **especie:** espécie do volume transportado
  * **marca:** marca do volume transportado (decimal)
  * **numero:** número do volume transportado (decimal)
  * **pesoBruto:** peso bruto transportado (decimal)
  * **pesoLiquido:** peso líquido transportado  (decimal)
* **enderecoEntrega:** dados do endereço de entrega
   * **logradouro:** nome do logradouro (string)
   * **numero:** número do endereço (string)
   * **bairro:** bairro do endereço (string)
   * **complemento:** complemento do endereço (string)
   * **cep:** CEP do endereço sem máscara (string)
   * **cidade:** Nome da cidade (string)
   * **uf:** Sigla do estado (string)
   * **receptorEntrega:** Nome da pessoa que receberá a entrega (string)
   * **receptorEntregaDocumento:** Documento da pessoa que receberá a entrega (string)
* **sistemaOrigem:**  sistema de origem do orçamento (ERP, ERP_API, PDV, PDV_CHECKOUT) (string)

### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/orcamentos

```javascript
[
{
    "dataAlteracao": "19-05-2014",
    "dataEmissao": "19-05-2014",
    "dataValidade": "03-06-2014",
    "id": 192,
    "status": "VIROU_PEDIDO",
    "idSaida": 79,
    "idPedido": 464,
    "sistemaOrigem":ERP_API,
    "plano": {
        "id": 1,
        "descricao": "A VISTA"
    },
    "entidade": {
        "id": 3,
        "nome": "Entidade teste",
        "documento": "00.000.000/0000-00"
    },
    "terceiro": {
        "id": 1,
        "nome": "DIVERSOS",
        "documento": "000.000.000-00"
    },
    "representante": {
        "id": 1,
        "nome": "ANA MARIA",
        "documento": "051.265.098-34"
    },
    "documentoTerceiro": "88.559.252/0001-04",
    "itens": [
        {
            "id": 1002,
            "produto": {
                "id": 245,
                "descricao": "BLUSA MALHA PRETA GG",
                "codigoSistema": "0001.0001",
                "codigoInterno": "",
                "codigoBarras": ""
            },
            "quantidade": 8,
            "tabelaPrecoId": 1,
            "valorUnitario": 10,
            "valorDesconto": 1,
            "ordem": 1
        }
    ],
    "servicos": [
        {
            "id": 1003,
            "servico": {
                "id": 15,
                "descricao": "Limpeza de artefatos",
                "codigoSistema": "S099.0003"
            },
            "quantidade": 1,
            "valorUnitario": 5,
            "valorDesconto": 0,
            "ordem": 2,
            "tabelaPrecoId": 1
        }
    ],
    "numeroOrcamento": "1-1212",
    "numeroPedidoCliente": "111-12",
    "observacao": "Entrar em contato pelo tel: XXXXXXX",
    "valorFrete": 2,
    "valorOutros": 4,
    "valorSeguro": 6,
    "vendaConsumidorFinal": true,
    "reservarEstoque": false,
    "origem": "MARKETPLACE",
    "tipo": "NORMAL",
    "enderecoEntrega": {
        "logradouro": "Rua iririu",
        "numero": "1777",
        "complemento": "Em cima do bradesco",
        "bairro": "Iririu",
        "cep": "89227-000",
        "cidade": "Joinville",
        "uf": "SC",
        "receptorEntrega": "Maria",
        "receptorEntregaDocumento": "000.000.000-00"
    },
    "intermediador": {
        "id": 1,
        "documento": "00.000.000/0001-00"
    },
    "transporte": {
        "modalidade": "EMITENTE",
        "transportador": {
            "id": 1,
            "documento": "00.000.000/0001-00"
        },
        "codigoANTT": "ABC1777",
        "placaVeiculo": "AFE8B87",
        "estadoVeiculo": "SC",
        "quantidade": "2",
        "especie": "CAIXA",
        "marca": "ASD",
        "numero": "23",
        "pesoBruto": 50,
        "pesoLiquido": 40
    }
}
]
```