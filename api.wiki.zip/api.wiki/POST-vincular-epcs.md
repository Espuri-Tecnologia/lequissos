### URL

> POST https://integrador.varejonline.com.br/apps/api/pedidos-compra/:id/vincular-epcs

### Parâmetros

* **id:** id do pedido de [compra](https://github.com/Varejonline/api/wiki/GET-pedidos-compra)


Envie um JSON no corpo da requisição, contendo:
* **codigo:** código do [produto](https://github.com/Varejonline/api/wiki/GET-Produtos) (obrigatório)
* **epcs:** códigos dos epcs (lista de string) (obrigatório)

### Retorno

Sucesso:
* HTTP STATUS 200 – OK

Requisição inválida: 
* HTTP STATUS 400 – BAD REQUEST
* Body: mensagem de erro

### Exemplo

> POST https://integrador.varejonline.com.br/apps/api/pedidos-compra/1024/vincular-epcs

'Content-Type'='application/json'
```javascript
{
    "codigo": "84058799",
    "epcs": [
        "CANECABRANCAIMP000000001",
        "CANECABRANCAIMP000000002",
        "CANECABRANCAIMP000000003"
    ]
}
```