Listagem das possíveis Naturezas de rendimento

<table>
<tr><th>ID</th><th>Nome</th></tr>
<tr><td>1</td><td>Rendimento decorrente do trabalho com vínculo empregatício</td></tr>
<tr><td>2</td><td>Rendimento decorrente do trabalho sem vínculo empregatício</td></tr>
<tr><td>3</td><td>Rendimento decorrente do trabalho pago a trabalhador avulso</td></tr>
<tr><td>4</td><td>Participação nos lucros ou resultados (PLR)</td></tr>
<tr><td>5</td><td>Benefício de Regime Próprio de Previdência Social</td></tr>
<tr><td>6</td><td>Benefício do Regime Geral de Previdência Social</td></tr>
<tr><td>7</td><td>Rendimentos relativos a prestação de serviços de Transporte Rodoviário Internacional de Carga, Auferidos por Transportador Autônomo Pessoa Física, Residente na República do Paraguai, considerado como Sociedade Unipessoal nesse País</td></tr>
<tr><td>8</td><td>Honorários advocatícios de sucumbência recebidos pelos advogados e procuradores públicos de que trata o art. 27 da Lei nº 13.327</td></tr>
<tr><td>9</td><td>Auxílio moradia</td></tr>
<tr><td>10</td><td>Bolsa ao médico residente</td></tr>
<tr><td>11</td><td>Decorrente de Decisão da Justiça do Trabalho</td></tr>
<tr><td>12</td><td>Decorrente de Decisão da Justiça Federal</td></tr>
<tr><td>13</td><td>Decorrente de Decisão da Justiça dos Estados/Distrito Federal</td></tr>
<tr><td>14</td><td>Responsabilidade Civil - juros e indenizações por lucros cessantes, inclusive astreinte</td></tr>
<tr><td>15</td><td>Decisão Judicial ¿ Importâncias pagas a título de indenizações por danos morais, decorrentes de sentença judicial.</td></tr>
<tr><td>16</td><td>Lucro e Dividendo</td></tr>
<tr><td>17</td><td>Resgate de Previdência Complementar - Modalidade Contribuição Definida/Variável - Não Optante pela Tributação Exclusiva</td></tr>
<tr><td>18</td><td>Resgate de Fundo de Aposentadoria Programada Individual (Fapi)- Não Optante pela Tributação Exclusiva</td></tr>
<tr><td>19</td><td>Resgate de Previdência Complementar - Modalidade Benefício Definido - Não Optante pela Tributação Exclusiva</td></tr>
<tr><td>20</td><td>Resgate de Previdência Complementar - Modalidade Contribuição Definida/Variável - Optante pela Tributação Exclusiva</td></tr>
<tr><td>21</td><td>Resgate de Fundo de Aposentadoria Programada Individual (Fapi)- Optante pela Tributação Exclusiva</td></tr>
<tr><td>22</td><td>Resgate de Planos de Seguro de Vida com Cláusula de Cobertura por Sobrevivência- Optante pela Tributação Exclusiva</td></tr>
<tr><td>23</td><td>Resgate de Planos de Seguro de Vida com Cláusula de Cobertura por Sobrevivência - Não Optante pela Tributação Exclusiva</td></tr>
<tr><td>24</td><td>Benefício de Previdência Complementar - Modalidade Contribuição Definida/Variável - Não Optante pela Tributação Exclusiva</td></tr>
<tr><td>25</td><td>Benefício de Fundo de Aposentadoria Programada Individual (Fapi)- Não Optante pela Tributação Exclusiva</td></tr>
<tr><td>26</td><td>Benefício de Previdência Complementar - Modalidade Benefício Definido - Não Optante pela Tributação Exclusiva</td></tr>
<tr><td>27</td><td>Benefício de Previdência Complementar - Modalidade Contribuição Definida/Variável - Optante pela Tributação Exclusiva</td></tr>
<tr><td>28</td><td>Benefício de Fundo de Aposentadoria Programada Individual (Fapi)- Optante pela Tributação Exclusiva</td></tr>
<tr><td>29</td><td>Benefício de Planos de Seguro de Vida com Cláusula de Cobertura por Sobrevivência- Optante pela Tributação Exclusiva</td></tr>
<tr><td>30</td><td>Benefício de Planos de Seguro de Vida com Cláusula de Cobertura por Sobrevivência - Não Optante pela Tributação Exclusiva</td></tr>
<tr><td>31</td><td>Juros sobre o Capital Próprio</td></tr>
<tr><td>32</td><td>Rendimento de Aplicações Financeiras de Renda Fixa, decorrentes de alienação, liquidação (total ou parcial), resgate, cessão ou repactuação do título ou aplicação</td></tr>
<tr><td>33</td><td>Rendimentos auferidos pela entrega de recursos à pessoa jurídica, sob qualquer forma e a qualquer título, independentemente de ser ou não a fonte pagadora instituição autorizada a funcionar pelo Banco Central</td></tr>
<tr><td>34</td><td>Rendimentos predeterminados obtidos em operações conjugadas realizadas: nos mercados de opções de compra e venda em bolsas de valores, de mercadorias e de futuros (box), no mercado a termo nas bolsas de valores, de mercadorias e de futuros, em operações de venda coberta e sem ajustes diários, e no mercado de balcão.</td></tr>
<tr><td>35</td><td>Rendimentos obtidos nas operações de transferência de dívidas realizadas com instituição financeira e outras instituições autorizadas a funcionar pelo Banco Central do Brasil</td></tr>
<tr><td>36</td><td>Rendimentos periódicos produzidos por título ou aplicação, bem como qualquer remuneração adicional aos rendimentos prefixados</td></tr>
<tr><td>37</td><td>Rendimentos auferidos nas operações de mútuo de recursos financeiros entre pessoa física e pessoa jurídica e entre pessoas jurídicas, inclusive controladoras, controladas, coligadas e interligadas</td></tr>
<tr><td>38</td><td>Rendimentos auferidos em operações de adiantamento sobre contratos de câmbio de exportação, não sacado (trava de câmbio), bem como operações com export notes, com debêntures, com depósitos voluntários para garantia de instância e com depósitos judiciais ou administrativos, quando seu levantamento se der em favor do depositante</td></tr>
<tr><td>39</td><td>Rendimentos obtidos nas operações de mútuo e de compra vinculada à revenda tendo por objeto ouro, ativo financeiro</td></tr>
<tr><td>40</td><td>Rendimentos auferidos em contas de depósitos de poupança</td></tr>
<tr><td>41</td><td>Rendimentos auferidos sobre juros produzidos por letras hipotecárias</td></tr>
<tr><td>42</td><td>Rendimentos ou ganhos decorrentes da negociação de títulos ou valores mobiliários de renda fixa em bolsas de valores, de mercadorias, de futuros e assemelhadas</td></tr>
<tr><td>43</td><td>Rendimentos auferidos em outras aplicações financeiras de renda fixa ou de renda variável</td></tr>
<tr><td>44</td><td>Rendimentos auferidos em Fundo de Investimento</td></tr>
<tr><td>45</td><td>Rendimentos auferidos em Fundos de investimento em quotas de fundos de investimento</td></tr>
<tr><td>46</td><td>Rendimentos produzidos por aplicações em fundos de investimento em ações</td></tr>
<tr><td>47</td><td>Rendimentos produzidos por aplicações em fundos de investimento em quotas de fundos de investimento em ações</td></tr>
<tr><td>48</td><td>Rendimentos produzidos por aplicações em Fundos Mútuos de Privatização com recursos do Fundo de Garantia por Tempo de Serviço (FGTS)</td></tr>
<tr><td>49</td><td>Rendimentos auferidos pela carteira dos Fundos de Investimento Imobiliário</td></tr>
<tr><td>50</td><td>Rendimentos distribuídos pelo Fundo de Investimento Imobiliário aos seus cotistas</td></tr>
<tr><td>51</td><td>Rendimento auferido pelo cotista no resgate de cotas na liquidação do Fundo de Investimento Imobiliário</td></tr>
<tr><td>52</td><td>Rendimentos auferidos pela carteira dos Fundos de Investimento Imobiliário ¿ Distribuição semestral</td></tr>
<tr><td>53</td><td>Rendimentos distribuídos pelo Fundo de Investimento Imobiliário aos seus cotistas - ¿ Distribuição semestral</td></tr>
<tr><td>54</td><td>Rendimento auferido pelo cotista no resgate de cotas na liquidação do Fundo de Investimento Imobiliário ¿ Distribuição semestral</td></tr>
<tr><td>55</td><td>Rendimentos e ganhos de capital distribuídos pelo Fundo de Investimento Cultural e Artístico (Ficart)</td></tr>
<tr><td>56</td><td>Rendimentos e ganhos de capital distribuídos pelo Fundo de Financiamento da Indústria Cinematográfica Nacional (Funcines)</td></tr>
<tr><td>57</td><td>Rendimentos auferidos no resgate de quotas de fundos de investimento mantidos com recursos provenientes de conversão de débitos externos brasileiros, e de que participem, exclusivamente, residentes ou domiciliados no exterior</td></tr>
<tr><td>58</td><td>Ganho de capital decorrente da integralização de cotas de fundos ou clubes de investimento por meio da entrega de ativos financeiros</td></tr>
<tr><td>59</td><td>Distribuição de Juros sobre o Capital Próprio pela companhia emissora de ações objeto de empréstimo</td></tr>
<tr><td>60</td><td>Rendimentos de Partes Beneficiárias ou de Fundador</td></tr>
<tr><td>61</td><td>Rendimentos auferidos em operações de swap</td></tr>
<tr><td>62</td><td>Rendimentos auferidos em operações day trade realizadas em bolsa de valores, de mercadorias, de futuros e assemelhadas</td></tr>
<tr><td>63</td><td>Rendimento decorrente de Operação realizada em bolsas de valores, de mercadorias, de futuros, e assemelhadas, exceto day trade</td></tr>
<tr><td>64</td><td>Rendimento decorrente de Operação realizada no mercado de balcão, com intermediação, tendo por objeto ações, ouro ativo financeiro e outros valores mobiliários negociados no mercado à vista</td></tr>
<tr><td>65</td><td>Rendimento decorrente de Operação realizada em mercados de liquidação futura fora de bolsa</td></tr>
<tr><td>66</td><td>Rendimentos de debêntures emitidas por sociedade de propósito específico conforme previsto no art. 2º da Lei nº 12.431 de 2011</td></tr>
<tr><td>67</td><td>Juros sobre o Capital Próprio cujos beneficiários não estejam identificados no momento do registro contábil</td></tr>
<tr><td>68</td><td>Demais rendimentos de Capital</td></tr>
<tr><td>69</td><td>Rendimentos de Aforamento</td></tr>
<tr><td>70</td><td>Rendimentos de Locação ou Sublocação</td></tr>
<tr><td>71</td><td>Rendimentos de Arrendamento ou Subarrendamento</td></tr>
<tr><td>72</td><td>Importâncias pagas por terceiros por conta do locador do bem (juros, comissões etc.)</td></tr>
<tr><td>73</td><td>Importâncias pagas ao locador pelo contrato celebrado (luvas, prêmios etc.)</td></tr>
<tr><td>74</td><td>Benfeitorias e quaisquer melhoramentos realizados no bem locado</td></tr>
<tr><td>75</td><td>Juros decorrente da alienação a prazo de bens</td></tr>
<tr><td>76</td><td>Rendimentos de Direito de Uso ou Passagem de Terrenos e de aproveitamento de águas</td></tr>
<tr><td>77</td><td>Rendimentos de Direito de colher ou extrair recursos vegetais, pesquisar e extrair recursos minerais</td></tr>
<tr><td>78</td><td>Rendimentos de Direito Autoral</td></tr>
<tr><td>79</td><td>Rendimentos de Direito Autoral (quando não percebidos pelo autor ou criador da obra)</td></tr>
<tr><td>80</td><td>Rendimentos de Direito de Imagem</td></tr>
<tr><td>81</td><td>Rendimentos de Direito sobre películas cinematográficas, Obras Audiovisuais, e Videofônicas</td></tr>
<tr><td>82</td><td>Rendimento de Direito relativo a radiodifusão de sons e imagens e serviço de comunicação eletrônica de massa por assinatura</td></tr>
<tr><td>83</td><td>Rendimentos de Direito de Conjuntos Industriais e Invenções</td></tr>
<tr><td>84</td><td>Rendimento de Direito de marcas de indústria e comércio, patentes de invenção e processo ou fórmulas de fabricação</td></tr>
<tr><td>85</td><td>Importâncias pagas por terceiros por conta do cedente dos direitos (juros, comissões etc.)</td></tr>
<tr><td>86</td><td>Importâncias pagas ao cedente do direito, pelo contrato celebrado (luvas, prêmios etc.)</td></tr>
<tr><td>87</td><td>Despesas para conservação dos direitos cedidos (quando compensadas pelo uso do bem ou direito)</td></tr>
<tr><td>88</td><td>Juros de mora e quaisquer outras compensações pelo atraso no pagamento de royalties ¿ decorrente de prestação de serviço</td></tr>
<tr><td>89</td><td>Juros de mora e quaisquer outras compensações pelo atraso no pagamento de royalties ¿ decorrente de aquisição de bens</td></tr>
<tr><td>90</td><td>Juros decorrente da alienação a prazo de direitos ¿ decorrente de prestação de serviço</td></tr>
<tr><td>91</td><td>Juros decorrente da alienação a prazo de direitos ¿ decorrente de aquisição de bens</td></tr>
<tr><td>92</td><td>Alienação de bens e direitos do ativo não circulante localizados no Brasil</td></tr>
<tr><td>93</td><td>Rendimento de Direito decorrente da transferência de atleta profissional</td></tr>
<tr><td>94</td><td>Juros e comissões correspondentes à parcela dos créditos de que trata o inciso XI do art. 1º da Lei nº 9.481, de 1997, não aplicada no financiamento de exportações</td></tr>
<tr><td>95</td><td>Demais rendimentos de Royalties</td></tr>
<tr><td>96</td><td>Demais rendimentos de Direito</td></tr>
<tr><td>97</td><td>Prêmios distribuídos, sob a forma de bens e serviços,</td></tr>
<tr><td>98</td><td>Prêmios distribuídos, sob a forma de dinheiro, mediante loterias, concursos e sorteios, exceto os de antecipação nos títulos de capitalização e os de mortização e resgate das ações das sociedades anônimas</td></tr>
<tr><td>99</td><td>Prêmios de Proprietários e Criadores de Cavalos de Corrida</td></tr>
<tr><td>100</td><td>Benefícios líquidos mediante sorteio de títulos de capitalização, sem amortização antecipada</td></tr>
<tr><td>101</td><td>Benefícios líquidos resultantes da amortização antecipada, mediante sorteio, dos títulos de capitalização e benefícios atribuídos aos portadores de títulos de capitalização nos lucros da empresa emitente</td></tr>
<tr><td>102</td><td>Prêmios distribuídos, sob a forma de bens e serviços, mediante sorteios de jogos de bingo permanente ou eventual</td></tr>
<tr><td>103</td><td>Prêmios distribuídos, em dinheiro, obtido mediante sorteios de jogos de bingo permanente ou eventual</td></tr>
<tr><td>104</td><td>Importâncias correspondentes a multas e qualquer outra vantagem, ainda que a título de indenização, em virtude de rescisão de contrato</td></tr>
<tr><td>105</td><td>Demais Benefícios Líquidos decorrentes de título de capitalização</td></tr>
<tr><td>106</td><td>Importâncias pagas ou creditadas a cooperativas de trabalho relativas a serviços pessoais que lhes forem prestados por associados destas ou colocados à disposição</td></tr>
<tr><td>107</td><td>Importâncias pagas ou creditadas a associações de profissionais ou assemelhadas, relativas a serviços pessoais que lhes forem prestados por associados destas ou colocados à disposição</td></tr>
<tr><td>108</td><td>Remuneração de Serviços de administração de bens ou negócios em geral, exceto consórcios ou fundos mútuos para aquisição de bens</td></tr>
<tr><td>109</td><td>Remuneração de Serviços de advocacia</td></tr>
<tr><td>110</td><td>Remuneração de Serviços de análise clínica laboratorial</td></tr>
<tr><td>111</td><td>Remuneração de Serviços de análises técnicas</td></tr>
<tr><td>112</td><td>Remuneração de Serviços de arquitetura</td></tr>
<tr><td>113</td><td>Remuneração de Serviços de assessoria e consultoria técnica, exceto serviço de assistência técnica prestado a terceiros e concernente a ramo de indústria ou comércio explorado pelo prestador do serviço</td></tr>
<tr><td>114</td><td>Remuneração de Serviços de assistência social</td></tr>
<tr><td>115</td><td>Remuneração de Serviços de auditoria</td></tr>
<tr><td>116</td><td>Remuneração de Serviços de avaliação e perícia</td></tr>
<tr><td>117</td><td>Remuneração de Serviços de biologia e biomedicina</td></tr>
<tr><td>118</td><td>Remuneração de Serviços de cálculo em geral</td></tr>
<tr><td>119</td><td>Remuneração de Serviços de consultoria</td></tr>
<tr><td>120</td><td>Remuneração de Serviços de contabilidade</td></tr>
<tr><td>121</td><td>Remuneração de Serviços de desenho técnico</td></tr>
<tr><td>122</td><td>Remuneração de Serviços de economia</td></tr>
<tr><td>123</td><td>Remuneração de Serviços de elaboração de projetos</td></tr>
<tr><td>124</td><td>Remuneração de Serviços de engenharia, exceto construção de estradas, pontes, prédios e obras assemelhadas</td></tr>
<tr><td>125</td><td>Remuneração de Serviços de ensino e treinamento</td></tr>
<tr><td>126</td><td>Remuneração de Serviços de estatística</td></tr>
<tr><td>127</td><td>Remuneração de Serviços de fisioterapia</td></tr>
<tr><td>128</td><td>Remuneração de Serviços de fonoaudiologia</td></tr>
<tr><td>129</td><td>Remuneração de Serviços de geologia</td></tr>
<tr><td>130</td><td>Remuneração de Serviços de leilão</td></tr>
<tr><td>131</td><td>Remuneração de Serviços de medicina, exceto aquela prestada por ambulatório, banco de sangue, casa de saúde, casa de recuperação ou repouso sob orientação médica, hospital e pronto-socorro</td></tr>
<tr><td>132</td><td>Remuneração de Serviços de nutricionismo e dietética</td></tr>
<tr><td>133</td><td>Remuneração de Serviços de odontologia</td></tr>
<tr><td>134</td><td>Remuneração de Serviços de organização de feiras de amostras, congressos, seminários, simpósios e congêneres</td></tr>
<tr><td>135</td><td>Remuneração de Serviços de pesquisa em geral</td></tr>
<tr><td>136</td><td>Remuneração de Serviços de planejamento</td></tr>
<tr><td>137</td><td>Remuneração de Serviços de programação</td></tr>
<tr><td>138</td><td>Remuneração de Serviços de prótese</td></tr>
<tr><td>139</td><td>Remuneração de Serviços de psicologia e psicanálise</td></tr>
<tr><td>140</td><td>Remuneração de Serviços de química</td></tr>
<tr><td>141</td><td>Remuneração de Serviços de radiologia e radioterapia</td></tr>
<tr><td>142</td><td>Remuneração de Serviços de relações públicas</td></tr>
<tr><td>143</td><td>Remuneração de Serviços de serviço de despachante</td></tr>
<tr><td>144</td><td>Remuneração de Serviços de terapêutica ocupacional</td></tr>
<tr><td>145</td><td>Remuneração de Serviços de tradução ou interpretação comercial</td></tr>
<tr><td>146</td><td>Remuneração de Serviços de urbanismo</td></tr>
<tr><td>147</td><td>Remuneração de Serviços de veterinária</td></tr>
<tr><td>148</td><td>Remuneração de Serviços de Limpeza</td></tr>
<tr><td>149</td><td>Remuneração de Serviços de Conservação/ Manutenção, exceto reformas e obras assemelhadas</td></tr>
<tr><td>150</td><td>Remuneração de Serviços de Segurança/Vigilância/Transporte de valores</td></tr>
<tr><td>151</td><td>Remuneração de Serviços Locação de Mão de obra</td></tr>
<tr><td>152</td><td>Remuneração de Serviços de Assessoria Creditícia,</td></tr>
<tr><td>153</td><td>Pagamentos Referentes à Aquisição de Autopeças</td></tr>
<tr><td>154</td><td>Pagamentos a entidades imunes ou isentas ¿ IN RFB 1.234/2012</td></tr>
<tr><td>155</td><td>Pagamento a título de transporte internacional de valores efetuado por empresas nacionais estaleiros navais brasileiros nas atividades de conservação, modernização, conversão e reparo de embarcações pré-registradas ou registradas no Registro Especial Brasileiro (REB)</td></tr>
<tr><td>156</td><td>Pagamento efetuado a empresas estrangeiras de transporte de valores</td></tr>
<tr><td>157</td><td>Demais comissões, corretagens, ou qualquer outra importância paga/creditada pela representação comercial ou pela mediação na realização de negócios civis e comerciais, que não se enquadrem nas situações listadas nos códigos do grupo 20</td></tr>
<tr><td>158</td><td>Demais rendimentos de serviços técnicos, de assistência técnica, de assistência administrativa e semelhantes</td></tr>
<tr><td>159</td><td>Rendimentos de serviços técnicos, de assistência técnica, de assistência administrativa e semelhantes</td></tr>
<tr><td>160</td><td>Demais rendimentos de juros e comissões</td></tr>
<tr><td>161</td><td>Rendimento pago a companhia de navegação aérea e marítima</td></tr>
<tr><td>162</td><td>Rendimento de Direito relativo a exploração de obras audiovisuais estrangeiras, radiodifusão de sons e imagens e serviço de comunicação eletrônica de massa por assinatura</td></tr>
<tr><td>163</td><td>Demais Rendimentos de qualquer natureza</td></tr>
<tr><td>164</td><td>Demais Rendimentos sujeitos à Alíquota Zero</td></tr>
<tr><td>165</td><td>Alimentação</td></tr>
<tr><td>166</td><td>Energia elétrica</td></tr>
<tr><td>167</td><td>Serviços prestados com emprego de materiais</td></tr>
<tr><td>168</td><td>Construção Civil por empreitada com emprego de materiais</td></tr>
<tr><td>169</td><td>Serviços hospitalares de que trata o art. 30 da Instrução Normativa RFB nº 1.234, de 11 de janeiro de 2012</td></tr>
<tr><td>170</td><td>Transporte de cargas, exceto os relacionados na natureza de rendimento "17017"</td></tr>
<tr><td>171</td><td>Serviços de auxílio diagnóstico e terapia, patologia clínica, imagenologia, anatomia patológica e citopatológica, medicina nuclear e análises e patologias clínicas, exames por métodos gráficos, procedimentos endoscópicos, radioterapia, quimioterapia, diálise e oxigenoterapia hiperbárica de que trata o art. 31 e parágrafo único da Instrução Normativa RFB nº 1.234, de 2012</td></tr>
<tr><td>172</td><td>Produtos farmacêuticos, de perfumaria, de toucador ou de higiene pessoal adquiridos de produtor, importador, distribuidor ou varejista, exceto os relacionados nas</td></tr>
<tr><td>173</td><td>Mercadorias e bens em geral</td></tr>
<tr><td>174</td><td>Gasolina, inclusive de aviação, óleo diesel, gás liquefeito de petróleo (GLP), combustíveis derivados de petróleo ou de gás natural, querosene de aviação (QAV), e demais produtos derivados de petróleo, adquiridos de refinarias de petróleo, de demais produtores, de importadores, de distribuidor ou varejista</td></tr>
<tr><td>175</td><td>Álcool etílico hidratado, inclusive para fins carburantes, adquirido diretamente de produtor, importador ou do distribuidor</td></tr>
<tr><td>176</td><td>Biodiesel adquirido de produtor ou importador 17013 Gasolina, exceto gasolina de aviação, óleo diesel e gás liquefeito de petróleo (GLP), derivados de petróleo ou de gás natural e querosene de aviação adquiridos de distribuidores e comerciantes varejistas</td></tr>
<tr><td>177</td><td>Álcool etílico hidratado nacional, inclusive para fins carburantes adquirido de comerciante varejista</td></tr>
<tr><td>178</td><td>Biodiesel adquirido de distribuidores e comerciantes varejistas</td></tr>
<tr><td>179</td><td>Biodiesel adquirido de produtor detentor regular do selo ¿Combustível Social¿, fabricado a partir de mamona ou fruto, caroço ou amêndoa de palma produzidos nas regiões norte e nordeste e no semiárido, por agricultor familiar enquadrado no Programa Nacional de Fortalecimento da Agricultura Familiar (Pronaf)</td></tr>
<tr><td>180</td><td>Transporte internacional de cargas efetuado por empresas nacionais</td></tr>
<tr><td>181</td><td>Estaleiros navais brasileiros nas atividades de Construção, conservação, modernização, conversão e reparo de embarcações pré-registradas ou registradas no REB</td></tr>
<tr><td>182</td><td>Produtos de perfumaria, de toucador e de higiene pessoal a que se refere o § 1º do art. 22 da Instrução Normativa RFB nº 1.234, de 2012, adquiridos de distribuidores e de comerciantes varejistas</td></tr>
<tr><td>183</td><td>Produtos a que se refere o § 2º do art. 22 da Instrução Normativa RFB nº 1.234, de 2012</td></tr>
<tr><td>184</td><td>Produtos de que tratam as alíneas ¿c¿ a ¿k¿ do inciso I do art. 5º da Instrução Normativa RFB nº 1.234, de 2012</td></tr>
<tr><td>185</td><td>Outros produtos ou serviços beneficiados com isenção, não incidência ou alíquotas zero da Cofins e da Contribuição para o PIS/Pasep, observado o disposto no § 5º do art. 2º da Instrução Normativa RFB nº 1.234, de 2012</td></tr>
<tr><td>186</td><td>Passagens aéreas, rodoviárias e demais serviços de transporte de passageiros, inclusive, tarifa de embarque, exceto transporte internacional de passageiros, efetuado por empresas nacionais</td></tr>
<tr><td>187</td><td>Transporte internacional de passageiros efetuado por empresas nacionais</td></tr>
<tr><td>188</td><td>Serviços prestados por associações profissionais ou assemelhadas e cooperativas</td></tr>
<tr><td>189</td><td>Serviços prestados por bancos comerciais, bancos de investimento, bancos de desenvolvimento, caixas econômicas, sociedades de crédito, financiamento e investimento, sociedades de crédito imobiliário, e câmbio, distribuidoras de títulos e valores mobiliários,</td></tr>
<tr><td>190</td><td>Seguro Saúde</td></tr>
<tr><td>191</td><td>Serviços de abastecimento de água</td></tr>
<tr><td>192</td><td>Telefone</td></tr>
<tr><td>193</td><td>Correio e telégrafos</td></tr>
<tr><td>194</td><td>Vigilância</td></tr>
<tr><td>195</td><td>Limpeza</td></tr>
<tr><td>196</td><td>Locação de mão de obra</td></tr>
<tr><td>197</td><td>Intermediação de negócios</td></tr>
<tr><td>198</td><td>Administração, locação ou cessão de bens imóveis, móveis e direitos de qualquer natureza</td></tr>
<tr><td>199</td><td>Factoring</td></tr>
<tr><td>200</td><td>Plano de saúde humano, veterinário ou odontológico com valores fixos por servidor, por empregado ou por animal</td></tr>
<tr><td>201</td><td>Pagamento efetuado a sociedade cooperativa pelo fornecimento de bens, conforme art. 24, da IN 1234/12.</td></tr>
<tr><td>202</td><td>Pagamento a Cooperativa de produção, em relação aos atos decorrentes da comercialização ou da industrialização de produtos de seus associados, excetuado o previsto no §§ 1º e 2º do art. 25 da IN 1.234/12</td></tr>
<tr><td>203</td><td>Serviços prestados por associações profissionais ou assemelhadas e cooperativas que envolver parcela de serviços fornecidos por terceiros não cooperados ou não associados, contratados ou conveniados, para cumprimento de contratos ¿ Serviços prestados com emprego de materiais, inclusive o de que trata a alínea ¿C¿ do Inciso II do art. 27 da IN 1.1234.</td></tr>
<tr><td>204</td><td>Serviços prestados por associações profissionais ou assemelhadas e cooperativas que envolver parcela de serviços fornecidos por terceiros não cooperados ou não associados, contratados ou conveniados, para cumprimento de contratos - Demais serviços</td></tr>
<tr><td>205</td><td>Pagamentos efetuados às associações e às cooperativas de médicos e de odontólogos, relativamente às importâncias recebidas a título de comissão, taxa de administração ou de adesão ao plano</td></tr>
<tr><td>206</td><td>Pagamento efetuado a sociedade cooperativa de produção, em relação aos atos decorrentes da comercialização ou de industrialização, pelas cooperativas agropecuárias e de pesca, de produtos adquiridos de não associados, agricultores, pecuaristas ou pescadores, para completar lotes destinados aoa cumprimento de contratos ou para suprir capacidade ociosa de suas instalações industriais, conforme § 1º do art. 25, da IN 1234/12.</td></tr>
<tr><td>207</td><td>Pagamento referente a aluguel de imóvel quando efetuado à entidade aberta de previdência complementar sem fins lucrativos, de que trata o art 34, § 2º da IN 1.234/2012.</td></tr>
<tr><td>208</td><td>Serviços prestados por cooperativas de radiotaxi, bem como àquelas cujos cooperados se dediquem a serviços relacionados a atividades culturais e demais</td></tr>
<tr><td>209</td><td>Pagamento efetuado na aquisição de bem imóvel, quando o vendedor for pessoa jurídica que exerce a atividade de compra e venda de imóveis, ou quando se tratar de imóveis adquiridos de entidades abertas de previdência complementar com fins lucrativos, conforme art. 23, inc I, da IN RFB 1234/2012.</td></tr>
<tr><td>210</td><td>Pagamento efetuado na aquisição de bem imóvel adquirido pertencente ao ativo não circulante da empresa vendedora, conforme art. 23, inc II da IN RFB 1234/2012.</td></tr>
<tr><td>211</td><td>Pagamento efetuado na aquisição de bem imóvel adquirido de entidade aberta de previdência complementar sem fins lucrativos, conforme art. 23, inc III, da IN RFB 1234/2012.</td></tr>
<tr><td>212</td><td>Propaganda e Publicidade, em desconformidade ao art 16 da IN RFB 1234/2012, referente ao § 4º do citado artigo.</td></tr>
<tr><td>213</td><td>Propaganda e Publicidade, em conformidade ao art 16 da IN RFB 1234/2012, referente ao § 4º do citado artigo.</td></tr>
<tr><td>214</td><td>Demais serviços</td></tr>
<tr><td>215</td><td>Fornecimento de bens, nos termos do art. 33 da Lei nº 10.833, de 2003</td></tr>
<tr><td>216</td><td>Prestação de serviços em geral, nos termos do art. 33 da Lei nº 10.833, de 2003</td></tr>
<tr><td>217</td><td>Transporte internacional de cargas ou de passageiros efetuados por empresas nacionais, aos estaleiros navais brasileiros e na aquisição de produtos isentos ou com Alíquota zero da Cofins e Pis/Pasep, conforme art. 4º, da IN SRF nº 475 de 2004.</td></tr>
<tr><td>218</td><td>Pagamentos efetuados às cooperativas, em relação aos atos cooperativos, conforme art. 5º, da IN SRF nº 475 de 2004.</td></tr>
<tr><td>219</td><td>Aquisição de imóvel pertencente a ativo permanente da empresa vendedora, conforme art. 19, II, da IN SRF nº 475 de 2004.</td></tr>
<tr><td>220</td><td>Pagamentos efetuados às sociedades cooperativas, pelo fornecimento de bens ou serviços, conforme art. 24, II, da IN SRF nº 475 de 2004.</td></tr>
<tr><td>221</td><td>Pagamentos efetuados à sociedade cooperativa de produção, em relação aos atos decorrentes da comercialização ou industrialização de produtos de seus associados, conforme art. 25, da IN SRF nº 475 de 2004.</td></tr>
<tr><td>222</td><td>Pagamentos efetuados às cooperativas de trabalho, pela prestação de serviços pessoais prestados pelos cooperados, nos termos do art. 26, da IN SRF nº 475 de 2004.</td></tr>
<tr><td>223</td><td>Pagamento de remuneração indireta a Beneficiário não identificado</td></tr>
<tr><td>224</td><td>Pagamento a Beneficiário não identificado</td></tr>
<tr><td>225</td><td>Rendimento de Serviços de propaganda e publicidade</td></tr>
<tr><td>226</td><td>Importâncias a título de comissões e corretagens relativas a colocação ou negociação de títulos de renda fixa</td></tr>
<tr><td>227</td><td>Importâncias a título de comissões e corretagens relativas a operações realizadas em Bolsas de Valores e em Bolsas de Mercadorias</td></tr>
<tr><td>228</td><td>Importâncias a título de comissões e corretagens relativas a distribuição de emissão de valores mobiliários, quando a pessoa jurídica atuar como agente da companhia emissora</td></tr>
<tr><td>229</td><td>Importâncias a título de comissões e corretagens relativas a operações de câmbio</td></tr>
<tr><td>230</td><td>Importâncias a título de comissões e corretagens relativas a vendas de passagens, excursões ou viagens</td></tr>
<tr><td>231</td><td>Importâncias a título de comissões e corretagens relativas a administração de cartões de crédito</td></tr>
<tr><td>232</td><td>Importâncias a título de comissões e corretagens relativas a prestação de serviços de distribuição de refeições pelo sistema de refeições-convênio</td></tr>
<tr><td>233</td><td>Importâncias a título de comissões e corretagens relativas a prestação de serviço de administração de convênios</td></tr>
</table>
