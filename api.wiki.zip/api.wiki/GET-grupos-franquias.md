### URLs

> GET https://integrador.varejonline.com.br/apps/api/gestao-franquias/grupos-franquias

    Obtém todos os grupos de franquias com retorno paginado

> GET https://integrador.varejonline.com.br/apps/api/gestao-franquias/grupos-franquias/:id

    Obtém as informações de um grupo de franquia por id


### Parâmetros

* **inicio:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **quantidade:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **alteradoApos:** [Entenda a Coleta de Alterações](https://github.com/Varejonline/api/wiki/Filtro-de-Data-Alteração)
* **franquias:** informe os ids das franquias que deseja filtrar (lista separada por virgula)

### Retorno

* **id:** id do grupo de franquias (long)
* **nome:** nome do grupo de franquias (string)
* **dataCriacao:** data de criação do grupo de franquias, no formato dd-mm-aaaa hh:mi:ss (string)
* **dataAlteracao:** data de alteração do grupo de franquias, no formato dd-mm-aaaa hh:mi:ss (string)
* **ativo:** indica se o grupo está ativo (boolean)
* **franquias:** lista de [franquias](https://github.com/Varejonline/api/wiki/GET-franquias)
   * **id:** id da franquia (long)
   * **documento:** documento da franquia (string)
   * **nome:** nome da franquia (string)

### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/gestao-franquias/grupos-franquias

```javascript
[
{
  "id": 1,
  "dataAlteracao": "05-07-2024 09:43:59",
  "dataCriacao": "08-04-2024 12:02:59",
  "nome": "FRANQUIAS FG",
  "franquias": [
    {
      "id": 1596069,
      "documento": "35.910.952/0001-27",
      "nome": "FRANQUIA FG-659"
    },
    {
      "id": 1596733,
      "documento": "17.622.696/0001-90",
      "nome": "FRANQUIA FG-674"
    }
  ],
  "ativo": true
}
]
```