### URLs

> GET https://integrador.varejonline.com.br/apps/api/categorias-servico

> GET https://integrador.varejonline.com.br/apps/api/categorias-servico/:id

### Parâmetros

* **inicio:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **quantidade:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **alteradoApos:** [Entenda a Coleta de Alterações](https://github.com/Varejonline/api/wiki/Filtro-de-Data-Alteração)

### Retorno

* **id:** id da categoria de serviço (long)
* **ativo:** indica se a categoria de serviço está ativa ou não (boolean)
* **nome:** nome da categoria de serviço (string)
* **categoriaPai:** id da categoria de serviços pai, caso houver alguma categoria em um nível hierárquico acima (long) 

### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/categorias-servico

```javascript
[
   {
      "id":1,
      "nome":"LAVAGEM",
      "ativo": false
   },
   {
      "id":2,
      "nome":"LAVAGEM DE AUTOMÓVEIS",
      "categoriaPai":1,
      "ativo": true
   },
   {
      "id":3,
      "nome":"LAVAGEM DE MÁQUINAS",
      "categoriaPai":1,
      "ativo": true
   },
   {
      "id":4,
      "nome":"DELIVERY",
      "ativo": true
   }
   {
      "id":5,
      "nome":"DELIVERY DE ALIMENTOS",
      "categoriaPai":4,
      "ativo": true
   }
   {
      "id":6,
      "nome":"ENTREGA DE PACOTES",
      "categoriaPai":4,
      "ativo": true
   }
]```