### URLs

> GET https://integrador.varejonline.com.br/apps/api/tabelas-preco/configuracoes

> GET https://integrador.varejonline.com.br/apps/api/tabelas-preco/configuracoes/:id

### Parâmetros

* **entidades:** [Veja como Funciona este Filtro](https://github.com/Varejonline/api/wiki/Filtro-de-Entidades)
* **inicio:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **quantidade:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **alteradoApos:** [Entenda a Coleta de Alterações](https://github.com/Varejonline/api/wiki/Filtro-de-Data-Alteração)

### Retorno

* **id:** id da configuração de preços (long). 
* **disponivel:** indica se a configuração de preços está disponível para uso no momento da consulta. As configurações de preços podem ter uma vigência configurável, podendo estar disponíveis apenas entre datas específicas ou durante um período específico do dia (boolean)
* **ativa:** indica se a configuração pode (true) ou não (false) ser aplicada (boolean).
* **tipoCalculo:** indica o modo de cálculo do preço final.
    * DESCONTO
    * ACRESCIMO
    * MARKUP
    * Para instruções sobre como o cálculo é realizado, leia esse [material](https://varejonline.movidesk.com/kb/article/21813/tabela-de-preco?ticketId=&q=tabela)
* **valor:** parâmetro de cálculo do preco final (decimal).
* **idsClassificacoesClientes:** [classificações](https://github.com/Varejonline/api/wiki/GET-classificacoes-clientes) de cliente para as quais os preços são aplicáveis (array). Quando vazio, significa que são aplicáveis para todas as classificações.
* **idsEntidades:** ids das [entidades](https://github.com/Varejonline/api/wiki/GET-entidades) para as quais a configuração de preços é válida (array). 
Quando vazio, significa que é válida para todas as entidades.
* **nome:** nome da configuração de preço (String)
* **permanente:** indica se a configuração é (true) ou não (false) permanente (boolean).
* **promocao:** indica se a configuração é (true) ou não (false) promocional (boolean).
* **excluido:** indica se a configuração foi (true) ou não (false) excluída no sistema (boolean).
* **inicioVigencia:** data inicial na qual a configuração pode ser aplicada, no formato dd-mm-aaaa hh:mi:ss (string).
* **fimVigencia:** data final na qual a configuração pode ser aplicada, no formato dd-mm-aaaa hh:mi:ss (string).
* **peso:** indica o peso para que a configuração seja aplicada, vide doc da API de [tabelas de preço](https://github.com/Varejonline/api/wiki/GET-tabelas-preco)

### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/tabelas-preco/configuracoes

```javascript
[
   {
        "id": 75,
        "valor": 20,
        "peso": 2,
        "nome": "DESCONTO SOBRE PADRÃO - TRAINING",
        "tipoCalculo": "DESCONTO",
        "disponivel": true,
        "idsEntidades": [
            2
        ],
        "fimVigencia": "30-09-2023 12:00:00",
        "promocao": false,
        "tabelaReferenciaId": 1,
        "compra": false,
        "ativa": true,
        "inicioVigencia": "11-09-2023 12:00:00",
        "idsClassificacoesClientes": [],
        "tabelaReferenciaNome": "PADRÃO",
        "excluido": false,
        "permanente": false
    },
    {
        "id": 76,
        "valor": 30,
        "peso": 2,
        "nome": "DESCONTO SOBRE PADRÃO - APPAREL",
        "tipoCalculo": "DESCONTO",
        "disponivel": true,
        "idsEntidades": [
            2
        ],
        "fimVigencia": "30-09-2023 12:00:00",
        "promocao": false,
        "tabelaReferenciaId": 1,
        "compra": false,
        "ativa": true,
        "inicioVigencia": "11-09-2023 12:00:00",
        "idsClassificacoesClientes": [],
        "tabelaReferenciaNome": "PADRÃO",
        "excluido": false,
        "permanente": false
    }
]
```