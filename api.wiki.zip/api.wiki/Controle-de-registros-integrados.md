# Controle de registros integrados e não integrados

## Objetivo

Por vezes as integrações entre o Varejonline e os sistemas externos necessitam controlar a nível de registro o que já foi e o que ainda não foi coletado via API e enviado ao sistema parceiro. 

Nesse sentido, foi criado o mecanismo de controle de registros integrados. 

Veja como utilizar abaixo.

## Método de uso

Alguns endpoints possuem o controle que é disponibilizado e deve ser utilizando em dois momentos:

### Consumo dos dados

Ao buscar os registros da API, devem ser informados dois parâmetros:

* **integrados:** Utilizado para definir se o cliente deseja apenas registros integrados ou não integrados, conforme opções abaixo:
  * **1** retorna apenas pedidos já marcados como coletados pelo integrador
  * **0** retorna apenas pedidos não marcados como coletados pelo integrador

* **integrador:** Nome utilizado pelo integrador para registrar o pedido como integrado

### Marcação de registro como integrado

Após ler os dados e integrar com o sistema desejado, os registros devem ser marcados como integrados no Varejonline. Para isso basta chamar o endpoint de registro informado em cada endpoint de coleta, enviando os ids a serem registrados e o nome do integrador utilizado.

Veja que dessa forma, você pode controlar o envio do mesmo registro para diferentes sistemas, usando nomes de integradores diferentes para cada controle. Ou seja, o controle de um registro é associado ao integrador registrado.

Em geral a URL de marcação de registro integrado é disponibilizada da seguinte forma:

> POST https://integrador.varejonline.com.br/apps/api/{endpoint}/registro/integracao/{integrador}

Onde {integrador} deve ser substituído pelo nome de integrador utilizado no controle de registros integrados

No corpo da mensagem, enviar um array de ids: 
```javascript
{
    "objectIds": [
        1,
        2,
        ....
    ]
}
```