### URLs

> GET https://integrador.varejonline.com.br/apps/api/status-pedido-venda

> GET https://integrador.varejonline.com.br/apps/api/status-pedido-venda/:id

### Retorno

+ id: identificador do status (long)
+ nome: nome do status (string)
+ descricao: descrição do status (string)
+ dataCriacao: data de criação do status, no formato dd-mm-aaaa (string)
+ dataAlteracao: última data de alteração do status, no formato dd-mm-aaaa (string)
+ ativo: indica se o status se encontra ativo (boolean)
+ deletado: indica se o status se encontra deletado (boolean)

### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/status-pedido-venda

```javascript
[
    {
        "id": 1,
        "nome": "Pendente",
        "descricao": "Pendente",
        "dataAlteracao": "06-11-2023",
        "dataCriacao": "06-11-2023",
        "ativo": true,
        "deletado": false
    },
    {
        "id": 2,
        "nome": "Recusado",
        "descricao": "Recusado",
        "dataAlteracao": "06-11-2023",
        "dataCriacao": "06-11-2023",
        "ativo": true,
        "deletado": false
    },
    {
        "id": 3,
        "nome": "Cancelado",
        "descricao": "Cancelado",
        "dataAlteracao": "06-11-2023",
        "dataCriacao": "06-11-2023",
        "ativo": true,
        "deletado": false
    },
    {
        "id": 4,
        "nome": "Em preparação",
        "descricao": "Em preparação",
        "dataAlteracao": "06-11-2023",
        "dataCriacao": "06-11-2023",
        "ativo": true,
        "deletado": false
    },
    {
        "id": 5,
        "nome": "Aguardando entrega",
        "descricao": "Aguardando entrega",
        "dataAlteracao": "06-11-2023",
        "dataCriacao": "06-11-2023",
        "ativo": true,
        "deletado": false
    },
    {
        "id": 6,
        "nome": "Finalizado",
        "descricao": "Finalizado",
        "dataAlteracao": "06-11-2023",
        "dataCriacao": "06-11-2023",
        "ativo": true,
        "deletado": false
    },
    {
        "id": 7,
        "nome": "Pedido criado",
        "descricao": "Pedido criado",
        "dataAlteracao": "06-11-2023",
        "dataCriacao": "06-11-2023",
        "ativo": true,
        "deletado": false
    },
    {
        "id": 8,
        "nome": "Coletado",
        "descricao": "Coletado",
        "dataAlteracao": "06-11-2023",
        "dataCriacao": "06-11-2023",
        "ativo": true,
        "deletado": false
    },
    {
        "id": 9,
        "nome": "Documento emitido",
        "descricao": "Documento emitido",
        "dataAlteracao": "06-11-2023",
        "dataCriacao": "06-11-2023",
        "ativo": true,
        "deletado": false
    },
    {
        "id": 10,
        "nome": "Separado",
        "descricao": "Separado",
        "dataAlteracao": "06-11-2023",
        "dataCriacao": "06-11-2023",
        "ativo": true,
        "deletado": false
    },
    {
        "id": 11,
        "nome": "Retirado pelo cliente",
        "descricao": "Retirado pelo cliente",
        "dataAlteracao": "06-11-2023",
        "dataCriacao": "06-11-2023",
        "ativo": true,
        "deletado": false
    },
    {
        "id": 12,
        "nome": "Em entrega",
        "descricao": "Em entrega",
        "dataAlteracao": "06-11-2023",
        "dataCriacao": "06-11-2023",
        "ativo": true,
        "deletado": false
    },
    {
        "id": 13,
        "nome": "Entregue",
        "descricao": "Entregue",
        "dataAlteracao": "06-11-2023",
        "dataCriacao": "06-11-2023",
        "ativo": true,
        "deletado": false
    }
]
```