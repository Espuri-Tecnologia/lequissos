<table>
<tr><th>Tipos de configuração do prêmio</th></tr>
<tr><td>PRODUTO</td></tr>
<tr><td>MENOR_VALOR_VENDA</td></tr>
<tr><td>MAIOR_VALOR_VENDA</td></tr>
<tr><td>ULTIMO_INSERIDO_VENDA</td></tr>
</table>

