Endpoint para obter um lote gerado pelo [POST de Lote de pedidos de compra](https://github.com/Varejonline/api/wiki/POST-Lotes-de-Pedidos-Compra)

### URLs

> GET https://integrador.varejonline.com.br/apps/api/pedidos-compra/lotes


### Parâmetros

* **inicio:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **quantidade:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **alteradoApos:** [Entenda a Coleta de Alterações](https://github.com/Varejonline/api/wiki/Filtro-de-Data-Alteração)
* **ids:** lista de ids dos lotes, separados por vírgula
* **codigos:** lista de códigos dos lotes, separados por vírgula
* **exibirJsonEnviado:** carrega o json enviado durante a criação do lote. _(boolean, padrão: false)_

> Busca pelo código gerencial enviado no [POST de Lote de pedidos](https://github.com/Varejonline/api/wiki/POST-Lote-de-Pedidos-Compra)

> GET https://integrador.varejonline.com.br/apps/api/pedidos-compra/lotes

### Retorno
    
* **id:** id do pedido (long)
* **codigo:** código gerencial do lote (string)
* **pedidos:** lista de pedidos processados
  * **id:** id do processamento do pedido
  * **idPedidoGerado:** id do [pedido gerado](https://github.com/Varejonline/api/wiki/GET-pedidos-compra)(long)
  * **status:** status do processamento (PENDENTE, PEDIDO_GERADO, ERRO) (string)
  * **erro:** em caso de erro de processamento, aqui haverá informações sobre o erro (string)
  * **dataAlteracao:** última data de alteração do processamento, no formato dd-mm-aaaa hh:mi:ss (string)
  * **jsonRecebido:** json enviado no lote (objeto complexo) 
      > Atenção: a existência deste json não indica que o pedido foi gerado, ele é apenas o JSON enviado no POST do Lote para simples conferência.
  * **fimProcessamento:** data do inicio do processamento do pedido, no formato dd-mm-aaaa hh:mi:ss (string)
  * **inicioProcessamento:** data do fim do processamento do pedido, no formato dd-mm-aaaa hh:mi:ss (string)
 
### Exemplo de lote processado com sucesso

> GET https://integrador.varejonline.com.br/apps/api/pedidos-compra/lotes?ids=1

```javascript
[
    {
        "id": 1,
        "dataCriacao": "10/10/2023",
        "pedidos": [
            {
                "id": 1,
                "status": "PEDIDO_GERADO",
                "idPedidoGerado": 121,
                "dataAlteracao": "10-10-2023 16:04:02",
                "inicioProcessamento": "10-10-2023 16:03:28",
                "fimProcessamento": "10-10-2023 16:04:01"
            }
        ]
    }
]
```

### Exemplo de lote processado com erro

> GET https://integrador.varejonline.com.br/apps/api/pedidos/?exibirJsonEnviado=true&ids=2

```javascript

[
    {
        "id": 2,
        "dataCriacao": "10/10/2023",
        "pedidos": [
            {
                "id": 2,
                "status": "ERRO",
                "jsonRecebido": {
                    "dataCompra": "03-10-2023",
                    "dataPrevisaoEntrega": "07-06-2021",
                    "dataLimiteEntrega": "07-11-2023",
                    "entidade": {
                        "id": 1,
                        "nome": null,
                        "documento": null
                    },
                    "fornecedor": {
                        "id": 223,
                        "nome": null,
                        "documento": null,
                        "endereco": null
                    },
                    "referenciaPedidoFornecedor": "aaa",
                    "produtos": [
                        {
                            "idProduto": null,
                            "produto": {
                                "id": 24,
                                "codigoSistema": null,
                                "descricao": null
                            },
                            "unidade": null,
                            "quantidade": 10,
                            "valorDesconto": 0,
                            "valorUnitario": 5,
                            "icms": null,
                            "icmsst": null,
                            "ipi": null,
                            "idOperacao": 20
                        }
                    ],
                    "valorSeguro": 10,
                    "valorFrete": 0,
                    "valorOutros": 0,
                    "parcelas": [
                        {
                            "dataVencimento": "07-10-2023",
                            "valor": 35
                        },
                        {
                            "dataVencimento": "07-11-2023",
                            "valor": 25
                        }
                    ],
                    "status": null,
                    "observacao": null,
                    "gerarPrevisao": true,
                    "tipoPlanoPagamento": 2,
                    "geradoEntregaFutura": false
                },
                "erro": "IllegalArgumentException: Foi encontrado um pedido de compra com a mesma referenciaPedidoFornecedor de acordo com os parâmetros de integração configurados no ERP.",
                "dataAlteracao": "10-10-2023 14:26:56",
                "fimProcessamento": "10-10-2023 14:27:08"
            }
        ]
    }
]

```