Listagem dos possíveis tipos de status de pedidos de compra

<table>
<tr><th>Status</th><th>PUT Enabled?</th></tr>
<tr><td>ATENDIDO</td><td>false</td></tr>
<tr><td>PARCIALMENTE_ATENDIDO</td><td>false</td></tr>
<tr><td>CANCELADO</td><td>true</td></tr>
<tr><td>EM_ANDAMENTO</td><td>false</td></tr>
<tr><td>ABERTO</td><td>true</td></tr>
<tr><td>BLOQUEADO_INTEGRACAO</td><td>true</td></tr>
<tr><td>PENDENTE_APROVACAO</td><td>false</td></tr>
<tr><td>PARCIALMENTE_APROVADO</td><td>false</td></tr>
<tr><td>APROVADO</td><td>false</td></tr>
<tr><td>ENCERRADO</td><td>false</td></tr>
</table>

### PUT Enabled?

Define a lista de status que podem ser enviados em uma atualização de pedido de compra (Operação PUT)

Adicionalmente, apenas pedidos que estejam com status ABERTO ou BLOQUEADO_INTEGRACAO, podem receber atualização via API.
