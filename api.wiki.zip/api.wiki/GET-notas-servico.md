### URLs

> GET https://integrador.varejonline.com.br/apps/api/notas-servico

> GET https://integrador.varejonline.com.br/apps/api/notas-servico/:id

### Parâmetros

* **inicio:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **quantidade:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **alteradoApos:** [Entenda a Coleta de Alterações](https://github.com/Varejonline/api/wiki/Filtro-de-Data-Alteração)
* **desde:** [Veja o Filtro de Datas](https://github.com/Varejonline/api/wiki/Filtro-de-Datas)
* **ate:** [Veja o Filtro de Datas](https://github.com/Varejonline/api/wiki/Filtro-de-Datas)
* **naoEscrituradas:** Indica se devem ser retornadas notas não escrituradas na consulta (boolean)
* **cfops:** Retorna somente as notas que possuem ao menos um dos cfops informados (lista numérica separada por virgula)

### Retorno

* **id:** id da nota (long)
* **tipo:** tipo da nota (string). Os valores possíveis são: ENTRADA e SAIDA
* **modelo:** [Modelo](https://github.com/Varejonline/api/wiki/Tipo-de-Documentos-Fiscais) da nota fiscal.
* **numeroNotafiscal:** número do documento da nota de serviço (long). 
* **data:** data de emissão da nota (string)
* **idTerceiroRemetente:** id do [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros) remetente da nota (long)
* **idTerceiroDestinatario:** id do [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros) destinatário da nota (long)
* **idEntidade:** id da [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) da nota (long)
* **status:** status da nota (string). [veja os valores de status de documentos  fiscais] (Status-Documentos-Fiscais)
* **valorTotal:** valor total da nota (decimal)
 * **entradas:** lista com os [ids das entradas](https://github.com/Varejonline/api/wiki/GET-entradas) associadas à nota emitida.
 * **saidas:** lista com os [ids das saídas](https://github.com/Varejonline/api/wiki/GET-saidas) associadas à nota emitida.
* **itens:** lista de itens da nota
   * **idServico:** id do servico prestado (long)
   * **cfop:** código CFOP da operação (integer)
   * **quantidade:** quantidade do serviço prestado (decimal)
   * **valorUnitario:** valor unitário do serviço na nota (decimal)
   * **valorTotal:** valor total do item (decimal)
   * **valorDesconto:** valor do desconto do item (decimal)
   * **cofins:** dados do COFINS aplicado ao item (segue a estrutura comum abaixo)
   * **pis:** dados do PIS aplicado ao item (segue a estrutura comum abaixo)
   * **iss:** dados do ISS aplicado ao item (segue a estrutura comum abaixo)
* **retencoes:** lista de retenções de tributos da nota
   * **nome:** nome do tributo (string)
   * **valor:** valor retido (decimal)

Estrutura comum para tributos:
   * **base:** valor da base de cálculo do tributo (decimal)
   * **aliquota:** valor da alíquota aplicada (decimal)
   * **valor:** valor do tributo (decimal)
   * **cst:** código de situação tributária (string)

### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/notas-servico

```javascript
[
   {
      "id":321,
      "tipo":"SAIDA",
      "modelo":"SERVICO",
      "numeroNotaFiscal":1234,
      "data":"19-06-2012",
      "idTerceiroRemetente":4,
      "idTerceiroDestinatario":48,
      "idEntidade":1,
      "status":"EMITIDO",
      "valorTotal":3000,
      "itens":[
         {
            "idServico":9,
            "cfop":5101,
            "quantidade":10,
            "valorUnitario":300.0000,
            "valorTotal":3000,
            "valorDesconto":0,
            "cofins":{
               "base":0,
               "valor":0,
               "aliquota":0,
               "cst":"99"
            },
            "pis":{
               "base":0,
               "valor":0,
               "aliquota":0,
               "cst":"99"
            },
            "iss":{
               "base":0,
               "valor":0,
               "aliquota":0,
               "cst":"N"
            }
         }
      ],
      "retencoes":[
         {
            "valor":20,
            "nome":"PIS RETIDO S/ SERVIÇO PRESTADO"
         },
         {
            "valor":34.8,
            "nome":"COFINS RETIDO S/ SERVIÇO PRESTADO"
         }
      ]
   }
]
```