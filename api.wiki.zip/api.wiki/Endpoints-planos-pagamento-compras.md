## [GET plano-pagamento](/Varejonline/api/wiki/GET-planos-pagamento-compras)
## [POST plano-pagamento](/Varejonline/api/wiki/POST-planos-pagamento-compras)
## [PUT plano-pagamento](/Varejonline/api/wiki/PUT-planos-pagamento-compras)
