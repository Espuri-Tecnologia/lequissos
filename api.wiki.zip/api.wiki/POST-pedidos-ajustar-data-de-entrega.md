
### URL

> POST https://integrador.varejonline.com.br/apps/api/pedidos/ajustar-data-entrega

### Parâmetros

Envie um JSON no corpo da requisição, contendo:

* **idPedido:** id do pedido que deseja ajustar (long) (obrigatório)
* **itens:** (obrigatório informar o id e/ou código sistema do produto e a data de entrega ajustada)
	* **id:** id do [produto](https://github.com/Varejonline/api/wiki/GET-Produtos). (long)
	* **codigo:** código sistema do produto. (string)
	* **dataEntregaAjustada:** data de entrega ajustada. (string dd-MM-yyyy) (obrigatório)
* **observacao:** observação referente ao ajuste da data de entrega (string) (opcional)


### Retorno

Sucesso HTTP 200 OK:

Retorna um Json com informações do resultado da operação realizada, contendo:

* **codigoMensagem:** Código de identificação da operação realizada. [veja a lista de Códigos](https://github.com/Varejonline/api/wiki/Retorno-API)
* **mensagem:** Mensagem da operação realizada

Requisição inválida: 
* HTTP STATUS 400 – BAD REQUEST
* Body: mensagem de erro

### Exemplo

> POST https://integrador.varejonline.com.br/apps/api/pedidos/ajustar-data-entrega

'Content-Type'='application/json'
```javascript
{ 
    "idPedido": 32,
    "itens": [{
        "id": 218,
        "codigo": "0002.0002",
        "dataEntregaAjustada": "20-09-2021"
    }], 
    "observacao": "Problemas com a entrega."
}
```