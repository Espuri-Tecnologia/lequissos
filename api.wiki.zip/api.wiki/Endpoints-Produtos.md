# Estrutura Mercadológica no ERP Varejonline

No ERP Varejonline, a estrutura mercadológica de um produto é definida pelo arranjo das categorias associadas ao produto. 

Durante uma implantação, são configurados os níveis de categorias presentes na empresa. Na manipulação dos produtos, para cada um desses níveis, uma categoria será associada ao produto. Dessa forma, ao final da configuração, um produto deve possuir uma categoria em cada nível do sistema (obrigatoriamente), definindo assim seu arranjo.

**Exemplo 1 :** Departamento A comercializa as marcas A e B

* **Nível:** DEPARTAMENTO
 * **Categoria:** Departamento A
* **Nível:** MARCA
 * **Categoria:** Marca A
 * **Categoria:** Marca B

* _Produto 1 - Tênis Marca A 33_
 * **Nível:** DEPARTAMENTO, **Categoria:** Departamento A
 * **Nível:** MARCA, **Categoria:** Marca A

* _Produto 2 - Tênis Marca B 33_
 * **Nível:** DEPARTAMENTO, **Categoria:** Departamento A
 * **Nível:** MARCA, **Categoria:** Marca B

**Exemplo 2 :** Departamento B comercializa as marcas A, C e D

* **Nível:** DEPARTAMENTO
 * **Categoria:** Departamento B
* **Nível:** MARCA
 * **Categoria:** Marca A
 * **Categoria:** Marca C
 * **Categoria:** Marca D

* _Produto 3 - Camiseta Marca D GG_
 * **Nível:** DEPARTAMENTO, **Categoria:** Departamento B
 * **Nível:** MARCA, **Categoria:** Marca D

# SKU vs Produto Base

O ERP Varejonline trabalha com dois tipos de produtos: SKU e Produto BASE. Um SKU existe sem um produto base, isso o define como um produto simples, que não faz parte de uma grade, porém um produto base não existe sem pelo menos um SKU. Entenda:

Um produto base é o produto utilizado como parâmetro para a criação de itens de grade. Quando é gerada uma grade no sistema (Exemplo: Um tênis específico com diferentes tamanhos, ou uma camisa com diferentes cores), é cadastrado um produto base, o qual contém a estrutura mercadológica da grade, a unidade de medida da grade, seus fornecedores, classificação, entre outros. Em seguida, são configurados os atributos da grade e seus valores, os quais darão origem aos SKUs. Veja o passo a passo completo para criação de uma grade no sistema:

**Exemplo** (Será gerado uma grade para o produto camisa social):

1. Deve ser cadastrado um produto base com nome: Camisa Social
1. Deve ser configurado o produto base com todos os parâmetros padrões da grade (Parâmetros que não variam por SKU da grade - Categorias, Unidade, Classificação, Fornecedores, Código Referência Base, etc)
1. Devem ser definidos os atributos da Grade: COR e TAMANHO
1. Devem ser definidos, para cada atributo, os valores dos atributos na grade: [Amarelo, Azul] e [P, M]
1. O sistema irá compor a grade e solicitar os parâmetros específicos por SKU (Código interno, Código Barras, Fotos, Preços de Custo e Venda Padrão):
 1. Camisa Social Amarelo P
 1. Camisa Social Azul P
 1. Camisa Social Amarelo M
 1. Camisa Social Azul M
1. Para cada SKU, o ERP vai gerar um código de sistema com base no código referência base do produto base e no modelo de geração de código configurado no sistema. Imagine o código do produto base: 0002. Nesse caso, cada SKU será gerado com um código de sistema similar a: 0002.000X, onde X é o incremento de controle do SKU na grade, variando de 1 até 4, em nosso exemplo.

O **modelo de geração do código** SKU pode variar conforme configuração do ERP. Existem 3 modos de geração de código:
* **Manual:** É respeitado o código informado pelo usuário.
* **Automático:** Código gerado pelo sistema de forma incremental.
* **Inteligente:** Código gerado pelo sistema com base na estrutura mercadológica e composição da grade.

A utilização dos endpoints POST e PUT de produtos, deve ser realizada conforme parametrização do sistema. Por exemplo: Se o sistema está configurado com geração automática, é desconsiderado o valor informado no campo Código do endpoint. Da mesma forma, se a geração é manual e o código não for informado, a requisição irá gerar um BAD REQUEST.

**Particularidades:** 
* Não existe um produto item de grade sem um produto base e as requisições nos endpoints de manutenção de produtos, devem refletir esse comportamento. Da mesma forma, um produto item de grade, sempre deve possuir atributos e valores de grade.
* Uma requisição POST ou PUT sem um produto base pode indicar que o produto será um produto base de grade ou um produto simples.

# Funcionamento dos Endpoints

Para manutenção de produtos, são disponibilizados três endpoints: GET, POST e PUT de produtos. Cada endpoint possui particularidades e funções específicas:

## [POST Produtos](https://github.com/Varejonline/api/wiki/POST-Produtos)
**Particularidades:** 
* Se estiver sendo realizado o POST de um SKU que faz parte de uma grade, deve ser informado o produto base da grade. Caso ele ainda não exista na base Varejonline, pode ser informado somente o nome e seu código de sistema, nos campos próprios, conforme documentação do endpoint. Com isso o produto base será gerado automaticamente durante a criação do item da grade. Caso já exista um produto com o nome informado no produto base, ele será utilizado como base para a criação do item da grade.

## [GET Produtos](https://github.com/Varejonline/api/wiki/GET-Produtos)

## [PUT Produtos](https://github.com/Varejonline/api/wiki/PUT-Produtos)
**Particularidades:** 
* Se estiver sendo realizado o PUT de um SKU que faz parte de uma grade, somente os campos específicos daquele SKU serão atualizados. Para atualizar os campos padrões de toda a grade, deve ser atualizado o produto base.

# Notas Importantes sobre Integração de Grades

Não é permitido o cadastro de duas mercadorias ativas com mesmo nome ou código. Em outras palavras, os campos: código de barras, código sistema e o nome da mercadoria devem ser únicos por produto cadastrado, inclusive para produtos base. Este último, pode ser parametrizado para permitir sua repetição nos parâmetros do sistema.

Em geral, ao configurar uma grade de produtos, utiliza-se o campo codigoSistema do produto base para definir a referência base da grade e o campo codigoSistema do item da grade para definir o código SKU. Também é recomendado que se siga o padrão de mercado que define que o código SKU é composto pelo código da referência mais um discriminador do item na grade.
