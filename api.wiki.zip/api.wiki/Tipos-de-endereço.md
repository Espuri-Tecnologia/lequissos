Lista dos tipos de endereço aceitos e retornados pela API de Terceiros:

1) ENDERECO_CORRESPONDENCIA<BR>
2) ENDERECO_COBRANCA<BR>
3) ENDERECO_ENTREGA<BR>
4) ENDERECO_SEDE<BR>