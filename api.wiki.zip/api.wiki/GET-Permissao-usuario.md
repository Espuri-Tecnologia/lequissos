### URLs

> GET https://integrador.varejonline.com.br/apps/api/permissao-usuario

> GET https://integrador.varejonline.com.br/apps/api/permissao-usuario/:id

### Parâmetros

* **inicio:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **quantidade:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)


### Retorno

* **id:** id da permissão (long)
* **descricao:** descrição da permissão (string)


### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/permissao-usuario

```javascript
[
  {
      "id": 2,
      "descricao": "ADMINISTRATIVO"
  },
  {
      "id": 3,
      "descricao": "ESTOQUE"
  }
]
```