### URL

> PUT https://integrador.varejonline.com.br/apps/api/pedidos-compra/:id

> PUT https://integrador.varejonline.com.br/apps/api/pedidos-compra/encerrar/:id

### Parâmetros

**Obs:** Ao chamar o endereço de encerramento, nenhuma informação é necessária no corpo da requisição. Lembre-se de que pedidos encerrados não podem ser mais manipulados no sistema e seus saldos pendentes passam a ser desconsiderados como estoque em trânsito. Adicionalmente, apenas pedidos com status ABERTO ou BLOQUEADO_INTEGRACAO, permitem atualização via API.

Envie um JSON no corpo da requisição, contendo:
* **dataCompra:** data do pedido de compra (string) (obrigatório)
* **dataLimiteEntrega:** data de limite de entrga do pedido de compra (string) (obrigatório)
* **status:** [Status](https://github.com/Varejonline/api/wiki/Status-de-pedido-de-compra) do pedido de compras (string)
* **entidade:** [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) utilizada (obrigatório)
  * **id:** id da [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) (long) (opcional)
  * **documento:** documento da [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) (string)  (opcional)
* **fornecedor:** fornecedor do pedido (obrigatório)
  * **id:** id do [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros) fornecedor do pedido de compra (long) (opcional)
  * **documento:** documento do [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros) fornecedor do pedido de compra (string)  (opcional)
* **referenciaPedidoFornecedor:** número do referência do pedido no fornecedor (string) (opcional)
* **valorSeguro:** valor de seguro do pedido de compra (decimal) (obrigatório)
* **valorFrete:** valor de frete do pedido de compra (decimal) (obrigatório)
* **valorOutros:** valor de outros do pedido de compra (decimal) (obrigatório)
* **parcelas:** lista de parcelas do pedido de compra (obrigatório)
   * **dataVencimento:** data de vencimento da parcela (string) (obrigatório)
   * **valor:** valor da parcela (decimal) (obrigatório)
* **observacao:** observações do pedido de compra (string) (opcional)
* **tipoPlanoPagamento:**  id do [plano de pagamento](https://github.com/Varejonline/api/wiki/GET-planos-pagamento-compras) (long) (opcional)
* **produtos:** lista de produtos do pedido de compra (obrigatório)
   * **produto:**
      * **id:** id do [produto](https://github.com/Varejonline/api/wiki/GET-Produtos) (opcional)
      * **codigoSistema:** código de sistema do [produto](https://github.com/Varejonline/api/wiki/GET-Produtos) (opcional)
   * **quantidade:** quantidade de produtos (decimal) (obrigatório)
   * **valorDesconto:** valor de desconto no produto (decimal) (opcional)
   * **valorUnitario:** valor unitário do produto (decimal) (obrigatório)
   * **idOperacao:** valor que indica o id da [operação](/Varejonline/api/wiki/Operações-de-Compra) de compra do produto (obrigatório)
* **dataPrevisaoEntrega:** data de previsão de entrega do pedido de compra (string) (opcional)

### Retorno

Sucesso:
* HTTP STATUS 200 – OK

Requisição inválida: 
* HTTP STATUS 400 – BAD REQUEST
* Body: mensagem de erro

### Exemplo

> PUT https://integrador.varejonline.com.br/apps/api/pedidos-compra/1

'Content-Type'='application/json'
```javascript
{
   "dataCompra":"07-04-2014",
   "dataLimiteEntrega":"07-05-2014",
   "entidade": {
       "id": 1,
       "documento" : "00000000000000"
   },
   "fornecedor": {
       "id": 1,
       "documento" : "00.000.000/0000-00"
   },
   "referenciaPedidoFornecedor": "REF. PEDIDO 1",
   "valorSeguro":1,
   "valorFrete":2,
   "valorOutros":3,
   "parcelas":[
      {
         "dataVencimento":"07-04-2014",
         "valor":53
      },
      {
         "dataVencimento":"07-05-2014",
         "valor":23
      }
   ],
   "observacao":"Detalhe adicional",
   "tipoPlanoPagamento": 2,
   "produtos":[
      {
         "produto": {
             "codigoSistema" : "0001.0001" 
         },
         "quantidade":10,
         "valorDesconto":1,
         "valorUnitario":5,
         "idOperacao":20
      }
   ],
   "dataPrevisaoEntrega":"07-05-2014",
}
```