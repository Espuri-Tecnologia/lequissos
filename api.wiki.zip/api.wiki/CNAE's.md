Listagem dos possíveis CNAE's

<table>
<tr><th>   Código   </th><th>Descrição</th></tr>
<tr><td>0111-3/03</td><td>Cultivo de trigo</td></tr>
<tr><td>0111-3/99</td><td>Cultivo de outros cereais não especificados anteriormente</td></tr>
<tr><td>0112-1/01</td><td>Cultivo de algodão herbáceo</td></tr>
<tr><td>0112-1/02</td><td>Cultivo de juta</td></tr>
<tr><td>0112-1/99</td><td>Cultivo de outras fibras de lavoura temporária não especificadas anteriormente</td></tr>
<tr><td>0113-0/00</td><td>Cultivo de cana-de-açúcar</td></tr>
<tr><td>0114-8/00</td><td>Cultivo de fumo</td></tr>
<tr><td>0115-6/00</td><td>Cultivo de soja</td></tr>
<tr><td>0116-4/01</td><td>Cultivo de amendoim</td></tr>
<tr><td>0116-4/02</td><td>Cultivo de girassol</td></tr>
<tr><td>0116-4/03</td><td>Cultivo de mamona</td></tr>
<tr><td>0116-4/99</td><td>Cultivo de outras oleaginosas de lavoura temporária não especificadas anteriormente</td></tr>
<tr><td>0119-9/01</td><td>Cultivo de abacaxi</td></tr>
<tr><td>0119-9/02</td><td>Cultivo de alho</td></tr>
<tr><td>0119-9/03</td><td>Cultivo de batata-inglesa</td></tr>
<tr><td>0119-9/04</td><td>Cultivo de cebola</td></tr>
<tr><td>0119-9/05</td><td>Cultivo de feijão</td></tr>
<tr><td>0119-9/06</td><td>Cultivo de mandioca</td></tr>
<tr><td>0119-9/07</td><td>Cultivo de melão</td></tr>
<tr><td>0119-9/08</td><td>Cultivo de melancia</td></tr>
<tr><td>0119-9/09</td><td>Cultivo de tomate rasteiro</td></tr>
<tr><td>0119-9/99</td><td>Cultivo de outras plantas de lavoura temporária não especificadas anteriormente</td></tr>
<tr><td>0121-1/01</td><td>Horticultura, exceto morango</td></tr>
<tr><td>0121-1/02</td><td>Cultivo de morango</td></tr>
<tr><td>0122-9/00</td><td>Cultivo de flores e plantas ornamentais</td></tr>
<tr><td>0131-8/00</td><td>Cultivo de laranja</td></tr>
<tr><td>0132-6/00</td><td>Cultivo de uva</td></tr>
<tr><td>0133-4/01</td><td>Cultivo de açaí</td></tr>
<tr><td>0133-4/02</td><td>Cultivo de banana</td></tr>
<tr><td>0133-4/03</td><td>Cultivo de caju</td></tr>
<tr><td>0133-4/04</td><td>Cultivo de cítricos, exceto laranja</td></tr>
<tr><td>0133-4/05</td><td>Cultivo de coco-da-baía</td></tr>
<tr><td>0133-4/06</td><td>Cultivo de guaraná</td></tr>
<tr><td>0133-4/07</td><td>Cultivo de maçã</td></tr>
<tr><td>0133-4/08</td><td>Cultivo de mamão</td></tr>
<tr><td>0133-4/09</td><td>Cultivo de maracujá</td></tr>
<tr><td>0133-4/10</td><td>Cultivo de manga</td></tr>
<tr><td>0133-4/11</td><td>Cultivo de pêssego</td></tr>
<tr><td>0133-4/99</td><td>Cultivo de frutas de lavoura permanente não especificadas anteriormente</td></tr>
<tr><td>0134-2/00</td><td>Cultivo de café</td></tr>
<tr><td>0135-1/00</td><td>Cultivo de cacau</td></tr>
<tr><td>0139-3/01</td><td>Cultivo de chá-da-índia</td></tr>
<tr><td>0139-3/02</td><td>Cultivo de erva-mate</td></tr>
<tr><td>0139-3/03</td><td>Cultivo de pimenta-do-reino</td></tr>
<tr><td>0139-3/04</td><td>Cultivo de plantas para condimento, exceto pimenta-do-reino</td></tr>
<tr><td>0139-3/05</td><td>Cultivo de dendê</td></tr>
<tr><td>0139-3/06</td><td>Cultivo de seringueira</td></tr>
<tr><td>0139-3/99</td><td>Cultivo de outras plantas de lavoura permanente não especificadas anteriormente</td></tr>
<tr><td>0141-5/01</td><td>Produção de sementes certificadas, exceto de forrageiras para pasto</td></tr>
<tr><td>0141-5/02</td><td>Produção de sementes certificadas de forrageiras para formação de pasto</td></tr>
<tr><td>0142-3/00</td><td>Produção de mudas e outras formas de propagação vegetal, certificadas</td></tr>
<tr><td>0151-2/01</td><td>Criação de bovinos para corte</td></tr>
<tr><td>0151-2/02</td><td>Criação de bovinos para leite</td></tr>
<tr><td>0151-2/03</td><td>Criação de bovinos, exceto para corte e leite</td></tr>
<tr><td>0152-1/01</td><td>Criação de bufalinos</td></tr>
<tr><td>0152-1/02</td><td>Criação de eqüinos</td></tr>
<tr><td>0152-1/03</td><td>Criação de asininos e muares</td></tr>
<tr><td>0153-9/01</td><td>Criação de caprinos</td></tr>
<tr><td>0153-9/02</td><td>Criação de ovinos, inclusive para produção de lã</td></tr>
<tr><td>0154-7/00</td><td>Criação de suínos</td></tr>
<tr><td>0155-5/01</td><td>Criação de frangos para corte</td></tr>
<tr><td>0155-5/02</td><td>Produção de pintos de um dia</td></tr>
<tr><td>0155-5/03</td><td>Criação de outros galináceos, exceto para corte</td></tr>
<tr><td>0155-5/04</td><td>Criação de aves, exceto galináceos</td></tr>
<tr><td>0155-5/05</td><td>Produção de ovos</td></tr>
<tr><td>0159-8/01</td><td>Apicultura</td></tr>
<tr><td>0159-8/02</td><td>Criação de animais de estimação</td></tr>
<tr><td>0159-8/03</td><td>Criação de escargô</td></tr>
<tr><td>0159-8/04</td><td>Criação de bicho-da-seda</td></tr>
<tr><td>0159-8/99</td><td>Criação de outros animais não especificados anteriormente</td></tr>
<tr><td>0161-0/01</td><td>Serviço de pulverização e controle de pragas agrícolas</td></tr>
<tr><td>0161-0/02</td><td>Serviço de poda de árvores para lavouras</td></tr>
<tr><td>0161-0/03</td><td>Serviço de preparação de terreno, cultivo e colheita</td></tr>
<tr><td>0161-0/99</td><td>Atividades de apoio à agricultura não especificadas anteriormente</td></tr>
<tr><td>0162-8/01</td><td>Serviço de inseminação artificial em animais</td></tr>
<tr><td>0162-8/02</td><td>Serviço de tosquiamento de ovinos</td></tr>
<tr><td>0162-8/03</td><td>Serviço de manejo de animais</td></tr>
<tr><td>0162-8/99</td><td>Atividades de apoio à pecuária não especificadas anteriormente</td></tr>
<tr><td>0163-6/00</td><td>Atividades de pós-colheita</td></tr>
<tr><td>0170-9/00</td><td>Caça e serviços relacionados</td></tr>
<tr><td>0210-1/01</td><td>Cultivo de eucalipto</td></tr>
<tr><td>0210-1/02</td><td>Cultivo de acácia-negra</td></tr>
<tr><td>0210-1/03</td><td>Cultivo de pinus</td></tr>
<tr><td>0210-1/04</td><td>Cultivo de teca</td></tr>
<tr><td>0210-1/05</td><td>Cultivo de espécies madeireiras, exceto eucalipto, acácia-negra, pinus e teca</td></tr>
<tr><td>0210-1/06</td><td>Cultivo de mudas em viveiros florestais</td></tr>
<tr><td>0210-1/07</td><td>Extração de madeira em florestas plantadas</td></tr>
<tr><td>0210-1/08</td><td>Produção de carvão vegetal - florestas plantadas</td></tr>
<tr><td>0210-1/09</td><td>Produção de casca de acácia-negra - florestas plantadas</td></tr>
<tr><td>0210-1/99</td><td>Produção de produtos não-madeireiros não especificados anteriormente em florestas plantadas</td></tr>
<tr><td>0220-9/01</td><td>Extração de madeira em florestas nativas</td></tr>
<tr><td>0220-9/02</td><td>Produção de carvão vegetal - florestas nativas</td></tr>
<tr><td>0220-9/03</td><td>Coleta de castanha-do-pará em florestas nativas</td></tr>
<tr><td>0220-9/04</td><td>Coleta de látex em florestas nativas</td></tr>
<tr><td>0220-9/05</td><td>Coleta de palmito em florestas nativas</td></tr>
<tr><td>0220-9/06</td><td>Conservação de florestas nativas</td></tr>
<tr><td>0220-9/99</td><td>Coleta de produtos não-madeireiros não especificados anteriormente em florestas nativas</td></tr>
<tr><td>0230-6/00</td><td>Atividades de apoio à produção florestal</td></tr>
<tr><td>0311-6/01</td><td>Pesca de peixes em água salgada</td></tr>
<tr><td>0311-6/02</td><td>Pesca de crustáceos e moluscos em água salgada</td></tr>
<tr><td>0311-6/03</td><td>Coleta de outros produtos marinhos</td></tr>
<tr><td>0311-6/04</td><td>Atividades de apoio à pesca em água salgada</td></tr>
<tr><td>0312-4/01</td><td>Pesca de peixes em água doce</td></tr>
<tr><td>0312-4/02</td><td>Pesca de crustáceos e moluscos em água doce</td></tr>
<tr><td>0312-4/03</td><td>Coleta de outros produtos aquáticos de água doce</td></tr>
<tr><td>0312-4/04</td><td>Atividades de apoio à pesca em água doce</td></tr>
<tr><td>0321-3/01</td><td>Criação de peixes em água salgada e salobra</td></tr>
<tr><td>0321-3/02</td><td>Criação de camarões em água salgada e salobra</td></tr>
<tr><td>0321-3/03</td><td>Criação de ostras e mexilhões em água salgada e salobra</td></tr>
<tr><td>0321-3/04</td><td>Criação de peixes ornamentais em água salgada e salobra</td></tr>
<tr><td>0321-3/05</td><td>Atividades de apoio à aqüicultura em água salgada e salobra</td></tr>
<tr><td>0321-3/99</td><td>Cultivos e semicultivos da aqüicultura em água salgada e salobra não especificados anteriormente</td></tr>
<tr><td>0322-1/01</td><td>Criação de peixes em água doce</td></tr>
<tr><td>0322-1/02</td><td>Criação de camarões em água doce</td></tr>
<tr><td>0322-1/03</td><td>Criação de ostras e mexilhões em água doce</td></tr>
<tr><td>0322-1/04</td><td>Criação de peixes ornamentais em água doce</td></tr>
<tr><td>0322-1/05</td><td>Ranicultura</td></tr>
<tr><td>0322-1/06</td><td>Criação de jacaré</td></tr>
<tr><td>0322-1/07</td><td>Atividades de apoio à aqüicultura em água doce</td></tr>
<tr><td>0322-1/99</td><td>Cultivos e semicultivos da aqüicultura em água doce não especificados anteriormente</td></tr>
<tr><td>0500-3/01</td><td>Extração de carvão mineral</td></tr>
<tr><td>0500-3/02</td><td>Beneficiamento de carvão mineral</td></tr>
<tr><td>0600-0/01</td><td>Extração de petróleo e gás natural</td></tr>
<tr><td>0600-0/02</td><td>Extração e beneficiamento de xisto</td></tr>
<tr><td>0600-0/03</td><td>Extração e beneficiamento de areias betuminosas</td></tr>
<tr><td>0710-3/01</td><td>Extração de minério de ferro</td></tr>
<tr><td>0710-3/02</td><td>Pelotização, sinterização e outros beneficiamentos de minério de ferro</td></tr>
<tr><td>0721-9/01</td><td>Extração de minério de alumínio</td></tr>
<tr><td>0721-9/02</td><td>Beneficiamento de minério de alumínio</td></tr>
<tr><td>0722-7/01</td><td>Extração de minério de estanho</td></tr>
<tr><td>0722-7/02</td><td>Beneficiamento de minério de estanho</td></tr>
<tr><td>0723-5/01</td><td>Extração de minério de manganês</td></tr>
<tr><td>0723-5/02</td><td>Beneficiamento de minério de manganês</td></tr>
<tr><td>0724-3/01</td><td>Extração de minério de metais preciosos</td></tr>
<tr><td>0724-3/02</td><td>Beneficiamento de minério de metais preciosos</td></tr>
<tr><td>0725-1/00</td><td>Extração de minerais radioativos</td></tr>
<tr><td>0729-4/01</td><td>Extração de minérios de nióbio e titânio</td></tr>
<tr><td>0729-4/02</td><td>Extração de minério de tungstênio</td></tr>
<tr><td>0729-4/03</td><td>Extração de minério de níquel</td></tr>
<tr><td>0729-4/04</td><td>Extração de minérios de cobre, chumbo, zinco e outros minerais metálicos não-ferrosos não especificados anteriormente</td></tr>
<tr><td>0729-4/05</td><td>Beneficiamento de minérios de cobre, chumbo, zinco e outros minerais metálicos não-ferrosos não especificados anteriormente</td></tr>
<tr><td>0810-0/01</td><td>Extração de ardósia e beneficiamento associado</td></tr>
<tr><td>0810-0/02</td><td>Extração de granito e beneficiamento associado</td></tr>
<tr><td>0810-0/03</td><td>Extração de mármore e beneficiamento associado</td></tr>
<tr><td>0810-0/04</td><td>Extração de calcário e dolomita e beneficiamento associado</td></tr>
<tr><td>0810-0/05</td><td>Extração de gesso e caulim</td></tr>
<tr><td>0810-0/06</td><td>Extração de areia, cascalho ou pedregulho e beneficiamento associado</td></tr>
<tr><td>0810-0/07</td><td>Extração de argila e beneficiamento associado</td></tr>
<tr><td>0810-0/08</td><td>Extração de saibro e beneficiamento associado</td></tr>
<tr><td>0810-0/09</td><td>Extração de basalto e beneficiamento associado</td></tr>
<tr><td>0810-0/10</td><td>Beneficiamento de gesso e caulim associado à extração</td></tr>
<tr><td>0810-0/99</td><td>Extração e britamento de pedras e outros materiais para construção e beneficiamento associado</td></tr>
<tr><td>0891-6/00</td><td>Extração de minerais para fabricação de adubos, fertilizantes e outros produtos químicos</td></tr>
<tr><td>0892-4/01</td><td>Extração de sal marinho</td></tr>
<tr><td>0892-4/02</td><td>Extração de sal-gema</td></tr>
<tr><td>0892-4/03</td><td>Refino e outros tratamentos do sal</td></tr>
<tr><td>0893-2/00</td><td>Extração de gemas (pedras preciosas e semipreciosas)</td></tr>
<tr><td>0899-1/01</td><td>Extração de grafita</td></tr>
<tr><td>0899-1/02</td><td>Extração de quartzo</td></tr>
<tr><td>0899-1/03</td><td>Extração de amianto</td></tr>
<tr><td>0899-1/99</td><td>Extração de outros minerais não-metálicos não especificados anteriormente</td></tr>
<tr><td>0910-6/00</td><td>Atividades de apoio à extração de petróleo e gás natural</td></tr>
<tr><td>0990-4/01</td><td>Atividades de apoio à extração de minério de ferro</td></tr>
<tr><td>0990-4/02</td><td>Atividades de apoio à extração de minerais metálicos não-ferrosos</td></tr>
<tr><td>0990-4/03</td><td>Atividades de apoio à extração de minerais não-metálicos</td></tr>
<tr><td>1011-2/01</td><td>Frigorífico - abate de bovinos</td></tr>
<tr><td>1011-2/02</td><td>Frigorífico - abate de eqüinos</td></tr>
<tr><td>1011-2/03</td><td>Frigorífico - abate de ovinos e caprinos</td></tr>
<tr><td>1011-2/04</td><td>Frigorífico - abate de bufalinos</td></tr>
<tr><td>1011-2/05</td><td>Matadouro - abate de reses sob contrato, exceto abate de suínos</td></tr>
<tr><td>1012-1/01</td><td>Abate de aves</td></tr>
<tr><td>1012-1/02</td><td>Abate de pequenos animais</td></tr>
<tr><td>1012-1/03</td><td>Frigorífico - abate de suínos</td></tr>
<tr><td>1012-1/04</td><td>Matadouro - abate de suínos sob contrato</td></tr>
<tr><td>1013-9/01</td><td>Fabricação de produtos de carne</td></tr>
<tr><td>1013-9/02</td><td>Preparação de subprodutos do abate</td></tr>
<tr><td>1020-1/01</td><td>Preservação de peixes, crustáceos e moluscos</td></tr>
<tr><td>1020-1/02</td><td>Fabricação de conservas de peixes, crustáceos e moluscos</td></tr>
<tr><td>1031-7/00</td><td>Fabricação de conservas de frutas</td></tr>
<tr><td>1032-5/01</td><td>Fabricação de conservas de palmito</td></tr>
<tr><td>1032-5/99</td><td>Fabricação de conservas de legumes e outros vegetais, exceto palmito</td></tr>
<tr><td>1033-3/01</td><td>Fabricação de sucos concentrados de frutas, hortaliças e legumes</td></tr>
<tr><td>1033-3/02</td><td>Fabricação de sucos de frutas, hortaliças e legumes, exceto concentrados</td></tr>
<tr><td>1041-4/00</td><td>Fabricação de óleos vegetais em bruto, exceto óleo de milho</td></tr>
<tr><td>1042-2/00</td><td>Fabricação de óleos vegetais refinados, exceto óleo de milho</td></tr>
<tr><td>1043-1/00</td><td>Fabricação de margarina e outras gorduras vegetais e de óleos não-comestíveis de animais</td></tr>
<tr><td>1051-1/00</td><td>Preparação do leite</td></tr>
<tr><td>1052-0/00</td><td>Fabricação de laticínios</td></tr>
<tr><td>1053-8/00</td><td>Fabricação de sorvetes e outros gelados comestíveis</td></tr>
<tr><td>1061-9/01</td><td>Beneficiamento de arroz</td></tr>
<tr><td>1061-9/02</td><td>Fabricação de produtos do arroz</td></tr>
<tr><td>1062-7/00</td><td>Moagem de trigo e fabricação de derivados</td></tr>
<tr><td>1063-5/00</td><td>Fabricação de farinha de mandioca e derivados</td></tr>
<tr><td>1064-3/00</td><td>Fabricação de farinha de milho e derivados, exceto óleos de milho</td></tr>
<tr><td>1065-1/01</td><td>Fabricação de amidos e féculas de vegetais</td></tr>
<tr><td>1065-1/02</td><td>Fabricação de óleo de milho em bruto</td></tr>
<tr><td>1065-1/03</td><td>Fabricação de óleo de milho refinado</td></tr>
<tr><td>1066-0/00</td><td>Fabricação de alimentos para animais</td></tr>
<tr><td>1069-4/00</td><td>Moagem e fabricação de produtos de origem vegetal não especificados anteriormente</td></tr>
<tr><td>1071-6/00</td><td>Fabricação de açúcar em bruto</td></tr>
<tr><td>1072-4/01</td><td>Fabricação de açúcar de cana refinado</td></tr>
<tr><td>1072-4/02</td><td>Fabricação de açúcar de cereais (dextrose) e de beterraba</td></tr>
<tr><td>1081-3/01</td><td>Beneficiamento de café</td></tr>
<tr><td>1081-3/02</td><td>Torrefação e moagem de café</td></tr>
<tr><td>1082-1/00</td><td>Fabricação de produtos à base de café</td></tr>
<tr><td>1091-1/00</td><td>Fabricação de produtos de panificação</td></tr>
<tr><td>1092-9/00</td><td>Fabricação de biscoitos e bolachas</td></tr>
<tr><td>1093-7/01</td><td>Fabricação de produtos derivados do cacau e de chocolates</td></tr>
<tr><td>1093-7/02</td><td>Fabricação de frutas cristalizadas, balas e semelhantes</td></tr>
<tr><td>1094-5/00</td><td>Fabricação de massas alimentícias</td></tr>
<tr><td>1095-3/00</td><td>Fabricação de especiarias, molhos, temperos e condimentos</td></tr>
<tr><td>1096-1/00</td><td>Fabricação de alimentos e pratos prontos</td></tr>
<tr><td>1099-6/01</td><td>Fabricação de vinagres</td></tr>
<tr><td>1099-6/02</td><td>Fabricação de pós alimentícios</td></tr>
<tr><td>1099-6/03</td><td>Fabricação de fermentos e leveduras</td></tr>
<tr><td>1099-6/04</td><td>Fabricação de gelo comum</td></tr>
<tr><td>1099-6/05</td><td>Fabricação de produtos para infusão (chá, mate, etc.)</td></tr>
<tr><td>1099-6/06</td><td>Fabricação de adoçantes naturais e artificiais</td></tr>
<tr><td>1099-6/99</td><td>Fabricação de outros produtos alimentícios não especificados anteriormente</td></tr>
<tr><td>1111-9/01</td><td>Fabricação de aguardente de cana-de-açúcar</td></tr>
<tr><td>1111-9/02</td><td>Fabricação de outras aguardentes e bebidas destiladas</td></tr>
<tr><td>1112-7/00</td><td>Fabricação de vinho</td></tr>
<tr><td>1113-5/01</td><td>Fabricação de malte, inclusive malte uísque</td></tr>
<tr><td>1113-5/02</td><td>Fabricação de cervejas e chopes</td></tr>
<tr><td>1121-6/00</td><td>Fabricação de águas envasadas</td></tr>
<tr><td>1122-4/01</td><td>Fabricação de refrigerantes</td></tr>
<tr><td>1122-4/02</td><td>Fabricação de chá mate e outros chás prontos para consumo</td></tr>
<tr><td>1122-4/03</td><td>Fabricação de refrescos, xaropes e pós para refrescos, exceto refrescos de frutas</td></tr>
<tr><td>1122-4/99</td><td>Fabricação de outras bebidas não-alcoólicas não especificadas anteriormente</td></tr>
<tr><td>1210-7/00</td><td>Processamento industrial do fumo</td></tr>
<tr><td>1220-4/01</td><td>Fabricação de cigarros</td></tr>
<tr><td>1220-4/02</td><td>Fabricação de cigarrilhas e charutos</td></tr>
<tr><td>1220-4/03</td><td>Fabricação de filtros para cigarros</td></tr>
<tr><td>1220-4/99</td><td>Fabricação de outros produtos do fumo, exceto cigarros, cigarrilhas e charutos</td></tr>
<tr><td>1311-1/00</td><td>Preparação e fiação de fibras de algodão</td></tr>
<tr><td>1312-0/00</td><td>Preparação e fiação de fibras têxteis naturais, exceto algodão</td></tr>
<tr><td>1313-8/00</td><td>Fiação de fibras artificiais e sintéticas</td></tr>
<tr><td>1314-6/00</td><td>Fabricação de linhas para costurar e bordar</td></tr>
<tr><td>1321-9/00</td><td>Tecelagem de fios de algodão</td></tr>
<tr><td>1322-7/00</td><td>Tecelagem de fios de fibras têxteis naturais, exceto algodão</td></tr>
<tr><td>1323-5/00</td><td>Tecelagem de fios de fibras artificiais e sintéticas</td></tr>
<tr><td>1330-8/00</td><td>Fabricação de tecidos de malha</td></tr>
<tr><td>1340-5/01</td><td>Estamparia e texturização em fios, tecidos, artefatos têxteis e peças do vestuário</td></tr>
<tr><td>1340-5/02</td><td>Alvejamento, tingimento e torção em fios, tecidos, artefatos têxteis e peças do vestuário</td></tr>
<tr><td>1340-5/99</td><td>Outros serviços de acabamento em fios, tecidos, artefatos têxteis e peças do vestuário</td></tr>
<tr><td>1351-1/00</td><td>Fabricação de artefatos têxteis para uso doméstico</td></tr>
<tr><td>1352-9/00</td><td>Fabricação de artefatos de tapeçaria</td></tr>
<tr><td>1353-7/00</td><td>Fabricação de artefatos de cordoaria</td></tr>
<tr><td>1354-5/00</td><td>Fabricação de tecidos especiais, inclusive artefatos</td></tr>
<tr><td>1359-6/00</td><td>Fabricação de outros produtos têxteis não especificados anteriormente</td></tr>
<tr><td>1411-8/01</td><td>Confecção de roupas íntimas</td></tr>
<tr><td>1411-8/02</td><td>Facção de roupas íntimas</td></tr>
<tr><td>1412-6/01</td><td>Confecção de peças do vestuário, exceto roupas íntimas e as confeccionadas sob medida</td></tr>
<tr><td>1412-6/02</td><td>Confecção, sob medida, de peças do vestuário, exceto roupas íntimas</td></tr>
<tr><td>1412-6/03</td><td>Facção de peças do vestuário, exceto roupas íntimas</td></tr>
<tr><td>1413-4/01</td><td>Confecção de roupas profissionais, exceto sob medida</td></tr>
<tr><td>1413-4/02</td><td>Confecção, sob medida, de roupas profissionais</td></tr>
<tr><td>1413-4/03</td><td>Facção de roupas profissionais</td></tr>
<tr><td>1414-2/00</td><td>Fabricação de acessórios do vestuário, exceto para segurança e proteção</td></tr>
<tr><td>1421-5/00</td><td>Fabricação de meias</td></tr>
<tr><td>1422-3/00</td><td>Fabricação de artigos do vestuário, produzidos em malharias e tricotagens, exceto meias</td></tr>
<tr><td>1510-6/00</td><td>Curtimento e outras preparações de couro</td></tr>
<tr><td>1521-1/00</td><td>Fabricação de artigos para viagem, bolsas e semelhantes de qualquer material</td></tr>
<tr><td>1529-7/00</td><td>Fabricação de artefatos de couro não especificados anteriormente</td></tr>
<tr><td>1531-9/01</td><td>Fabricação de calçados de couro</td></tr>
<tr><td>1531-9/02</td><td>Acabamento de calçados de couro sob contrato</td></tr>
<tr><td>1532-7/00</td><td>Fabricação de tênis de qualquer material</td></tr>
<tr><td>1533-5/00</td><td>Fabricação de calçados de material sintético</td></tr>
<tr><td>1539-4/00</td><td>Fabricação de calçados de materiais não especificados anteriormente</td></tr>
<tr><td>1540-8/00</td><td>Fabricação de partes para calçados, de qualquer material</td></tr>
<tr><td>1610-2/01</td><td>Serrarias com desdobramento de madeira</td></tr>
<tr><td>1610-2/02</td><td>Serrarias sem desdobramento de madeira</td></tr>
<tr><td>1621-8/00</td><td>Fabricação de madeira laminada e de chapas de madeira compensada, prensada e aglomerada</td></tr>
<tr><td>1622-6/01</td><td>Fabricação de casas de madeira pré-fabricadas</td></tr>
<tr><td>1622-6/02</td><td>Fabricação de esquadrias de madeira e de peças de madeira para instalações industriais e comerciais</td></tr>
<tr><td>1622-6/99</td><td>Fabricação de outros artigos de carpintaria para construção</td></tr>
<tr><td>1623-4/00</td><td>Fabricação de artefatos de tanoaria e de embalagens de madeira</td></tr>
<tr><td>1629-3/01</td><td>Fabricação de artefatos diversos de madeira, exceto móveis</td></tr>
<tr><td>1629-3/02</td><td>Fabricação de artefatos diversos de cortiça, bambu, palha, vime e outros materiais trançados, exceto móveis</td></tr>
<tr><td>1710-9/00</td><td>Fabricação de celulose e outras pastas para a fabricação de papel</td></tr>
<tr><td>1721-4/00</td><td>Fabricação de papel</td></tr>
<tr><td>1722-2/00</td><td>Fabricação de cartolina e papel-cartão</td></tr>
<tr><td>1731-1/00</td><td>Fabricação de embalagens de papel</td></tr>
<tr><td>1732-0/00</td><td>Fabricação de embalagens de cartolina e papel-cartão</td></tr>
<tr><td>1733-8/00</td><td>Fabricação de chapas e de embalagens de papelão ondulado</td></tr>
<tr><td>1741-9/01</td><td>Fabricação de formulários contínuos</td></tr>
<tr><td>1741-9/02</td><td>Fabricação de produtos de papel, cartolina, papel-cartão e papelão ondulado para uso comercial e de escritório</td></tr>
<tr><td>1742-7/01</td><td>Fabricação de fraldas descartáveis</td></tr>
<tr><td>1742-7/02</td><td>Fabricação de absorventes higiênicos</td></tr>
<tr><td>1742-7/99</td><td>Fabricação de produtos de papel para uso doméstico e higiênico-sanitário não especificados anteriormente</td></tr>
<tr><td>1749-4/00</td><td>Fabricação de produtos de pastas celulósicas, papel, cartolina, papel-cartão e papelão ondulado não especificados anteriormente</td></tr>
<tr><td>1811-3/01</td><td>Impressão de jornais</td></tr>
<tr><td>1811-3/02</td><td>Impressão de livros, revistas e outras publicações periódicas</td></tr>
<tr><td>1812-1/00</td><td>Impressão de material de segurança</td></tr>
<tr><td>1813-0/01</td><td>Impressão de material para uso publicitário</td></tr>
<tr><td>1813-0/99</td><td>Impressão de material para outros usos</td></tr>
<tr><td>1821-1/00</td><td>Serviços de pré-impressão</td></tr>
<tr><td>1822-9/00</td><td>Serviços de acabamentos gráficos</td></tr>
<tr><td>1830-0/01</td><td>Reprodução de som em qualquer suporte</td></tr>
<tr><td>1830-0/02</td><td>Reprodução de vídeo em qualquer suporte</td></tr>
<tr><td>1830-0/03</td><td>Reprodução de software em qualquer suporte</td></tr>
<tr><td>1910-1/00</td><td>Coquerias</td></tr>
<tr><td>1921-7/00</td><td>Fabricação de produtos do refino de petróleo</td></tr>
<tr><td>1922-5/01</td><td>Formulação de combustíveis</td></tr>
<tr><td>1922-5/02</td><td>Rerrefino de óleos lubrificantes</td></tr>
<tr><td>1922-5/99</td><td>Fabricação de outros produtos derivados do petróleo, exceto produtos do refino</td></tr>
<tr><td>1931-4/00</td><td>Fabricação de álcool</td></tr>
<tr><td>1932-2/00</td><td>Fabricação de biocombustíveis, exceto álcool</td></tr>
<tr><td>2011-8/00</td><td>Fabricação de cloro e álcalis</td></tr>
<tr><td>2012-6/00</td><td>Fabricação de intermediários para fertilizantes</td></tr>
<tr><td>2013-4/00</td><td>Fabricação de adubos e fertilizantes</td></tr>
<tr><td>2014-2/00</td><td>Fabricação de gases industriais</td></tr>
<tr><td>2019-3/01</td><td>Elaboração de combustíveis nucleares</td></tr>
<tr><td>2019-3/99</td><td>Fabricação de outros produtos químicos inorgânicos não especificados anteriormente</td></tr>
<tr><td>2021-5/00</td><td>Fabricação de produtos petroquímicos básicos</td></tr>
<tr><td>2022-3/00</td><td>Fabricação de intermediários para plastificantes, resinas e fibras</td></tr>
<tr><td>2029-1/00</td><td>Fabricação de produtos químicos orgânicos não especificados anteriormente</td></tr>
<tr><td>2031-2/00</td><td>Fabricação de resinas termoplásticas</td></tr>
<tr><td>2032-1/00</td><td>Fabricação de resinas termofixas</td></tr>
<tr><td>2033-9/00</td><td>Fabricação de elastômeros</td></tr>
<tr><td>2040-1/00</td><td>Fabricação de fibras artificiais e sintéticas</td></tr>
<tr><td>2051-7/00</td><td>Fabricação de defensivos agrícolas</td></tr>
<tr><td>2052-5/00</td><td>Fabricação de desinfestantes domissanitários</td></tr>
<tr><td>2061-4/00</td><td>Fabricação de sabões e detergentes sintéticos</td></tr>
<tr><td>2062-2/00</td><td>Fabricação de produtos de limpeza e polimento</td></tr>
<tr><td>2063-1/00</td><td>Fabricação de cosméticos, produtos de perfumaria e de higiene pessoal</td></tr>
<tr><td>2071-1/00</td><td>Fabricação de tintas, vernizes, esmaltes e lacas</td></tr>
<tr><td>2072-0/00</td><td>Fabricação de tintas de impressão</td></tr>
<tr><td>2073-8/00</td><td>Fabricação de impermeabilizantes, solventes e produtos afins</td></tr>
<tr><td>2091-6/00</td><td>Fabricação de adesivos e selantes</td></tr>
<tr><td>2092-4/01</td><td>Fabricação de pólvoras, explosivos e detonantes</td></tr>
<tr><td>2092-4/02</td><td>Fabricação de artigos pirotécnicos</td></tr>
<tr><td>2092-4/03</td><td>Fabricação de fósforos de segurança</td></tr>
<tr><td>2093-2/00</td><td>Fabricação de aditivos de uso industrial</td></tr>
<tr><td>2094-1/00</td><td>Fabricação de catalisadores</td></tr>
<tr><td>2099-1/01</td><td>Fabricação de chapas, filmes, papéis e outros materiais e produtos químicos para fotografia</td></tr>
<tr><td>2099-1/99</td><td>Fabricação de outros produtos químicos não especificados anteriormente</td></tr>
<tr><td>2110-6/00</td><td>Fabricação de produtos farmoquímicos</td></tr>
<tr><td>2121-1/01</td><td>Fabricação de medicamentos alopáticos para uso humano</td></tr>
<tr><td>2121-1/02</td><td>Fabricação de medicamentos homeopáticos para uso humano</td></tr>
<tr><td>2121-1/03</td><td>Fabricação de medicamentos fitoterápicos para uso humano</td></tr>
<tr><td>2122-0/00</td><td>Fabricação de medicamentos para uso veterinário</td></tr>
<tr><td>2123-8/00</td><td>Fabricação de preparações farmacêuticas</td></tr>
<tr><td>2211-1/00</td><td>Fabricação de pneumáticos e de câmaras-de-ar</td></tr>
<tr><td>2212-9/00</td><td>Reforma de pneumáticos usados</td></tr>
<tr><td>2219-6/00</td><td>Fabricação de artefatos de borracha não especificados anteriormente</td></tr>
<tr><td>2221-8/00</td><td>Fabricação de laminados planos e tubulares de material plástico</td></tr>
<tr><td>2222-6/00</td><td>Fabricação de embalagens de material plástico</td></tr>
<tr><td>2223-4/00</td><td>Fabricação de tubos e acessórios de material plástico para uso na construção</td></tr>
<tr><td>2229-3/01</td><td>Fabricação de artefatos de material plástico para uso pessoal e doméstico</td></tr>
<tr><td>2229-3/02</td><td>Fabricação de artefatos de material plástico para usos industriais</td></tr>
<tr><td>2229-3/03</td><td>Fabricação de artefatos de material plástico para uso na construção, exceto tubos e acessórios</td></tr>
<tr><td>2229-3/99</td><td>Fabricação de artefatos de material plástico para outros usos não especificados anteriormente</td></tr>
<tr><td>2311-7/00</td><td>Fabricação de vidro plano e de segurança</td></tr>
<tr><td>2312-5/00</td><td>Fabricação de embalagens de vidro</td></tr>
<tr><td>2319-2/00</td><td>Fabricação de artigos de vidro</td></tr>
<tr><td>2320-6/00</td><td>Fabricação de cimento</td></tr>
<tr><td>2330-3/01</td><td>Fabricação de estruturas pré-moldadas de concreto armado, em série e sob encomenda</td></tr>
<tr><td>2330-3/02</td><td>Fabricação de artefatos de cimento para uso na construção</td></tr>
<tr><td>2330-3/03</td><td>Fabricação de artefatos de fibrocimento para uso na construção</td></tr>
<tr><td>2330-3/04</td><td>Fabricação de casas pré-moldadas de concreto</td></tr>
<tr><td>2330-3/05</td><td>Preparação de massa de concreto e argamassa para construção</td></tr>
<tr><td>2330-3/99</td><td>Fabricação de outros artefatos e produtos de concreto, cimento, fibrocimento, gesso e materiais semelhantes</td></tr>
<tr><td>2341-9/00</td><td>Fabricação de produtos cerâmicos refratários</td></tr>
<tr><td>2342-7/01</td><td>Fabricação de azulejos e pisos</td></tr>
<tr><td>2342-7/02</td><td>Fabricação de artefatos de cerâmica e barro cozido para uso na construção, exceto azulejos e pisos</td></tr>
<tr><td>2349-4/01</td><td>Fabricação de material sanitário de cerâmica</td></tr>
<tr><td>2349-4/99</td><td>Fabricação de produtos cerâmicos não-refratários não especificados anteriormente</td></tr>
<tr><td>2391-5/01</td><td>Britamento de pedras, exceto associado à extração</td></tr>
<tr><td>2391-5/02</td><td>Aparelhamento de pedras para construção, exceto associado à extração</td></tr>
<tr><td>2391-5/03</td><td>Aparelhamento de placas e execução de trabalhos em mármore, granito, ardósia e outras pedras</td></tr>
<tr><td>2392-3/00</td><td>Fabricação de cal e gesso</td></tr>
<tr><td>2399-1/01</td><td>Decoração, lapidação, gravação, vitrificação e outros trabalhos em cerâmica, louça, vidro e cristal</td></tr>
<tr><td>2399-1/99</td><td>Fabricação de outros produtos de minerais não-metálicos não especificados anteriormente</td></tr>
<tr><td>2411-3/00</td><td>Produção de ferro-gusa</td></tr>
<tr><td>2412-1/00</td><td>Produção de ferroligas</td></tr>
<tr><td>2421-1/00</td><td>Produção de semi-acabados de aço</td></tr>
<tr><td>2422-9/01</td><td>Produção de laminados planos de aço ao carbono, revestidos ou não</td></tr>
<tr><td>2422-9/02</td><td>Produção de laminados planos de aços especiais</td></tr>
<tr><td>2423-7/01</td><td>Produção de tubos de aço sem costura</td></tr>
<tr><td>2423-7/02</td><td>Produção de laminados longos de aço, exceto tubos</td></tr>
<tr><td>2424-5/01</td><td>Produção de arames de aço</td></tr>
<tr><td>2424-5/02</td><td>Produção de relaminados, trefilados e perfilados de aço, exceto arames</td></tr>
<tr><td>2431-8/00</td><td>Produção de tubos de aço com costura</td></tr>
<tr><td>2439-3/00</td><td>Produção de outros tubos de ferro e aço</td></tr>
<tr><td>2441-5/01</td><td>Produção de alumínio e suas ligas em formas primárias</td></tr>
<tr><td>2441-5/02</td><td>Produção de laminados de alumínio</td></tr>
<tr><td>2442-3/00</td><td>Metalurgia dos metais preciosos</td></tr>
<tr><td>2443-1/00</td><td>Metalurgia do cobre</td></tr>
<tr><td>2449-1/01</td><td>Produção de zinco em formas primárias</td></tr>
<tr><td>2449-1/02</td><td>Produção de laminados de zinco</td></tr>
<tr><td>2449-1/03</td><td>Produção de soldas e ânodos para galvanoplastia</td></tr>
<tr><td>2449-1/99</td><td>Metalurgia de outros metais não-ferrosos e suas ligas não especificados anteriormente</td></tr>
<tr><td>2451-2/00</td><td>Fundição de ferro e aço</td></tr>
<tr><td>2452-1/00</td><td>Fundição de metais não-ferrosos e suas ligas</td></tr>
<tr><td>2511-0/00</td><td>Fabricação de estruturas metálicas</td></tr>
<tr><td>2512-8/00</td><td>Fabricação de esquadrias de metal</td></tr>
<tr><td>2513-6/00</td><td>Fabricação de obras de caldeiraria pesada</td></tr>
<tr><td>2521-7/00</td><td>Fabricação de tanques, reservatórios metálicos e caldeiras para aquecimento central</td></tr>
<tr><td>2522-5/00</td><td>Fabricação de caldeiras geradoras de vapor, exceto para aquecimento central e para veículos</td></tr>
<tr><td>2531-4/01</td><td>Produção de forjados de aço</td></tr>
<tr><td>2531-4/02</td><td>Produção de forjados de metais não-ferrosos e suas ligas</td></tr>
<tr><td>2532-2/01</td><td>Produção de artefatos estampados de metal</td></tr>
<tr><td>2532-2/02</td><td>Metalurgia do pó</td></tr>
<tr><td>2539-0/00</td><td>Serviços de usinagem, solda, tratamento e revestimento em metais</td></tr>
<tr><td>2541-1/00</td><td>Fabricação de artigos de cutelaria</td></tr>
<tr><td>2542-0/00</td><td>Fabricação de artigos de serralheria, exceto esquadrias</td></tr>
<tr><td>2543-8/00</td><td>Fabricação de ferramentas</td></tr>
<tr><td>2550-1/01</td><td>Fabricação de equipamento bélico pesado, exceto veículos militares de combate</td></tr>
<tr><td>2550-1/02</td><td>Fabricação de armas de fogo e munições</td></tr>
<tr><td>2591-8/00</td><td>Fabricação de embalagens metálicas</td></tr>
<tr><td>2592-6/01</td><td>Fabricação de produtos de trefilados de metal padronizados</td></tr>
<tr><td>2592-6/02</td><td>Fabricação de produtos de trefilados de metal, exceto padronizados</td></tr>
<tr><td>2593-4/00</td><td>Fabricação de artigos de metal para uso doméstico e pessoal</td></tr>
<tr><td>2599-3/01</td><td>Serviços de confecção de armações metálicas para a construção</td></tr>
<tr><td>2599-3/99</td><td>Fabricação de outros produtos de metal não especificados anteriormente</td></tr>
<tr><td>2610-8/00</td><td>Fabricação de componentes eletrônicos</td></tr>
<tr><td>2621-3/00</td><td>Fabricação de equipamentos de informática</td></tr>
<tr><td>2622-1/00</td><td>Fabricação de periféricos para equipamentos de informática</td></tr>
<tr><td>2631-1/00</td><td>Fabricação de equipamentos transmissores de comunicação, peças e acessórios</td></tr>
<tr><td>2632-9/00</td><td>Fabricação de aparelhos telefônicos e de outros equipamentos de comunicação, peças e acessórios</td></tr>
<tr><td>2640-0/00</td><td>Fabricação de aparelhos de recepção, reprodução, gravação e amplificação de áudio e vídeo</td></tr>
<tr><td>2651-5/00</td><td>Fabricação de aparelhos e equipamentos de medida, teste e controle</td></tr>
<tr><td>2652-3/00</td><td>Fabricação de cronômetros e relógios</td></tr>
<tr><td>2660-4/00</td><td>Fabricação de aparelhos eletromédicos e eletroterapêuticos e equipamentos de irradiação</td></tr>
<tr><td>2670-1/01</td><td>Fabricação de equipamentos e instrumentos ópticos, peças e acessórios</td></tr>
<tr><td>2670-1/02</td><td>Fabricação de aparelhos fotográficos e cinematográficos, peças e acessórios</td></tr>
<tr><td>2680-9/00</td><td>Fabricação de mídias virgens, magnéticas e ópticas</td></tr>
<tr><td>2710-4/01</td><td>Fabricação de geradores de corrente contínua e alternada, peças e acessórios</td></tr>
<tr><td>2710-4/02</td><td>Fabricação de transformadores, indutores, conversores, sincronizadores e semelhantes, peças e acessórios</td></tr>
<tr><td>2710-4/03</td><td>Fabricação de motores elétricos, peças e acessórios</td></tr>
<tr><td>2721-0/00</td><td>Fabricação de pilhas, baterias e acumuladores elétricos, exceto para veículos automotores</td></tr>
<tr><td>2722-8/01</td><td>Fabricação de baterias e acumuladores para veículos automotores</td></tr>
<tr><td>2722-8/02</td><td>Recondicionamento de baterias e acumuladores para veículos automotores</td></tr>
<tr><td>2731-7/00</td><td>Fabricação de aparelhos e equipamentos para distribuição e controle de energia elétrica</td></tr>
<tr><td>2732-5/00</td><td>Fabricação de material elétrico para instalações em circuito de consumo</td></tr>
<tr><td>2733-3/00</td><td>Fabricação de fios, cabos e condutores elétricos isolados</td></tr>
<tr><td>2740-6/01</td><td>Fabricação de lâmpadas</td></tr>
<tr><td>2740-6/02</td><td>Fabricação de luminárias e outros equipamentos de iluminação</td></tr>
<tr><td>2751-1/00</td><td>Fabricação de fogões, refrigeradores e máquinas de lavar e secar para uso doméstico, peças e acessórios</td></tr>
<tr><td>2759-7/01</td><td>Fabricação de aparelhos elétricos de uso pessoal, peças e acessórios</td></tr>
<tr><td>2759-7/99</td><td>Fabricação de outros aparelhos eletrodomésticos não especificados anteriormente, peças e acessórios</td></tr>
<tr><td>2790-2/01</td><td>Fabricação de eletrodos, contatos e outros artigos de carvão e grafita para uso elétrico, eletroímãs e isoladores</td></tr>
<tr><td>2790-2/02</td><td>Fabricação de equipamentos para sinalização e alarme</td></tr>
<tr><td>2790-2/99</td><td>Fabricação de outros equipamentos e aparelhos elétricos não especificados anteriormente</td></tr>
<tr><td>2811-9/00</td><td>Fabricação de motores e turbinas, peças e acessórios, exceto para aviões e veículos rodoviários</td></tr>
<tr><td>2812-7/00</td><td>Fabricação de equipamentos hidráulicos e pneumáticos, peças e acessórios, exceto válvulas</td></tr>
<tr><td>2813-5/00</td><td>Fabricação de válvulas, registros e dispositivos semelhantes, peças e acessórios</td></tr>
<tr><td>2814-3/01</td><td>Fabricação de compressores para uso industrial, peças e acessórios</td></tr>
<tr><td>2814-3/02</td><td>Fabricação de compressores para uso não-industrial, peças e acessórios</td></tr>
<tr><td>2815-1/01</td><td>Fabricação de rolamentos para fins industriais</td></tr>
<tr><td>2815-1/02</td><td>Fabricação de equipamentos de transmissão para fins industriais, exceto rolamentos</td></tr>
<tr><td>2821-6/01</td><td>Fabricação de fornos industriais, aparelhos e equipamentos não-elétricos para instalações térmicas, peças e acessórios</td></tr>
<tr><td>2821-6/02</td><td>Fabricação de estufas e fornos elétricos para fins industriais, peças e acessórios</td></tr>
<tr><td>2822-4/01</td><td>Fabricação de máquinas, equipamentos e aparelhos para transporte e elevação de pessoas, peças e acessórios</td></tr>
<tr><td>2822-4/02</td><td>Fabricação de máquinas, equipamentos e aparelhos para transporte e elevação de cargas, peças e acessórios</td></tr>
<tr><td>2823-2/00</td><td>Fabricação de máquinas e aparelhos de refrigeração e ventilação para uso industrial e comercial, peças e acessórios</td></tr>
<tr><td>2824-1/01</td><td>Fabricação de aparelhos e equipamentos de ar condicionado para uso industrial</td></tr>
<tr><td>2824-1/02</td><td>Fabricação de aparelhos e equipamentos de ar condicionado para uso não-industrial</td></tr>
<tr><td>2825-9/00</td><td>Fabricação de máquinas e equipamentos para saneamento básico e ambiental, peças e acessórios</td></tr>
<tr><td>2829-1/01</td><td>Fabricação de máquinas de escrever, calcular e outros equipamentos não-eletrônicos para escritório, peças e acessórios</td></tr>
<tr><td>2829-1/99</td><td>Fabricação de outras máquinas e equipamentos de uso geral não especificados anteriormente, peças e acessórios</td></tr>
<tr><td>2831-3/00</td><td>Fabricação de tratores agrícolas, peças e acessórios</td></tr>
<tr><td>2832-1/00</td><td>Fabricação de equipamentos para irrigação agrícola, peças e acessórios</td></tr>
<tr><td>2833-0/00</td><td>Fabricação de máquinas e equipamentos para a agricultura e pecuária, peças e acessórios, exceto para irrigação</td></tr>
<tr><td>2840-2/00</td><td>Fabricação de máquinas-ferramenta, peças e acessórios</td></tr>
<tr><td>2851-8/00</td><td>Fabricação de máquinas e equipamentos para a prospecção e extração de petróleo, peças e acessórios</td></tr>
<tr><td>2852-6/00</td><td>Fabricação de outras máquinas e equipamentos para uso na extração mineral, peças e acessórios, exceto na extração de petróleo</td></tr>
<tr><td>2853-4/00</td><td>Fabricação de tratores, peças e acessórios, exceto agrícolas</td></tr>
<tr><td>2854-2/00</td><td>Fabricação de máquinas e equipamentos para terraplenagem, pavimentação e construção, peças e acessórios, exceto tratores</td></tr>
<tr><td>2861-5/00</td><td>Fabricação de máquinas para a indústria metalúrgica, peças e acessórios, exceto máquinas-ferramenta</td></tr>
<tr><td>2862-3/00</td><td>Fabricação de máquinas e equipamentos para as indústrias de alimentos, bebidas e fumo, peças e acessórios</td></tr>
<tr><td>2863-1/00</td><td>Fabricação de máquinas e equipamentos para a indústria têxtil, peças e acessórios</td></tr>
<tr><td>2864-0/00</td><td>Fabricação de máquinas e equipamentos para as indústrias do vestuário, do couro e de calçados, peças e acessórios</td></tr>
<tr><td>2865-8/00</td><td>Fabricação de máquinas e equipamentos para as indústrias de celulose, papel e papelão e artefatos, peças e acessórios</td></tr>
<tr><td>2866-6/00</td><td>Fabricação de máquinas e equipamentos para a indústria do plástico, peças e acessórios</td></tr>
<tr><td>2869-1/00</td><td>Fabricação de máquinas e equipamentos para uso industrial específico não especificados anteriormente, peças e acessórios</td></tr>
<tr><td>2910-7/01</td><td>Fabricação de automóveis, camionetas e utilitários</td></tr>
<tr><td>2910-7/02</td><td>Fabricação de chassis com motor para automóveis, camionetas e utilitários</td></tr>
<tr><td>2910-7/03</td><td>Fabricação de motores para automóveis, camionetas e utilitários</td></tr>
<tr><td>2920-4/01</td><td>Fabricação de caminhões e ônibus</td></tr>
<tr><td>2920-4/02</td><td>Fabricação de motores para caminhões e ônibus</td></tr>
<tr><td>2930-1/01</td><td>Fabricação de cabines, carrocerias e reboques para caminhões</td></tr>
<tr><td>2930-1/02</td><td>Fabricação de carrocerias para ônibus</td></tr>
<tr><td>2930-1/03</td><td>Fabricação de cabines, carrocerias e reboques para outros veículos automotores, exceto caminhões e ônibus</td></tr>
<tr><td>2941-7/00</td><td>Fabricação de peças e acessórios para o sistema motor de veículos automotores</td></tr>
<tr><td>2942-5/00</td><td>Fabricação de peças e acessórios para os sistemas de marcha e transmissão de veículos automotores</td></tr>
<tr><td>2943-3/00</td><td>Fabricação de peças e acessórios para o sistema de freios de veículos automotores</td></tr>
<tr><td>2944-1/00</td><td>Fabricação de peças e acessórios para o sistema de direção e suspensão de veículos automotores</td></tr>
<tr><td>2945-0/00</td><td>Fabricação de material elétrico e eletrônico para veículos automotores, exceto baterias</td></tr>
<tr><td>2949-2/01</td><td>Fabricação de bancos e estofados para veículos automotores</td></tr>
<tr><td>2949-2/99</td><td>Fabricação de outras peças e acessórios para veículos automotores não especificadas anteriormente</td></tr>
<tr><td>2950-6/00</td><td>Recondicionamento e recuperação de motores para veículos automotores</td></tr>
<tr><td>3011-3/01</td><td>Construção de embarcações de grande porte</td></tr>
<tr><td>3011-3/02</td><td>Construção de embarcações para uso comercial e para usos especiais, exceto de grande porte</td></tr>
<tr><td>3012-1/00</td><td>Construção de embarcações para esporte e lazer</td></tr>
<tr><td>3031-8/00</td><td>Fabricação de locomotivas, vagões e outros materiais rodantes</td></tr>
<tr><td>3032-6/00</td><td>Fabricação de peças e acessórios para veículos ferroviários</td></tr>
<tr><td>3041-5/00</td><td>Fabricação de aeronaves</td></tr>
<tr><td>3042-3/00</td><td>Fabricação de turbinas, motores e outros componentes e peças para aeronaves</td></tr>
<tr><td>3050-4/00</td><td>Fabricação de veículos militares de combate</td></tr>
<tr><td>3091-1/00</td><td>Fabricação de motocicletas, peças e acessórios</td></tr>
<tr><td>3092-0/00</td><td>Fabricação de bicicletas e triciclos não-motorizados, peças e acessórios</td></tr>
<tr><td>3099-7/00</td><td>Fabricação de equipamentos de transporte não especificados anteriormente</td></tr>
<tr><td>3101-2/00</td><td>Fabricação de móveis com predominância de madeira</td></tr>
<tr><td>3102-1/00</td><td>Fabricação de móveis com predominância de metal</td></tr>
<tr><td>3103-9/00</td><td>Fabricação de móveis de outros materiais, exceto madeira e metal</td></tr>
<tr><td>3104-7/00</td><td>Fabricação de colchões</td></tr>
<tr><td>3211-6/01</td><td>Lapidação de gemas</td></tr>
<tr><td>3211-6/02</td><td>Fabricação de artefatos de joalheria e ourivesaria</td></tr>
<tr><td>3211-6/03</td><td>Cunhagem de moedas e medalhas</td></tr>
<tr><td>3212-4/00</td><td>Fabricação de bijuterias e artefatos semelhantes</td></tr>
<tr><td>3220-5/00</td><td>Fabricação de instrumentos musicais, peças e acessórios</td></tr>
<tr><td>3230-2/00</td><td>Fabricação de artefatos para pesca e esporte</td></tr>
<tr><td>3240-0/01</td><td>Fabricação de jogos eletrônicos</td></tr>
<tr><td>3240-0/02</td><td>Fabricação de mesas de bilhar, de sinuca e acessórios não associada à locação</td></tr>
<tr><td>3240-0/03</td><td>Fabricação de mesas de bilhar, de sinuca e acessórios associada à locação</td></tr>
<tr><td>3240-0/99</td><td>Fabricação de outros brinquedos e jogos recreativos não especificados anteriormente</td></tr>
<tr><td>3250-7/01</td><td>Fabricação de instrumentos não-eletrônicos e utensílios para uso médico, cirúrgico, odontológico e de laboratório</td></tr>
<tr><td>3250-7/02</td><td>Fabricação de mobiliário para uso médico, cirúrgico, odontológico e de laboratório</td></tr>
<tr><td>3250-7/03</td><td>Fabricação de aparelhos e utensílios para correção de defeitos físicos e aparelhos ortopédicos em geral sob encomenda</td></tr>
<tr><td>3250-7/04</td><td>Fabricação de aparelhos e utensílios para correção de defeitos físicos e aparelhos ortopédicos em geral, exceto sob encomenda</td></tr>
<tr><td>3250-7/05</td><td>Fabricação de materiais para medicina e odontologia</td></tr>
<tr><td>3250-7/06</td><td>Serviços de prótese dentária</td></tr>
<tr><td>3250-7/07</td><td>Fabricação de artigos ópticos</td></tr>
<tr><td>3250-7/08</td><td>Fabricação de artefatos de tecido não tecido para uso odonto-médico-hospitalar</td></tr>
<tr><td>3291-4/00</td><td>Fabricação de escovas, pincéis e vassouras</td></tr>
<tr><td>3292-2/01</td><td>Fabricação de roupas de proteção e segurança e resistentes a fogo</td></tr>
<tr><td>3292-2/02</td><td>Fabricação de equipamentos e acessórios para segurança pessoal e profissional</td></tr>
<tr><td>3299-0/01</td><td>Fabricação de guarda-chuvas e similares</td></tr>
<tr><td>3299-0/02</td><td>Fabricação de canetas, lápis e outros artigos para escritório</td></tr>
<tr><td>3299-0/03</td><td>Fabricação de letras, letreiros e placas de qualquer material, exceto luminosos</td></tr>
<tr><td>3299-0/04</td><td>Fabricação de painéis e letreiros luminosos</td></tr>
<tr><td>3299-0/05</td><td>Fabricação de aviamentos para costura</td></tr>
<tr><td>3299-0/99</td><td>Fabricação de produtos diversos não especificados anteriormente</td></tr>
<tr><td>3311-2/00</td><td>Manutenção e reparação de tanques, reservatórios metálicos e caldeiras, exceto para veículos</td></tr>
<tr><td>3312-1/02</td><td>Manutenção e reparação de aparelhos e instrumentos de medida, teste e controle</td></tr>
<tr><td>3312-1/03</td><td>Manutenção e reparação de aparelhos eletromédicos e eletroterapêuticos e equipamentos de irradiação</td></tr>
<tr><td>3312-1/04</td><td>Manutenção e reparação de equipamentos e instrumentos ópticos</td></tr>
<tr><td>3313-9/01</td><td>Manutenção e reparação de geradores, transformadores e motores elétricos</td></tr>
<tr><td>3313-9/02</td><td>Manutenção e reparação de baterias e acumuladores elétricos, exceto para veículos</td></tr>
<tr><td>3313-9/99</td><td>Manutenção e reparação de máquinas, aparelhos e materiais elétricos não especificados anteriormente</td></tr>
<tr><td>3314-7/01</td><td>Manutenção e reparação de máquinas motrizes não-elétricas</td></tr>
<tr><td>3314-7/02</td><td>Manutenção e reparação de equipamentos hidráulicos e pneumáticos, exceto válvulas</td></tr>
<tr><td>3314-7/03</td><td>Manutenção e reparação de válvulas industriais</td></tr>
<tr><td>3314-7/04</td><td>Manutenção e reparação de compressores</td></tr>
<tr><td>3314-7/05</td><td>Manutenção e reparação de equipamentos de transmissão para fins industriais</td></tr>
<tr><td>3314-7/06</td><td>Manutenção e reparação de máquinas, aparelhos e equipamentos para instalações térmicas</td></tr>
<tr><td>3314-7/07</td><td>Manutenção e reparação de máquinas e aparelhos de refrigeração e ventilação para uso industrial e comercial</td></tr>
<tr><td>3314-7/08</td><td>Manutenção e reparação de máquinas, equipamentos e aparelhos para transporte e elevação de cargas</td></tr>
<tr><td>3314-7/09</td><td>Manutenção e reparação de máquinas de escrever, calcular e de outros equipamentos não-eletrônicos para escritório</td></tr>
<tr><td>3314-7/10</td><td>Manutenção e reparação de máquinas e equipamentos para uso geral não especificados anteriormente</td></tr>
<tr><td>3314-7/11</td><td>Manutenção e reparação de máquinas e equipamentos para agricultura e pecuária</td></tr>
<tr><td>3314-7/12</td><td>Manutenção e reparação de tratores agrícolas</td></tr>
<tr><td>3314-7/13</td><td>Manutenção e reparação de máquinas-ferramenta</td></tr>
<tr><td>3314-7/14</td><td>Manutenção e reparação de máquinas e equipamentos para a prospecção e extração de petróleo</td></tr>
<tr><td>3314-7/15</td><td>Manutenção e reparação de máquinas e equipamentos para uso na extração mineral, exceto na extração de petróleo</td></tr>
<tr><td>3314-7/16</td><td>Manutenção e reparação de tratores, exceto agrícolas</td></tr>
<tr><td>3314-7/17</td><td>Manutenção e reparação de máquinas e equipamentos de terraplenagem, pavimentação e construção, exceto tratores</td></tr>
<tr><td>3314-7/18</td><td>Manutenção e reparação de máquinas para a indústria metalúrgica, exceto máquinas-ferramenta</td></tr>
<tr><td>3314-7/19</td><td>Manutenção e reparação de máquinas e equipamentos para as indústrias de alimentos, bebidas e fumo</td></tr>
<tr><td>3314-7/20</td><td>Manutenção e reparação de máquinas e equipamentos para a indústria têxtil, do vestuário, do couro e calçados</td></tr>
<tr><td>3314-7/21</td><td>Manutenção e reparação de máquinas e aparelhos para a indústria de celulose, papel e papelão e artefatos</td></tr>
<tr><td>3314-7/22</td><td>Manutenção e reparação de máquinas e aparelhos para a indústria do plástico</td></tr>
<tr><td>3314-7/99</td><td>Manutenção e reparação de outras máquinas e equipamentos para usos industriais não especificados anteriormente</td></tr>
<tr><td>3315-5/00</td><td>Manutenção e reparação de veículos ferroviários</td></tr>
<tr><td>3316-3/01</td><td>Manutenção e reparação de aeronaves, exceto a manutenção na pista</td></tr>
<tr><td>3316-3/02</td><td>Manutenção de aeronaves na pista</td></tr>
<tr><td>3317-1/01</td><td>Manutenção e reparação de embarcações e estruturas flutuantes</td></tr>
<tr><td>3317-1/02</td><td>Manutenção e reparação de embarcações para esporte e lazer</td></tr>
<tr><td>3319-8/00</td><td>Manutenção e reparação de equipamentos e produtos não especificados anteriormente</td></tr>
<tr><td>3321-0/00</td><td>Instalação de máquinas e equipamentos industriais</td></tr>
<tr><td>3329-5/01</td><td>Serviços de montagem de móveis de qualquer material</td></tr>
<tr><td>3329-5/99</td><td>Instalação de outros equipamentos não especificados anteriormente</td></tr>
<tr><td>3511-5/00</td><td>Geração de energia elétrica</td></tr>
<tr><td>3512-3/00</td><td>Transmissão de energia elétrica</td></tr>
<tr><td>3513-1/00</td><td>Comércio atacadista de energia elétrica</td></tr>
<tr><td>3514-0/00</td><td>Distribuição de energia elétrica</td></tr>
<tr><td>3520-4/01</td><td>Produção de gás; processamento de gás natural</td></tr>
<tr><td>3520-4/02</td><td>Distribuição de combustíveis gasosos por redes urbanas</td></tr>
<tr><td>3530-1/00</td><td>Produção e distribuição de vapor, água quente e ar condicionado</td></tr>
<tr><td>3600-6/01</td><td>Captação, tratamento e distribuição de água</td></tr>
<tr><td>3600-6/02</td><td>Distribuição de água por caminhões</td></tr>
<tr><td>3701-1/00</td><td>Gestão de redes de esgoto</td></tr>
<tr><td>3702-9/00</td><td>Atividades relacionadas a esgoto, exceto a gestão de redes</td></tr>
<tr><td>3811-4/00</td><td>Coleta de resíduos não-perigosos</td></tr>
<tr><td>3812-2/00</td><td>Coleta de resíduos perigosos</td></tr>
<tr><td>3821-1/00</td><td>Tratamento e disposição de resíduos não-perigosos</td></tr>
<tr><td>3822-0/00</td><td>Tratamento e disposição de resíduos perigosos</td></tr>
<tr><td>3831-9/01</td><td>Recuperação de sucatas de alumínio</td></tr>
<tr><td>3831-9/99</td><td>Recuperação de materiais metálicos, exceto alumínio</td></tr>
<tr><td>3832-7/00</td><td>Recuperação de materiais plásticos</td></tr>
<tr><td>3839-4/01</td><td>Usinas de compostagem</td></tr>
<tr><td>3839-4/99</td><td>Recuperação de materiais não especificados anteriormente</td></tr>
<tr><td>3900-5/00</td><td>Descontaminação e outros serviços de gestão de resíduos</td></tr>
<tr><td>4110-7/00</td><td>Incorporação de empreendimentos imobiliários</td></tr>
<tr><td>4120-4/00</td><td>Construção de edifícios</td></tr>
<tr><td>4211-1/01</td><td>Construção de rodovias e ferrovias</td></tr>
<tr><td>4211-1/02</td><td>Pintura para sinalização em pistas rodoviárias e aeroportos</td></tr>
<tr><td>4212-0/00</td><td>Construção de obras-de-arte especiais</td></tr>
<tr><td>4213-8/00</td><td>Obras de urbanização - ruas, praças e calçadas</td></tr>
<tr><td>4221-9/01</td><td>Construção de barragens e represas para geração de energia elétrica</td></tr>
<tr><td>4221-9/02</td><td>Construção de estações e redes de distribuição de energia elétrica</td></tr>
<tr><td>4221-9/03</td><td>Manutenção de redes de distribuição de energia elétrica</td></tr>
<tr><td>4221-9/04</td><td>Construção de estações e redes de telecomunicações</td></tr>
<tr><td>4221-9/05</td><td>Manutenção de estações e redes de telecomunicações</td></tr>
<tr><td>4222-7/01</td><td>Construção de redes de abastecimento de água, coleta de esgoto e construções correlatas, exceto obras de irrigação</td></tr>
<tr><td>4222-7/02</td><td>Obras de irrigação</td></tr>
<tr><td>4223-5/00</td><td>Construção de redes de transportes por dutos, exceto para água e esgoto</td></tr>
<tr><td>4291-0/00</td><td>Obras portuárias, marítimas e fluviais</td></tr>
<tr><td>4292-8/01</td><td>Montagem de estruturas metálicas</td></tr>
<tr><td>4292-8/02</td><td>Obras de montagem industrial</td></tr>
<tr><td>4299-5/01</td><td>Construção de instalações esportivas e recreativas</td></tr>
<tr><td>4299-5/99</td><td>Outras obras de engenharia civil não especificadas anteriormente</td></tr>
<tr><td>4311-8/01</td><td>Demolição de edifícios e outras estruturas</td></tr>
<tr><td>4311-8/02</td><td>Preparação de canteiro e limpeza de terreno</td></tr>
<tr><td>4312-6/00</td><td>Perfurações e sondagens</td></tr>
<tr><td>4313-4/00</td><td>Obras de terraplenagem</td></tr>
<tr><td>4319-3/00</td><td>Serviços de preparação do terreno não especificados anteriormente</td></tr>
<tr><td>4321-5/00</td><td>Instalação e manutenção elétrica</td></tr>
<tr><td>4322-3/01</td><td>Instalações hidráulicas, sanitárias e de gás</td></tr>
<tr><td>4322-3/02</td><td>Instalação e manutenção de sistemas centrais de ar condicionado, de ventilação e refrigeração</td></tr>
<tr><td>4322-3/03</td><td>Instalações de sistema de prevenção contra incêndio</td></tr>
<tr><td>4329-1/01</td><td>Instalação de painéis publicitários</td></tr>
<tr><td>4329-1/02</td><td>Instalação de equipamentos para orientação à navegação marítima, fluvial e lacustre</td></tr>
<tr><td>4329-1/03</td><td>Instalação, manutenção e reparação de elevadores, escadas e esteiras rolantes, exceto de fabricação própria</td></tr>
<tr><td>4329-1/04</td><td>Montagem e instalação de sistemas e equipamentos de iluminação e sinalização em vias públicas, portos e aeroportos</td></tr>
<tr><td>4329-1/05</td><td>Tratamentos térmicos, acústicos ou de vibração</td></tr>
<tr><td>4329-1/99</td><td>Outras obras de instalações em construções não especificadas anteriormente</td></tr>
<tr><td>4330-4/01</td><td>Impermeabilização em obras de engenharia civil</td></tr>
<tr><td>4330-4/02</td><td>Instalação de portas, janelas, tetos, divisórias e armários embutidos de qualquer material</td></tr>
<tr><td>4330-4/03</td><td>Obras de acabamento em gesso e estuque</td></tr>
<tr><td>4330-4/04</td><td>Serviços de pintura de edifícios em geral</td></tr>
<tr><td>4330-4/05</td><td>Aplicação de revestimentos e de resinas em interiores e exteriores</td></tr>
<tr><td>4330-4/99</td><td>Outras obras de acabamento da construção</td></tr>
<tr><td>4391-6/00</td><td>Obras de fundações</td></tr>
<tr><td>4399-1/01</td><td>Administração de obras</td></tr>
<tr><td>4399-1/02</td><td>Montagem e desmontagem de andaimes e outras estruturas temporárias</td></tr>
<tr><td>4399-1/03</td><td>Obras de alvenaria</td></tr>
<tr><td>4399-1/04</td><td>Serviços de operação e fornecimento de equipamentos para transporte e elevação de cargas e pessoas para uso em obras</td></tr>
<tr><td>4399-1/05</td><td>Perfuração e construção de poços de água</td></tr>
<tr><td>4399-1/99</td><td>Serviços especializados para construção não especificados anteriormente</td></tr>
<tr><td>4511-1/01</td><td>Comércio a varejo de automóveis, camionetas e utilitários novos</td></tr>
<tr><td>4511-1/02</td><td>Comércio a varejo de automóveis, camionetas e utilitários usados</td></tr>
<tr><td>4511-1/03</td><td>Comércio por atacado de automóveis, camionetas e utilitários novos e usados</td></tr>
<tr><td>4511-1/04</td><td>Comércio por atacado de caminhões novos e usados</td></tr>
<tr><td>4511-1/05</td><td>Comércio por atacado de reboques e semi-reboques novos e usados</td></tr>
<tr><td>4511-1/06</td><td>Comércio por atacado de ônibus e microônibus novos e usados</td></tr>
<tr><td>4512-9/01</td><td>Representantes comerciais e agentes do comércio de veículos automotores</td></tr>
<tr><td>4512-9/02</td><td>Comércio sob consignação de veículos automotores</td></tr>
<tr><td>4520-0/01</td><td>Serviços de manutenção e reparação mecânica de veículos automotores</td></tr>
<tr><td>4520-0/02</td><td>Serviços de lanternagem ou funilaria e pintura de veículos automotores</td></tr>
<tr><td>4520-0/03</td><td>Serviços de manutenção e reparação elétrica de veículos automotores</td></tr>
<tr><td>4520-0/04</td><td>Serviços de alinhamento e balanceamento de veículos automotores</td></tr>
<tr><td>4520-0/05</td><td>Serviços de lavagem, lubrificação e polimento de veículos automotores</td></tr>
<tr><td>4520-0/06</td><td>Serviços de borracharia para veículos automotores</td></tr>
<tr><td>4520-0/07</td><td>Serviços de instalação, manutenção e reparação de acessórios para veículos automotores</td></tr>
<tr><td>4530-7/01</td><td>Comércio por atacado de peças e acessórios novos para veículos automotores</td></tr>
<tr><td>4530-7/02</td><td>Comércio por atacado de pneumáticos e câmaras-de-ar</td></tr>
<tr><td>4530-7/03</td><td>Comércio a varejo de peças e acessórios novos para veículos automotores</td></tr>
<tr><td>4530-7/04</td><td>Comércio a varejo de peças e acessórios usados para veículos automotores</td></tr>
<tr><td>4530-7/05</td><td>Comércio a varejo de pneumáticos e câmaras-de-ar</td></tr>
<tr><td>4530-7/06</td><td>Representantes comerciais e agentes do comércio de peças e acessórios novos e usados para veículos automotores</td></tr>
<tr><td>4541-2/01</td><td>Comércio por atacado de motocicletas e motonetas</td></tr>
<tr><td>4541-2/02</td><td>Comércio por atacado de peças e acessórios para motocicletas e motonetas</td></tr>
<tr><td>4541-2/03</td><td>Comércio a varejo de motocicletas e motonetas novas</td></tr>
<tr><td>4541-2/04</td><td>Comércio a varejo de motocicletas e motonetas usadas</td></tr>
<tr><td>4541-2/05</td><td>Comércio a varejo de peças e acessórios para motocicletas e motonetas</td></tr>
<tr><td>4542-1/01</td><td>Representantes comerciais e agentes do comércio de motocicletas e motonetas, peças e acessórios</td></tr>
<tr><td>4542-1/02</td><td>Comércio sob consignação de motocicletas e motonetas</td></tr>
<tr><td>4543-9/00</td><td>Manutenção e reparação de motocicletas e motonetas</td></tr>
<tr><td>4611-7/00</td><td>Representantes comerciais e agentes do comércio de matérias-primas agrícolas e animais vivos</td></tr>
<tr><td>4612-5/00</td><td>Representantes comerciais e agentes do comércio de combustíveis, minerais, produtos siderúrgicos e químicos</td></tr>
<tr><td>4613-3/00</td><td>Representantes comerciais e agentes do comércio de madeira, material de construção e ferragens</td></tr>
<tr><td>4614-1/00</td><td>Representantes comerciais e agentes do comércio de máquinas, equipamentos, embarcações e aeronaves</td></tr>
<tr><td>4615-0/00</td><td>Representantes comerciais e agentes do comércio de eletrodomésticos, móveis e artigos de uso doméstico</td></tr>
<tr><td>4616-8/00</td><td>Representantes comerciais e agentes do comércio de têxteis, vestuário, calçados e artigos de viagem</td></tr>
<tr><td>4617-6/00</td><td>Representantes comerciais e agentes do comércio de produtos alimentícios, bebidas e fumo</td></tr>
<tr><td>4618-4/01</td><td>Representantes comerciais e agentes do comércio de medicamentos, cosméticos e produtos de perfumaria</td></tr>
<tr><td>4618-4/02</td><td>Representantes comerciais e agentes do comércio de instrumentos e materiais odonto-médico-hospitalares</td></tr>
<tr><td>4618-4/03</td><td>Representantes comerciais e agentes do comércio de jornais, revistas e outras publicações</td></tr>
<tr><td>4618-4/99</td><td>Outros representantes comerciais e agentes do comércio especializado em produtos não especificados anteriormente</td></tr>
<tr><td>4619-2/00</td><td>Representantes comerciais e agentes do comércio de mercadorias em geral não especializado</td></tr>
<tr><td>4621-4/00</td><td>Comércio atacadista de café em grão</td></tr>
<tr><td>4622-2/00</td><td>Comércio atacadista de soja</td></tr>
<tr><td>4623-1/01</td><td>Comércio atacadista de animais vivos</td></tr>
<tr><td>4623-1/02</td><td>Comércio atacadista de couros, lãs, peles e outros subprodutos não-comestíveis de origem animal</td></tr>
<tr><td>4623-1/03</td><td>Comércio atacadista de algodão</td></tr>
<tr><td>4623-1/04</td><td>Comércio atacadista de fumo em folha não beneficiado</td></tr>
<tr><td>4623-1/05</td><td>Comércio atacadista de cacau</td></tr>
<tr><td>4623-1/06</td><td>Comércio atacadista de sementes, flores, plantas e gramas</td></tr>
<tr><td>4623-1/07</td><td>Comércio atacadista de sisal</td></tr>
<tr><td>4623-1/08</td><td>Comércio atacadista de matérias-primas agrícolas com atividade de fracionamento e acondicionamento associada</td></tr>
<tr><td>4623-1/09</td><td>Comércio atacadista de alimentos para animais</td></tr>
<tr><td>4623-1/99</td><td>Comércio atacadista de matérias-primas agrícolas não especificadas anteriormente</td></tr>
<tr><td>4631-1/00</td><td>Comércio atacadista de leite e laticínios</td></tr>
<tr><td>4632-0/01</td><td>Comércio atacadista de cereais e leguminosas beneficiados</td></tr>
<tr><td>4632-0/02</td><td>Comércio atacadista de farinhas, amidos e féculas</td></tr>
<tr><td>4632-0/03</td><td>Comércio atacadista de cereais e leguminosas beneficiados, farinhas, amidos e féculas, com atividade de fracionamento e acondicionamento associada</td></tr>
<tr><td>4633-8/01</td><td>Comércio atacadista de frutas, verduras, raízes, tubérculos, hortaliças e legumes frescos</td></tr>
<tr><td>4633-8/02</td><td>Comércio atacadista de aves vivas e ovos</td></tr>
<tr><td>4633-8/03</td><td>Comércio atacadista de coelhos e outros pequenos animais vivos para alimentação</td></tr>
<tr><td>4634-6/01</td><td>Comércio atacadista de carnes bovinas e suínas e derivados</td></tr>
<tr><td>4634-6/02</td><td>Comércio atacadista de aves abatidas e derivados</td></tr>
<tr><td>4634-6/03</td><td>Comércio atacadista de pescados e frutos do mar</td></tr>
<tr><td>4634-6/99</td><td>Comércio atacadista de carnes e derivados de outros animais</td></tr>
<tr><td>4635-4/01</td><td>Comércio atacadista de água mineral</td></tr>
<tr><td>4635-4/02</td><td>Comércio atacadista de cerveja, chope e refrigerante</td></tr>
<tr><td>4635-4/03</td><td>Comércio atacadista de bebidas com atividade de fracionamento e acondicionamento associada</td></tr>
<tr><td>4635-4/99</td><td>Comércio atacadista de bebidas não especificadas anteriormente</td></tr>
<tr><td>4636-2/01</td><td>Comércio atacadista de fumo beneficiado</td></tr>
<tr><td>4636-2/02</td><td>Comércio atacadista de cigarros, cigarrilhas e charutos</td></tr>
<tr><td>4637-1/01</td><td>Comércio atacadista de café torrado, moído e solúvel</td></tr>
<tr><td>4637-1/02</td><td>Comércio atacadista de açúcar</td></tr>
<tr><td>4637-1/03</td><td>Comércio atacadista de óleos e gorduras</td></tr>
<tr><td>4637-1/04</td><td>Comércio atacadista de pães, bolos, biscoitos e similares</td></tr>
<tr><td>4637-1/05</td><td>Comércio atacadista de massas alimentícias</td></tr>
<tr><td>4637-1/06</td><td>Comércio atacadista de sorvetes</td></tr>
<tr><td>4637-1/07</td><td>Comércio atacadista de chocolates, confeitos, balas, bombons e semelhantes</td></tr>
<tr><td>4637-1/99</td><td>Comércio atacadista especializado em outros produtos alimentícios não especificados anteriormente</td></tr>
<tr><td>4639-7/01</td><td>Comércio atacadista de produtos alimentícios em geral</td></tr>
<tr><td>4639-7/02</td><td>Comércio atacadista de produtos alimentícios em geral, com atividade de fracionamento e acondicionamento associada</td></tr>
<tr><td>4641-9/01</td><td>Comércio atacadista de tecidos</td></tr>
<tr><td>4641-9/02</td><td>Comércio atacadista de artigos de cama, mesa e banho</td></tr>
<tr><td>4641-9/03</td><td>Comércio atacadista de artigos de armarinho</td></tr>
<tr><td>4642-7/01</td><td>Comércio atacadista de artigos do vestuário e acessórios, exceto profissionais e de segurança</td></tr>
<tr><td>4642-7/02</td><td>Comércio atacadista de roupas e acessórios para uso profissional e de segurança do trabalho</td></tr>
<tr><td>4643-5/01</td><td>Comércio atacadista de calçados</td></tr>
<tr><td>4643-5/02</td><td>Comércio atacadista de bolsas, malas e artigos de viagem</td></tr>
<tr><td>4644-3/01</td><td>Comércio atacadista de medicamentos e drogas de uso humano</td></tr>
<tr><td>4644-3/02</td><td>Comércio atacadista de medicamentos e drogas de uso veterinário</td></tr>
<tr><td>4645-1/01</td><td>Comércio atacadista de instrumentos e materiais para uso médico, cirúrgico, hospitalar e de laboratórios</td></tr>
<tr><td>4645-1/02</td><td>Comércio atacadista de próteses e artigos de ortopedia</td></tr>
<tr><td>4645-1/03</td><td>Comércio atacadista de produtos odontológicos</td></tr>
<tr><td>4646-0/01</td><td>Comércio atacadista de cosméticos e produtos de perfumaria</td></tr>
<tr><td>4646-0/02</td><td>Comércio atacadista de produtos de higiene pessoal</td></tr>
<tr><td>4647-8/01</td><td>Comércio atacadista de artigos de escritório e de papelaria</td></tr>
<tr><td>4647-8/02</td><td>Comércio atacadista de livros, jornais e outras publicações</td></tr>
<tr><td>4649-4/01</td><td>Comércio atacadista de equipamentos elétricos de uso pessoal e doméstico</td></tr>
<tr><td>4649-4/02</td><td>Comércio atacadista de aparelhos eletrônicos de uso pessoal e doméstico</td></tr>
<tr><td>4649-4/03</td><td>Comércio atacadista de bicicletas, triciclos e outros veículos recreativos</td></tr>
<tr><td>4649-4/04</td><td>Comércio atacadista de móveis e artigos de colchoaria</td></tr>
<tr><td>4649-4/05</td><td>Comércio atacadista de artigos de tapeçaria; persianas e cortinas</td></tr>
<tr><td>4649-4/06</td><td>Comércio atacadista de lustres, luminárias e abajures</td></tr>
<tr><td>4649-4/07</td><td>Comércio atacadista de filmes, CDs, DVDs, fitas e discos</td></tr>
<tr><td>4649-4/08</td><td>Comércio atacadista de produtos de higiene, limpeza e conservação domiciliar</td></tr>
<tr><td>4649-4/09</td><td>Comércio atacadista de produtos de higiene, limpeza e conservação domiciliar, com atividade de fracionamento e acondicionamento associada</td></tr>
<tr><td>4649-4/10</td><td>Comércio atacadista de jóias, relógios e bijuterias, inclusive pedras preciosas e semipreciosas lapidadas</td></tr>
<tr><td>4649-4/99</td><td>Comércio atacadista de outros equipamentos e artigos de uso pessoal e doméstico não especificados anteriormente</td></tr>
<tr><td>4651-6/01</td><td>Comércio atacadista de equipamentos de informática</td></tr>
<tr><td>4651-6/02</td><td>Comércio atacadista de suprimentos para informática</td></tr>
<tr><td>4652-4/00</td><td>Comércio atacadista de componentes eletrônicos e equipamentos de telefonia e comunicação</td></tr>
<tr><td>4661-3/00</td><td>Comércio atacadista de máquinas, aparelhos e equipamentos para uso agropecuário; partes e peças</td></tr>
<tr><td>4662-1/00</td><td>Comércio atacadista de máquinas, equipamentos para terraplenagem, mineração e construção; partes e peças</td></tr>
<tr><td>4663-0/00</td><td>Comércio atacadista de máquinas e equipamentos para uso industrial; partes e peças</td></tr>
<tr><td>4664-8/00</td><td>Comércio atacadista de máquinas, aparelhos e equipamentos para uso odonto-médico-hospitalar; partes e peças</td></tr>
<tr><td>4665-6/00</td><td>Comércio atacadista de máquinas e equipamentos para uso comercial; partes e peças</td></tr>
<tr><td>4669-9/01</td><td>Comércio atacadista de bombas e compressores; partes e peças</td></tr>
<tr><td>4669-9/99</td><td>Comércio atacadista de outras máquinas e equipamentos não especificados anteriormente; partes e peças</td></tr>
<tr><td>4671-1/00</td><td>Comércio atacadista de madeira e produtos derivados</td></tr>
<tr><td>4672-9/00</td><td>Comércio atacadista de ferragens e ferramentas</td></tr>
<tr><td>4673-7/00</td><td>Comércio atacadista de material elétrico</td></tr>
<tr><td>4674-5/00</td><td>Comércio atacadista de cimento</td></tr>
<tr><td>4679-6/01</td><td>Comércio atacadista de tintas, vernizes e similares</td></tr>
<tr><td>4679-6/02</td><td>Comércio atacadista de mármores e granitos</td></tr>
<tr><td>4679-6/03</td><td>Comércio atacadista de vidros, espelhos e vitrais</td></tr>
<tr><td>4679-6/04</td><td>Comércio atacadista especializado de materiais de construção não especificados anteriormente</td></tr>
<tr><td>4679-6/99</td><td>Comércio atacadista de materiais de construção em geral</td></tr>
<tr><td>4681-8/01</td><td>Comércio atacadista de álcool carburante, biodiesel, gasolina e demais derivados de petróleo, exceto lubrificantes, não realizado por transportador retalhista (TRR)</td></tr>
<tr><td>4681-8/02</td><td>Comércio atacadista de combustíveis realizado por transportador retalhista (TRR)</td></tr>
<tr><td>4681-8/03</td><td>Comércio atacadista de combustíveis de origem vegetal, exceto álcool carburante</td></tr>
<tr><td>4681-8/04</td><td>Comércio atacadista de combustíveis de origem mineral em bruto</td></tr>
<tr><td>4681-8/05</td><td>Comércio atacadista de lubrificantes</td></tr>
<tr><td>4682-6/00</td><td>Comércio atacadista de gás liqüefeito de petróleo (GLP)</td></tr>
<tr><td>4683-4/00</td><td>Comércio atacadista de defensivos agrícolas, adubos, fertilizantes e corretivos do solo</td></tr>
<tr><td>4684-2/01</td><td>Comércio atacadista de resinas e elastômeros</td></tr>
<tr><td>4684-2/02</td><td>Comércio atacadista de solventes</td></tr>
<tr><td>4684-2/99</td><td>Comércio atacadista de outros produtos químicos e petroquímicos não especificados anteriormente</td></tr>
<tr><td>4685-1/00</td><td>Comércio atacadista de produtos siderúrgicos e metalúrgicos, exceto para construção</td></tr>
<tr><td>4686-9/01</td><td>Comércio atacadista de papel e papelão em bruto</td></tr>
<tr><td>4686-9/02</td><td>Comércio atacadista de embalagens</td></tr>
<tr><td>4687-7/01</td><td>Comércio atacadista de resíduos de papel e papelão</td></tr>
<tr><td>4687-7/02</td><td>Comércio atacadista de resíduos e sucatas não-metálicos, exceto de papel e papelão</td></tr>
<tr><td>4687-7/03</td><td>Comércio atacadista de resíduos e sucatas metálicos</td></tr>
<tr><td>4689-3/01</td><td>Comércio atacadista de produtos da extração mineral, exceto combustíveis</td></tr>
<tr><td>4689-3/02</td><td>Comércio atacadista de fios e fibras beneficiados</td></tr>
<tr><td>4689-3/99</td><td>Comércio atacadista especializado em outros produtos intermediários não especificados anteriormente</td></tr>
<tr><td>4691-5/00</td><td>Comércio atacadista de mercadorias em geral, com predominância de produtos alimentícios</td></tr>
<tr><td>4692-3/00</td><td>Comércio atacadista de mercadorias em geral, com predominância de insumos agropecuários</td></tr>
<tr><td>4693-1/00</td><td>Comércio atacadista de mercadorias em geral, sem predominância de alimentos ou de insumos agropecuários</td></tr>
<tr><td>4711-3/01</td><td>Comércio varejista de mercadorias em geral, com predominância de produtos alimentícios - hipermercados</td></tr>
<tr><td>4711-3/02</td><td>Comércio varejista de mercadorias em geral, com predominância de produtos alimentícios - supermercados</td></tr>
<tr><td>4712-1/00</td><td>Comércio varejista de mercadorias em geral, com predominância de produtos alimentícios - minimercados, mercearias e armazéns</td></tr>
<tr><td>4713-0/01</td><td>Lojas de departamentos ou magazines</td></tr>
<tr><td>4713-0/02</td><td>Lojas de variedades, exceto lojas de departamentos ou magazines</td></tr>
<tr><td>4713-0/03</td><td>Lojas duty free de aeroportos internacionais</td></tr>
<tr><td>4721-1/01</td><td>Padaria e confeitaria com predominância de produção própria</td></tr>
<tr><td>4721-1/02</td><td>Padaria e confeitaria com predominância de revenda</td></tr>
<tr><td>4721-1/03</td><td>Comércio varejista de laticínios e frios</td></tr>
<tr><td>4721-1/04</td><td>Comércio varejista de doces, balas, bombons e semelhantes</td></tr>
<tr><td>4722-9/01</td><td>Comércio varejista de carnes - açougues</td></tr>
<tr><td>4722-9/02</td><td>Peixaria</td></tr>
<tr><td>4723-7/00</td><td>Comércio varejista de bebidas</td></tr>
<tr><td>4724-5/00</td><td>Comércio varejista de hortifrutigranjeiros</td></tr>
<tr><td>4729-6/01</td><td>Tabacaria</td></tr>
<tr><td>4729-6/99</td><td>Comércio varejista de produtos alimentícios em geral ou especializado em produtos alimentícios não especificados anteriormente</td></tr>
<tr><td>4731-8/00</td><td>Comércio varejista de combustíveis para veículos automotores</td></tr>
<tr><td>4732-6/00</td><td>Comércio varejista de lubrificantes</td></tr>
<tr><td>4741-5/00</td><td>Comércio varejista de tintas e materiais para pintura</td></tr>
<tr><td>4742-3/00</td><td>Comércio varejista de material elétrico</td></tr>
<tr><td>4743-1/00</td><td>Comércio varejista de vidros</td></tr>
<tr><td>4744-0/01</td><td>Comércio varejista de ferragens e ferramentas</td></tr>
<tr><td>4744-0/02</td><td>Comércio varejista de madeira e artefatos</td></tr>
<tr><td>4744-0/03</td><td>Comércio varejista de materiais hidráulicos</td></tr>
<tr><td>4744-0/04</td><td>Comércio varejista de cal, areia, pedra britada, tijolos e telhas</td></tr>
<tr><td>4744-0/05</td><td>Comércio varejista de materiais de construção não especificados anteriormente</td></tr>
<tr><td>4744-0/99</td><td>Comércio varejista de materiais de construção em geral</td></tr>
<tr><td>4751-2/00</td><td>Comércio varejista especializado de equipamentos e suprimentos de informática</td></tr>
<tr><td>4752-1/00</td><td>Comércio varejista especializado de equipamentos de telefonia e comunicação</td></tr>
<tr><td>4753-9/00</td><td>Comércio varejista especializado de eletrodomésticos e equipamentos de áudio e vídeo</td></tr>
<tr><td>4754-7/01</td><td>Comércio varejista de móveis</td></tr>
<tr><td>4754-7/02</td><td>Comércio varejista de artigos de colchoaria</td></tr>
<tr><td>4754-7/03</td><td>Comércio varejista de artigos de iluminação</td></tr>
<tr><td>4755-5/01</td><td>Comércio varejista de tecidos</td></tr>
<tr><td>4755-5/02</td><td>Comercio varejista de artigos de armarinho</td></tr>
<tr><td>4755-5/03</td><td>Comercio varejista de artigos de cama, mesa e banho</td></tr>
<tr><td>4756-3/00</td><td>Comércio varejista especializado de instrumentos musicais e acessórios</td></tr>
<tr><td>4757-1/00</td><td>Comércio varejista especializado de peças e acessórios para aparelhos eletroeletrônicos para uso doméstico, exceto informática e comunicação</td></tr>
<tr><td>4759-8/01</td><td>Comércio varejista de artigos de tapeçaria, cortinas e persianas</td></tr>
<tr><td>4759-8/99</td><td>Comércio varejista de outros artigos de uso doméstico não especificados anteriormente</td></tr>
<tr><td>4761-0/01</td><td>Comércio varejista de livros</td></tr>
<tr><td>4761-0/02</td><td>Comércio varejista de jornais e revistas</td></tr>
<tr><td>4761-0/03</td><td>Comércio varejista de artigos de papelaria</td></tr>
<tr><td>4762-8/00</td><td>Comércio varejista de discos, CDs, DVDs e fitas</td></tr>
<tr><td>4763-6/01</td><td>Comércio varejista de brinquedos e artigos recreativos</td></tr>
<tr><td>4763-6/02</td><td>Comércio varejista de artigos esportivos</td></tr>
<tr><td>4763-6/03</td><td>Comércio varejista de bicicletas e triciclos; peças e acessórios</td></tr>
<tr><td>4763-6/04</td><td>Comércio varejista de artigos de caça, pesca e camping</td></tr>
<tr><td>4763-6/05</td><td>Comércio varejista de embarcações e outros veículos recreativos; peças e acessórios</td></tr>
<tr><td>4771-7/01</td><td>Comércio varejista de produtos farmacêuticos, sem manipulação de fórmulas</td></tr>
<tr><td>4771-7/02</td><td>Comércio varejista de produtos farmacêuticos, com manipulação de fórmulas</td></tr>
<tr><td>4771-7/03</td><td>Comércio varejista de produtos farmacêuticos homeopáticos</td></tr>
<tr><td>4771-7/04</td><td>Comércio varejista de medicamentos veterinários</td></tr>
<tr><td>4772-5/00</td><td>Comércio varejista de cosméticos, produtos de perfumaria e de higiene pessoal</td></tr>
<tr><td>4773-3/00</td><td>Comércio varejista de artigos médicos e ortopédicos</td></tr>
<tr><td>4774-1/00</td><td>Comércio varejista de artigos de óptica</td></tr>
<tr><td>4781-4/00</td><td>Comércio varejista de artigos do vestuário e acessórios</td></tr>
<tr><td>4782-2/01</td><td>Comércio varejista de calçados</td></tr>
<tr><td>4782-2/02</td><td>Comércio varejista de artigos de viagem</td></tr>
<tr><td>4783-1/01</td><td>Comércio varejista de artigos de joalheria</td></tr>
<tr><td>4783-1/02</td><td>Comércio varejista de artigos de relojoaria</td></tr>
<tr><td>4784-9/00</td><td>Comércio varejista de gás liqüefeito de petróleo (GLP)</td></tr>
<tr><td>4785-7/01</td><td>Comércio varejista de antigüidades</td></tr>
<tr><td>4785-7/99</td><td>Comércio varejista de outros artigos usados</td></tr>
<tr><td>4789-0/01</td><td>Comércio varejista de suvenires, bijuterias e artesanatos</td></tr>
<tr><td>4789-0/02</td><td>Comércio varejista de plantas e flores naturais</td></tr>
<tr><td>4789-0/03</td><td>Comércio varejista de objetos de arte</td></tr>
<tr><td>4789-0/04</td><td>Comércio varejista de animais vivos e de artigos e alimentos para animais de estimação</td></tr>
<tr><td>4789-0/05</td><td>Comércio varejista de produtos saneantes domissanitários</td></tr>
<tr><td>4789-0/06</td><td>Comércio varejista de fogos de artifício e artigos pirotécnicos</td></tr>
<tr><td>4789-0/07</td><td>Comércio varejista de equipamentos para escritório</td></tr>
<tr><td>4789-0/08</td><td>Comércio varejista de artigos fotográficos e para filmagem</td></tr>
<tr><td>4789-0/09</td><td>Comércio varejista de armas e munições</td></tr>
<tr><td>4789-0/99</td><td>Comércio varejista de outros produtos não especificados anteriormente</td></tr>
<tr><td>4911-6/00</td><td>Transporte ferroviário de carga</td></tr>
<tr><td>4912-4/01</td><td>Transporte ferroviário de passageiros intermunicipal e interestadual</td></tr>
<tr><td>4912-4/02</td><td>Transporte ferroviário de passageiros municipal e em região metropolitana</td></tr>
<tr><td>4912-4/03</td><td>Transporte metroviário</td></tr>
<tr><td>4921-3/01</td><td>Transporte rodoviário coletivo de passageiros, com itinerário fixo, municipal</td></tr>
<tr><td>4921-3/02</td><td>Transporte rodoviário coletivo de passageiros, com itinerário fixo, intermunicipal em região metropolitana</td></tr>
<tr><td>4922-1/01</td><td>Transporte rodoviário coletivo de passageiros, com itinerário fixo, intermunicipal, exceto em região metropolitana</td></tr>
<tr><td>4922-1/02</td><td>Transporte rodoviário coletivo de passageiros, com itinerário fixo, interestadual</td></tr>
<tr><td>4922-1/03</td><td>Transporte rodoviário coletivo de passageiros, com itinerário fixo, internacional</td></tr>
<tr><td>4923-0/01</td><td>Serviço de táxi</td></tr>
<tr><td>4923-0/02</td><td>Serviço de transporte de passageiros - locação de automóveis com motorista</td></tr>
<tr><td>4924-8/00</td><td>Transporte escolar</td></tr>
<tr><td>4929-9/01</td><td>Transporte rodoviário coletivo de passageiros, sob regime de fretamento, municipal</td></tr>
<tr><td>4929-9/02</td><td>Transporte rodoviário coletivo de passageiros, sob regime de fretamento, intermunicipal, interestadual e internacional</td></tr>
<tr><td>4929-9/03</td><td>Organização de excursões em veículos rodoviários próprios, municipal</td></tr>
<tr><td>4929-9/04</td><td>Organização de excursões em veículos rodoviários próprios, intermunicipal, interestadual e internacional</td></tr>
<tr><td>4929-9/99</td><td>Outros transportes rodoviários de passageiros não especificados anteriormente</td></tr>
<tr><td>4930-2/01</td><td>Transporte rodoviário de carga, exceto produtos perigosos e mudanças, municipal</td></tr>
<tr><td>4930-2/02</td><td>Transporte rodoviário de carga, exceto produtos perigosos e mudanças, intermunicipal, interestadual e internacional</td></tr>
<tr><td>4930-2/03</td><td>Transporte rodoviário de produtos perigosos</td></tr>
<tr><td>4930-2/04</td><td>Transporte rodoviário de mudanças</td></tr>
<tr><td>4940-0/00</td><td>Transporte dutoviário</td></tr>
<tr><td>4950-7/00</td><td>Trens turísticos, teleféricos e similares</td></tr>
<tr><td>5011-4/01</td><td>Transporte marítimo de cabotagem - Carga</td></tr>
<tr><td>5011-4/02</td><td>Transporte marítimo de cabotagem - passageiros</td></tr>
<tr><td>5012-2/01</td><td>Transporte marítimo de longo curso - Carga</td></tr>
<tr><td>5012-2/02</td><td>Transporte marítimo de longo curso - Passageiros</td></tr>
<tr><td>5021-1/01</td><td>Transporte por navegação interior de carga, municipal, exceto travessia</td></tr>
<tr><td>5021-1/02</td><td>Transporte por navegação interior de carga, intermunicipal, interestadual e internacional, exceto travessia</td></tr>
<tr><td>5022-0/01</td><td>Transporte por navegação interior de passageiros em linhas regulares, municipal, exceto travessia</td></tr>
<tr><td>5022-0/02</td><td>Transporte por navegação interior de passageiros em linhas regulares, intermunicipal, interestadual e internacional, exceto travessia</td></tr>
<tr><td>5030-1/01</td><td>Navegação de apoio marítimo</td></tr>
<tr><td>5030-1/02</td><td>Navegação de apoio portuário</td></tr>
<tr><td>5091-2/01</td><td>Transporte por navegação de travessia, municipal</td></tr>
<tr><td>5091-2/02</td><td>Transporte por navegação de travessia, intermunicipal</td></tr>
<tr><td>5099-8/01</td><td>Transporte aquaviário para passeios turísticos</td></tr>
<tr><td>5099-8/99</td><td>Outros transportes aquaviários não especificados anteriormente</td></tr>
<tr><td>5111-1/00</td><td>Transporte aéreo de passageiros regular</td></tr>
<tr><td>5112-9/01</td><td>Serviço de táxi aéreo e locação de aeronaves com tripulação</td></tr>
<tr><td>5112-9/99</td><td>Outros serviços de transporte aéreo de passageiros não-regular</td></tr>
<tr><td>5120-0/00</td><td>Transporte aéreo de carga</td></tr>
<tr><td>5130-7/00</td><td>Transporte espacial</td></tr>
<tr><td>5211-7/01</td><td>Armazéns gerais - emissão de warrant</td></tr>
<tr><td>5211-7/02</td><td>Guarda-móveis</td></tr>
<tr><td>5211-7/99</td><td>Depósitos de mercadorias para terceiros, exceto armazéns gerais e guarda-móveis</td></tr>
<tr><td>5212-5/00</td><td>Carga e descarga</td></tr>
<tr><td>5221-4/00</td><td>Concessionárias de rodovias, pontes, túneis e serviços relacionados</td></tr>
<tr><td>5222-2/00</td><td>Terminais rodoviários e ferroviários</td></tr>
<tr><td>5223-1/00</td><td>Estacionamento de veículos</td></tr>
<tr><td>5229-0/01</td><td>Serviços de apoio ao transporte por táxi, inclusive centrais de chamada</td></tr>
<tr><td>5229-0/02</td><td>Serviços de reboque de veículos</td></tr>
<tr><td>5229-0/99</td><td>Outras atividades auxiliares dos transportes terrestres não especificadas anteriormente</td></tr>
<tr><td>5231-1/01</td><td>Administração da infra-estrutura portuária</td></tr>
<tr><td>5231-1/02</td><td>Operações de terminais</td></tr>
<tr><td>5232-0/00</td><td>Atividades de agenciamento marítimo</td></tr>
<tr><td>5239-7/00</td><td>Atividades auxiliares dos transportes aquaviários não especificadas anteriormente</td></tr>
<tr><td>5240-1/01</td><td>Operação dos aeroportos e campos de aterrissagem</td></tr>
<tr><td>5240-1/99</td><td>Atividades auxiliares dos transportes aéreos, exceto operação dos aeroportos e campos de aterrissagem</td></tr>
<tr><td>5250-8/01</td><td>Comissaria de despachos</td></tr>
<tr><td>5250-8/02</td><td>Atividades de despachantes aduaneiros</td></tr>
<tr><td>5250-8/03</td><td>Agenciamento de cargas, exceto para o transporte marítimo</td></tr>
<tr><td>5250-8/04</td><td>Organização logística do transporte de carga</td></tr>
<tr><td>5250-8/05</td><td>Operador de transporte multimodal - OTM</td></tr>
<tr><td>5310-5/01</td><td>Atividades do Correio Nacional</td></tr>
<tr><td>5310-5/02</td><td>Atividades de franqueadas e permissionárias do Correio Nacional</td></tr>
<tr><td>5320-2/01</td><td>Serviços de malote não realizados pelo Correio Nacional</td></tr>
<tr><td>5320-2/02</td><td>Serviços de entrega rápida</td></tr>
<tr><td>5510-8/01</td><td>Hotéis</td></tr>
<tr><td>5510-8/02</td><td>Apart-hotéis</td></tr>
<tr><td>5510-8/03</td><td>Motéis</td></tr>
<tr><td>5590-6/01</td><td>Albergues, exceto assistenciais</td></tr>
<tr><td>5590-6/02</td><td>Campings</td></tr>
<tr><td>5590-6/03</td><td>Pensões (alojamento)</td></tr>
<tr><td>5590-6/99</td><td>Outros alojamentos não especificados anteriormente</td></tr>
<tr><td>5611-2/01</td><td>Restaurantes e similares</td></tr>
<tr><td>5611-2/02</td><td>Bares e outros estabelecimentos especializados em servir bebidas</td></tr>
<tr><td>5611-2/03</td><td>Lanchonetes, casas de chá, de sucos e similares</td></tr>
<tr><td>5612-1/00</td><td>Serviços ambulantes de alimentação</td></tr>
<tr><td>5620-1/01</td><td>Fornecimento de alimentos preparados preponderantemente para empresas</td></tr>
<tr><td>5620-1/02</td><td>Serviços de alimentação para eventos e recepções - bufê</td></tr>
<tr><td>5620-1/03</td><td>Cantinas - serviços de alimentação privativos</td></tr>
<tr><td>5620-1/04</td><td>Fornecimento de alimentos preparados preponderantemente para consumo domiciliar</td></tr>
<tr><td>5811-5/00</td><td>Edição de livros</td></tr>
<tr><td>5812-3/00</td><td>Edição de jornais</td></tr>
<tr><td>5813-1/00</td><td>Edição de revistas</td></tr>
<tr><td>5819-1/00</td><td>Edição de cadastros, listas e outros produtos gráficos</td></tr>
<tr><td>5821-2/00</td><td>Edição integrada à impressão de livros</td></tr>
<tr><td>5822-1/00</td><td>Edição integrada à impressão de jornais</td></tr>
<tr><td>5823-9/00</td><td>Edição integrada à impressão de revistas</td></tr>
<tr><td>5829-8/00</td><td>Edição integrada à impressão de cadastros, listas e outros produtos gráficos</td></tr>
<tr><td>5911-1/01</td><td>Estúdios cinematográficos</td></tr>
<tr><td>5911-1/02</td><td>Produção de filmes para publicidade</td></tr>
<tr><td>5911-1/99</td><td>Atividades de produção cinematográfica, de vídeos e de programas de televisão não especificadas anteriormente</td></tr>
<tr><td>5912-0/01</td><td>Serviços de dublagem</td></tr>
<tr><td>5912-0/02</td><td>Serviços de mixagem sonora em produção audiovisual</td></tr>
<tr><td>5912-0/99</td><td>Atividades de pós-produção cinematográfica, de vídeos e de programas de televisão não especificadas anteriormente</td></tr>
<tr><td>5913-8/00</td><td>Distribuição cinematográfica, de vídeo e de programas de televisão</td></tr>
<tr><td>5914-6/00</td><td>Atividades de exibição cinematográfica</td></tr>
<tr><td>5920-1/00</td><td>Atividades de gravação de som e de edição de música</td></tr>
<tr><td>6010-1/00</td><td>Atividades de rádio</td></tr>
<tr><td>6021-7/00</td><td>Atividades de televisão aberta</td></tr>
<tr><td>6022-5/01</td><td>Programadoras</td></tr>
<tr><td>6022-5/02</td><td>Atividades relacionadas à televisão por assinatura, exceto programadoras</td></tr>
<tr><td>6110-8/01</td><td>Serviços de telefonia fixa comutada - STFC</td></tr>
<tr><td>6110-8/02</td><td>Serviços de redes de transporte de telecomunicações - SRTT</td></tr>
<tr><td>6110-8/03</td><td>Serviços de comunicação multimídia - SCM</td></tr>
<tr><td>6110-8/99</td><td>Serviços de telecomunicações por fio não especificados anteriormente</td></tr>
<tr><td>6120-5/01</td><td>Telefonia móvel celular</td></tr>
<tr><td>6120-5/02</td><td>Serviço móvel especializado - SME</td></tr>
<tr><td>6120-5/99</td><td>Serviços de telecomunicações sem fio não especificados anteriormente</td></tr>
<tr><td>6130-2/00</td><td>Telecomunicações por satélite</td></tr>
<tr><td>6141-8/00</td><td>Operadoras de televisão por assinatura por cabo</td></tr>
<tr><td>6142-6/00</td><td>Operadoras de televisão por assinatura por microondas</td></tr>
<tr><td>6143-4/00</td><td>Operadoras de televisão por assinatura por satélite</td></tr>
<tr><td>6190-6/01</td><td>Provedores de acesso às redes de comunicações</td></tr>
<tr><td>6190-6/02</td><td>Provedores de voz sobre protocolo internet - VOIP</td></tr>
<tr><td>6190-6/99</td><td>Outras atividades de telecomunicações não especificadas anteriormente</td></tr>
<tr><td>6201-5/00</td><td>Desenvolvimento de programas de computador sob encomenda</td></tr>
<tr><td>6202-3/00</td><td>Desenvolvimento e licenciamento de programas de computador customizáveis</td></tr>
<tr><td>6203-1/00</td><td>Desenvolvimento e licenciamento de programas de computador não-customizáveis</td></tr>
<tr><td>6204-0/00</td><td>Consultoria em tecnologia da informação</td></tr>
<tr><td>6209-1/00</td><td>Suporte técnico, manutenção e outros serviços em tecnologia da informação</td></tr>
<tr><td>6311-9/00</td><td>Tratamento de dados, provedores de serviços de aplicação e serviços de hospedagem na internet</td></tr>
<tr><td>6319-4/00</td><td>Portais, provedores de conteúdo e outros serviços de informação na internet</td></tr>
<tr><td>6391-7/00</td><td>Agências de notícias</td></tr>
<tr><td>6399-2/00</td><td>Outras atividades de prestação de serviços de informação não especificadas anteriormente</td></tr>
<tr><td>6410-7/00</td><td>Banco Central</td></tr>
<tr><td>6421-2/00</td><td>Bancos comerciais</td></tr>
<tr><td>6422-1/00</td><td>Bancos múltiplos, com carteira comercial</td></tr>
<tr><td>6423-9/00</td><td>Caixas econômicas</td></tr>
<tr><td>6424-7/01</td><td>Bancos cooperativos</td></tr>
<tr><td>6424-7/02</td><td>Cooperativas centrais de crédito</td></tr>
<tr><td>6424-7/03</td><td>Cooperativas de crédito mútuo</td></tr>
<tr><td>6424-7/04</td><td>Cooperativas de crédito rural</td></tr>
<tr><td>6431-0/00</td><td>Bancos múltiplos, sem carteira comercial</td></tr>
<tr><td>6432-8/00</td><td>Bancos de investimento</td></tr>
<tr><td>6433-6/00</td><td>Bancos de desenvolvimento</td></tr>
<tr><td>6434-4/00</td><td>Agências de fomento</td></tr>
<tr><td>6435-2/01</td><td>Sociedades de crédito imobiliário</td></tr>
<tr><td>6435-2/02</td><td>Associações de poupança e empréstimo</td></tr>
<tr><td>6435-2/03</td><td>Companhias hipotecárias</td></tr>
<tr><td>6436-1/00</td><td>Sociedades de crédito, financiamento e investimento - financeiras</td></tr>
<tr><td>6437-9/00</td><td>Sociedades de crédito ao microempreendedor</td></tr>
<tr><td>6440-9/00</td><td>Arrendamento mercantil</td></tr>
<tr><td>6450-6/00</td><td>Sociedades de capitalização</td></tr>
<tr><td>6461-1/00</td><td>Holdings de instituições financeiras</td></tr>
<tr><td>6462-0/00</td><td>Holdings de instituições não-financeiras</td></tr>
<tr><td>6463-8/00</td><td>Outras sociedades de participação, exceto holdings</td></tr>
<tr><td>6470-1/01</td><td>Fundos de investimento, exceto previdenciários e imobiliários</td></tr>
<tr><td>6470-1/02</td><td>Fundos de investimento previdenciários</td></tr>
<tr><td>6470-1/03</td><td>Fundos de investimento imobiliários</td></tr>
<tr><td>6491-3/00</td><td>Sociedades de fomento mercantil - factoring</td></tr>
<tr><td>6492-1/00</td><td>Securitização de créditos</td></tr>
<tr><td>6493-0/00</td><td>Administração de consórcios para aquisição de bens e direitos</td></tr>
<tr><td>6499-9/01</td><td>Clubes de investimento</td></tr>
<tr><td>6499-9/02</td><td>Sociedades de investimento</td></tr>
<tr><td>6499-9/03</td><td>Fundo garantidor de crédito</td></tr>
<tr><td>6499-9/04</td><td>Caixas de financiamento de corporações</td></tr>
<tr><td>6499-9/05</td><td>Concessão de crédito pelas OSCIP</td></tr>
<tr><td>6499-9/99</td><td>Outras atividades de serviços financeiros não especificadas anteriormente</td></tr>
<tr><td>6511-1/01</td><td>Seguros de vida</td></tr>
<tr><td>6511-1/02</td><td>Planos de auxílio-funeral</td></tr>
<tr><td>6512-0/00</td><td>Seguros não-vida</td></tr>
<tr><td>6520-1/00</td><td>Seguros-saúde</td></tr>
<tr><td>6530-8/00</td><td>Resseguros</td></tr>
<tr><td>6541-3/00</td><td>Previdência complementar fechada</td></tr>
<tr><td>6542-1/00</td><td>Previdência complementar aberta</td></tr>
<tr><td>6550-2/00</td><td>Planos de saúde</td></tr>
<tr><td>6611-8/01</td><td>Bolsa de valores</td></tr>
<tr><td>6611-8/02</td><td>Bolsa de mercadorias</td></tr>
<tr><td>6611-8/03</td><td>Bolsa de mercadorias e futuros</td></tr>
<tr><td>6611-8/04</td><td>Administração de mercados de balcão organizados</td></tr>
<tr><td>6612-6/01</td><td>Corretoras de títulos e valores mobiliários</td></tr>
<tr><td>6612-6/02</td><td>Distribuidoras de títulos e valores mobiliários</td></tr>
<tr><td>6612-6/03</td><td>Corretoras de câmbio</td></tr>
<tr><td>6612-6/04</td><td>Corretoras de contratos de mercadorias</td></tr>
<tr><td>6612-6/05</td><td>Agentes de investimentos em aplicações financeiras</td></tr>
<tr><td>6613-4/00</td><td>Administração de cartões de crédito</td></tr>
<tr><td>6619-3/01</td><td>Serviços de liquidação e custódia</td></tr>
<tr><td>6619-3/02</td><td>Correspondentes de instituições financeiras</td></tr>
<tr><td>6619-3/03</td><td>Representações de bancos estrangeiros</td></tr>
<tr><td>6619-3/04</td><td>Caixas eletrônicos</td></tr>
<tr><td>6619-3/05</td><td>Operadoras de cartões de débito</td></tr>
<tr><td>6619-3/99</td><td>Outras atividades auxiliares dos serviços financeiros não especificadas anteriormente</td></tr>
<tr><td>6621-5/01</td><td>Peritos e avaliadores de seguros</td></tr>
<tr><td>6621-5/02</td><td>Auditoria e consultoria atuarial</td></tr>
<tr><td>6622-3/00</td><td>Corretores e agentes de seguros, de planos de previdência complementar e de saúde</td></tr>
<tr><td>6629-1/00</td><td>Atividades auxiliares dos seguros, da previdência complementar e dos planos de saúde não especificadas anteriormente</td></tr>
<tr><td>6630-4/00</td><td>Atividades de administração de fundos por contrato ou comissão</td></tr>
<tr><td>6810-2/01</td><td>Compra e venda de imóveis próprios</td></tr>
<tr><td>6810-2/02</td><td>Aluguel de imóveis próprios</td></tr>
<tr><td>6821-8/01</td><td>Corretagem na compra e venda e avaliação de imóveis</td></tr>
<tr><td>6821-8/02</td><td>Corretagem no aluguel de imóveis</td></tr>
<tr><td>6822-6/00</td><td>Gestão e administração da propriedade imobiliária</td></tr>
<tr><td>6911-7/01</td><td>Serviços advocatícios</td></tr>
<tr><td>6911-7/02</td><td>Atividades auxiliares da justiça</td></tr>
<tr><td>6911-7/03</td><td>Agente de propriedade industrial</td></tr>
<tr><td>6912-5/00</td><td>Cartórios</td></tr>
<tr><td>6920-6/01</td><td>Atividades de contabilidade</td></tr>
<tr><td>6920-6/02</td><td>Atividades de consultoria e auditoria contábil e tributária</td></tr>
<tr><td>7020-4/00</td><td>Atividades de consultoria em gestão empresarial, exceto consultoria técnica específica</td></tr>
<tr><td>7111-1/00</td><td>Serviços de arquitetura</td></tr>
<tr><td>7112-0/00</td><td>Serviços de engenharia</td></tr>
<tr><td>7119-7/01</td><td>Serviços de cartografia, topografia e geodésia</td></tr>
<tr><td>7119-7/02</td><td>Atividades de estudos geológicos</td></tr>
<tr><td>7119-7/03</td><td>Serviços de desenho técnico relacionados à arquitetura e engenharia</td></tr>
<tr><td>7119-7/04</td><td>Serviços de perícia técnica relacionados à segurança do trabalho</td></tr>
<tr><td>7119-7/99</td><td>Atividades técnicas relacionadas à engenharia e arquitetura não especificadas anteriormente</td></tr>
<tr><td>7120-1/00</td><td>Testes e análises técnicas</td></tr>
<tr><td>7210-0/00</td><td>Pesquisa e desenvolvimento experimental em ciências físicas e naturais</td></tr>
<tr><td>7220-7/00</td><td>Pesquisa e desenvolvimento experimental em ciências sociais e humanas</td></tr>
<tr><td>7311-4/00</td><td>Agências de publicidade</td></tr>
<tr><td>7312-2/00</td><td>Agenciamento de espaços para publicidade, exceto em veículos de comunicação</td></tr>
<tr><td>7319-0/01</td><td>Criação de estandes para feiras e exposições</td></tr>
<tr><td>7319-0/02</td><td>Promoção de vendas</td></tr>
<tr><td>7319-0/03</td><td>Marketing direto</td></tr>
<tr><td>7319-0/04</td><td>Consultoria em publicidade</td></tr>
<tr><td>7319-0/99</td><td>Outras atividades de publicidade não especificadas anteriormente</td></tr>
<tr><td>7320-3/00</td><td>Pesquisas de mercado e de opinião pública</td></tr>
<tr><td>7410-2/01</td><td>Design</td></tr>
<tr><td>7410-2/02</td><td>Decoração de interiores</td></tr>
<tr><td>7420-0/01</td><td>Atividades de produção de fotografias, exceto aérea e submarina</td></tr>
<tr><td>7420-0/02</td><td>Atividades de produção de fotografias aéreas e submarinas</td></tr>
<tr><td>7420-0/03</td><td>Laboratórios fotográficos</td></tr>
<tr><td>7420-0/04</td><td>Filmagem de festas e eventos</td></tr>
<tr><td>7420-0/05</td><td>Serviços de microfilmagem</td></tr>
<tr><td>7490-1/01</td><td>Serviços de tradução, interpretação e similares</td></tr>
<tr><td>7490-1/02</td><td>Escafandria e mergulho</td></tr>
<tr><td>7490-1/03</td><td>Serviços de agronomia e de consultoria às atividades agrícolas e pecuárias</td></tr>
<tr><td>7490-1/04</td><td>Atividades de intermediação e agenciamento de serviços e negócios em geral, exceto imobiliários</td></tr>
<tr><td>7490-1/05</td><td>Agenciamento de profissionais para atividades esportivas, culturais e artísticas</td></tr>
<tr><td>7490-1/99</td><td>Outras atividades profissionais, científicas e técnicas não especificadas anteriormente</td></tr>
<tr><td>7500-1/00</td><td>Atividades veterinárias</td></tr>
<tr><td>7711-0/00</td><td>Locação de automóveis sem condutor</td></tr>
<tr><td>7719-5/01</td><td>Locação de embarcações sem tripulação, exceto para fins recreativos</td></tr>
<tr><td>7719-5/02</td><td>Locação de aeronaves sem tripulação</td></tr>
<tr><td>7719-5/99</td><td>Locação de outros meios de transporte não especificados anteriormente, sem condutor</td></tr>
<tr><td>7721-7/00</td><td>Aluguel de equipamentos recreativos e esportivos</td></tr>
<tr><td>7722-5/00</td><td>Aluguel de fitas de vídeo, DVDs e similares</td></tr>
<tr><td>7723-3/00</td><td>Aluguel de objetos do vestuário, jóias e acessórios</td></tr>
<tr><td>7729-2/01</td><td>Aluguel de aparelhos de jogos eletrônicos</td></tr>
<tr><td>7729-2/02</td><td>Aluguel de móveis, utensílios e aparelhos de uso doméstico e pessoal; instrumentos musicais</td></tr>
<tr><td>7729-2/03</td><td>Aluguel de material médico</td></tr>
<tr><td>7729-2/99</td><td>Aluguel de outros objetos pessoais e domésticos não especificados anteriormente</td></tr>
<tr><td>7731-4/00</td><td>Aluguel de máquinas e equipamentos agrícolas sem operador</td></tr>
<tr><td>7732-2/01</td><td>Aluguel de máquinas e equipamentos para construção sem operador, exceto andaimes</td></tr>
<tr><td>7732-2/02</td><td>Aluguel de andaimes</td></tr>
<tr><td>7733-1/00</td><td>Aluguel de máquinas e equipamentos para escritório</td></tr>
<tr><td>7739-0/01</td><td>Aluguel de máquinas e equipamentos para extração de minérios e petróleo, sem operador</td></tr>
<tr><td>7739-0/02</td><td>Aluguel de equipamentos científicos, médicos e hospitalares, sem operador</td></tr>
<tr><td>7739-0/03</td><td>Aluguel de palcos, coberturas e outras estruturas de uso temporário, exceto andaimes</td></tr>
<tr><td>7739-0/99</td><td>Aluguel de outras máquinas e equipamentos comerciais e industriais não especificados anteriormente, sem operador</td></tr>
<tr><td>7740-3/00</td><td>Gestão de ativos intangíveis não-financeiros</td></tr>
<tr><td>7810-8/00</td><td>Seleção e agenciamento de mão-de-obra</td></tr>
<tr><td>7820-5/00</td><td>Locação de mão-de-obra temporária</td></tr>
<tr><td>7830-2/00</td><td>Fornecimento e gestão de recursos humanos para terceiros</td></tr>
<tr><td>7911-2/00</td><td>Agências de viagens</td></tr>
<tr><td>7912-1/00</td><td>Operadores turísticos</td></tr>
<tr><td>7990-2/00</td><td>Serviços de reservas e outros serviços de turismo não especificados anteriormente</td></tr>
<tr><td>8011-1/01</td><td>Atividades de vigilância e segurança privada</td></tr>
<tr><td>8011-1/02</td><td>Serviços de adestramento de cães de guarda</td></tr>
<tr><td>8012-9/00</td><td>Atividades de transporte de valores</td></tr>
<tr><td>8020-0/00</td><td>Atividades de monitoramento de sistemas de segurança</td></tr>
<tr><td>8030-7/00</td><td>Atividades de investigação particular</td></tr>
<tr><td>8111-7/00</td><td>Serviços combinados para apoio a edifícios, exceto condomínios prediais</td></tr>
<tr><td>8112-5/00</td><td>Condomínios prediais</td></tr>
<tr><td>8121-4/00</td><td>Limpeza em prédios e em domicílios</td></tr>
<tr><td>8122-2/00</td><td>Imunização e controle de pragas urbanas</td></tr>
<tr><td>8129-0/00</td><td>Atividades de limpeza não especificadas anteriormente</td></tr>
<tr><td>8130-3/00</td><td>Atividades paisagísticas</td></tr>
<tr><td>8211-3/00</td><td>Serviços combinados de escritório e apoio administrativo</td></tr>
<tr><td>8219-9/01</td><td>Fotocópias</td></tr>
<tr><td>8219-9/99</td><td>Preparação de documentos e serviços especializados de apoio administrativo não especificados anteriormente</td></tr>
<tr><td>8220-2/00</td><td>Atividades de teleatendimento</td></tr>
<tr><td>8230-0/01</td><td>Serviços de organização de feiras, congressos, exposições e festas</td></tr>
<tr><td>8230-0/02</td><td>Casas de festas e eventos</td></tr>
<tr><td>8291-1/00</td><td>Atividades de cobrança e informações cadastrais</td></tr>
<tr><td>8292-0/00</td><td>Envasamento e empacotamento sob contrato</td></tr>
<tr><td>8299-7/01</td><td>Medição de consumo de energia elétrica, gás e água</td></tr>
<tr><td>8299-7/02</td><td>Emissão de vales-alimentação, vales-transporte e similares</td></tr>
<tr><td>8299-7/03</td><td>Serviços de gravação de carimbos, exceto confecção</td></tr>
<tr><td>8299-7/04</td><td>Leiloeiros independentes</td></tr>
<tr><td>8299-7/05</td><td>Serviços de levantamento de fundos sob contrato</td></tr>
<tr><td>8299-7/06</td><td>Casas lotéricas</td></tr>
<tr><td>8299-7/07</td><td>Salas de acesso à internet</td></tr>
<tr><td>8299-7/99</td><td>Outras atividades de serviços prestados principalmente às empresas não especificadas anteriormente</td></tr>
<tr><td>8411-6/00</td><td>Administração pública em geral</td></tr>
<tr><td>8412-4/00</td><td>Regulação das atividades de saúde, educação, serviços culturais e outros serviços sociais</td></tr>
<tr><td>8413-2/00</td><td>Regulação das atividades econômicas</td></tr>
<tr><td>8421-3/00</td><td>Relações exteriores</td></tr>
<tr><td>8422-1/00</td><td>Defesa</td></tr>
<tr><td>8423-0/00</td><td>Justiça</td></tr>
<tr><td>8424-8/00</td><td>Segurança e ordem pública</td></tr>
<tr><td>8425-6/00</td><td>Defesa Civil</td></tr>
<tr><td>8430-2/00</td><td>Seguridade social obrigatória</td></tr>
<tr><td>8511-2/00</td><td>Educação infantil - creche</td></tr>
<tr><td>8512-1/00</td><td>Educação infantil - pré-escola</td></tr>
<tr><td>8513-9/00</td><td>Ensino fundamental</td></tr>
<tr><td>8520-1/00</td><td>Ensino médio</td></tr>
<tr><td>8531-7/00</td><td>Educação superior - graduação</td></tr>
<tr><td>8532-5/00</td><td>Educação superior - graduação e pós-graduação</td></tr>
<tr><td>8533-3/00</td><td>Educação superior - pós-graduação e extensão</td></tr>
<tr><td>8541-4/00</td><td>Educação profissional de nível técnico</td></tr>
<tr><td>8542-2/00</td><td>Educação profissional de nível tecnológico</td></tr>
<tr><td>8550-3/01</td><td>Administração de caixas escolares</td></tr>
<tr><td>8550-3/02</td><td>Atividades de apoio à educação, exceto caixas escolares</td></tr>
<tr><td>8591-1/00</td><td>Ensino de esportes</td></tr>
<tr><td>8592-9/01</td><td>Ensino de dança</td></tr>
<tr><td>8592-9/02</td><td>Ensino de artes cênicas, exceto dança</td></tr>
<tr><td>8592-9/03</td><td>Ensino de música</td></tr>
<tr><td>8592-9/99</td><td>Ensino de arte e cultura não especificado anteriormente</td></tr>
<tr><td>8593-7/00</td><td>Ensino de idiomas</td></tr>
<tr><td>8599-6/01</td><td>Formação de condutores</td></tr>
<tr><td>8599-6/02</td><td>Cursos de pilotagem</td></tr>
<tr><td>8599-6/03</td><td>Treinamento em informática</td></tr>
<tr><td>8599-6/04</td><td>Treinamento em desenvolvimento profissional e gerencial</td></tr>
<tr><td>8599-6/05</td><td>Cursos preparatórios para concursos</td></tr>
<tr><td>8599-6/99</td><td>Outras atividades de ensino não especificadas anteriormente</td></tr>
<tr><td>8610-1/01</td><td>Atividades de atendimento hospitalar, exceto pronto-socorro e unidades para atendimento a urgências</td></tr>
<tr><td>8610-1/02</td><td>Atividades de atendimento em pronto-socorro e unidades hospitalares para atendimento a urgências</td></tr>
<tr><td>8621-6/01</td><td>UTI móvel</td></tr>
<tr><td>8621-6/02</td><td>Serviços móveis de atendimento a urgências, exceto por UTI móvel</td></tr>
<tr><td>8622-4/00</td><td>Serviços de remoção de pacientes, exceto os serviços móveis de atendimento a urgências</td></tr>
<tr><td>8630-5/01</td><td>Atividade médica ambulatorial com recursos para realização de procedimentos cirúrgicos</td></tr>
<tr><td>8630-5/02</td><td>Atividade médica ambulatorial com recursos para realização de exames complementares</td></tr>
<tr><td>8630-5/03</td><td>Atividade médica ambulatorial restrita a consultas</td></tr>
<tr><td>8630-5/04</td><td>Atividade odontológica</td></tr>
<tr><td>8630-5/06</td><td>Serviços de vacinação e imunização humana</td></tr>
<tr><td>8630-5/07</td><td>Atividades de reprodução humana assistida</td></tr>
<tr><td>8630-5/99</td><td>Atividades de atenção ambulatorial não especificadas anteriormente</td></tr>
<tr><td>8640-2/01</td><td>Laboratórios de anatomia patológica e citológica</td></tr>
<tr><td>8640-2/02</td><td>Laboratórios clínicos</td></tr>
<tr><td>8640-2/03</td><td>Serviços de diálise e nefrologia</td></tr>
<tr><td>8640-2/04</td><td>Serviços de tomografia</td></tr>
<tr><td>8640-2/05</td><td>Serviços de diagnóstico por imagem com uso de radiação ionizante, exceto tomografia</td></tr>
<tr><td>8640-2/06</td><td>Serviços de ressonância magnética</td></tr>
<tr><td>8640-2/07</td><td>Serviços de diagnóstico por imagem sem uso de radiação ionizante, exceto ressonância magnética</td></tr>
<tr><td>8640-2/08</td><td>Serviços de diagnóstico por registro gráfico - ECG, EEG e outros exames análogos</td></tr>
<tr><td>8640-2/09</td><td>Serviços de diagnóstico por métodos ópticos - endoscopia e outros exames análogos</td></tr>
<tr><td>8640-2/10</td><td>Serviços de quimioterapia</td></tr>
<tr><td>8640-2/11</td><td>Serviços de radioterapia</td></tr>
<tr><td>8640-2/12</td><td>Serviços de hemoterapia</td></tr>
<tr><td>8640-2/13</td><td>Serviços de litotripsia</td></tr>
<tr><td>8640-2/14</td><td>Serviços de bancos de células e tecidos humanos</td></tr>
<tr><td>8640-2/99</td><td>Atividades de serviços de complementação diagnóstica e terapêutica não especificadas anteriormente</td></tr>
<tr><td>8650-0/01</td><td>Atividades de enfermagem</td></tr>
<tr><td>8650-0/02</td><td>Atividades de profissionais da nutrição</td></tr>
<tr><td>8650-0/03</td><td>Atividades de psicologia e psicanálise</td></tr>
<tr><td>8650-0/04</td><td>Atividades de fisioterapia</td></tr>
<tr><td>8650-0/05</td><td>Atividades de terapia ocupacional</td></tr>
<tr><td>8650-0/06</td><td>Atividades de fonoaudiologia</td></tr>
<tr><td>8650-0/07</td><td>Atividades de terapia de nutrição enteral e parenteral</td></tr>
<tr><td>8650-0/99</td><td>Atividades de profissionais da área de saúde não especificadas anteriormente</td></tr>
<tr><td>8660-7/00</td><td>Atividades de apoio à gestão de saúde</td></tr>
<tr><td>8690-9/01</td><td>Atividades de práticas integrativas e complementares em saúde humana</td></tr>
<tr><td>8690-9/02</td><td>Atividades de bancos de leite humano</td></tr>
<tr><td>8690-9/99</td><td>Outras atividades de atenção à saúde humana não especificadas anteriormente</td></tr>
<tr><td>8711-5/01</td><td>Clínicas e residências geriátricas</td></tr>
<tr><td>8711-5/02</td><td>Instituições de longa permanência para idosos</td></tr>
<tr><td>8711-5/03</td><td>Atividades de assistência a deficientes físicos, imunodeprimidos e convalescentes</td></tr>
<tr><td>8711-5/04</td><td>Centros de apoio a pacientes com câncer e com AIDS</td></tr>
<tr><td>8711-5/05</td><td>Condomínios residenciais para idosos</td></tr>
<tr><td>8712-3/00</td><td>Atividades de fornecimento de infra-estrutura de apoio e assistência a paciente no domicílio</td></tr>
<tr><td>8720-4/01</td><td>Atividades de centros de assistência psicossocial</td></tr>
<tr><td>8720-4/99</td><td>Atividades de assistência psicossocial e à saúde a portadores de distúrbios psíquicos, deficiência mental e dependência química não especificadas anteriormente</td></tr>
<tr><td>8730-1/01</td><td>Orfanatos</td></tr>
<tr><td>8730-1/02</td><td>Albergues assistenciais</td></tr>
<tr><td>8730-1/99</td><td>Atividades de assistência social prestadas em residências coletivas e particulares não especificadas anteriormente</td></tr>
<tr><td>8800-6/00</td><td>Serviços de assistência social sem alojamento</td></tr>
<tr><td>9001-9/01</td><td>Produção teatral</td></tr>
<tr><td>9001-9/02</td><td>Produção musical</td></tr>
<tr><td>9001-9/03</td><td>Produção de espetáculos de dança</td></tr>
<tr><td>9001-9/04</td><td>Produção de espetáculos circenses, de marionetes e similares</td></tr>
<tr><td>9001-9/05</td><td>Produção de espetáculos de rodeios, vaquejadas e similares</td></tr>
<tr><td>9001-9/06</td><td>Atividades de sonorização e de iluminação</td></tr>
<tr><td>9001-9/99</td><td>Artes cênicas, espetáculos e atividades complementares não especificados anteriormente</td></tr>
<tr><td>9002-7/01</td><td>Atividades de artistas plásticos, jornalistas independentes e escritores</td></tr>
<tr><td>9002-7/02</td><td>Restauração de obras de arte</td></tr>
<tr><td>9003-5/00</td><td>Gestão de espaços para artes cênicas, espetáculos e outras atividades artísticas</td></tr>
<tr><td>9101-5/00</td><td>Atividades de bibliotecas e arquivos</td></tr>
<tr><td>9102-3/01</td><td>Atividades de museus e de exploração de lugares e prédios históricos e atrações similares</td></tr>
<tr><td>9102-3/02</td><td>Restauração e conservação de lugares e prédios históricos</td></tr>
<tr><td>9103-1/00</td><td>Atividades de jardins botânicos, zoológicos, parques nacionais, reservas ecológicas e áreas de proteção ambiental</td></tr>
<tr><td>9200-3/01</td><td>Casas de bingo</td></tr>
<tr><td>9200-3/02</td><td>Exploração de apostas em corridas de cavalos</td></tr>
<tr><td>9200-3/99</td><td>Exploração de jogos de azar e apostas não especificados anteriormente</td></tr>
<tr><td>9311-5/00</td><td>Gestão de instalações de esportes</td></tr>
<tr><td>9312-3/00</td><td>Clubes sociais, esportivos e similares</td></tr>
<tr><td>9313-1/00</td><td>Atividades de condicionamento físico</td></tr>
<tr><td>9319-1/01</td><td>Produção e promoção de eventos esportivos</td></tr>
<tr><td>9319-1/99</td><td>Outras atividades esportivas não especificadas anteriormente</td></tr>
<tr><td>9321-2/00</td><td>Parques de diversão e parques temáticos</td></tr>
<tr><td>9329-8/01</td><td>Discotecas, danceterias, salões de dança e similares</td></tr>
<tr><td>9329-8/02</td><td>Exploração de boliches</td></tr>
<tr><td>9329-8/03</td><td>Exploração de jogos de sinuca, bilhar e similares</td></tr>
<tr><td>9329-8/04</td><td>Exploração de jogos eletrônicos recreativos</td></tr>
<tr><td>9329-8/99</td><td>Outras atividades de recreação e lazer não especificadas anteriormente</td></tr>
<tr><td>9411-1/00</td><td>Atividades de organizações associativas patronais e empresariais</td></tr>
<tr><td>9412-0/00</td><td>Atividades de organizações associativas profissionais</td></tr>
<tr><td>9420-1/00</td><td>Atividades de organizações sindicais</td></tr>
<tr><td>9430-8/00</td><td>Atividades de associações de defesa de direitos sociais</td></tr>
<tr><td>9491-0/00</td><td>Atividades de organizações religiosas</td></tr>
<tr><td>9492-8/00</td><td>Atividades de organizações políticas</td></tr>
<tr><td>9493-6/00</td><td>Atividades de organizações associativas ligadas à cultura e à arte</td></tr>
<tr><td>9499-5/00</td><td>Atividades associativas não especificadas anteriormente</td></tr>
<tr><td>9511-8/00</td><td>Reparação e manutenção de computadores e de equipamentos periféricos</td></tr>
<tr><td>9512-6/00</td><td>Reparação e manutenção de equipamentos de comunicação</td></tr>
<tr><td>9521-5/00</td><td>Reparação e manutenção de equipamentos eletroeletrônicos de uso pessoal e doméstico</td></tr>
<tr><td>9529-1/01</td><td>Reparação de calçados, bolsas e artigos de viagem</td></tr>
<tr><td>9529-1/02</td><td>Chaveiros</td></tr>
<tr><td>9529-1/03</td><td>Reparação de relógios</td></tr>
<tr><td>9529-1/04</td><td>Reparação de bicicletas, triciclos e outros veículos não-motorizados</td></tr>
<tr><td>9529-1/05</td><td>Reparação de artigos do mobiliário</td></tr>
<tr><td>9529-1/06</td><td>Reparação de jóias</td></tr>
<tr><td>9529-1/99</td><td>Reparação e manutenção de outros objetos e equipamentos pessoais e domésticos não especificados anteriormente</td></tr>
<tr><td>9601-7/01</td><td>Lavanderias</td></tr>
<tr><td>9601-7/02</td><td>Tinturarias</td></tr>
<tr><td>9601-7/03</td><td>Toalheiros</td></tr>
<tr><td>9602-5/01</td><td>Cabeleireiros</td></tr>
<tr><td>9602-5/02</td><td>Outras atividades de tratamento de beleza</td></tr>
<tr><td>9603-3/01</td><td>Gestão e manutenção de cemitérios</td></tr>
<tr><td>9603-3/02</td><td>Serviços de cremação</td></tr>
<tr><td>9603-3/03</td><td>Serviços de sepultamento</td></tr>
<tr><td>9603-3/04</td><td>Serviços de funerárias</td></tr>
<tr><td>9603-3/05</td><td>Serviços de somatoconservação</td></tr>
<tr><td>9603-3/99</td><td>Atividades funerárias e serviços relacionados não especificados anteriormente</td></tr>
<tr><td>9609-2/01</td><td>Clínicas de estética e similares</td></tr>
<tr><td>9609-2/02</td><td>Agências matrimoniais</td></tr>
<tr><td>9609-2/03</td><td>Alojamento, higiene e embelezamento de animais</td></tr>
<tr><td>9609-2/04</td><td>Exploração de máquinas de serviços pessoais acionadas por moeda</td></tr>
<tr><td>9609-2/08</td><td>Higiene e embelezamento de animais domésticos</td></tr>
<tr><td>9609-2/99</td><td>Outras atividades de serviços pessoais não especificadas anteriormente</td></tr>
<tr><td>9700-5/00</td><td>Serviços domésticos</td></tr>
<tr><td>9900-8/00</td><td>Organismos internacionais e outras instituições extraterritoriais</td></tr>
</table>
