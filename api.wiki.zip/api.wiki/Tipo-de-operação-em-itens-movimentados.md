Listagem dos possíveis tipos de operação de um item movimentado

<table>
<tr><th>ID</th><th>Descrição</th></tr>
<tr><td> 1 </td><td> Venda </td></tr>
<tr><td> 12 </td><td> Remessa em bonificação, doação ou brinde </td></tr>
<tr><td> 1056 </td><td> Entrada de mercadoria recebida em consignação mercantil ou industrial </td></tr>
<tr><td> 1093 </td><td> Simples Faturamento </td></tr>
<tr><td> 1156 </td><td> Devolução simbólica de mercadoria vendida ou utilizada em processo industrial, recebida em consignação mercantil ou industrial </td></tr>
<tr><td> 1155 </td><td> Compra para comercialização, de mercadoria recebida anteriormente em consignação mercantil </td></tr>
</table>