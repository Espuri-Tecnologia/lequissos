Endpoint para obter um lote gerado pelo [POST de Lote de pedidos](https://github.com/Varejonline/api/wiki/POST-Lote-de-Pedidos)

### URLs
> Busca pelo ID retornado no [POST de Lote de pedidos](https://github.com/Varejonline/api/wiki/POST-Lote-de-Pedidos)

> GET https://integrador.varejonline.com.br/apps/api/pedidos/lote/:id


<br>


> Busca pelo código gerencial enviado no [POST de Lote de pedidos](https://github.com/Varejonline/api/wiki/POST-Lote-de-Pedidos)

> GET https://integrador.varejonline.com.br/apps/api/pedidos/lote/codigo/:codigo

### Retorno
    
* **id:** id do pedido (long)
* **codigo:** código gerencial do lote (string)
* **pedidos:** lista de pedidos processados
  * **id:** id do processamento do pedido
  * **idPedidoGerado:** id do [pedido gerado](https://github.com/Varejonline/api/wiki/GET-pedidos)(long)
  * **status:** status do processamento (PENDENTE, PEDIDO_GERADO, ERRO) (string)
  * **erro:** em caso de erro de processamento, aqui haverá informações sobre o erro (string)
  * **erroNota:** em caso de erro de processamento da nota, aqui haverá informações sobre o erro (string)
  * **dataAlteracao:** última data de alteração do processamento, no formato dd-mm-aaaa hh:mi:ss (string)
  * **jsonRecebido:** json enviado no lote (objeto complexo) 
      > Atenção: a existência deste json não indica que o pedido foi gerado, ele é apenas o JSON enviado no POST do Lote para simples conferência.
  * **notasFiscais:**  lista de notas fiscais do pedido, cada uma contendo:
    * **status:** [status](https://github.com/Varejonline/api/wiki/Status-Documentos-Fiscais) da nota fiscal (string).
    * **idNotaFiscal:** id da [nota fiscal](https://github.com/Varejonline/api/wiki/GET-notas-mercadoria) (long)
    * **tipoNotaFiscal:** tipo da nota fiscal (string)
  * **fimProcessamento:** data do inicio do processamento do pedido, no formato dd-mm-aaaa hh:mi:ss (string)
  * **inicioProcessamento:** data do fim do processamento do pedido, no formato dd-mm-aaaa hh:mi:ss (string)
 
### Exemplo de lote processado com sucesso

> GET https://integrador.varejonline.com.br/apps/api/pedidos/lote/1

```javascript
{
   "pedidos":[
      {
         "idPedidoGerado":7161,
         "status":"PEDIDO_GERADO",
         "dataAlteracao":"07-07-2023 16:44:44",
         "jsonRecebido":{
            "terceiro":{
               "id":11,
               "nome":null,
               "documento":null,
               "endereco":null
            },
            "entidade":{
               "id":4,
               "nome":"DEPOSITO CENTRAL",
               "documento":"90.010.013/0001-34"
            },
            "idRepresentante":10,
            "representante":{
               "id":1,
               "nome":"Treinamento",
               "documento":"698.184.085-51"
            },
            "itens":[
               {
                  "produto":{
                     "id":4,
                     "codigoSistema":"0022",
                     "codigoInterno":"VF08623",
                     "codigoBarras":null,
                     "descricao":"PRODUTO OK REVENDA SD28"
                  },
                  "idProduto":4,
                  "quantidade":1,
                  "valorUnitario":99.99,
                  "valorDesconto":2,
                  "tabelaPrecoId":1,
                  "operacao":1,
                  "reservarEstoque":false,
                  "dataEntrega":null,
                  "simplesFaturamento":null,
                  "ordem":null,
                  "itemKitId":null,
                  "descontoDetalhes":[
                     
                  ]
               }
            ],
            "valorDesconto":2,
            "valorFrete":14.63,
            "valorSeguro":0,
            "valorOutros":0,
            "idPlanoPagamento":null,
            "plano":{
               "id":1,
               "descricao":"À VISTA"
            },
            "observacao":null,
            "vendaConsumidorFinal":true,
            "vendaPresencial":false,
            "origem":null,
            "tipo":null,
            "enderecoEntrega":null,
            "intermediador":null,
            "transporte":null,
            "descontoDetalhes":[
               
            ],
            "urlEtiqueta":null,
            "data":"07-07-2023",
            "horario":"04:26:39",
            "numeroPedidoCliente":"tray-22375",
            "servicos":[
               
            ],
            "pagamento":null,
            "emitirNotaFiscal":true,
            "emitirNotaFiscalPresente":false,
            "usaNumeroExterno":false,
            "notasFiscais":null,
            "idTerceiro":11,
            "idEntidade":4
         },
         "notasFiscais":[
            {
               "status":"ERRO_ENVIO",
               "idNotaFiscal":1021,
               "tipoNotaFiscal":"MERCADORIA"
            }
         ],
         "fimProcessamento":"07-07-2023 16:44:44",
         "inicioProcessamento":"07-07-2023 16:44:33",
         "id":19881
      }
   ],
   "codigo":"ZZZ65",
   "id":201
}
```

### Exemplo de lote processado com erro

> GET https://integrador.varejonline.com.br/apps/api/pedidos/lote/2

```javascript
{
   "pedidos":[
      {
         "status":"ERRO",
         "erro":"APIException: Item de pedido sem identificador",
         "dataAlteracao":"07-07-2023 16:48:34",
         "jsonRecebido":{
            "terceiro":{
               "id":11,
               "nome":null,
               "documento":null,
               "endereco":null
            },
            "entidade":{
               "id":4,
               "nome":"DEPOSITO CENTRAL",
               "documento":"90.010.013/0001-34"
            },
            "idRepresentante":10,
            "representante":{
               "id":1,
               "nome":"Treinamento",
               "documento":"698.184.085-51"
            },
            "itens":[
               {
                  "produto":{
                     "id":null,
                     "codigoSistema":null,
                     "codigoInterno":null,
                     "codigoBarras":null,
                     "descricao":null
                  },
                  "idProduto":null,
                  "quantidade":1,
                  "valorUnitario":99.99,
                  "valorDesconto":2,
                  "tabelaPrecoId":1,
                  "operacao":1,
                  "reservarEstoque":false,
                  "dataEntrega":null,
                  "simplesFaturamento":null,
                  "ordem":null,
                  "itemKitId":null,
                  "descontoDetalhes":[
                     
                  ]
               }
            ],
            "valorDesconto":2,
            "valorFrete":14.63,
            "valorSeguro":0,
            "valorOutros":0,
            "idPlanoPagamento":null,
            "plano":{
               "id":1,
               "descricao":"À VISTA"
            },
            "observacao":null,
            "vendaConsumidorFinal":true,
            "vendaPresencial":false,
            "origem":null,
            "tipo":null,
            "enderecoEntrega":null,
            "intermediador":null,
            "transporte":null,
            "descontoDetalhes":[
               
            ],
            "urlEtiqueta":null,
            "data":"07-07-2023",
            "horario":"04:26:39",
            "numeroPedidoCliente":"tray-22375",
            "servicos":[
               
            ],
            "pagamento":null,
            "emitirNotaFiscal":true,
            "emitirNotaFiscalPresente":false,
            "usaNumeroExterno":false,
            "notasFiscais":null,
            "idTerceiro":11,
            "idEntidade":4
         },
         "notasFiscais":[
            
         ],
         "fimProcessamento":"07-07-2023 16:48:34",
         "inicioProcessamento":"07-07-2023 16:48:34",
         "id":19902
      }
   ],
   "codigo":"ZZZ65",
   "id":222
}
```