### URL

> PUT https://integrador.varejonline.com.br/apps/api/acoes-promocionais/:id

* **id:** ID da [Ação promocional](https://github.com/Varejonline/api/wiki/GET-Acoes-promocionais) que deve ser alterada (Long - Path Param)

### Parâmetros


Envie um JSON no corpo da requisição, contendo os mesmos parâmetros do [POST Ações promocionais](https://github.com/Varejonline/api/wiki/POST-Acoes-promocionais):