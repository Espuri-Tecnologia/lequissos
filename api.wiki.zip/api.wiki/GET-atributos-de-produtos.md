### URLs

> GET https://integrador.varejonline.com.br/apps/api/atributos-produto

> GET https://integrador.varejonline.com.br/apps/api/atributos-produto/:id

### Retorno 

* **id:** id do atributo (long)
* **permiteMultiplosRegistros:** indicativo se o campo permite múltiplos valores selecionados no cadastro de produtos (boolean)
* **tipo:** pode ser "CAMPO" ou "VALOR" (string)
* **nome:** nome do atributo (string)
* **filhos:** lista com todos os filhos da estrutura deste objeto (mesma estrutura de objeto)

### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/atributos-produto

```javascript
{
    "id": 101,
    "permiteMultiplosRegistros": false,
    "filhos": [
        {
            "id": 102,
            "permiteMultiplosRegistros": false,
            "filhos": [
                {
                    "id": 105,
                    "permiteMultiplosRegistros": false,
                    "filhos": [
                        {
                            "id": 106,
                            "permiteMultiplosRegistros": false,
                            "filhos": [],
                            "tipo": "VALOR",
                            "nome": "2022"
                        },
                        {
                            "id": 107,
                            "permiteMultiplosRegistros": false,
                            "filhos": [],
                            "tipo": "VALOR",
                            "nome": "2023"
                        },
                        {
                            "id": 108,
                            "permiteMultiplosRegistros": false,
                            "filhos": [
                                {
                                    "id": 109,
                                    "permiteMultiplosRegistros": false,
                                    "filhos": [],
                                    "tipo": "VALOR",
                                    "nome": "NDA"
                                },
                                {
                                    "id": 110,
                                    "permiteMultiplosRegistros": false,
                                    "filhos": [],
                                    "tipo": "VALOR",
                                    "nome": "Life"
                                }
                            ],
                            "tipo": "CAMPO",
                            "nome": "Estilo"
                        }
                    ],
                    "tipo": "CAMPO",
                    "nome": "Coleção"
                }
            ],
            "tipo": "VALOR",
            "nome": "Jóias"
        },
        {
            "id": 103,
            "permiteMultiplosRegistros": false,
            "filhos": [
                {
                    "id": 121,
                    "permiteMultiplosRegistros": false,
                    "filhos": [
                        {
                            "id": 122,
                            "permiteMultiplosRegistros": false,
                            "filhos": [],
                            "tipo": "VALOR",
                            "nome": "Ano novo"
                        },
                        {
                            "id": 123,
                            "permiteMultiplosRegistros": false,
                            "filhos": [],
                            "tipo": "VALOR",
                            "nome": "Natal"
                        },
                        {
                            "id": 124,
                            "permiteMultiplosRegistros": true,
                            "filhos": [
                                {
                                    "id": 125,
                                    "permiteMultiplosRegistros": false,
                                    "filhos": [],
                                    "tipo": "VALOR",
                                    "nome": "Smart"
                                },
                                {
                                    "id": 126,
                                    "permiteMultiplosRegistros": false,
                                    "filhos": [],
                                    "tipo": "VALOR",
                                    "nome": "Parede"
                                }
                            ],
                            "tipo": "CAMPO",
                            "nome": "Modelo"
                        }
                    ],
                    "tipo": "CAMPO",
                    "nome": "Coleção"
                }
            ],
            "tipo": "VALOR",
            "nome": "Relógio"
        }
    ],
    "tipo": "CAMPO",
    "nome": "Departamento"
}
```