Endpoint para exclusão de representantes.

### URLs

DELETE https://integrador.varejonline.com.br/apps/api/representantes/:id

### Parâmetros

* **id:** Id do representante que deve ser excluído (Long - Path Param)

### Retorno

HTTP Status OK