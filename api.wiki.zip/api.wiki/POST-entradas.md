### URL

> POST https://integrador.varejonline.com.br/apps/api/entradas

### Observações gerais:
#### Caso o valor da propriedade entradaManual true:
* Qualquer valor relativo a tributação que não for informado será considerado como zero.

#### Caso o valor da propriedade entradaManual false:
* Os valores de tributação serão calculados de acordo com o configurado na operação.
* Frete, seguro e outros devem ser informados no total. Cada um desses valores será distribuído proporcionalmente entre os produtos.
* Caso seja informado um desconto total, o valor dos descontos individuais será ignorado.
* Para corrigir algum eventual problema de arredondamento, total.valorProdutos e total.valorTotal podem informados para serem alterados em até 3 centavos.</em>

<em> Somente ao habilitar o [parâmetro Permitir Vincular Pedido de Compra de Outra Entidade na Entrada de Notas](https://varejonline.movidesk.com/kb/article/57114/parametros-entrada-de-nota), será possível selecionar pedidos de compra realizados em entidades diferentes. </em>

### Parâmetros

Envie um JSON no corpo da requisição, contendo:

* **entradaManual:** Indica se a entrada deve ignorar cálculos de tributação, frete, seguro, desconto e outros. Todos esses valores devem ser informados manualmente em cada produto e também no total. (boolean) _(opcional, padrão: false)_
* **entidade:** id da [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) utilizada (long) _(obrigatório)_
* **fornecedor:** [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros) utilizado _(obrigatório)_
  *   **id:** _(opcional)_
  *   **documento:** com/sem formatação _(opcional)_
* **dataEmissao:** (string dd-MM-yyyy) _(obrigatório)_
* **dataEntrada:** (string dd-MM-yyyy) _(obrigatório)_
* **operacao:** id da [operação](https://github.com/Varejonline/api/wiki/Tipo-de-operação-em-itens-movimentados), considerada como operação principal. Pode ser alterada em cada produto (long) _(obrigatório)_
* **pedidosCompra:** ids dos [pedidos de compra](https://github.com/Varejonline/api/wiki/GET-pedidos-compra) (array[long]) _(opcional)_
* **encerrarPedidosCompra:** altera automaticamente o status do(s) pedido(s) vinculados a entrada para encerrado (boolean) _(opcional, padrão: false)_ 
* **numeroDocumento:** número da nota (int) _(obrigatório)_
* **serie:** (int) _(obrigatório)_
* **chaveNfe:** (String) _(obrigatório caso tipoNotaFiscal = NOTA_55)_
* **tipoNotaFiscal:** tipo de nota fiscal: NOTA_55, NOTA_1, NOTA_1A ou NOTA_4  (string) _(obrigatório)_
* **dadosAdicionais:** dados adicionais da nota (string)  _(opcional)_ 
* **excluirIcmsDaBasePisCofins:** excluir o ICMS da base de cálculo do PIS e COFINS (boolean)  _(opcional, padrão: false)_ 
* **cte:** Conhecimento de transporte (opcional)
  *   **numero:** (obrigatório)
  *   **valorIcms:** _(opcional)_
  *   **valorPis:** _(opcional)_
  *   **valorCofins:** _(opcional)_
  *   **valorTotal:** _(obrigatório)_
  *   **data:** _(obrigatório)_
  *   **prestadorServico:** [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros) terceiro prestador do serviço _(obrigatório)_
        *   **id:** _(opcional)_
        *   **documento:**  com/sem formatação _(opcional)_
  *   **parcelas:** 
      *   **numero:** _(obrigatório)_
      *   **dataVencimento:** _(obrigatório)_
      *   **valor:** _(obrigatório)_
* **produtos:** lista de itens do pedido _(obrigatório)_
  * **produto:** informar um dos critérios para pesquisa do [produto](https://github.com/Varejonline/api/wiki/GET-Produtos) _(obrigatório. Usa-se o primeiro critério da ordem)_
     * **id:** id do produto (long) (opcional)
     * **codigoSistema:** código de sistema (string) (opcional)
     * **codigoBarras:** código de barras (string) (opcional)
     * **codigoInterno:** código interno (string) (opcional)
  * **quantidade:** quantidade do item (decimal) _(obrigatório)_
  * **valorUnitario:** valor unitário do item (decimal) _(opcional, padrão: preço de custo referencial do produto.)_
  * **operacao:** id da [operação](https://github.com/Varejonline/api/wiki/Tipo-de-operação-em-itens-movimentados) (long) _(opcional, padrão: operação principal)_
  * **ean:** código ean na nota (String) _(opcional)_
  * **codigoProduto:** código do produto na nota (String) _(opcional)_
  * **considerarNoValorTotal:** correspondente a tag indTot. Indica se o valor do produto faz parte do valor total da nota (boolean) _(opcional, padrão: true)_
  * **desconto:** (decimal) _(opcional)_
  * **frete:** (decimal) _(opcional)_
  * **seguro:** (decimal) _(opcional)_
  * **outros:** (decimal) _(opcional)_

  * **valorIcmsDesonerado:**  (decimal) _(opcional)_

  * **aliquotaIcms:** (decimal) _(opcional)_
  * **baseIcms:** (decimal) _(opcional)_
  * **valorIcms:**  (decimal) _(opcional)_
  
  * **aliquotaIcmsSn:** (decimal) _(opcional)_
  * **baseIcmsSn:** (decimal) _(opcional)_
  * **valorIcmsSn:** (decimal) _(opcional)_

  * **aliquotaIcmsSt:** (decimal) _(opcional)_
  * **baseIcmsSt:** (decimal) _(opcional)_
  * **valorIcmsSt:** (decimal) _(opcional)_
  * **baseIcmsStAjustado:** (decimal) _(opcional)_
  * **valorIcmsStAjustado:** (decimal) _(opcional)_


  * **aliquotaDiferencialIcms:** (decimal) _(opcional)_
  * **baseDiferencialIcms:** (decimal) _(opcional)_
  * **valorDiferencialIcms :** (decimal) _(opcional)_

  * **aliquotaDiferimentoIcms:** (decimal) _(opcional)_
  * **valorDiferimentoIcms :** (decimal) _(opcional)_

  * **aliquotaDiferencialIcmsInter:** (decimal) _(opcional)_
  * **aliquotaDiferencialIcmsIntra:** (decimal) _(opcional)_
  * **valorIvaAjustado:** (decimal) _(opcional)_

  * **aliquotaIpi:** (decimal) _(opcional)_
  * **baseIpi:** (decimal) _(opcional)_
  * **valorIpi:** (decimal) _(opcional)_

  * **aliquotaPis:** (decimal) _(opcional)_
  * **basePis:** (decimal) _(opcional)_
  * **valorPis:** (decimal) _(opcional)_

  * **aliquotaCofins:** (decimal) _(opcional)_
  * **baseCofins:** (decimal) _(opcional)_
  * **valorCofins:** (decimal) _(opcional)_

  * **aliquotaFcp:**  (decimal) _(opcional)_
  * **baseFcp:** (decimal) _(opcional)_
  * **valorFcp:** (decimal) _(opcional)_

  * **aliquotaFcpSt:** _(opcional)_
  * **baseFcpSt:** (decimal) _(opcional)_
  * **valorFcpSt:** (decimal) _(opcional)_

* **totalProdutos:** _(obrigatório se entradaManual = true)_
  * **desconto:** (decimal) _(opcional)_ 
  * **frete:**  (decimal) _(opcional)_ 
  * **seguro:**  (decimal) _(opcional)_ 
  * **outros:** (decimal) _(opcional)_ 
  * **custoAdicional:** custo adicional será rateado entre os itens e somado ao custo do produto, para posteriormente ser considerado no custo médio. O valor do item na entrada não será afetado (decimal) _(opcional)_ 
  
  * **baseIcms:** (decimal ) _(opcional)_
  * **valorIcms:** (decimal) _(opcional)_

  * **baseIcmsSn:** (decimal) _(opcional)_
  * **valorIcmsSn:** (decimal) _(opcional)_ 

  * **baseIcmsSt:** (decimal) _(opcional)_
  * **valorIcmsSt:** (decimal) _(opcional)_

  * **valorDiferimentoIcms:** (decimal) _(opcional)_
  * **valorDiferencialIcms:** (decimal) _(opcional)_ 
  * **valorDesoneradoIcms:** (decimal) _(opcional)_

  * **valorIpi:** (decimal) _(opcional)_
  * **valorPis:** (decimal) _(opcional)_
  * **valorCofins:** (decimal) _(opcional)_

  * **valorFcp:** (decimal) _(opcional)_ 
  * **baseFcp:** (decimal) _(opcional)_ 

  * **valorFcpSt:** (decimal)_(opcional)_ 
  * **baseFcpSt:** (decimal) _(opcional)_ 

  * **valorProdutos:** (decimal) _(obrigatório se entradaManual = true)_
  * **valorTotal:** (decimal) _(obrigatório se entradaManual = true)_
* **pagamento:** detalhes do pagamento da entrada _(obrigatório)_
  * **planoPagamento:** id do [plano de pagamento](https://github.com/Varejonline/api/wiki/GET-planos-pagamento-compras) (long) _(obrigatório)_
  * **formaPagamentoBancario:** (long) _(opcional)_
  * **contaDestinatario:** (long) _(opcional)_
  * **parcelas:** lista de parcelas da entrada _(obrigatório)_
    * **numero:** (long) _(obrigatório)_
    * **dataVencimento:** (string dd-MM-yyyy) _(obrigatório)_
    * **valor:** (decimal) _(obrigatório)_
    * **dataPagamento:** (string dd-MM-yyyy) _(opcional)_
    * **linhaDigitavel:** (string) _(opcional)_
    * **chavePix:** (string) _(opcional)_
    * **qrCodePix:** (string) _(opcional)_

### Retorno

Sucesso HTTP 201 CREATED:

Retorna um Json com informações do resultado da operação realizada, contendo:

* **idRecurso:** id do pedido gerado.
* **codigoMensagem:** Código de identificação da operação realizada. [veja a lista de Códigos](https://github.com/Varejonline/api/wiki/Retorno-API)
* **mensagem:** Mensagem da operação realizada

Requisição inválida: 
* HTTP STATUS 400 – BAD REQUEST
* Body: mensagem de erro

### Exemplo

> POST https://integrador.varejonline.com.br/apps/api/entradas

'Content-Type'='application/json'
```javascript
{
  "pedidosCompra": [
    1,
    2,
    3
  ],
  "fornecedor": {
    "id": 10
  },
  "entidade": 1,
  "dataEmissao": "02-08-2023",
  "dataEntrada": "02-08-2023",
  "numeroDocumento": 1,
  "serie": 15,
  "operacao": 20,
  "tipoNotaFiscal": "NOTA_1",
  "dadosAdicionais": "daos adicionais da nota",
  "pagamento": {
    "parcelas": [
      {
        "numero": 1,
        "data": "02-08-2023",
        "valor": 50,
        "dataPagamento": "02-08-2023",
        "dataVencimento": "02-08-2023"
      },
      {
        "numero": 2,
        "data": "02-09-2023",
        "valor": 50,
        "dataPagamento": "02-09-2023",
        "dataVencimento": "02-09-2023"
      }
    ],
    "planoPagamento": 5,
    "quantidadeParcelas": 2
  },
  "produtos": [
    {
      "produto": {
        "id": 24
      },
      "quantidade": 100
    }
  ],
  "cte": {
    "numero": 10,
    "valorTotal": 20,
    "data": "02-08-2023",
    "prestadorServico": {
      "id": 12
    },
    "parcelas": [
      {
        "numero": 1,
        "dataVencimento": "02-08-2023",
        "valor": 10
      },
      {
        "numero": 2,
        "dataVencimento": "02-09-2023",
        "valor": 10
      }
    ]
  },
  "totalProdutos": {}
}
```