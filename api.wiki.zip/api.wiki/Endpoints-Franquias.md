## [GET franquias](/Varejonline/api/wiki/GET-franquias)
## [GET grupos de franquias](/Varejonline/api/wiki/GET-grupos-franquias)
## [POST grupos de franquias](/Varejonline/api/wiki/POST-grupos-franquias)
## [PUT grupos de franquias](/Varejonline/api/wiki/PUT-grupos-franquias)



