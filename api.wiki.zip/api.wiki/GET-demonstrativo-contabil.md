### URL

> GET https://integrador.varejonline.com.br/apps/api/planos-gerenciais/:id/demonstrativo-contabil

### Parâmetros

* **id:** id do plano gerencial do qual se deseja obter o demonstrativo (long)
* **desde:** [Veja o Filtro de Datas](https://github.com/Varejonline/api/wiki/Filtro-de-Datas)
* **ate:** [Veja o Filtro de Datas](https://github.com/Varejonline/api/wiki/Filtro-de-Datas)
* **terceiro:** [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros) a ser considerado no cálculo do valor contábil (long)

### Retorno

* **nivel:** nível da conta do plano gerencial (string)
* **nome:** nome da conta do plano gerencial (string)
* **valor:** valor contábil movimentado na conta no período solicitado (string)

### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/planos-gerenciais/1/demonstrativo-contabil

```javascript
[
   {
      "nivel":"100",
      "nome":"ENTRADAS",
      "valor":43446.68
   },
   {
      "nivel":"100.119",
      "nome":"ADIANTAMENTOS",
      "valor":-704.5
   }
]
```