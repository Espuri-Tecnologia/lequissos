### URL

PUT https://integrador.varejonline.com.br/apps/api/notas-fiscal-devolucao/:id

* **Idproduto:** id da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos).

* **quantidadeDevolvida:** quantidade de produto devolvido.


### EXEMPLO

PUT  https://integrador.varejonline.com.br/apps/api/nota-fiscal-devolucao/:id
``` javascript
{ 
   "idProduto" : 2,
   "quantidadeDevolvida" : "2"
}
```