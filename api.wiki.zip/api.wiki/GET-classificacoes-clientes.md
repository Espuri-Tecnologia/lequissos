### URLs

> GET https://integrador.varejonline.com.br/apps/api/classificacoes-clientes

> GET https://integrador.varejonline.com.br/apps/api/classificacoes-clientes/:id

### Parâmetros

* **inicio:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **quantidade:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)

### Retorno

* **id:** id da classificação (long)
* **nome:** nome da classificação (String)
* **idsTerceiros:** ids dos [terceiros](https://github.com/Varejonline/api/wiki/GET-terceiros) inclusos na classificação (array) [Vide API de Terceiros]

### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/classificacoes-clientes

```javascript
[
  {
     "id":1,
     "nome":"PADRÃO",
     "idsTerceiros":[1,12,11,5,10,15,9]
  }
]
```