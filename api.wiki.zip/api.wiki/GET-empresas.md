### URLs

> GET https://integrador.varejonline.com.br/apps/api/empresas

> GET https://integrador.varejonline.com.br/apps/api/empresas/:id

### Parâmetros

* **inicio:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **quantidade:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **alteradoApos:** [Entenda a Coleta de Alterações](https://github.com/Varejonline/api/wiki/Filtro-de-Data-Alteração)
* **status:** filtra pelo status da empresa (enum: ATIVO, INATIVO, EXCLUIDO), separados por vírgula
* **campoCustomizadoNome:** Nome de um campo customizado que pode ser encontrando no endpoint [GET Campos Customizados](https://github.com/Varejonline/api/wiki/GET-Campos-Customizados)
* **campoCustomizadoValor:** Irá filtrar o valor do campo informado na propriedade **campoCustomizadoNome** (Só filtra valores contidos na estrutura de **valoresPrimitivo**)
* **cnpj:** filtra os resultados pelo CNPJ da empresa

<em> Obs.: Empresas excluídas são exibidas apenas se incluso o parâmetro status EXCLUIDO e não exibem nem são filtradas por campo customizado.</em>

### Retorno

* **id:** id da empresa (long)
* **dataAlteracao:** última data de alteração da empresa, no formato dd-mm-aaaa hh:mi:ss (string)
* **dataCriacao:** data em que a empresa foi criada no sistema, no formato dd-mm-aaaa hh:mi:ss (string)
* **nome:** nome da empresa (string)
* **documento:** cpf ou cnpj da empresa formatado (string)
* **entidades:** lista de entidades da empresa com as mesmas propriedades do [GET-Entidades](https://github.com/Varejonline/api/wiki/GET-entidades)
* **ativa:** indica se a empresa está ativa (boolean)
* **excluida:** indica se a empresa foi excluída (boolean)
* **idTerceiro:** id do [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros) associado com a empresa (long)
* **grupoEmpresarial:** grupo empresarial (string)
* **utilizaLinkJusta:** indica se a empresa utiliza o serviço de link de pagamento no aplicativo [VO Closer](https://varejonline.movidesk.com/kb/article/130648/vocloser) (boolean)
* **tokenLinkPagamentoJusta:** token do serviço, se utilizado (string)

* **idEntidadePrincipal:** id da [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) principal (long)
* **idEntidadeEcommerce:** indica para essa empresa, qual é o [id da entidade](https://github.com/Varejonline/api/wiki/GET-entidades) associada ao faturamento de ecommerce (long)
* **camposCustomizados:** Define os valores da estrutura de [campos customizados](https://github.com/Varejonline/api/wiki/GET-Campos-Customizados) da base.
  * **id:** id do terceiro associado aos valores informados (long)
  * **valoresPrimitivo:** valores dos campos customizados [primitivos](https://github.com/Varejonline/api/wiki/Tipos-de-Campos-Customizados)
    * **id:** id do campo customizado (long)
    * **value:** valor do campo customizado (object - varia conforme tipagem do campo)
    * **type:** [tipo](https://github.com/Varejonline/api/wiki/Tipos-de-Campos-Customizados) do campo customizado (string)
  * **valoresComposicao:** valores dos campos customizados do [tipo](https://github.com/Varejonline/api/wiki/Tipos-de-Campos-Customizados) COMPOSICAO
    * **id:** id do campo customizado (long)
    * **valores:** lista de valores primitivos 
      * **id:** id do campo customizado (long)
      * **value:** valor do campo customizado (object - varia conforme tipagem do campo)
      * **type:** [tipo](https://github.com/Varejonline/api/wiki/Tipos-de-Campos-Customizados) do campo customizado (string)
  * **valoresLista:** valores dos campos customizados do [tipo](https://github.com/Varejonline/api/wiki/Tipos-de-Campos-Customizados) LISTA 
    * **campoId:** id do campo customizado retornado pela lista (long)
    * **valoresPrimitivo:** lista de valores primitivos 
      * **id:** id do campo customizado (long)
      * **value:** valor do campo customizado (object - varia conforme tipagem do campo)
      * **type:** [tipo](https://github.com/Varejonline/api/wiki/Tipos-de-Campos-Customizados) do campo customizado (string)
    * **valoresComposicao:** valores dos campos customizados do [tipo](https://github.com/Varejonline/api/wiki/Tipos-de-Campos-Customizados) COMPOSICAO
      * **id:** id do campo customizado (long)
      * **valores:** lista de valores primitivos 
        * **id:** id do campo customizado (long)
        * **value:** valor do campo customizado (object - varia conforme tipagem do campo)
        * **type:** [tipo](https://github.com/Varejonline/api/wiki/Tipos-de-Campos-Customizados) do campo customizado (string)

### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/empresas?inicio=0&quantidade=3&status=ATIVO,INATIVO,EXCLUIDO

```javascript
[
  {
      "id":1,
      "nome":"Empresa Exemplo",
      "documento":"12.123.123/0001-12",
      "ativa": true,
      "excluida": false,
      "idTerceiro": 12,
      "idEntidadePrincipal": 1,
      "idEntidadeEcommerce": 1,
      "camposCustomizados": {
          "id": 1,
          "valoresPrimitivo": [],
          "valoresComposicao": [],
          "valoresLista": []
      },
      "entidades": [
            {
                "id": 1,
                "principal": true,
                "nome": "Varejonline LTDA",
                "entidadeEcommerce": true,
                "permiteVendaEstoqueNegativo": true,
                "grupos": [],
                "modalidadeTributacao": "SIMPLES_NACIONAL",
                "idEmpresa": 1,
                "ativa": true
            },
            {
                "id": 2,
                "principal": false,
                "entidadeEcommerce": false,
                "nome": "LETÍCIA LUCRO REAL",
                "permiteVendaEstoqueNegativo": false,
                "grupos": [],
                "modalidadeTributacao": "LUCRO_REAL",
                "idEmpresa": 1,
                "ativa": false
            }
        ],

  },
  {
      "id":2,
      "nome":"Empresa Exemplo 2",
      "documento":"12.123.123/0001-12",
      "ativa": true,
      "excluida": false,
      "idTerceiro": 2,
      "camposCustomizados": {
          "id": 9,
          "valoresPrimitivo": [],
          "valoresComposicao": [],
          "valoresLista": []
      },
      "entidades": [
            {
                "id": 2,
                "principal": false,
                "entidadeEcommerce": false,
                "nome": "LETÍCIA LUCRO REAL",
                "permiteVendaEstoqueNegativo": false,
                "grupos": [],
                "modalidadeTributacao": "LUCRO_REAL",
                "idEmpresa": 2,
                "ativa": false
            }
        ],
  },
  {
      "id": 3,
      "ativa": false,
      "excluida": true,
      "entidades": [],
      "utilizaLinkJusta": false
  }
]
```