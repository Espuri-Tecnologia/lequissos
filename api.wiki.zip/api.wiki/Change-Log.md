Veja abaixo as últimas alteração da API:

---

### 📅 13/05/2025
#### 🌐 [GET Pedidos](/Varejonline/api/wiki/GET-pedidos)
#### 🌐 [GET Saidas](/Varejonline/api/wiki/GET-saidas)

- Retornar os executores dos serviços da venda.

### 📅 06/05/2025
#### 🌐 [Franquias](/Varejonline/api/wiki/Endpoints-Franquias)

- Novos endpoints para leitura de franquias.
- Novos endpoints para leitura e escrita de grupos de franquias.

### 📅 15/04/2025
#### 🌐 [GET Produtos](/Varejonline/api/wiki/GET-produtos)
#### 🌐 [POST Produtos](/Varejonline/api/wiki/POST-produtos)
#### 🌐 [PUT Produtos](/Varejonline/api/wiki/PUT-produtos)

- Ajuste para permitir definir o preço de venda do produto pela ficha técnica (componentes).

---

### 📅 18/03/2025
#### 🌐 [GET Pedidos](/Varejonline/api/wiki/GET-pedidos)
#### 🌐 [GET Saidas](/Varejonline/api/wiki/GET-saidas)
- Retornado o valor relativo ao Fcp St.

---

### 📅 11/03/2025
#### 🌐 [GET Orcamentos](/Varejonline/api/wiki/GET-orcamentos)
#### 🌐 [GET Pedidos](/Varejonline/api/wiki/GET-pedidos)
- Novo campo: sistemaOrigem: indica a origem do pedido ou orçamento.

---

### 📅 21/02/2025
#### 🌐 [POST Produtos](/Varejonline/api/wiki/POST-Produtos)
#### 🌐 [PUT Produtos](/Varejonline/api/wiki/PUT-Produtos)
#### 🌐 [GET Produtos](/Varejonline/api/wiki/GET-Produtos)
- Novos campos: codBeneficioFiscalRbc, codBeneficioFiscalCp, percentualCreditoPresumido e modalidadeCalculoFiscalCreditoPresumido.

---

### 📅 03/12/2024
#### 🌐 [GET Vouchers](/Varejonline/api/wiki/GET-Vouchers)
- Exibir informações à respeito do vale presente digital

#### 🌐 [GET Pedidos](/Varejonline/api/wiki/GET-Pedidos)
#### 🌐 [GET Pedidos](/Varejonline/api/wiki/POST-Pedidos)
- Ler e Escrever informações à respeito do vale presente digital

#### 🌐 [GET Pedidos](/Varejonline/api/wiki/GET-Produtos)
#### 🌐 [GET Pedidos](/Varejonline/api/wiki/POST-Produtos)
- Ler e Escrever informações à respeito do vale presente

---

### 📅 30/10/2024
#### 🌐 [GET Pedidos](/Varejonline/api/wiki/GET-Pedidos)
- Novas informações de pagamentos: valoresAdiantamento, valoresVoucher e valoresValePresente.

---

### 📅 15/09/2024
#### 🌐 [EndPoints nota fiscal devolução](/Varejonline/api/wiki/Endpoints-nota‐fiscal‐devolucao)
- Nova api para as notas fiscal de devoluções.

---

### 📅 19/09/2024
#### 🌐 [GET Saldo Vouchers](/Varejonline/api/wiki/GET-Saldo-Vouchers)
- Nova api para consulta de saldos disponíveis de vouchers.

---

### 📅 08/08/2024
**⚠️ Atualização Importante:** Novo certificado root para consumo da API.

Caro parceiro, para continuar utilizando a API VO, é necessário instalar o novo certificado root da GlobalSign em seu servidor/sistema.  
O certificado pode ser baixado diretamente no site da [GlobalSign](https://support.globalsign.com/ca-certificates/root-certificates/globalsign-root-certificates).  

> **⚠️ Atenção:** Deve ser instalado o **Root R6**.

---

### 📅 09/09/2024
#### 🌐 [GET Terceiros](/Varejonline/api/wiki/GET-terceiros)
- Adicionado ao retorno a propriedade `dependentes`.

---

### 📅 23/07/2024
#### 🌐 [PUT Pedidos de compra - Alterar observação](/Varejonline/api/wiki/PUT-pedidos-compra-alterar-observacao)
- Adicionado ENDPOINT para alteração da observação do pedido de compra.

---

### 📅 03/06/2024
#### 🌐 [GET Produtos](/Varejonline/api/wiki/GET-produtos)
- Adicionado ao retorno a propriedade `amostraGratis`.

#### 🌐 [POST Pedidos](/Varejonline/api/wiki/POST-pedidos)
- Agora é possível indicar se um item é `amostraGratis`.

---

### 📅 23/05/2024
#### 🌐 [GET Empresas](/Varejonline/api/wiki/GET-empresas)
- Retornar data de alteração e criação no endpoint, bem como permitir filtrar pela data de alteração.

---

### 📅 24/04/2024
## [GET Empresas](/Varejonline/api/wiki/GET-empresas)
### Indicação da entidade que está associada aos faturamentos de ecommerce.

## [GET Entidades](/Varejonline/api/wiki/GET-entidades)
### Indicação da entidade que está associada aos faturamentos de ecommerce.

## [GET Categorias produto](/Varejonline/api/wiki/GET-categorias-produto)
### Permitir filtrar uma categoria pelo nome do seu nível e pelo nome da própria categoria.

## [GET Terceiros](/Varejonline/api/wiki/GET-terceiros)
### inclusão dos filtros desde-ate.

### 📅 09/04/2024
## [GET pedidos](/Varejonline/api/wiki/GET-pedidos)
### Novas informações disponíveis nos itens: valorFreteRateado, valorICMSItem e valorICMSFrete.

### 📅 12/03/2024
## [GET pedidos](/Varejonline/api/wiki/GET-pedidos)
### Incluído filtro para tipos de venda (NORMAL, SHIP_FROM_STORE, CLICK_COLLECT).

## [GET saldos líquidos mercadorias](/Varejonline/api/wiki/GET-saldos-liquidos-mercadorias)
### Incluído filtro de codigosInternos.
### Incluído filtros para tornar carregamentos de estoqueEmTransito, EstoqueMinimoMaximo e QuantidadeReservada opcionais.

### 📅 22/02/2024
## [GET entradas](/Varejonline/api/wiki/GET-Entradas)
### Incluído atributo que indica o ID da devolução de venda online ou offline vinculada à entrada
### Incluído array de notas fiscais vinculadas à entrada

### 📅  30/01/2024
## [POST baixas](/Varejonline/api/wiki/POST-baixas)
### Nova propriedade opcional: historico

### 📅 21/11/2023
## [GET Pedidos](/Varejonline/api/wiki/GET-pedidos)
### Novo filtra para buscar pedidos pelo statusVenda.

# 09/11/2023
## [GET DANFE notas mercadoria](/Varejonline/api/wiki/GET-DANFE-notas-mercadoria)
### Nova rota para obtenção do danfe da nfe.

# 31/10/2023
## [ENDPOINTS acoes promocionais](/Varejonline/api/wiki/Endpoints-acoes-promocionais)
### Novas rotas para obtenção, edição e criação de ações promocionais.

## [GET devoluções](/Varejonline/api/wiki/GET-devolucoes)
### Novo parâmetro carregarImpostosNota, que quando true irá carregar os valores de impostos da nfe vinculada.

## [GET marcas](/Varejonline/api/wiki/GET-marcas)
### API para obtenção de marcas.

## [GET terceiros](/Varejonline/api/wiki/GET-terceiros)
## [POST terceiros](/Varejonline/api/wiki/POST-terceiros)
## [PUT terceiros](/Varejonline/api/wiki/PUT-terceiros)
### Leitura e escrita de marcas de terceiros

# 03/10/2023
## [POST Voucher](/Varejonline/api/wiki/POST-Voucher)
### Novo endpoint para criação de voucher

## [PUT Voucher](/Varejonline/api/wiki/PUT-Voucher)
### Novo endpoint para edição de voucher

## [DELETE Voucher](/Varejonline/api/wiki/DELETE-Voucher)
### Novo endpoint para exclusão de voucher

# 22/09/2023
## [Integração ecom](https://github.com/Varejonline/api/wiki/Roteiro-de-integra%C3%A7%C3%A3o-com-Ecom)
### Manual de direcionamento para integração com ecommerces

# 29/08/2023
## [POST Entradas](/Varejonline/api/wiki/POST-Entradas)
### Novo endpoint para criação de entradas

# 16/08/2023
## [GET Lote de Pedidos](/Varejonline/api/wiki/GET-Lote-de-Pedidos)
## [POST Lote de Pedidos](/Varejonline/api/wiki/POST-Lote-de-Pedidos)
### Novas apis para criação de pedidos em lote

## [POST Pedidos](/Varejonline/api/wiki/POST-pedidos)
### Nova propriedade **enviarEmailNota** para envio condicional de nfe

## [Webhook](/Varejonline/api/wiki/Entenda-o-Webhook)
### Novas eventos de Webhook NOTAFISCALSERVICO e LOTE_PEDIDO

# 15/08/2023
## [GET Terceiros](/Varejonline/api/wiki/GET-Terceiros)
## [POST Terceiros](/Varejonline/api/wiki/POST-terceiros)
## [PUT Terceiros](/Varejonline/api/wiki/PUT-terceiros)
### Adicionadas propriedades para leitura e escrita de limite de crédito

## [PUT Limites Crédito](/Varejonline/api/wiki/PUT-Limites-Cr%C3%A9dito)
### Escrita de limite de crédito em lote

# 08/08/2023
## [POST Pedidos](/Varejonline/api/wiki/POST-pedidos)
### Adicionado numerosValesPresentes aos itens do pedido

# 18/07/2023
## [GET Entradas](/Varejonline/api/wiki/GET-entradas)
### Adicionado valorTotalFcpSt aos itens disponíveis da entrada.

# 04/07/2023
## [ENDPOINTS Usuários](/Varejonline/api/wiki/Endpoints-Usuarios)
## [ENDPOINTS Representantes](/Varejonline/api/wiki/Endpoints-Representantes)
### Novos ENDPOINTS

## [GET representantes](/Varejonline/api/wiki/GET-representantes) e [GET atendimentos](/Varejonline/api/wiki/GET-atendimentos)
### Novos filtros de entidades e ids de representantes

# 27/06/2023
## [GET notas mercadoria](https://github.com/Varejonline/api/wiki/GET-notas-mercadoria)
### Agora o endpoint retorna o endereço do destinatário e o endereço de entrega

# 20/06/2023
## [GET servicos](https://github.com/Varejonline/api/wiki/GET-servicos)
### Agora o endpoint retorna os resultados de forma paginada, seguindo o padrão existente nos outros endpoints.

# 15/06/2023
## [GET notas servico](https://github.com/Varejonline/api/wiki/GET-notas-servico)
### Agora o endpoint retorna o id das "entradas" ou "saidas" vinculadas ao documento.

# 06/06/2023
## [GET notas mercadoria](https://github.com/Varejonline/api/wiki/GET-notas-mercadoria)
### Agora o endpoint retorna o número da nota de origem caso a nota seja uma devolução

# 30/05/2023
## [GET notas mercadoria](https://github.com/Varejonline/api/wiki/GET-notas-mercadoria)
### Agora é possível filtrar a nota por sua data de emissão utilizando os parametros desde e ate

# 09/02/2023
## [POST Pedidos](https://github.com/Varejonline/api/wiki/POST-pedidos)
### Agora é possível enviar pedidos com pagamentos em PIX

## [GET Vouchers](https://github.com/Varejonline/api/wiki/GET-vouchers)
### Criação de endpoint para obtenção de vouchers

## [GET Pedidos](https://github.com/Varejonline/api/wiki/GET-Pedidos)
### Inclusão dos valores de acréscimo ao retorno

# 07/02/2023
### Novo endpoint: 
## [GET Atributos de Produtos](https://github.com/Varejonline/api/wiki/GET-atributos-de-produtos)
## Ajuste em [GET Produtos](https://github.com/Varejonline/api/wiki/GET-Produtos):
Novo atributo "campo" nos atributosProduto.
## Ajuste em [POST Produtos](https://github.com/Varejonline/api/wiki/POST-Produtos/) e [PUT Produtos](https://github.com/Varejonline/api/wiki/PUT-Produtos/):
Nova propriedade opcional "atributosProduto" para o JSON da requisição

### Ajuste em diversos endpoints para usar objetos complexos para entidade e/ou terceiro:
endpoints com alterações:
#### [POST Pedidos compra](https://github.com/Varejonline/api/wiki/POST-pedidos-compra) (entidade, fornecedor)
#### [PUT Pedidos compra](https://github.com/Varejonline/api/wiki/PUT-pedidos-compra) (entidade, fornecedor)
#### [GET Devoluções](https://github.com/Varejonline/api/wiki/GET-devolucoes) (terceiro, entidade)
#### [GET Notas Mercadoria](https://github.com/Varejonline/api/wiki/GET-notas-mercadoria) (entidade, remetente e destinatário)
#### [GET Notas consumo](https://github.com/Varejonline/api/wiki/GET-notas-consumo) (entidade, remetente e destinatário)
#### [GET Entradas](https://github.com/Varejonline/api/wiki/GET-Entradas) (entidade e terceiro)
#### [GET Orçamentos](https://github.com/Varejonline/api/wiki/GET-orcamentos) (entidade e terceiro)
#### [POST Orçamentos](https://github.com/Varejonline/api/wiki/POST-orcamentos) (entidade e terceiro)
#### [PUT Orçamentos](https://github.com/Varejonline/api/wiki/PUT-orcamentos) (entidade e terceiro)
#### [GET Pedidos](https://github.com/Varejonline/api/wiki/GET-Pedidos) (entidade e cliente)
#### [POST Pedidos](https://github.com/Varejonline/api/wiki/POST-pedidos) (entidade e terceiro)
#### [GET Balanços estoque](https://github.com/Varejonline/api/wiki/GET-Balancos-estoque) (entidade)
#### [POST Ajuste estoque](https://github.com/Varejonline/api/wiki/POST-Ajuste-de-estoque) (entidade)
#### [GET Saídas](https://github.com/Varejonline/api/wiki/GET-Saidas) (entidade e terceiro)
#### [GET Saldos mercadorias](https://github.com/Varejonline/api/wiki/GET-saldos-mercadorias) (entidade)
#### [POST Transferência](https://github.com/Varejonline/api/wiki/POST-Transferencia) (remetente e destinatário)
#### [GET Lançamentos Contábeis](https://github.com/Varejonline/api/wiki/GET-Lan%C3%A7amentos-Cont%C3%A1beis) (entidade e terceiro)
#### [POST baixas](https://github.com/Varejonline/api/wiki/POST-baixas) (entidade)
#### [GET negociações cartão](https://github.com/Varejonline/api/wiki/GET-negociacoes-cartao) (terceiro)
#### [GET Contas pagar](https://github.com/Varejonline/api/wiki/GET-Contas-pagar) (entidade e terceiro)
#### [GET Contas receber](https://github.com/Varejonline/api/wiki/GET-Contas-receber) (entidade e terceiro)
#### [GET previsoes](https://github.com/Varejonline/api/wiki/GET-previsoes) (entidade e terceiro)


# 12/01/2023
## [GET Planos de Pagamento](https://github.com/Varejonline/api/wiki/GET-planos-pagamento)
Agora são exibidas no retorno as parcelas do plano.
# 02/12/2022
## [GET Grupo entidades](https://github.com/Varejonline/api/wiki/Get-grupo-entidades)
Novo endpoint.
## [GET empresas](https://github.com/Varejonline/api/wiki/GET-empresas), [GET entidades](https://github.com/Varejonline/api/wiki/GET-entidades) e [GET terceiros](https://github.com/Varejonline/api/wiki/GET-terceiros)
Novo filtro de status, para pesquisa de registros ativos, inativos ou excluídos.  
Também foi incluso um boolean no retorno para indicar se o registro foi excluído.  
Adicionalmente, no [GET entidades](https://github.com/Varejonline/api/wiki/GET-entidades), foi incluso um boolean nos grupos que a entidade faz parte, para indicar se o mesmo está ativo.
# 08/11/2022
## [GET notas mercadoria](https://github.com/Varejonline/api/wiki/GET-notas-mercadoria)
Novo filtro modeloDocumentoFiscal: Permitir filtrar apenas os modelos de doc desejados.
## [GET Pedidos Compra](https://github.com/Varejonline/api/wiki/GET-Pedidos-Compra)
Novo filtro status: Permitir filtrar apenas os pedidos nos status desejados.
# 25/10/2022
## [GET notas mercadoria](https://github.com/Varejonline/api/wiki/GET-notas-mercadoria)
Novo filtro chaves: Indica quais chaves de notas devem ser filtradas.
# 18/10/2022
## [GET Saidas](https://github.com/Varejonline/api/wiki/GET-Saidas) e [GET Pedidos](https://github.com/Varejonline/api/wiki/GET-Pedidos)
Novo filtro ignorarSimplesFaturamento: Indica se lançamentos de simples faturamento devem ser ignorados.
Adição de operação no retorno dos itens do pedido.
# 11/10/2022
## [GET Contas receber](https://github.com/Varejonline/api/wiki/GET-Contas-receber) e [GET Contas pagar](https://github.com/Varejonline/api/wiki/GET-Contas-pagar)
Novo filtro carregarLancamentoBaixa: Indicar se as contas contábeis da baixa devem ser exibidas no retorno.
# 04/10/2022
## [GET Saidas](https://github.com/Varejonline/api/wiki/GET-saidas) e [GET Pedidos](https://github.com/Varejonline/api/wiki/GET-pedidos)
Retornar a descrição da referência do detalhe de desconto
# 30/08/2022
## [GET Saidas](https://github.com/Varejonline/api/wiki/GET-saidas) e [GET Pedidos](https://github.com/Varejonline/api/wiki/GET-pedidos)
Permitir ler detalhes sobre os descontos concedidos nos pedidos
## [POST Pedidos](https://github.com/Varejonline/api/wiki/POST-pedidos)
Permitir informar detalhes sobre os descontos concedidos nos pedidos
# 25/08/2022
## [GET notas-mercadoria](https://github.com/Varejonline/api/wiki/GET-notas-mercadoria)
Novas informações adicionadas ao retorno: informacoesAdicionaisFisco, informacoesAdicionais.
# 23/08/2022
## [GET contas-receber](https://github.com/Varejonline/api/wiki/GET-Contas-receber)
Inclusão dos valores de voucher e vale presente na composição do valor baixado.
## [GET pedidos](https://integrador.varejonline.com.br/apps/api/pedidos)
Inclusão dos valores de voucher e vale presente na composição do pagamento.
# 16/08/2022
## [POST pedidos-alterar-status](https://github.com/Varejonline/api/wiki/POST-pedidos-alterar-status)
Novo endpoint para alteração de status de pedidos
# 26/07/2022
## [GET entidades](https://github.com/Varejonline/api/wiki/GET-entidades)
Nova propriedade no retorno para indicar se a entidade é a principal
## [GET empresas](https://github.com/Varejonline/api/wiki/GET-empresas)
Nova propriedade no retorno: id da entidade principal
# 21/07/2022
## [POST provisoes](https://github.com/Varejonline/api/wiki/POST-provisoes)
Recepção de novas informações: tipo de documento, número do documento e documento de terceiro.
# 19/07/2022
## [POST transferencia](https://github.com/Varejonline/api/wiki/POST-Transferencia)
Nova opção para o tipoValor: ULTIMA_COMPRA.
# 28/06/2022
## [POST e PUT terceiros](https://github.com/Varejonline/api/wiki/POST-Terceiros)
Tratamentos nos endpoints de terceiros para permitir gravação do campo de entidade de cadastro do terceiro.
## [GET empresas](https://github.com/Varejonline/api/wiki/GET-empresas)
Retornar a lista de entidades vinculada à empresa e permitir filtrar empresa por campo customizado
# 07/06/2022
## [GET, POST e PUT terceiros](https://github.com/Varejonline/api/wiki/GET-Terceiros)
Tratamentos nos endpoints de terceiros para permitir leitura e gravação dos Opt-in de comunicação por sms ou email.
# 31/05/2022
## [GET conferencias-caixa](https://github.com/Varejonline/api/wiki/GET-conferencias-caixa)
Criação do endpoint para busca de conferências de caixa.
# 17/05/2022
## [POST Pedidos](https://github.com/Varejonline/api/wiki/POST-pedidos)
Recepção de novas informações: origem da venda, tipo da venda, forma de pagamento da venda, Cnpj da loja, endereço de entrega, intermediador da venda e dados de transporte.
## [GET Pedidos](https://github.com/Varejonline/api/wiki/GET-pedidos)
Novos campos na api: status da venda, origem da venda, tipo da venda, forma de pagamento da venda, endereço de entrega, intermediador da venda e dados de transporte.
## [POST Orcamentos](https://github.com/Varejonline/api/wiki/POST-orcamentos)
Recepção de novas informações: origem da venda, tipo da venda, cnpj da loja, endereço de entrega, intermediador da venda e dados de transporte.
## [GET Orcamentos](https://github.com/Varejonline/api/wiki/GET-orcamentos)
Novos campos na api: origem da venda, tipo da venda, endereço de entrega, intermediador da venda e dados de transporte.
## [GET Contas Pagar](https://github.com/Varejonline/api/wiki/GET-Contas-pagar)
## [GET Contas Receber](https://github.com/Varejonline/api/wiki/GET-Contas-receber)
Novo filtro: idLancamentoPadrao
Novo campo no retorno: idLancamentoPadrao

# 04/05/2022
## [GET Empresas](https://github.com/Varejonline/api/wiki/GET-empresas)
Adicionado campos customizados na api


# 24/03/2022
## [GET Contas Receber](https://github.com/Varejonline/api/wiki/GET-Contas-pagar)
## [GET Contas Pagar](https://github.com/Varejonline/api/wiki/GET-Contas-receber)
Adicionado filtro de entidades

# 25/02/2022
## [GET saldos liquidos mercadorias](https://github.com/Varejonline/api/wiki/GET-saldos-liquidos-mercadorias)
## [GET saldos mercadorias](https://github.com/Varejonline/api/wiki/GET-saldos-mercadorias)
## [GET Reserva Estoque](https://github.com/Varejonline/api/wiki/GET-Reserva-Estoque)
Adicionado filtros somenteEcommerce e somenteMarketplace

# 18/02/2022
## [GET Terceiros](https://github.com/Varejonline/api/wiki/GET-Terceiros)
Adicionado filtro de integração

## [GET notas mercadoria](https://github.com/Varejonline/api/wiki/GET-notas-mercadoria)
Adicionado informações de transporte no retorno

## [GET Pedidos](https://github.com/Varejonline/api/wiki/GET-Pedidos)
Adicionado filtros numeros e numeroPedidoCliente

# 20/01/2022
## [GET notas servico](https://github.com/Varejonline/api/wiki/GET-notas-servico)
## [GET notas mercadoria](https://github.com/Varejonline/api/wiki/GET-notas-mercadoria)
Criação de um novo filtro de CFOP

# 29/04/2021
## [POST ajuste-estoque](https://github.com/Varejonline/api/wiki/POST-Ajuste-de-estoque)
Criação de uma nova API de ajuste de estoque

# 23/07/2020
## [GET representantes](https://github.com/Varejonline/api/wiki/GET-representantes)
Inclusão da pesquisa de vendedor pelo seu id de usuário

Inclusão dos atributos permiteVender e maximoDesconto

## [GET Reserva Estoque](https://github.com/Varejonline/api/wiki/GET-Reserva-Estoque)
Inclusão da pesquisa de reservas por orçamento ou faturamento antecipado

Inclusão do atributo tipoDocumento, idDocumento e idDocumentoItem

## [GET orcamentos](https://github.com/Varejonline/api/wiki/GET-orcamentos)
Mudança do plano de pagamento e representante para objetos complexos

Inclusão do atributo que indica se o orçamento possui ou não reservas de estoque

Inclusão do atributo que indica o pedido no qual o orçamento virou venda


## [GET Saidas](https://github.com/Varejonline/api/wiki/GET-Saidas)

Inclusão do atributo que indica se a saída possui ou não reservas de estoque

## [GET entidades](https://github.com/Varejonline/api/wiki/GET-entidades)

Inclusão dos atributo permiteVendaEstoqueNegativo, grupoEntidade e idGrupoEntidade

## [POST Baixas](https://github.com/Varejonline/api/wiki/POST-baixas)

Inclusão do atributo que define a entidade da baixa e o tipo do documento.

Ajustada a documentação sobre itens obrigatórios.

** [POST Estorno Baixa](https://github.com/Varejonline/api/wiki/POST-Estorno-Baixa)

Nova API para realização de estorno de baixas

# 05/05/2020
## [POST Pedidos compra](https://github.com/Varejonline/api/wiki/POST-pedidos-compra)
Inclusão do campo dataPrevisaoEntrega.
## [PUT Pedidos compra](https://github.com/Varejonline/api/wiki/PUT-pedidos-compra)
Inclusão do campo dataPrevisaoEntrega.

# 23/09/2019
## [GET Pedidos](https://github.com/Varejonline/api/wiki/GET-pedidos)
Inclusão da composição dos pagamentos dos pedidos.

Mudança no retorno da entidade, cliente, plano de pagamento e vendedores.

# 29/07/2019
## [Endpoints de Cupons](https://github.com/Varejonline/api/wiki/GET-cupons-fiscais-emitidos)
Inclusão das opções de filtragem por data de início e fim de emissão dos cupons

Inclusão dos atributos de vale trocas gerado e consumidos na venda.

Inclusão do objeto complexo para retornar o plano de pagamento usado no cupom.


# 12/06/2019
## [Endpoints de Produtos](https://github.com/Varejonline/api/wiki/Endpoints-Produtos)
Inclusão do atributo que define se o produto tem preço variável: preço de venda definido apenas durante a venda da mercadoria.

# 11/06/2019
## [GET Cupons Fiscais Emitidos](https://github.com/Varejonline/api/wiki/GET-cupons-fiscais-emitidos)
Inclusão dos atributos do produto junto aos itens do cupom.

# 18/02/2019
## [Webhook](https://github.com/Varejonline/api/wiki/Entenda-o-Webhook)
Inclusão de dois novos tipos de webhook: Pedidos de vendas e Notas fiscais de mercadoria.

# 18/02/2019
## [Endpoints de Produtos](https://github.com/Varejonline/api/wiki/Endpoints-Produtos)
Inclusão do controle de tags de pesquisa

# 18/02/2019
## [POST Pedido](https://github.com/Varejonline/api/wiki/POST-pedidos)
Possibilidade de informar vendedor e plano de pagamento pelo nome.

Possibilidade de informar o produto pelo seu código sistema.

# 18/02/2019
## [POST Orcamento](https://github.com/Varejonline/api/wiki/POST-orcamentos)
Possibilidade de informar vendedor e plano de pagamento pelo nome.

# 18/02/2019
## [PUT Orcamento](https://github.com/Varejonline/api/wiki/PUT-orcamentos)
Possibilidade de informar vendedor e plano de pagamento pelo nome.

# 22/01/2019
## [GET Notas Mercadoria](https://github.com/Varejonline/api/wiki/GET-notas-mercadoria)
Inclusão de opção de filtragem por número de nota.

# 01/01/2019
## [GET Saídas](https://github.com/Varejonline/api/wiki/GET-Saidas)
Inclusão da tabela de preço aplicada em cada produto da venda.

## [GET Orçamentos](https://github.com/Varejonline/api/wiki/GET-orcamentos)
Inclusão da tabela de preço aplicada em cada produto do orçamento.

## [GET Pedidos](https://github.com/Varejonline/api/wiki/GET-Pedidos)
Inclusão da tabela de preço aplicada em cada produto da saída.

# 20/11/2018
## [GET Devolucoes](https://github.com/Varejonline/api/wiki/GET-devolucoes)
Ajuste da documentação para orientação sobre como buscar devoluções por ID.

# 23/10/2018
## [GET Contas Receber](https://github.com/Varejonline/api/wiki/GET-contas-receber)
Atualização da documentação incluindo os atributos associados aos pagamentos via cartão.

# 01/10/2018
## [POST orcamento](https://github.com/Varejonline/api/wiki/POST-orcamentos)
Possibilidade de solicitar a criação de uma reserva de estoque para o orçamento.

## [PUT orcamento](https://github.com/Varejonline/api/wiki/PUT-Orcamentos)
Possibilidade de solicitar a criação ou atualização de uma reserva de estoque para o orçamento.

## [GET orcamento](https://github.com/Varejonline/api/wiki/GET-orcamentos)
Indicação dos IDs dos itens de orçamento.

## [GET Reserva estoque](https://github.com/Varejonline/api/wiki/GET-Reserva-Estoque)
Novo endpoint de coleta de reservas de estoque.

## [PUT Cancelar Reserva](https://github.com/Varejonline/api/wiki/PUT-Cancelar-Reserva)
Novo endpoint de coleta de reservas de estoque.

# 27/08/2018
## [PUT transacao-cartao](https://github.com/Varejonline/api/wiki/PUT-Ajuste-Transações-de-Cartão)
Criação do endpoint para ajuste de pagamentos com cartão.

# 30/07/2018
## [GET Pedidos](/Varejonline/api/wiki/GET-Pedidos), [GET Saidas](/Varejonline/api/wiki/GET-saidas) e [GET Pedidos](/Varejonline/api/wiki/GET-notas-mercadoria)
Inclusão do CNPJ dos terceiros envolvidos no movimento.

# 11/07/2018
## [Obter Pagamento de Vendas](/Varejonline/api/wiki/Capturar-Pagamento-de-Vendas)
Nova página explicativa para coleta de formas de pagamento e composições de pagamento de vendas realizadas.

# 04/07/2018
## [PUT Pedidos Compra](/Varejonline/api/wiki/PUT-pedidos-compra)
Viabilizar o encerramento de pedido de compra via endpoint PUT.

# 24/05/2018
## [GET Terceiros](/Varejonline/api/wiki/GET-Terceiros)
Inclusão da documentação de retorno de valores de campos customizados

## [GET Campos Custom.](/Varejonline/api/wiki/GET-Campos-Customizados)
Inclusão da documentação do endpoint

# 20/04/2018
## [GET preco-produtos](/Varejonline/api/wiki/GET-tabelas-preco-produtos)

Inclusão de filtro:

* **getHistorico:** Indica se deve ser incluído no JSON o histórico de alterações de preço (boolean opcional)

# 16/04/2018
## [GET tabelas-preco](/Varejonline/api/wiki/GET-tabelas-preco)
Inclusão de atributos:

* **ativo:** indica se a tabela pode (true) ou não (false) ser aplicada (boolean).

* **excluido:** indica se a tabela foi (true) ou não (false) excluída no sistema (boolean).

* **inicioVigencia:** data inicial na qual a tabela pode ser aplicada, no formato dd-mm-aaaa hh:mi:ss (string).

* **fimVigencia:** data final na qual a tabela pode ser aplicada, no formato dd-mm-aaaa hh:mi:ss (string).



# 28/03/2018
## [GET Notas Mercadoria](https://github.com/Varejonline/api/wiki/GET-notas-mercadoria)
* Inclusão do filtro tipo
* Inclusão do detalhamento dos produtos da saída.
* Inclusão da filtragem por entidade

# 27/03/2018
## [GET, POST e PUT Terceiros](https://github.com/Varejonline/api/wiki/GET-Terceiros)
* Inclusão do tipo do telefone

## [GET Pedido](https://github.com/Varejonline/api/wiki/GET-pedidos)
* Inclusão do detalhamento do desconto dos itens (Desconto no item ou no total da venda)

## [GET Saídas](https://github.com/Varejonline/api/wiki/GET-saidas)
* Inclusão do detalhamento do desconto dos itens (Desconto no item ou no total da venda)

# 06/03/2018
## [GET, POST e PUT Produtos](https://github.com/Varejonline/api/wiki/GET-Produtos)
* Inclusão do atributo custoUnitarioRoyalties - define o valor unitário cobrado em royalties da mercadoria.

## [GET, POST e PUT Serviços](https://github.com/Varejonline/api/wiki/GET-servicos)
* Novas APIs de POST e PUT de serviços e inúmeros atributos novos no GET.

# 20/02/2018
## [GET custo-produtos](https://github.com/Varejonline/api/wiki/GET-Custo-Produtos)
* Inclusão da API

# 10/01/2018
## [GET, POST e PUT Produto](https://github.com/Varejonline/api/wiki/Endpoints-Produtos)
* Inclusão dos atributos de unidades proporcionais e do controle de estoque mínimo e máximo por SKU e por Loja.