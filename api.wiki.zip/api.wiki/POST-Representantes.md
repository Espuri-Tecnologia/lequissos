### URL

> POST https://integrador.varejonline.com.br/apps/api/representantes

### Parâmetros

Envie um JSON no corpo da requisição, contendo:

* **apelido:** apelido para o representante, max 150 caracteres (string) _(opcional)_
* **matricula:** matricula para o representante, max 255 caracteres (string) _(opcional)_
* **ativo:** status do representante (boolean) _(opcional, padrão: true)_
* **permiteVender:** se o vendedor estará disponível para vendas (boolean) _(opcional, padrão: true)_
* **entidades:** lista de ids de [entidades](https://github.com/Varejonline/api/wiki/GET-entidades) do representante (array) _(obrigatório)_
* **perfilVendedor :** perfil do representante: CAIXA, GERENTE ou VENDEDOR (string) _(obrigatório)_
* **contaCaixa:** para perfil CAIXA ou GERENTE, id da conta caixa para vincular registros financeiro do novo PDV _(opcional)_
* **liberarCreditoExcedente:** se o representante pode liberar crédito excedente (boolean) _(opcional, padrão: false)_
* **valorCreditoExcedente:** percentual de liberação, de 0 até 99.99, com no máximo 2 casas de precisão (BigDecimal) _(obrigatório se liberarCreditoExcedente)_
* **isentaJurosMulta:** se o representante pode isentar juros e multa na baixa de parcelas (boolean) _(opcional, padrão: false)_
* **maximoDesconto:** o desconto máximo que o representante poderá conceder na venda, de 0 até 99.99, com no máximo 2 casas de precisão (BigDecimal) _(opcional, padrão: 0%)_
* **comissaoSuasVendas:** se o representante terá comissão sobre as vendas próprias (boolean) _(opcional, padrão: false)_
* **comissaoVendasLoja:** se o representante terá comissão sobre as vendas da loja (boolean) _(opcional, padrão: false)_
* **porcentagemComissao:** o percentual de comissão que o vendedor terá sobre as vendas, de 0 até 99.99, com no máximo 2 casas de precisão (BigDecimal) _(opcional, padrão: 0%)_
* **tipoComissao:** se o percentual de comissão se aplicará sobre o valor FATURADO ou REALIZADO (string) _(obrigatório)_
* **diaVencimento:** dia de vencimento da provisão de contas a pagar de comissão, de 1 a 31 (int) _(obrigatório)_
* **competenciaVencimento:** se o vencimento da provisão de contas a pagar será no MES_CORRENTE ou MES_SEGUINTE _(obrigatório)_
* **usuario:** usuário que será associado ao representante. Pode ser informado um usuário existente, pelo id de usuário ou id/documento de um terceiro. Também pode ser informado os dados para criação de um novo [usuário](https://github.com/Varejonline/api/wiki/POST-Usuarios) _(obrigatório)_
   * **id:** id do [usuário](https://github.com/Varejonline/api/wiki/GET-Usuario) (long) _(opcional)_
   * **terceiro:** terceiro com usuário existente _(opcional)_
      * **id:** id do terceiro _(opcional)_
      * **documento:** documento do terceiro, com/sem formatação _(opcional)_
   * **email:** quando informado um email, ele será o email principal do terceiro. O email principal antigo irá para a lista de emails secundários (string) _(opcional)_
   * **entidades:**  lista de ids de [entidades](https://github.com/Varejonline/api/wiki/GET-entidades) que o usuário possuirá acesso (array) _(obrigatório)_
   * **permissao:** id da [permissão de usuário](https://github.com/Varejonline/api/wiki/GET-Permissao-usuario) (long) _(obrigatório)_
   * **exibirComoComprador:** marcar o usuário como comprador nas rotinas do sistema (boolean) _(opcional, padrão: false)_
   * **ativo:** status do usuário (boolean) _(opcional, padrão: true)_
   * **login:** login do usuário, 3-50 dígitos, único, sem espaços (string) _(opcional, padrão: documento do terceiro, sem formatação)_

### Exemplo de retorno:

_Sucesso:_
* HTTP STATUS 201 – CREATED
* Body:
```javascript
{
      "idRecurso": 1,
      "codigoMensagem": 0,
      "mensagem": "Operação realizada com sucesso."
}
```

### Exemplo: Criar representante a partir do ID de um usuário

> POST https://integrador.varejonline.com.br/apps/api/representantes

'Content-Type'='application/json'

```javascript
{
    "apelido": "apelido",
    "matricula": "mat",
    "ativo": false,
    "permiteVender": true,
    "entidades": [1,2],
    "perfil": "GERENTE",
    "contaCaixa": 10,
    "liberarCreditoExcedente": true,
    "valorCreditoExcedente": 10.22,
    "isentaJurosMulta": true,
    "maximoDesconto": 10.1,
    "comissaoSuasVendas": false,
    "comissaoVendasLoja": true,
    "porcentagemComissao": 20,
    "tipoComissao": "FATURADO",
    "diaVencimento": "31",
    "competenciaVencimento": "MES_CORRENTE",
    "usuario": {
        "id": 42
    }
}
```

### Exemplo: Criar representante a partir do ID ou documento de um terceiro

> POST https://integrador.varejonline.com.br/apps/api/representantes

'Content-Type'='application/json'

```javascript
{
    "apelido": "apelido",
    "matricula": "mat",
    "ativo": false,
    "permiteVender": true,
    "entidades": [1,2],
    "perfil": "GERENTE",
    "contaCaixa": 10,
    "liberarCreditoExcedente": true,
    "valorCreditoExcedente": 10.22,
    "isentaJurosMulta": true,
    "maximoDesconto": 10.1,
    "comissaoSuasVendas": false,
    "comissaoVendasLoja": true,
    "porcentagemComissao": 20,
    "tipoComissao": "FATURADO",
    "diaVencimento": "31",
    "competenciaVencimento": "MES_CORRENTE",
    "usuario": {
       "terceiro": {
          "id": 0,
          "documento": "000.000.000-00"
       }
    }
}
```

### Exemplo: Criar representante com novo usuário

> POST https://integrador.varejonline.com.br/apps/api/representantes

'Content-Type'='application/json'

```javascript
{
    "apelido": "apelido",
    "matricula": "mat",
    "ativo": false,
    "permiteVender": true,
    "entidades": [1,2],
    "perfil": "GERENTE",
    "contaCaixa": 10,
    "liberarCreditoExcedente": true,
    "valorCreditoExcedente": 10.22,
    "isentaJurosMulta": true,
    "maximoDesconto": 10.1,
    "comissaoSuasVendas": false,
    "comissaoVendasLoja": true,
    "porcentagemComissao": 20,
    "tipoComissao": "FATURADO",
    "diaVencimento": "31",
    "competenciaVencimento": "MES_CORRENTE",
    "usuario": {
        "terceiro":{
            "id": 0
            "documento": "000.000.000-00"
        },
        "email": "teste@email.com",
        "entidades": [1,2],
        "permissao": "3",
        "exibirComoComprador": true,
        "ativo": false,
        "login": "teste"
    }
}
```