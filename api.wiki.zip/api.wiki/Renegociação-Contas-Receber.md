### URL

> POST https://integrador.varejonline.com.br/apps/api/provisoes-contas/contas-receber/renegociacao

### Parâmetros

Envie um JSON no corpo da requisição, contendo:
* **novasParcelas:** 
   * **numero:** Número sequencial da parcela (long) _(obrigatório)_
   * **valor:** Valor da parcela (decimal) _(obrigatório)_
   * **dataVencimento:** Data de vencimento da parcela (data no formato dd/mm/yyyy) _(obrigatório)_
* **idsParcelasRenegociadas:** ids das parcelas renegociadas (array de long) _(obrigatório)_
* **numeroDoc:**  Identificação da Renegociação (string) _(opcional)_
* **dataLancamento:**  Data da renegociação (data no formato dd/mm/yyyy hh:mm:ss) _(obrigatório)_

      A dataLancamento não pode ser menor que a data de lançamento das parcelas a serem renegociadas

* **valorAcrescimo:** Valor do acréscimo gerado na negociação (decimal) _(obrigatório)_
* **valorDesconto:** Valor do desconto gerado na negociação (decimal) _(obrigatório)_
* **valorLiquido:** Valor da soma das novas parcelas (decimal) _(obrigatório)_
* **tipoDocumento:** [Tipos de documento](/Varejonline/api/wiki/Tipos-de-Documentos-Financeiros) de controle (long) _(obrigatório)_ 
* **diasCarenciaMulta:** Dias de carência para início da contabilização da multa (int) _(opcional)_
* **diasCarenciaJuros:** Dias de carência para início da contabilização dos juros (int) _(opcional)_
* **multa:** Percentual de multa aplicado por atraso no pagamento (decimal) _(opcional)_
* **juros:** Percentual de juros mensal aplicado por atraso no pagamento (decimal) _(opcional)_

### Retorno

Sucesso:
* HTTP STATUS 201 – CREATED
* Body: id da provisão gerada

Requisição inválida: 
* HTTP STATUS 400 – BAD REQUEST
* Body: mensagem de erro

### Exemplo

> POST https://integrador.varejonline.com.br/apps/api/provisoes-contas/contas-receber/renegociacao

'Content-Type'='application/json'

```javascript
{
    "novasParcelas" : [{
        "numero" : 1,
        "valor" : 10.00,
        "dataVencimento" : "20/02/2017"
    },{
        "numero" : 2,
        "valor" : 10.00,
        "dataVencimento" : "20/03/2017"
    }],
    "idsParcelasRenegociadas" : [
        35556, 41225, 42110
    ],
    "numeroDoc" : "",
    "dataLancamento" : "20/02/2017",
    "valorAcrescimo" : 0.00,
    "valorDesconto" : 8.89,
    "valorLiquido" : 20.00,
    "tipoDocumento" : 25,
    "diasCarenciaMulta" : 2,
    "diasCarenciaJuros" : 2,
    "juros" : 4.00,
    "multa" : 2.00
}
```