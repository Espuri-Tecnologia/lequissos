Estas são as contas a pagar da empresa. Estão aqui tanto as contas que a empresa já pagou quanto as que ela ainda não pagou.

### URLs

> GET https://integrador.varejonline.com.br/apps/api/contas-pagar

> GET https://integrador.varejonline.com.br/apps/api/contas-pagar/:id

### Parâmetros

* **entidades:** [Veja como Funciona este Filtro](https://github.com/Varejonline/api/wiki/Filtro-de-Entidades)
* **inicio:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **quantidade:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **desde:** [Veja o Filtro de Datas](https://github.com/Varejonline/api/wiki/Filtro-de-Datas)
* **ate:** [Veja o Filtro de Datas](https://github.com/Varejonline/api/wiki/Filtro-de-Datas)
* **alteradoApos:** [Entenda a Coleta de Alterações](https://github.com/Varejonline/api/wiki/Filtro-de-Data-Alteração)
* **filtroData:** especifica qual data será analizada pelos parâmetros desde e até. Este parâmetro é opcional, e pode receber os valores "dataVencimento", "dataEmissao" ou "dataBaixa". Se não for especificado o parâmetro com nenhum desses valores, por padrão o filtro desde a até será aplicado à data de vencimento da conta a pagar.
* **idProvisao:** Lista de ids das provisões associadas às parcelas buscadas, separados por vírgula.
* **idLancamentoContabil:** Lista de ids dos lançamentos contábeis associados às parcelas buscadas, separados por vírgula.
* **documentoTerceiro:** Filtra apenas parcelas associadas ao [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros) do CPF ou CNPJ informado.
* **idLancamentoPadrao:** Filtra parcelas associadas aos ids de [lançamentos padrões](https://github.com/Varejonline/api/wiki/GET-lancamentos-padroes), separados por vírgula.
* **idsRenegociacoes:** Filtra parcelas associadas aos ids de renegociações (tanto parcelas originais dessa renegociação quanto as parcelas geradas a partir dela).
* **carregarLancamentoBaixa:** Indica se as contas contábeis da baixa devem ser exibidas no retorno (boolean).

### Retorno

* **id:** id da conta (long)
* **dataAlteracao:** última data de alteração do conta a pagar, no formato dd-mm-aaaa hh:mi:ss (string)
* **idProvisao:** id da provisão associadas as parcelas
* **entidade:** [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) que será paga  (objeto complexo)
    * **id:** id da entidade (long)
    * **nome:** nome da entidade (string)
    * **documento:** documento da entidade (string)
* **terceiro:** [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros) a quem a conta será paga (objeto complexo)
    * **id:**  id do terceiro (long)
    * **nome:** nome do terceiro (string)
    * **documento:** documento do terceiro (string)
* **valor:** valor da conta (decimal)
* **dataVencimento:** data de vencimento da conta (string)
* **dataEmissao:** data em que a conta a pagar foi emitida (string)
* **numeroParcela:** número desta parcela (long)
* **totalParcelas:** número total de parcelas (long)
* **valorTotalParcelas:** valor total das parcelas(decimal) 
* **valorTotalRetencoes:** valor total das retenções (decimal) 
* **idOperacaoFinanceira:** número da operação financeira (long)
* **numeroDocumento:** número de documento da conta (string)
* **tipoDocumento:** tipo de documento da conta (string)
* **baixada:** indica se já foi dada a baixa da conta (boolean)
* **valorBaixado:** valor pago ao [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros), caso a conta esteja baixada (decimal)
* **dataBaixa:** data em que foi dada a baixa da conta (string)
* **composicaoValorBaixado:** mostra como o pagamento foi dividido entre cartão, cheque, dinheiro ou outras formas de pagamento
   * **dinheiro:** valor pago em dinheiro (decimal)
   * **cheque:** valor pago em cheque (decimal)
   * **cartao:** valor pago em cartão (decimal)
   * **renegociacao:** valor baixado com renegociação (decimal) 
   * **idRenegociacao:** id da renegociação de baixa (long) 
   * **saldoDevedor:** valor de saldo devedor (decimal) 
   * **baixaContabil:** valor baixado como baixa contábil (decimal) 
   * **adiantamentoRecebido:** valor baixado com adiantamentos (decimal)
* **contaContabilCredito:** conta contábil que indica o pagamento da conta no passivo da empresa
* **classificacoesContabeis:** classificações contábeis que indicam como a conta a pagar está distribuida nas despesas ou custos da empresa.
   * **contaContabil:** conta contábil onde foi lançado a despesa/custo (string)
   * **porcentagemApropriada:** porcentagem da conta a pagar a ser apropriado na conta contábil (string)
   * **idLancamentoPadrao:** id do lançamento padrão associado à parcela (long)
* **contasContabeisBaixa:** Contas contábeis que indicam como a conta a pagar foi baixada.
   * **idContaContabilDebito:** id da conta contábil débito da baixa (long)
   * **contaContabilDebito:** nome da conta contábil débito da baixa (string)
   * **idContaContabilCredito:** id da conta contábil crédito da baixa (long)
   * **contaContabilCredito:** nome da conta contábil crédito da baixa (string)

### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/contas-pagar

```javascript
[
   {
      "id":331,
      "dataAlteração":"19-06-2012 15:28:05",
      "idProvisao": 33769,
      "entidade": {
          "id": 3,
          "nome": "Entidade teste",
          "documento": "00.000.000/0000-00"
      },
      "terceiro": {
          "id": 1,
          "nome": "DIVERSOS",
          "documento": "000.000.000-00"
      },
      "valor":5734.72,
      "dataVencimento":"06-07-2012",
      "dataEmissao":"01-06-2012",
      "numeroParcela":1,
      "totalParcelas":2,
      "valorTotalParcelas":5834.72,
      "valorTotalRetencoes":0,
      "idOperacaoFinanceira":35,
      "numeroDocumento":"00332187300000002940",
      "tipoDocumento":"BOLETO",
      "baixada":true,
      "valorBaixado":5834.72,
      "dataBaixa":"05-07-2012"
      "composicaoValorBaixado":[
          "dinheiro":834.72,
          "cheque":0,
          "cartao":5000.00,
          "renegociacao":0,
          "saldoDevedor":0,
          "baixaContabil":0,
          "adiantamentoRecebido":0
      ]
      "contaContabilCredito":"22601 - CONTAS A PAGAR DIVERSAS",
      "classificacoesContabeis":[
         {
            "contaContabil":"11215 - CAIXA DESPESAS DIARIAS",
            "porcentagemApropriada":100.0
         }
      ],
      "contasContabeisBaixa": {
            "idContaContabilDebito": 99,
            "contaContabilDebito": "13101 - CLIENTES",
            "idContaContabilCredito": 100,
            "contaContabilCredito": "22601 - CONTAS A PAGAR DIVERSAS"
      }
   },
   {
      "id":332,
      "dataAlteração":"24-02-2013 08:44:11",
      "idProvisao": 33769,
      "entidade": {
          "id": 3,
          "nome": "Entidade teste",
          "documento": "00.000.000/0000-00"
      },
      "terceiro": {
          "id": 1,
          "nome": "DIVERSOS",
          "documento": "000.000.000-00"
      },
      "valor":100.0,
      "dataVencimento":"06-08-2012",
      "dataEmissao":"01-06-2012",
      "numeroParcela":2,
      "totalParcelas":2,
      "valorTotalParcelas":5834.72,
      "valorTotalRetencoes":0,
      "idOperacaoFinanceira":35,
      "numeroDocumento":"248",
      "tipoDocumento":"NOTA FISCAL",
      "baixada":false,
      "idLancamentoPadrao":1,
      "contaContabilCredito":"22601 - CONTAS A PAGAR DIVERSAS",
      "classificacoesContabeis":[
         {
            "contaContabil":"11215 - CAIXA DESPESAS DIARIAS",
            "porcentagemApropriada":100.0
         }
      ]
   }
]
```