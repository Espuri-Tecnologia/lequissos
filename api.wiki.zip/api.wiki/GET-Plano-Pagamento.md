### URLs

> GET https://integrador.varejonline.com.br/apps/api/planos-pagamento

> GET https://integrador.varejonline.com.br/apps/api/planos-pagamento/:id

### Parâmetros

* **inicio:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **quantidade:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **alteradoApos:** [Entenda a Coleta de Alterações](https://github.com/Varejonline/api/wiki/Filtro-de-Data-Alteração)
* **documentoTerceiro:** Busca o plano de pagamento associado ao [cliente](https://github.com/Varejonline/api/wiki/GET-terceiros) do CNPJ informado. 


### Retorno 

* **id:** id do plano de pagamento (long)
* **descricao:** descrição do plano de pagamento (string)
* **numeroParcelas:** número de parcelas do plano de pagamento (inteiro)
* **dataAlteracao:** última data de alteração do plano de pagamento, no formato dd-mm-aaaa hh:mi:ss (string)
* **juros:** indica a porcentagem de juros a ser cobrado pelo plano de pagamento, em caso de atraso de pagamento (decimal)
* **acrescimo:** indica a porcentagem de acréscimo a ser adicionado em um pedido de venda quando o plano de pagamento é utilizado (decimal)
* **multa:** indica a porcentagem de multa a ser cobrada pelo plano depagamento, em caso de atraso de pagamento(decimal)
* **ativo:** indica o se o plano de pagamento está ativo ou inativo (booleano)
* **valorMinimoParcela:** Valor mínimo por parcela permitido (decimal)
* **periodoEntreVencimentos:** indica o período entre cada parcela (string)
    * O período define o prazo entre uma parcela e a próxima
    * Os períodos possíveis são: ANUAL, BIMESTRAL, MENSAL, TRIMESTRAL
    * Usado somente em planos de pagamento com tipoVencimentos: FIXO
* **tipoVencimentos:** indica o modelo de vencimentos do plano (string)
    * Os tipos de vencimento são: AVISTA, FIXO, VARIAVEL, ACUMULADO
    * Vencimentos com tipo FIXO, possuem um dia pré-definido de vencimento das parcelas, que são geradas de acordo com o período de vencimentos escolhido.
    * Vencimentos com tipo VARIAVEL é aquele onde existe um prazo entre parcelas, ex: 30, 60, 90 ....
    * Vencimentos com tipo ACUMULADO são iguais ao VARIAVEL, com a diferença que são faturados ao cliente diversos pedidos ao mesmo tempo, de acordo com os períodos de faturamento (não apresentados nessa API)
* **parcelas:** Llista de parcelas do plano de pagamento
    * **dia:** Dia ou prazo de vencimento da parcela, variando de acordo com o atributo tipoVencimentos (inteiro).
    * **porcentagem:** Porcentagem da parcela sobre o total do pagamento (decimal)

### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/planos-pagamento

```javascript
[
    {
        "id": 1,
        "ativo": true,
        "descricao": "A VISTA",
        "numeroParcelas": 1,
        "multa": 0,
        "parcelas": [],
        "acrescimo": 0,
        "juros": 0,
        "dataAlteracao": "31-05-2018 15:57:21",
        "tipoVencimentos": "AVISTA",
        "valorMinimoParcela": 0
    },
    {
        "id": 2,
        "ativo": true,
        "descricao": "AVULSO",
        "numeroParcelas": 1,
        "multa": 0,
        "parcelas": [],
        "acrescimo": 0,
        "juros": 0,
        "dataAlteracao": "21-03-2012 08:55:28",
        "tipoVencimentos": "AVISTA",
        "valorMinimoParcela": 0
    },
    {
        "id": 100,
        "ativo": true,
        "descricao": "2X SEM JUROS - DIA 10",
        "numeroParcelas": 2,
        "multa": 0,
        "parcelas": [
            {
                "dia": 10,
                "porcentagem": 50
            },
            {
                "dia": 10,
                "porcentagem": 50
            }
        ],
        "acrescimo": 0,
        "juros": 0,
        "dataAlteracao": "24-10-2018 14:47:40",
        "tipoVencimentos": "FIXO",
        "periodoEntreVencimentos": "MENSAL",
        "valorMinimoParcela": 300
    },
    {
        "id": 101,
        "ativo": true,
        "descricao": "30 60  90",
        "numeroParcelas": 3,
        "multa": 0,
        "parcelas": [
            {
                "dia": 30,
                "porcentagem": 33.34
            },
            {
                "dia": 60,
                "porcentagem": 33.33
            },
            {
                "dia": 90,
                "porcentagem": 33.33
            }
        ],
        "acrescimo": 0,
        "juros": 0,
        "dataAlteracao": "24-10-2018 14:48:18",
        "tipoVencimentos": "VARIAVEL",
        "valorMinimoParcela": 0
    }
]
```