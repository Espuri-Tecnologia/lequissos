> ### ATENÇÃO: 
> Nunca deve-ser exposta a url de nossa api para consulta de danfe dentro de ecommerces ou marketplaces, caso a api seja utilizada para essa finalidade, o DANFE deve ser baixado, hospedado em algum local publico e então divulgado a url pública dessa hospedagem, do contrário o TOKEN de acesso da base ficará visível à terceiros.

### URL
Para obter o DANFE em pdf de uma nota fiscal autorizado:
> GET https://integrador.varejonline.com.br/apps/api/notas-mercadoria/danfe/:id

### Parâmetro na URL
* **id:** id da [nota de mercadoria](https://github.com/Varejonline/api/wiki/GET-notas-mercadoria)

### Retorno
O retorno dessa api será o PDF com Content-Type=application/pdf.

**Observações:**
* Só é possível obter o DANFE de notas modelo 55.
* Só é possível obter o DANFE de notas emitidas pela própria Varejonline
* Só é possível obter o DANFE de notas autorizadas.