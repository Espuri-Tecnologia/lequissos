### URLs

> GET https://integrador.varejonline.com.br/apps/api/devolucoes

> GET https://integrador.varejonline.com.br/apps/api/devolucoes/:id

### Parâmetros

* **entidades:** [Veja como Funciona este Filtro](https://github.com/Varejonline/api/wiki/Filtro-de-Entidades)
* **inicio:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **quantidade:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **alteradoApos:** [Entenda a Coleta de Alterações](https://github.com/Varejonline/api/wiki/Filtro-de-Data-Alteração)
* **desde:** [Veja o Filtro de Datas](https://github.com/Varejonline/api/wiki/Filtro-de-Datas) Data da Entrada Associada ([Vide Observações](https://github.com/Varejonline/api/wiki/GET-devolucoes#observações-importantes))
* **ate:** [Veja o Filtro de Datas](https://github.com/Varejonline/api/wiki/Filtro-de-Datas) Data da Entrada Associada ([Vide Observações](https://github.com/Varejonline/api/wiki/GET-devolucoes#observações-importantes))
* **produto:** id do [produto](https://github.com/Varejonline/api/wiki/GET-Produtos) devolvido (long)
* **carregarImpostosNota:** indica se os impostos devem ser carregados a partir da nota fiscal vinculada (boolean)

### Retorno

* **id:** id da devolução (long) 
`Obs: São duas sequências de id (uma para devoluções ONLINE e outra para devoluções OFFLINE - vide atributo tipoDevolucao)`
* **data:** data de realização da devolução (string dd-mm-aaaa hh:mm:ss)
* **entidade:** [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) à qual a devolução pertence (objeto complexo)
    * **id:** id da entidade (long)
    * **nome:** nome da entidade (string)
    * **documento:** documento da entidade (string)
* **terceiro:** [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros) que realizou a devolução (objeto complexo)
    * **id:**  id do terceiro (long)
    * **nome:** nome do terceiro (string)
    * **documento:** documento do terceiro (string)
* **idPedidoOrigem:** id do pedido de venda do item que foi devolvido (long) **(DEPRECATED)**
* **idEntradaGerada:** id da entrada gerada pela devolução (long)
* **tipoDevolucao:** Define se a devolução foi ONLINE (realizada no ERP) ou OFFLINE (realizada no PDV)
* **itensDevolvidos:** lista de itens devolvidos, cada um contendo:
    * **produto:** dados do produto devolvido (objeto complexo)
        * **id:** id da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos)
        * **descricao:** id da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos)
        * **codigoSistema:** Código Sistema da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos)
        * **codigoInterno:** Código Interno da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos)
        * **codigoBarras:** Código de Barras da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos)
    * **quantidade:** quantidade devolvida do produto (decimal)
    * **valor:** valor devolvido do produto (decimal)
    * **motivo:** motivo da troca (string) (Valores possíveis: SIMPLES, DEVOLUCAO, DEFEITO)
    * **idPedidoOrigem:** id do pedido de venda do item que foi devolvido (long)
    * **idSaidaMercadoria:** id do item vendido (Id do item na [saída](https://github.com/Varejonline/api/wiki/GET-Saidas))
    * **valorPIS:** valor do PIS aplicado ao item (decimal)
    * **valorICMS:** valor do ICMS aplicado ao item (decimal)
    * **valorCOFINS:** valor do CONFINS aplicado ao item (decimal)
    * **valorICMSST:** valor do ICMS ST aplicado ao item (decimal)
    * **valorIPI:** valor do IPI aplicado ao item (decimal)

### Observações Importantes

Toda devolução quando é cancelada no Varejonline tem seu registro excluído. Logo, não ocorre a notificação de cancelamento da devolução por este endpoint (Veja que não existe um controle sobre cancelamento no retorno do endpoint). Para isso, deve ser acompanhado os retornos do [endpoint de entradas](https://github.com/Varejonline/api/wiki/GET-entradas), verificando se a entrada retornada está cancelada e se ela se refere à uma devolução. Caso isso ocorra, significa que a devolução foi cancelada no Varejonline.

A data da devolução (atributo "data" retornado pelo endpoint) representa o dia em que a devolução foi realizada. Para obter a data da operação (data fiscal do movimento), deve ser buscada a entrada associada à devolução e colhido o atributo "data" da entrada associada. Já os filtros "desde" e "até" operam sobre a data fiscal do movimento (data da operação informada na entrada associada)

O valor devolvido representa o preço de venda aplicado no item que está sendo devolvido na época da venda. Ao buscar a entrada gerada na devolução, os valores dos itens na entrada representam o custo médio dos produtos na época da venda. 

**O GET de devolução por ID, retorna sempre as devoluções OFFLINE (trocas). Para obter uma devolução ONLINE, informe na consulta o parâmetro online=true**

> GET https://integrador.varejonline.com.br/apps/api/devolucoes/:id?online=true

### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/devolucoes

```javascript
[ 
   { 
      "id":1, 
      "data":"14-05-2013 23:59:59", 
      "entidade": {
          "id": 3,
          "nome": "Entidade teste",
          "documento": "00.000.000/0000-00"
      },
      "terceiro": {
          "id": 1,
          "nome": "DIVERSOS",
          "documento": "000.000.000-00"
      },
      "idPedidoOrigem":1813, 
      "idEntradaGerada":114, 
      "tipoDevolucao": "ONLINE",
      "itensDevolvidos":[ 
         { 
           "produto": {
               "id":9342,
               "descricao":"BLUSA MALHA PRETA GG",
               "codigoSistema":"0001.0001",
               "codigoInterno":"",
               "codigoBarras":""
            },
            "valor":85, 
            "quantidade":1, 
            "idSaidaMercadoria": 678,
            "idPedidoOrigem":1813 
         } 
      ] 
   }, 
   { 
      "id":2, 
      "data":"14-05-2013 23:59:59", 
      "entidade": {
          "id": 3,
          "nome": "Entidade teste",
          "documento": "00.000.000/0000-00"
      },
      "terceiro": {
          "id": 1,
          "nome": "DIVERSOS",
          "documento": "000.000.000-00"
      },
      "idPedidoOrigem":464, 
      "idEntradaGerada":128, 
      "tipoDevolucao": "OFFLINE",
      "itensDevolvidos":[ 
         { 
            "produto": {
               "id":9342,
               "descricao":"BLUSA MALHA PRETA GG",
               "codigoSistema":"0001.0001",
               "codigoInterno":"",
               "codigoBarras":""
            },
            "valor":99, 
            "quantidade":1, 
            "idSaidaMercadoria": 679,
            "idPedidoOrigem":464 
         } 
      ] 
   } 
]
```