Permite consultar os canais vinculados às vendas do PDV.

### URLs

> GET https://integrador.varejonline.com.br/apps/api/canais-digitais

> GET https://integrador.varejonline.com.br/apps/api/canais-digitais/:id

### Parâmetros

* **alteradoApos:** [Entenda a Coleta de Alterações](https://github.com/Varejonline/api/wiki/Filtro-de-Data-Alteração)
* **inicio:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **quantidade:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)

### Retorno 

* **id:** id do canal (long)
* **nome:** nome do canal (string)
* **ativo:** indica se o canal está ativo (boolean)
* **excluido:** indica se o canal está excluído (boolean)
* **dataAlteracao:** data da última alteração dd-mm-aaaa hh:mm:ss (string)

### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/canais-digitais

```javascript
[
  {
      "id": 1,
      "nome": "canal exemplo",
      "ativo": false,
      "excluido": true,
      "dataAlteracao": "12-10-2022 10:25:40"
  },
  {
      "id": 2,
      "nome": "canal exemplo 2",
      "ativo": true,
      "excluido": false,
      "dataAlteracao": "13-10-2022 10:00:00"

  }
]
```