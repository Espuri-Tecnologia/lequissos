## **Sucesso**
* **0:** Operação realizada com sucesso.

## **Erros**
_Erros Comuns_
* **1:** Erro genérico.
* **3:** Objeto nulo.
* **42:** Objeto já existe.
* **120:** Parâmetro de consulta inválido.

_Produto_
* **10:** Produto sem descrição.
* **11:** Produto sem categoria.
* **12:** Produto sem ncm.
* **13:** Produto com ncm inválido.
* **14:** Produto sem classificação.
* **15:** Produto com classificação inválida.
* **16:** Produto sem origem.
* **17:** Produto com origem inválida.
* **18:** Produto sem método de controle.
* **19:** Produto com método de controle inválido.
* **20:** Produto sem unidade.
* **21:** Produto com unidade inválida.
* **22:** Produto com fornecedor inválido.
* **23:** Produto base da grade inválido.
* **24:** Atributos de grade inválidos.
* **25:** Grade inválida.
* **26:** Grade inativa.
* **27:** Grade desatualizada.
* **28:** Valores dos atributos de grade são inválidos.
* **29:** Categoria não encontrada.
* **31:** Existem Categorias com múltiplos pais, utilize a referencia base.
* **38:** Código referência base ou código SKU inválido.
* **39:** Não é permitido alterar o código referência base ou código SKU.
* **40:** Tipo de geração de código atual não permite a inserção do código referência base ou código SKU 
manualmente.
* **41:** Não foram informadas categorias para todos os níveis cadastrados no sistema.
* **43:** Código de Barras informado já utilizado em outra mercadoria.
* **44:** Código Interno informado já utilizado em outra mercadoria.
* **45:** Nome da mercadoria já utilizado em outra mercadoria.

_Categoria_
* **51:** Categoria sem nome.
* **52:** Categoria com unidade inválida.
* **53:** Categoria com classificação inválida.
* **54:** Categoria com origem inválida.
* **55:** Categoria com método de controle inválido.
* **56:** Categoria não encontrada.
* **57:** Nível não encontrado.
* **58:** Não é possível cadastrar/atualizar uma Categoria no mesmo Nível da Categorias Pai.
* **59:** Existem Categorias sem Nível vínculado.
* **60:** Existem Categorias Pais em níveis diferentes.
* **61:** Não foi possível cadastrar um novo nível.
* **62:** Categoria pai não vinculada com um nível.
* **63:** Categoria pai em nível inferior ao nível da categoria atual.

_Boleto_
* **100:** Conta a Receber já foi baixada.
* **101:** Já existe boleto gerado para esta Conta a Receber.

_Estoque_
* **200:** Saldo da mercadoria insuficiente para executar a operação.

_Terceiros_
* **300:** Terceiro não encontrado.

_Planos de Pagamento_
* **401:** Plano de pagamento não encontrado.

_Representantes_
* **500:** Representante não encontrado.

_Cartão_
* **600:** Negociação de cartão não encontrada.