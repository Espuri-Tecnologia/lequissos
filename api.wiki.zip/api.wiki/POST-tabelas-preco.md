### URLs

> POST https://integrador.varejonline.com.br/apps/api/tabelas-preco

### Parâmetros
Envie um JSON no corpo da requisição, contendo:

* **nome:** Nome da tabela de preço
* **disponivel:** Informa se a tabela estará ativa. Ex.: false para inativa e true para ativa.
* **idsEntidades:** [Entidade](https://github.com/Varejonline/api/wiki/GET-entidades) da tabela de preço
* **classificacoesCliente:** Classificações da tabela de preço
    * nome: Nome dado para a classificação de cliente a qual a tabela é restrita
* **permanente:** Informa se é uma tabela permanente. (Boolean) Ex.: false para não permanente e true para permanente.
* **inicioVigencia:** Início da vigência da tabela. Ex.: 01/01/2015 13:00:00
* **fimVigencia:** Fim da vigência da tabela. Ex.: 10/06/2015 11:00:00
* **promocao:** Indica se a tabela é promocional ou não (Boolean)
* **peso:** indica o peso para que a tabela seja aplicada, quando não informado, é usado o seguinte critério:
    * Tabela padrão: Peso 0
    * Tabela permanente não promocional sem classificação de cliente: Peso 1
    * Tabela permanente não promocional com classificação de cliente: Peso 2
    * Tabela com vigência não promocional sem classificação de cliente: Peso 3
    * Tabela com vigência não promocional com classificação de cliente: Peso 4
    * Tabela permanente promocional sem classificação de cliente: Peso 5
    * Tabela permanente promocional com classificação de cliente: Peso 6
    * Tabela com vigência promocional sem classificação de cliente: Peso 7
    * Tabela com vigência promocional com classificação de cliente: Peso 8

    * O maior peso define o preço que será aplicado na venda do item.
    * Deve ser informado um valor maior que 8 para que o peso informado tenha efeito.

### Exemplo

> POST https://integrador.varejonline.com.br/apps/api/tabelas-preco

```javascript
   {
      "nome": "Tabela TESTE",
      "idsEntidades":[3],
      "compra": false,
      "aplicaDesconto": true, 
      "disponivel": true, 
      "classificacoesCliente":[{
          "nome":"PADRAO"
       }],
      "permanente": false,	
      "promocao": true,		
      "peso": 200,	
      "inicioVigencia":"01/05/2023 13:00:00",
      "fimVigencia":"10/07/2023 11:00:00"
   }

```

### Exemplo de retorno:

_Sucesso:_
* HTTP STATUS 200 – OK
* Body:
```javascript
{
      "idRecurso": 1002,
      "codigoMensagem": 0,
      "mensagem": "Operação realizada com sucesso."
}
```

_Requisição inválida:_
* HTTP STATUS 400 – BAD REQUEST
* Body: 
```javascript
{
      "idRecurso": 0,
      "codigoMensagem": 10,
      "mensagem": "Descrição do erro"
}
```