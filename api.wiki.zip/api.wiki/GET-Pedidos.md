### URLs

> GET https://integrador.varejonline.com.br/apps/api/pedidos

> GET https://integrador.varejonline.com.br/apps/api/pedidos/:id

### Parâmetros

* **entidades:** [Veja como Funciona este Filtro](https://github.com/Varejonline/api/wiki/Filtro-de-Entidades)
* **inicio:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **quantidade:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **alteradoApos:** [Entenda a Coleta de Alterações](https://github.com/Varejonline/api/wiki/Filtro-de-Data-Alteração)
* **desde:** [Veja o Filtro de Datas](https://github.com/Varejonline/api/wiki/Filtro-de-Datas)
* **ate:** [Veja o Filtro de Datas](https://github.com/Varejonline/api/wiki/Filtro-de-Datas)
* **terceiro:** [Veja o filtro de Terceiro](https://github.com/Varejonline/api/wiki/Filtro-de-Terceiro)
* **carregarPagamentos:** indica se "composicaoPagamento" deve ser carregado (boolean)
* **carregarImpostosNota:** indica se os impostos devem ser carregados no pedidos a partir da nota fiscal vinculada. Necessário para exibir os valores de tributação nos itens em pedidos realizados no PDV. (boolean)
* **numeros:** lista de números dos pedidos de venda gerado pelo sistema (string, separada por vírgula)
* **numeroPedidoCliente:** número do referência do pedido de venda utilizado pelo cliente (string)
* **idsOrcamentos:** lista de ids de orçamentos. Retorna as saídas associadas aos orçamentos (long, separado por vírgula)
* **tipos:** lista de tipos de venda (NORMAL, SHIP_FROM_STORE, CLICK_COLLECT) (string, separada por vírgula)
* **orderBy:** Tipo da ordenação de resultados desejada (string)
  * **id**  ordenação crescente pelo id dos registros (Valor padrão caso não informado)
  * **saida.dataAlteracao** ordenação crescente pela data de alteração dos registros
  * **saida.dataCriacao** ordenação crescente pela data de criação dos registros
  * **saida.dataCancelamento** ordenação crescente pela data de cancelamento
  * **saida.numeroDocumento** ordenação crescente pelo campo numero
* **[integrados](https://github.com/Varejonline/api/wiki/Controle-de-registros-integrados):** Filtro de controle de integração de registros(boolean)
  * **1** retorna apenas registros já marcados como coletados pelo integrador
  * **0** retorna apenas registros não marcados como coletados pelo integrador
* **[integrador](https://github.com/Varejonline/api/wiki/Controle-de-registros-integrados):** Nome utilizado pelo integrador para registrar o registro como integrado (String)
* **ignorarSimplesFaturamento:** indica se lançamentos de simples faturamento devem ser ignorados (boolean)
* **statusPedidoVendaIds:** lista de ids de status pedido venda. Retorna as saídas associadas aos [Status Pedido Venda](https://github.com/Varejonline/api/wiki/GET-Status-Pedido-Venda) (long, separado por vírgula)

**Observações**

**carregarImpostosNota** pode aumentar consideravelmente o tempo para o retorno. Considere carregar somente se necessário.

### Retorno
    
* **id:** id do pedido (long)
* **idSaida:** [id da saída](https://github.com/Varejonline/api/wiki/GET-saidas) vinculada (long)
* **numero:** número do pedido de venda gerado pelo sistema (string)
* **numeroPedidoCliente:** número do referência do pedido de venda utilizado pelo cliente (string)
* **data:** data de emissão do pedido (string)
* **horario:** horário de criação do pedido, no formato hh:mm:ss (string)
* **dataAlteracao:** última data de alteração do pedido, no formato dd-mm-aaaa hh:mi:ss (string)
* **cancelado:** informa se o pedido está cancelado (boolean)
* **entidade:** dados da entidade onde foi realizado o pedido
  * **id:** id da [entidade](https://github.com/Varejonline/api/wiki/GET-entidades)(long)
  * **nome:** nome da [entidade](https://github.com/Varejonline/api/wiki/GET-entidades)(string)
  * **documento:** CNPJ formatado da loja associada a [entidade](https://github.com/Varejonline/api/wiki/GET-entidades)(string)
* **representante:** dados do [vendedor](https://github.com/Varejonline/api/wiki/GET-representantes) principal da venda
  * **id:** id do [vendedor](https://github.com/Varejonline/api/wiki/GET-representantes)(long)
  * **nome:** nome do [vendedor](https://github.com/Varejonline/api/wiki/GET-representantes)(string)
  * **documento:** CPF formato do [vendedor](https://github.com/Varejonline/api/wiki/GET-representantes)(string)
* **cliente:** dados do [cliente](https://github.com/Varejonline/api/wiki/GET-terceiros) associado à venda
    * **id:** id do [cliente](https://github.com/Varejonline/api/wiki/GET-terceiros) (long)
    * **nome:** nome do [cliente](https://github.com/Varejonline/api/wiki/GET-terceiros) (string)
    * **documento:** CNPJ/CPF formatado do [cliente](https://github.com/Varejonline/api/wiki/GET-terceiros) (string)
* **idProvisao:** id da [provisão](https://github.com/Varejonline/api/wiki/GET-contas-receber) gerada pelo pedido no contas a receber. Use o parâmetro idProvisao no GET Contas Receber (long)
* **parcelas:** lista das [parcelas](https://github.com/Varejonline/api/wiki/GET-contas-receber) do pedido, cada uma contendo:
  * **id:** id da [parcela](https://github.com/Varejonline/api/wiki/GET-contas-receber) (long)
  * **dataVencimento:** data de vencimento da parcela (string)
  * **valor:** valor total da parcela (decimal)
* **valePresenteUtilizado:** Informações sobre o vale presente utilizado como pagamento (lista de objeto complexo) (só aparece se o parâmetro **carregarPagamentos** for true) (**deprecated**: agora esta propriedade esta dentro da **composicaoPagamento**)
  * **voucherId:** id do voucher relacionado (long)
  * **valorUtilizado:** valor consumido do vale presente (decimal)
  * **numeroValePresente:** número do vale presente (string)
* **valePresente:** Informações para vale presente (objeto complexo)
  * **controleNumeracao:** tipo do controle de numeração (AUTOMATICO, MANUAL) (string)
  * **usoUnico:** uso único (booleano)
  * **controlaValidade:** controle de validade (booleano)
  * **periodoValidadeTipo:** tipo do periodo de validade (DIAS, MESES, ANOS) (string)
  * **periodoValidadeValor:** tempo do periodo de validade (numerico)
  * **formatoValePresente:** formato do vale presente (FISICO, DIGITAL, AMBOS) (string)
* **composicaoPagamento:** Dados do pagamento aplicado na venda
  * **saidaId:** id da [saida](https://github.com/Varejonline/api/wiki/GET-saidas) associada ao pedido (long)
  * **valorChequeVista:** valor pago em cheque a vista (decimal)
  * **valorChequePrazo:** valor pago em cheque a prazo (decimal)
  * **valorDinheiro:** valor pago em dinheiro (decimal)
  * **valorCrediario:** valor gerado no crediário (decimal)
  * **valorVoucher:** valor pago em voucher (decimal)
  * **valorValePresente:** valor pago com vale presente (decimal)
  * **valorTroca:** valor pago com troca (decimal)
  * **valorAdiantamento:** valor pago utilizando adiantamentos (decimal)
  * **valoresValePresente:** Lista de pagamentos utilizando Vale Presente. Lista de:
    * **valorUtilizado:** valor do PIX (decimal)
    * **voucherId:** Id do [voucher](https://github.com/Varejonline/api/wiki/GET-Vouchers) (long)
    * **numeroValePresente:** número do vale presente (string)
  * **valoresVoucher:** Lista de pagamentos utilizando Voucher. Lista de:
    * **valorUtilizado:** valor utilizado do voucher (decimal)
    * **voucherId:** Id do [voucher](https://github.com/Varejonline/api/wiki/GET-Vouchers) (long)
  * **valoresAdiantamento:** Lista de pagamentos utilizando Adiantamento. Lista de:
    * **valorUtilizado:** valor utilizado do adiantamento (decimal)
    * **adiantamentoId:** Id do [adiantamento](https://github.com/Varejonline/api/wiki/GET-adiantamentos-recebidos) (long)
  * **valoresPix:** Lista de pagamentos utilizando PIX. Lista de:
    * **valor:** valor do PIX (decimal)
    * **nsu:** Número sequêncial único do PIX (string)
    * **autorizacao:** autorização da transação (string)
  * **valoresBoleto:** Lista de pagamentos utilizando BOLETO. Lista de:
    * **valor:** valor do BOLETO(decimal)
    * **identificacao:** Identificacao do BOLETO (string)
  * **valoresCartao:** Lista de pagamentos em cartão. Lista de:
    * **valor:** valor do cartão (decimal)
    * **bandeira:** [bandeira](https://github.com/Varejonline/api/wiki/Cartao-bandeiras) do cartão (string)
    * **tipoCartao:** tipo do cartão (string CREDITO, DEBITO ou OUTROS)
    * **operadora:** [operadora](https://github.com/Varejonline/api/wiki/Cartao-operadoras) do cartão (string)
    * **numeroParcelas:** número de parcelas aplicadas no cartão (inteiro)
    * **nsu:** NSU da transação (string)
    * **autorizacao:** Autorização da transação (string)
  * **plano:** Dados do plano de pagamento utilizado na venda
    * **id:** id do [plano de pagamento](https://github.com/Varejonline/api/wiki/GET-planos-pagamento)(long)
    * **descricao:** nome do [plano de pagamento](https://github.com/Varejonline/api/wiki/GET-planos-pagamento)(long)
* **valorTotal:** valor do pedido (Com abatimentos dos descontos concedidos [bruto - descontos]) (decimal)
* **valorDesconto:** valor de desconto total do pedido (decimal)
  * **valesPresentes:** lista de vales presentes contendo:
    * **numeroValePresente:** número do vale presente (string)
    * **emailValePresente:** email do vale presente (string)
    * **formatoValePresente:** formato do vale presente (string) (FISICO, DIGITAL, AMBOS)
    * **nomePresenteado:** nome do presenteado (string)
    * **usoValePresente:** uso do vale presente (string) (PROPRIO, PRESENTE)
* **valorAcrescimo:** valor de acréscimo total do pedido (decimal)
* **descontoDetalhes:** lista de detalhes do desconto, contendo:
    * **observacao:** observação do desconto (string)
    * **valor:** valor do desconto (decimal)
    * **origemDesconto:** [origem](https://github.com/Varejonline/api/wiki/Origens-de-detalhe-de-Desconto) do desconto 
    * **idReferencia:** id da tabela origem do desconto, por exemplo se a origem do desconto for TABELA_PRECO, será o id da tabela (long)
    * **descricao:** Nome original de referência (Ex, nome da **tabela de preço** ou nome da **ação promocional** )
* **valorLiquido:** valor líquido do pedido (valorTotal - pagamento com vale trocas [valeTrocasUtilizados]) (decimal)
* **valorFrete:** valor de frete do pedido (decimal)
* **valorSeguro:** valor de seguro do pedido (decimal)
* **valorOutros:** outros valores do pedido (decimal)
* **observacao:** observações incluídas no pedido (string)
* **itens:** lista de itens do pedido, cada um contendo:
    * **produto:** dados do produto devolvido (objeto complexo)
        * **id:** id da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos)
        * **descricao:** id da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos)
        * **codigoSistema:** Código Sistema da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos)
        * **codigoInterno:** Código Interno da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos)
        * **codigoBarras:** Código de Barras da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos)
    * **unidade:** unidade utilizada na venda (string)
    * **quantidade:** quantidade vendida do produto na unidade informada (decimal)
    * **tabelaPrecoId:** [tabela de preço](https://github.com/Varejonline/api/wiki/GET-tabelas-preco) aplicada na venda do item (long)
    * **reservarEstoque:** indica se foi criada uma reserva de estoque para o item (boolean opcional).
    * **dataEntrega:** indica a data em que será entregue o item ao cliente (Apenas para operação de simples faturamento, formato dd-MM-yyyy)
    * **valorTotal:** valor total do item (decimal)
    * **valorDesconto:** valor de desconto total do item (decimal)
    * **valorAcrescimo:** valor de acréscimo total do item (decimal)
    * **descontoDetalhes:** lista de detalhes do desconto, contendo:
      * **observacao:** observação do desconto (string)
      * **valor:** valor do desconto (decimal)
      * **origemDesconto:** [origem](https://github.com/Varejonline/api/wiki/Origens-de-detalhe-de-Desconto) do desconto
      * **idReferencia:** id da tabela origem do desconto, por exemplo se a origem do desconto for TABELA_PRECO, será o id da tabela (long) 
      * **descricao:** Nome original de referência (Ex, nome da **tabela de preço** ou nome da **ação promocional** )
    * **valorDescontoItem:** valor de desconto oferecido no item (decimal)
    * **valorDescontoRateado:** valor de desconto oferecido na venda, rateado no item (decimal)
    * **valorFreteRateado:** valor rateado do frete para o produto (decimal)
    * **valorICMSItem:** valor do ICMS considerando apenas valorTotal X ICMS% (decimal)
    * **valorICMSFrete:** valor do ICMS considerando apenas o valor do frete rateado X ICMS% (decimal)
    * **valorPIS:** valor do PIS aplicado ao item (decimal)
    * **valorICMS:** valor do ICMS aplicado ao item (decimal)
    * **valorCOFINS:** valor do CONFINS aplicado ao item (decimal)
    * **valorICMSST:** valor do ICMS ST aplicado ao item (decimal)
    * **valorIPI:** valor do IPI aplicado ao item (decimal)
    * **valorFCPST:** valor do FCPST aplicado ao item (decimal)
    * **valorCusto:** valor apurado de quanto custou a mercadoria vendida para a empresa. Este é o valor total para toda a quantidade dos itens, o valor individual pode ser obtido dividindo-se este valor pela quantidade de itens (decimal)
    * **lote:** o lote de origem do item, contendo
        * **id:** id do lote (long)
        * **codigo:** código do lote (string)
        * **dataFabricacao:** data de fabricação do lote (string)
        * **dataVencimento:** data de vencimento do lote (string)
    * **serie:** lista de séries dos produtos vendidos, cada uma contendo:
        * **id:** id da série (long)
        * **numero:** número de série do produto (string)
        * **dataFabricacao:** data de fabricação do produto (string)
    * **representante:** dados do [vendedor](https://github.com/Varejonline/api/wiki/GET-representantes) do item
      * **id:** id do [vendedor](https://github.com/Varejonline/api/wiki/GET-representantes)(long)
      * **nome:** nome do [vendedor](https://github.com/Varejonline/api/wiki/GET-representantes)(string)
      * **documento:** CPF formato do [vendedor](https://github.com/Varejonline/api/wiki/GET-representantes)(string)
    * **operacao:** Operação do movimento (long)
      * **descricao:** descrição da operação (string)
      * **id:** id da operação (long)
    * **valesPresentes:** Lista de vale presente do item, contendo
      * **id:** id do vale presente (long)
      * **numeroValePresente:** numero do vale presente (string) 
    * **servicos:** lista de servicos vendidos no pedido, cada um contendo:
    * **servico:** dados do [serviço](https://github.com/Varejonline/api/wiki/GET-servicos) (objeto complexo)
        * **id:** (Long)
        * **descricao:** (string)
        * **codigoSistema:** (string)
        * **codigoInterno:** (string)
        * **executores:** lista de [terceiros executores](https://github.com/Varejonline/api/wiki/GET-terceiros) (objeto complexo)
          * **id:** id do terceiro (Long)
          * **nome:** nome do terceiro (string)
          * **documento:** documento do terceiro (string)
    * **unidade:** unidade utilizada na venda (string)
    * **quantidade:** quantidade vendida do serviço na unidade informada (decimal)
    * **valorTotal:** valor total do serviço (decimal)
    * **valorDesconto:** valor de desconto oferecido no serviço (decimal)
    * **valorAcrescimo:** valor de acréscimo total no serviço (decimal)
    * **descontoDetalhes:** lista de detalhes do desconto, contendo:
      * **observacao:** observação do desconto (string)
      * **valor:** valor do desconto (decimal)
      * **origemDesconto:** [origem](https://github.com/Varejonline/api/wiki/Origens-de-detalhe-de-Desconto) do desconto 
      * **idReferencia:** id da tabela origem do desconto, por exemplo se a origem do desconto for TABELA_PRECO, será o id da tabela (long)
      * **descricao:** Nome original de referência (Ex, nome da **tabela de preço** ou nome da **ação promocional** )
    * **valorPIS:** valor do PIS aplicado ao serviço (decimal)
    * **valorCOFINS:** valor do CONFINS aplicado ao serviço(decimal)
    * **valorISS:** valor do ISS aplicado ao serviço(decimal)
    * **representante:** dados do [vendedor](https://github.com/Varejonline/api/wiki/GET-representantes) do item
      * **id:** id do [vendedor](https://github.com/Varejonline/api/wiki/GET-representantes)(long)
      * **nome:** nome do [vendedor](https://github.com/Varejonline/api/wiki/GET-representantes)(string)
      * **documento:** CPF formato do [vendedor](https://github.com/Varejonline/api/wiki/GET-representantes)
* **statusConferencia:** status da conferência de caixa: 'NAO_CONFERIDO', 'CONFERIDO', 'CONFIRMADO', 'PROCESSANDO', 'CONCLUIDO', 'CONFERIDO_AUTOMATICAMENTE' e 'ERRO'  (string)
* **nomeTerminal:** nome do terminal onde foi realizada a venda na loja (string)
* **notasFiscais:**  lista de notas fiscais do pedido, cada uma contendo:
  * **status:** [status](https://github.com/Varejonline/api/wiki/Status-Documentos-Fiscais) da nota fiscal (string).
  * **idNotaFiscal:** id da [nota fiscal](https://github.com/Varejonline/api/wiki/GET-notas-mercadoria) (long)
  * **tipoNotaFiscal:** tipo da nota fiscal (string)
* **valeTrocaGerado:** Vale trocas gerados durante a venda (Venda com troca de mercadorias)
  * **numeroValeTroca:** numero do vale troca gerado na troca de mercadorias (string)
  * **idDevolucaoGerada:** id da [devolução de venda](https://github.com/Varejonline/api/wiki/GET-devolucoes) gerada na troca (decimal)
* **valeTrocasUtilizados:** lista de valores de vale trocas utilizados no pagamento do pedido
  * **valorUtilizado:** valor utilizado no pagamento (decimal)

* **origem:** origem da venda (ECOMMERCE, MARKETPLACE, LOJA_FISICA) (string)
* **tipo:** tipo da venda (NORMAL, SHIP_FROM_STORE, CLICK_COLLECT) (string)
* **statusPedidoVenda:** [Status da venda](https://github.com/Varejonline/api/wiki/GET-Status-Pedido-Venda) (string)
* **intermediador:** intermediador da venda (informar id ou documento)
  * **id:** id do [intermediador](https://github.com/Varejonline/api/wiki/GET-terceiros) (long)
  * **documento:** documento do intermediador (string)
* **transporte:** dados de transporte
  * **modalidade:** modalidade do transporte (EMITENTE, DESTINATARIO_REMETENTE, TERCEIRO, PROPRIO_REMETENTE, PROPRIO_DESTINATARIO)
  * **transportador:**
    * **id:** id do [transportador](https://github.com/Varejonline/api/wiki/GET-terceiros) (long)
    * **documento:** documento do transportador (string)
  * **codigoANTT:** Código ANTT do transporte (string)
  * **placaVeiculo:** Placa do veiculo de transporte (string)
  * **estadoVeiculo:** Sigla do estado do veiculo de transporte (string)
  * **especie:** espécie do volume transportado
  * **marca:** marca do volume transportado (decimal)
  * **numero:** número do volume transportado (decimal)
  * **pesoBruto:** peso bruto transportado (decimal)
  * **pesoLiquido:** peso líquido transportado  (decimal)
* **enderecoEntrega:** dados do endereço de entrega
   * **logradouro:** nome do logradouro (string)
   * **numero:** número do endereço (string)
   * **bairro:** bairro do endereço (string)
   * **complemento:** complemento do endereço (string)
   * **cep:** CEP do endereço sem máscara (string)
   * **cidade:** Nome da cidade (string)
   * **uf:** Sigla do estado (string)
   * **receptorEntrega:** Nome da pessoa que receberá a entrega (string)
   * **receptorEntregaDocumento:** Documento da pessoa que receberá a entrega (string)
* **idsOrcamentos:** lista de ids de orçamentos. Retorna as saídas associadas aos orçamentos (lista de longs)
* **urlEtiqueta:** url de impressão da etiqueta (string)
* **sistemaOrigem:**  sistema de origem do pedido (ERP, ERP_API, PDV, PDV_CHECKOUT) (string)

### Observações Importantes

As parcelas do pedido só são geradas após a conferência de caixa, ou seja, as parcelas só serão retornadas no endpoint quando o statusConferencia for 'CONCLUIDO' ou 'CONFERIDO_AUTOMATICAMENTE'.
 
### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/pedidos

```javascript
{  
    "id":60378,
    "idSaida":103755,
    "data":"13-07-2019",
    "valorFrete":0,
    "valorSeguro":0,
    "valorOutros":0,
    "cancelado":false,
    "valorTotal":86.5,
    "valorLiquido":86.5,
    "statusConferencia":"CONCLUIDO",
    "numero":"4-38712",
    "dataAlteracao":"06-09-2019 19:43:51",
    "horario":"13:36:58",
    "vendaConsumidorFinal":false,
    "sistemaOrigem":ERP,
    "cliente":{  
       "id":1,
       "nome":"DIVERSOS",
       "documento":"000.000.000-00"
    },
    "entidade":{  
       "id":1,
       "nome":"NOME DA ENTIDADE",
       "documento":"21.097.764/0001-45"
    },
    "representante":{  
       "id":30,
       "nome":"VENDEDOR PRINCIPAL",
       "documento":"069.345.876-31"
    },
    "nomeTerminal":"PDV2",
    "notasFiscais":[  
       {  
          "status":"EMITIDO",
          "idNotaFiscal":193306,
          "tipoNotaFiscal":"MERCADORIA"
       }
    ],
    "servicos":[  
 
    ],
    "itens":[  
       {  
          "quantidade":1,
          "valorDescontoRateado":0.00,
          "valorFreteRateado":0.00,
          "valorICMSItem":0.00,
          "valorICMSFrete":0.00,
          "representante":{  
             "id":30,
             "nome":"VENDEDOR DO ITEM",
             "documento":"087.345.000-02"
          },
          "reservarEstoque":true,
          "dataEntrega":"01-02-2021",
          "valorCOFINS":0,
          "valorFCPST":0,
          "valorICMS":0,
          "valorICMSST":0,
          "valorIPI":0,
          "valorCusto":47.79,
          "idProduto":5299,
          "idRepresentante":30,
          "valorTotal":86.5,
          "valorDesconto":0.00,
          "valorAcrescimo":0.00,
          "valorPIS":0,
          "unidade":"UN",
          "tabelaPrecoId":1,
          "produto":{  
             "id":5299,
             "descricao":"PRODUTO DO ITEM UM",
             "codigoBarras":"78970859143465",
             "codigoInterno":"",
             "codigoSistema":"0001"
          },
          "valorDescontoItem":0.00
       }
    ],
    "idProvisao":114016,
    "parcelas":[  
       {  
          "id":118755,
          "valor":86.5,
          "dataVencimento":"13-07-2019"
       }
    ],
    "composicaoPagamento":{  
       "saidaId":61269,
       "valorChequeVista":0,
       "valorChequePrazo":0,
       "idPlanoCrediario":1,
       "valorDinheiro":0,
       "valorCrediario":0,
       "valorVoucher":0,
       "valorValePresente":0,
       "valorTroca":0,
       "valorAdiantamento":0,
       "valoresCartao":[  
          {  
             "valor":10,
             "nsu":"005539932"
          }
       ],
       "valoresCartao":[  
          {  
             "valor":76.5,
             "bandeira":"OUTROS",
             "tipoCartao":"DEBITO",
             "operadora":"GETNET",
             "numeroParcelas":1,
             "nsu": "01092731",
             "autorizacao": "01838164871"
          }
       ],
       "valoresPix": [
         {
             "nsu": "500003",
             "autorizacao": "11111111",
             "valor": 164.9
          }
       ],
       "plano":{  
          "id":1,
          "descricao":"A VISTA"
       }
    },
    "statusPedidoVenda": {
        "id": 6,
        "nome": "Finalizado",
        "descricao": "Finalizado",
        "dataAlteracao": "06-11-2023",
        "dataCriacao": "06-11-2023",
        "ativo": true,
        "deletado": false
    },
    "origem": "MARKETPLACE",
    "tipo": "NORMAL",
    "enderecoEntrega": {
        "logradouro": "Rua iririu",
        "numero": "1777",
        "complemento": "Em cima do bradesco",
        "bairro": "Iririu",
        "cep": "89227-000",
        "cidade": "Joinville",
        "uf": "SC",
        "receptorEntrega": "Maria",
        "receptorEntregaDocumento": "000.000.000-00"
    },
    "intermediador": {
        "id": 1,
        "documento": "00.000.000/0001-00"
    },
    "transporte": {
        "modalidade": "EMITENTE",
        "transportador": {
            "id": 1,
            "documento": "00.000.000/0001-00"
        },
        "codigoANTT": "ABC1777",
        "placaVeiculo": "AFE8B87",
        "estadoVeiculo": "SC",
        "quantidade": "2",
        "especie": "CAIXA",
        "marca": "ASD",
        "numero": "23",
        "pesoBruto": 50,
        "pesoLiquido": 40
    }
 }
```

### URL de controle de registro integrado

> POST https://integrador.varejonline.com.br/apps/api/pedidos/registro/integracao/{integrador}

Onde {integrador} deve ser substituído pelo nome de integrador utilizado no controle de registros integrados

No corpo da mensagem, enviar um array com os ids a serem marcados como integrados pelo integrador: 

```javascript
{
    "objectIds": [
        1,
        2,
        ....
    ]
}
```