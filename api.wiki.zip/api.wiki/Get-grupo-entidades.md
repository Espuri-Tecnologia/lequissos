### URLs

> GET https://integrador.varejonline.com.br/apps/api/grupo-entidades

> GET https://integrador.varejonline.com.br/apps/api/grupo-entidades/:id

### Parâmetros

* **inicio:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **quantidade:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **alteradoApos:** [Entenda a Coleta de Alterações](https://github.com/Varejonline/api/wiki/Filtro-de-Data-Alteração)
* **ativo:** filtrar grupos com base no status ativo (1 ou 0) (boolean)
* **deletado:** filtrar grupos com base no status deletado (1 ou 0) (boolean)


### Retorno

* **id:** id do grupo (long)
* **descricao:** nome do grupo (string)
* **ativo:** indica se o grupo está ativo (boolean)
* **deletado:** indica se o grupo foi deletado (boolean)
* **entidades:** lista de ids das entidades que fazem parte do grupo (lista de long)

### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/grupo-entidades/?inicio=0&quantidade=1&ativo=0&deletado=0

```javascript
[
    {
        "id": 1,
        "descricao": "Grupo G1",
        "deletado": false,
        "ativo": false,
        "entidades": [
            3,
            9,
            15
        ]
    }
]
```