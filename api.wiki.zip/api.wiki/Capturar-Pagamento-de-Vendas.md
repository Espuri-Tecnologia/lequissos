# Capturando os dados de pagamento das vendas

## 1) Obter a Nota de Mercadoria

**API**: https://github.com/Varejonline/api/wiki/GET-notas-mercadoria

**Exemplo**:

https://integrador.varejonline.com.br/apps/api/notas-mercadoria/999999?token=....

Dentro do JSON retornado, temos as saídas vinculadas à nota: 
	
	"saidas":[97156]

## 2) Capturar as Saídas

**API**: https://github.com/Varejonline/api/wiki/GET-saidas

**Exemplo**:

https://integrador.varejonline.com.br/apps/api/saidas/97156?token=....

Dentro do JSON retornado, temos a provisão gerada:

	"idProvisao":287724

## 3) Capturar o Contas a Receber

**API**: https://github.com/Varejonline/api/wiki/GET-contas-receber

**Exemplo**:

https://integrador.varejonline.com.br/apps/api/contas-receber?idProvisao=287724&token=....

Dentro do JSON retornado, temos a composição do valor baixado, contendo todas as formas de pagamento utilizadas na baixa da provisão. Entre os tipos de pagamento, estará a composição de cartões utilizados (vide documentação da API). Dentro de cada cartão usado, existirá a negociação de cartão associada.

	“idNegociacao":6

## 4) Obter a Negociação de Cartão

**API**: https://github.com/Varejonline/api/wiki/GET-negociacoes-cartao

**Exemplo**: 

https://integrador.varejonline.com.br/apps/api/negociacoes-cartao/6?token=....

O retorno da API vai apresentar a modalidade (crédito ou débito), operadora, bandeira, entre outros.
