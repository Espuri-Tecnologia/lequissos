Listagem dos possíveis tipos de classificação de um terceiro.

<table>
<tr><th>Classe</th></tr>
<tr><td> CLIENTE </td></tr>
<tr><td> COOPERADO </td></tr>
<tr><td> ACIONISTA </td></tr>
<tr><td> FORNECEDOR </td></tr>
<tr><td> FUNCIONARIO </td></tr>
<tr><td> OUTROS </td></tr>
<tr><td> PRESTADOR_SERVICO </td></tr>
<tr><td> SOCIO_PROPRIETARIO </td></tr>
<tr><td> TECNICO </td></tr>
</table>