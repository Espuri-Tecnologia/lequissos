### URLs

> GET https://integrador.varejonline.com.br/apps/api/planos-pagamento

> GET https://integrador.varejonline.com.br/apps/api/planos-pagamento/:id

### Parâmetros

* **inicio:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **quantidade:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **alteradoApos:** [Entenda a Coleta de Alterações](https://github.com/Varejonline/api/wiki/Filtro-de-Data-Alteração)
* **documentoTerceiro:** Busca o plano de pagamento associado ao [cliente](https://github.com/Varejonline/api/wiki/GET-terceiros) do CNPJ informado. 


### Retorno 

* **id:** id do plano de pagamento (long)
* **descricao:** descrição do plano de pagamento (string)
* **dataAlteracao:** última data de alteração do plano de pagamento, no formato dd-mm-aaaa hh:mi:ss (string)
* **juros:** indica a porcentagem de juros a ser cobrado pelo plano de pagamento, em caso de atraso de pagamento (decimal)
* **acrescimo:** indica a porcentagem de acréscimo a ser adicionado em um pedido de venda quando o plano de pagamento é utilizado (decimal)
* **multa:** indica a porcentagem de multa a ser cobrada pelo plano depagamento, em caso de atraso de pagamento (decimal)
* **ativo:** indica o se o plano de pagamento está ativo ou inativo (booleano)
* **parcelas:** parcelas que compõem o plano
    * **id:** id da parcela (long)
    * **porcentagem:** expressa a proporção do valor da parcela em relação ao somatório de porcentagem de todas as parcelas (100) (decimal)
    * **dia:** número de dias até o vencimento (int)

### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/planos-pagamento

```javascript
[
   {
      "id":1,
      "descricao":"A VISTA",
      "dataAlteracao":"21-01-2013 15:28:05",
      "juros": 0.0,
      "acrescimo": 0.0,
      "multa":0.0,
      "ativo":true
   },
   {
      "id": 2,
      "acrescimo": 0,
      "multa": 0,
      "juros": 0,
      "dataAlteracao": "21-03-2012 08:55:28",
      "descricao": "AVULSO",
      "ativo": true
   },
   {
      "id":100,
      "descricao":"1 + 5x CREDIÁRIO",
      "dataAlteracao":"11-01-2013 14:44:32",
      "juros": 1.50,
      "acrescimo": 3.70,
      "multa":2.30,
      "ativo":true,
      "parcelas": [
          {
              "id": 1,
              "porcentagem": 16.7,
              "dia": 0
          },
          {
              "id": 2,
              "porcentagem": 16.66,
              "dia": 30
          },
          {
              "id": 3,
              "porcentagem": 16.66,
              "dia": 60
          },
          {
              "id": 4,
              "porcentagem": 16.66,
              "dia": 90
          },
          {
              "id": 5,
              "porcentagem": 16.66,
              "dia": 120
          },
          {
              "id": 6,
              "porcentagem": 16.66,
              "dia": 150
          }
        ]
   }
]
```