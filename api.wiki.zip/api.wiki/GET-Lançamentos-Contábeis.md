Endpoint para coleta de lançamentos contábeis.

### URLs

> GET https://integrador.varejonline.com.br/apps/api/lancamento-contabil

### Parâmetros

* **inicio:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **quantidade:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **desde:** [Veja o Filtro de Datas](https://github.com/Varejonline/api/wiki/Filtro-de-Datas)
* **ate:** [Veja o Filtro de Datas](https://github.com/Varejonline/api/wiki/Filtro-de-Datas)
* **alteradoApos:** [Entenda a Coleta de Alterações](https://github.com/Varejonline/api/wiki/Filtro-de-Data-Alteração)
* **idOperacaoContabil:** Buscar por id de operação contábil. 

### Retorno

* **id**: id do lançamento contábil (long)
* **data:** data base da operação contábil (string format dd-mm-aaaa)
* **valor:** valor do lançamento contábil (decimal)
* **sequencia:** número sequencial do lançamento dentro da operação contábil (long)
* **entidade:** [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) associada à operação contábil  (objeto complexo)
    * **id:** id da entidade (long)
    * **nome:** nome da entidade (string)
    * **documento:** documento da entidade (string)
* **terceiro:** [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros) associado ao lançamento contábil (objeto complexo)
    * **id:**  id do terceiro (long)
    * **nome:** nome do terceiro (string)
    * **documento:** documento do terceiro (string)
* **numero:** número do lançamento contábil, informado pelo usuário (string)
* **historico:** histórico do lançamento contábil (string - possui quebras de linha "\n")
* **contas:** par de contas contábeis associadas ao lançamento contábil (array)
    * **id:** id da conta (inteiro)
    * **nome:** nome da conta (string)
    * **classificador:** classificador completo da conta (string)
    * **acesso:** número de acesso da conta contábil (string)
    * **natureza:** natureza da conta contábil (string "CREDITO" ou "DEBITO")
    * **tipoConta:** ANALITICA, SINTETICA, SUBCONTA (string)
    * **contaAcessoExterna:** número de acesso da conta externa (string)
* **tipoDocumento:** [Tipo do Documento](https://github.com/Varejonline/api/wiki/Tipos-de-Documentos-Financeiros) que gerou a operação contábil (string)

### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/lancamento-contabil

```javascript
[
    {
        "id": 80,
        "data": "23-09-2016",
        "valor": 55.58,
        "sequencia": 1,
        "entidade": {
            "id": 3,
            "nome": "Entidade teste",
            "documento": "00.000.000/0000-00"
        },
        "terceiro": {
            "id": 1,
            "nome": "DIVERSOS",
            "documento": "000.000.000-00"
        },
        "numero": "27706.0",
        "historico": "CUPOM FISCAL - 27706",
        "contas": [
            {
                "id": 721,
                "nome": "13802 Débitos C/C ENTIDADES",
                "classificador": "1.01.20.50.01.00.00",
                "acesso": "13501",
                "natureza": "DEBITO",
                "tipoConta": "ANALITICA",
                "contaAcessoExterna": "19-555"
            },
            {
                "id": 722,
                "nome": "13802 CRÉDITOS C/C ENTIDADES",
                "classificador": "1.01.20.90.70.00.00",
                "acesso": "13970",
                "natureza": "CREDITO",
                "tipoConta": "ANALITICA",
                "contaAcessoExterna": "12892"
            }
        ],
        "tipoDocumento": "CUPOM FISCAL"
    }
]
```