Balanço de estoque é o aferimento da quantidade em estoque físico real com a quantidade demonstrada no inventário do Varejonline.

### URLs

> GET https://integrador.varejonline.com.br/apps/api/balancos-estoque

> ATENÇÃO: ENDPOINT OBSOLETO

### Parâmetros

* **entidade:** id da [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) da qual se deseja obter os balanços de estoque.

### Retorno

* **id:** identificador do balanço de estoque (long)
* **entidade:** [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) na qual o balanço de estoque se refere  (objeto complexo)
    * **id:** id da entidade (long)
    * **nome:** nome da entidade (string)
    * **documento:** documento da entidade (string)
* **descricao:** descricao do balanço de estoque (string)
* **contagens:** lista de produtos relacionados ao balanço de estoque, contendo:
	* **idProduto:** id do [produto](https://github.com/Varejonline/api/wiki/GET-Produtos) (long)
	* **quantidade:** quantidade da contagem de mercadorias realizadas (decimal)
	* **codigoEAN:** informação de codigo EAN da mercadoria (string)
	* **descricao:** nome da mercadoria (string)
	* **siglaUnidade:** sigla da unidade relacionada a mercadoria(string)



### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/balancos-estoque?entidade=1

```javascript
[
   {
      "id":1,
      "entidade": {
          "id": 3,
          "nome": "Entidade teste",
          "documento": "00.000.000/0000-00"
      },
      "descricao":”Balanço de Final de Ano FILIAL 1”,
      "contagens":[{
          "idProduto":7,
          "quantidade":0.00,
          "codigoEAN":"2012547855447",
          "descricao":"Extrato de Tomate",
          "siglaUnidade":"UN"
      }]
   },
   {
      "id":2,
      "idEntidade":1,
      "descricao":”Balanço de Final de Ano 2”,
      "contagens":[{
          "idProduto":9,
          "quantidade":0.00,
          "codigoEAN":"9874555554",
          "descricao":"Oléo de Cozinha",
          "siglaUnidade":"UN"
      }]
   }
]

```