Permite filtrar objetos pelo terceiro associado, informe o parâmetro abaixo na URL, conforme exemplo.

* **terceiro:** id do terceiro que deve ser usado como filtragem dos objetos.

## Exemplos de uso

> GET [https://integrador.varejonline.com.br/apps/api/pedidos?terceiro=1](https://integrador.varejonline.com.br/apps/api/pedidos?terceiro=1)