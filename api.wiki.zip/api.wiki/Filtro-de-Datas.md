Alguns dos recursos disponíveis para consulta têm uma relação forte com a data em que eles foram gerados. Para recursos desta natureza, é possível filtrar o resultado de uma consulta por uma margem de datas.


Para informar o período desejado, basta incluir na requisição os seguintes parâmetros:

* **desde:** data inicial do perído, no formato dd-mm-aaaa
* **ate:** data final do período, no formato dd-mm-aaaa

<discutimos sobre a possibilidade de usar apenas o "desde" ou o "até" e, para conseguir isso, precisaremos mudar o serviço de contas que está trazendo a data atual como padrão. Colocamos esta atividade no backlog>

<relacionar os serviços que usam o filtro de datas. Hoje são: contas pagas, contas a pagar, contas recebidas, contas a receber>

### Exemplos de uso

> GET https://integrador.varejonline.com.br/apps/api/contas-pagas/?desde=20-05-2012&ate=15-07-2012

>Essa busca retornará as contas pagas com vencimento entre 20/05/2012 e 15/07/2012.
