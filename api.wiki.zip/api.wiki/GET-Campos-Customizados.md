### Descrição

Endpoint utilizado para obter os metadados associados à campos customizados da base do cliente.

Campos customizados são estruturas de dados dinâmicas, parametrizadas pelo cliente em sua base. Essas estruturas são transformadas em campos na tela e permitem que o cliente configure objetos com informações específicas do seu domínio de negócio, não absorvidas pelos campos padrões do sistema.

### URLs

> GET https://integrador.varejonline.com.br/apps/api/campo-customizado

### Parâmetros

* **telacustomizavel:** Tipo de tela para qual os campos foram configurados (Obrigatório) (Opções: CADASTRO_TERCEIRO, CADASTRO_EMPRESA)
* **alteradoApos:** [Entenda a Coleta de Alterações](https://github.com/Varejonline/api/wiki/Filtro-de-Data-Alteração)

### Retorno

* **id**: id do campo (long)
* **nome:** nome do campo (string)
* **ativo:** indica se o campo está ativo ou não (boolean)
* **excluido:** indica se o campo está excluído ou não (boolean)
* **tipo:** [tipo](https://github.com/Varejonline/api/wiki/Tipos-de-Campos-Customizados) do campo (String)
* **classesTerceiro:** lista de [classes](https://github.com/Varejonline/api/wiki/Classes-de-Terceiro) de terceiro para as quais o campo é aplicado (Lista)
* **opcoes:** Lista de valores permitidos para o campo (aplicado em campos de [tipo](https://github.com/Varejonline/api/wiki/Tipos-de-Campos-Customizados) "OPCIONAL") (boolean)
* **visivel:** Indica se o campo é ou não visível individualmente em tela (boolean) (Vide Observações)
* **camposComposicao:** Lista de campos customizados que fazem parte da composição, (aplicado em campos de [tipo](https://github.com/Varejonline/api/wiki/Tipos-de-Campos-Customizados) "COMPOSICAO") (Vide Observações)
* **idCampoUtilizado:** Id do campo utilizado na listagem, (aplicado em campos de [tipo](https://github.com/Varejonline/api/wiki/Tipos-de-Campos-Customizados) "LISTA") (Vide Observações)

### Observações Importantes

Campos não visíveis representam campos que não são apresentados de forma individual em tela para preenchimento. Esses campos são, geralmente, campos incluídos em campos do tipo "composite". 

**Exemplo:** Base com dois campos customizados invisíveis individualmente, sendo um o **sexo** e outro a **altura** do terceiro e um terceiro campo **composite** chamado: **dados do terceiro**, composto pelos dois primeiros campos.

Campos com tipagem "LISTA", indicam que é possível informar uma lista de outro campo customizado em tela.

Campos com tipagem "COMPOSICAO", indicam que o campo é uma composição de outros campos customizados.

### Exemplo

![Estrutura em Tela](https://github.com/Varejonline/api/blob/master/images/camposCustomizado.png)

> GET https://integrador.varejonline.com.br/apps/api/campo-customizado?telacustomizavel=CADASTRO_TERCEIRO

```javascript
[
    {
        "opcoes": [],
        "visivel": false,
        "id": 21,
        "classesTerceiro": [
            "Cliente"
        ],
        "excluido": false,
        "ativo": true,
        "nome": "NOME",
        "tipo": "TEXTO"
    },
    {
        "opcoes": [
            "F",
            "M"
        ],
        "visivel": false,
        "id": 22,
        "classesTerceiro": [
            "Cliente"
        ],
        "excluido": false,
        "ativo": true,
        "nome": "SEXO",
        "tipo": "OPCIONAL"
    },
    {
        "opcoes": [],
        "visivel": false,
        "id": 23,
        "classesTerceiro": [
            "Cliente"
        ],
        "excluido": false,
        "ativo": true,
        "nome": "NASCIMENTO",
        "tipo": "DATA"
    },
    {
        "opcoes": [
            "CAES",
            "AVES",
        ],
        "visivel": false,
        "id": 24,
        "classesTerceiro": [
            "Cliente"
        ],
        "excluido": false,
        "ativo": true,
        "nome": "SETOR",
        "tipo": "OPCIONAL"
    },
    {
        "opcoes": [
            "CALOPSITA",
            "CANARIO",
            "CANICHE",
            "CARDEAL",
            "CHIHUAHUA",
            "LABRADOR",
            "OUTROS"
        ],
        "visivel": false,
        "id": 25,
        "classesTerceiro": [
            "Cliente"
        ],
        "excluido": false,
        "ativo": true,
        "nome": "RAÇA",
        "tipo": "OPCIONAL"
    },
    {
        "opcoes": [
            "PEQUENO",
            "MEDIO",
            "GRANDE",
            "GIGANTE"
        ],
        "visivel": false,
        "id": 26,
        "classesTerceiro": [
            "Cliente"
        ],
        "excluido": false,
        "ativo": true,
        "nome": "PORTE",
        "tipo": "OPCIONAL"
    },
    {
        "camposComposicao": [
            {
                "opcoes": [],
                "visivel": false,
                "id": 21,
                "classesTerceiro": [
                    "Cliente"
                ],
                "excluido": false,
                "ativo": true,
                "nome": "NOME",
                "tipo": "TEXTO"
            },
            {
                "opcoes": [
                    "F",
                    "M"
                ],
                "visivel": false,
                "id": 22,
                "classesTerceiro": [
                    "Cliente"
                ],
                "excluido": false,
                "ativo": true,
                "nome": "SEXO",
                "tipo": "OPCIONAL"
            },
            {
                "opcoes": [],
                "visivel": false,
                "id": 23,
                "classesTerceiro": [
                    "Cliente"
                ],
                "excluido": false,
                "ativo": true,
                "nome": "NASCIMENTO",
                "tipo": "DATA"
            },
            {
                "opcoes": [
                    "CAES",
                    "AVES"
                ],
                "visivel": false,
                "id": 24,
                "classesTerceiro": [
                    "Cliente"
                ],
                "excluido": false,
                "ativo": true,
                "nome": "SETOR",
                "tipo": "OPCIONAL"
            },
            {
                "opcoes": [
                   "CALOPSITA",
                   "CANARIO",
                   "CANICHE",
                   "CARDEAL",
                   "CHIHUAHUA",
                   "LABRADOR",
                   "OUTROS"
                ],
                "visivel": false,
                "id": 25,
                "classesTerceiro": [
                    "Cliente"
                ],
                "excluido": false,
                "ativo": true,
                "nome": "RAÇA",
                "tipo": "OPCIONAL"
            },
            {
                "opcoes": [
                    "PEQUENO",
                    "MEDIO",
                    "GRANDE",
                    "GIGANTE"
                ],
                "visivel": false,
                "id": 26,
                "classesTerceiro": [
                    "Cliente"
                ],
                "excluido": false,
                "ativo": true,
                "nome": "PORTE",
                "tipo": "OPCIONAL"
            }
        ],
        "visivel": false,
        "id": 27,
        "classesTerceiro": [
            "Cliente"
        ],
        "excluido": false,
        "ativo": true,
        "nome": "INFORMAÇÕES",
        "tipo": "COMPOSICAO"
    },
    {
        "idCampoUtilizado": 27,
        "id": 28,
        "classesTerceiro": [
            "Cliente"
        ],
        "excluido": false,
        "ativo": true,
        "nome": "DADOS DO PET",
        "tipo": "LISTA"
    }
]
```