Terceiros são quaisquer pessoas físicas ou jurídicas cadastradas no sistema. Estão neste grupo os clientes, funcionários, fornecedores e todas pessoas com as quais a empresa tem relação.

### URL

> POST https://integrador.varejonline.com.br/apps/api/terceiros

### Parâmetros

Envie um JSON no corpo da requisição, contendo:
* **tipoPessoa:** Define se a Pessoa é Física (PF), Jurídica (PJ), Física Estrangeiro (PF_ESTRANGEIRO) ou Jurídica Estrangeiro (PJ_ESTRANGEIRO) _(opcional para PF e PJ. Caso não informado, assume PF ou PJ de acordo com o documento informado)_
* **padraoNome:** "NOME_FANTASIA" ou "RAZAO_SOCIAL". Indica ao sistema qual nome convencionar na apresentação em tela (apenas para PJ e PJ_ESTRANGEIRO) (string) _(opcional, padrão: RAZAO_SOCIAL)_
* **nome:** nome do terceiro (considerado razão social para PJ) (string) _(obrigatório)_ _(max 255 char)_
* **nomeFantasia:** nome fantasia da empresa (apenas para PJ e PJ_ESTRANGEIRO) (string) _(obrigatório caso padraoNome NOME_FANTASIA)_ _(max 255 char)_
* **documento:** CPF ou CNPJ do terceiro com/sem formatação (string) _(obrigatório)_ _(max 255 char)_
* **emails:** Emails do terceiro (List String) _(opcional)_ _(max 255 char)_
* **rg:** número do RG do terceiro. (Apenas PF) (string) _(opcional)_ _(max 50 char)_
* **dataNascimento:** data de nascimento do terceiro (apenas PF ou PF_ESTRANGEIRO) (dd-mm-aaaa) _(opcional)_
* **ie:** número da Inscrição Estadual do terceiro. (Apenas PJ) (string) _(opcional)_ _(max 255 char)_
* **ativo:** indica se o terceiro está ativo ou não (boolean) _(opcional, padrão: true)_
* **entidadeCadastro:** id da [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) de cadastro do terceiro (long) _(opcional)_
* **enderecos:** endereços do terceiro (Lista de objetos complexos) _(opcional)_
   * **tipo:** tipo do logradouro (string). Exemplos: RUA, AVENIDA, RODOVIA. [Veja a lista completa](Tipos-de-Logradouro) _(obrigatório)_
   * **logradouro:** nome do logradouro (string) _(opcional)_ _(max 255 char)_
   * **numero:** número do endereço (string) _(opcional)_ _(max 400 char)_
   * **bairro:** bairro do endereço (string) _(obrigatório caso informado o codigoIBGECidade)_ _(max 255 char)_
   * **complemento:** complemento do endereço (string) _(opcional)_ _(max 255 char)_
   * **cep:** CEP do endereço sem máscara (string) _(obrigatório)_
   * **codigoIBGECidade:** código do IBGE da cidade (long) _(opcional)_
   * **pais:** [País do Endereço](https://github.com/Varejonline/api/wiki/Paises) (string) _(opcional, padrão: BRASIL)_
   * **uf:** sigla em caixa alta da UF do endereço (string) (Se estrangeiro enviar "EX") (apenas para pais diferente do BRASIL) _(opcional)_
   * **cidade:** nome da cidade (string) (apenas para pais diferente do BRASIL) _(opcional)_ _(max 255 char)_
   * **tipoEndereco:** [Tipo do Endereço](https://github.com/Varejonline/api/wiki/Tipos-de-endereço) (string) _(opcional, padrão: ENDERECO_SEDE)_
* **telefones:** telefones do terceiro (Lista de objetos complexos) _(opcional)_
   * **ddd:** Código do DDD (int) _(obrigatório)_ _(max 10 char)_
   * **ddi:** Código do DDI (int) _(obrigatório)_ _(max 10 char)_
   * **numero:** Número do telefone (string) _(obrigatório)_ _(max 255 char)_
   * **ramal:** Número do ramal (int) _(obrigatório)_ _(max 10 char)_
   * **tipoTelefone:** CELULAR, RESIDENCIAL, COMERCIAL, RECADO (string) _(opcional, padrão: COMERCIAL)_
* **classes:** lista de [classes](https://github.com/Varejonline/api/wiki/Classes-de-Terceiro) às quais o terceiro pertence _(opcional)_
* **categoria:** Define a categorização do terceiro no Varejonline (string) _(opcional)_
* **autorizaReceberEmail:** Opt-in do terceiro autorizando ou não a comunicação por email (boolean) _(opcional, padrão: false)_
* **autorizaReceberSms:** Opt-in do terceiro autorizando ou não a comunicação por sms (boolean) _(opcional, padrão: false)_
* **autorizaReceberWhatsapp:** Opt-in do terceiro autorizando ou não a comunicação por whatsapp (boolean) _(opcional, padrão: false)_
* **limiteCredito:** Define os valores de limite de crédito para o terceiro (objeto complexo) _(opcional)_
  * **valorTotal:** limite de crédito total (Decimal) _(opcional)_
  * **valorMensal:** limite de crédito mensal (Decimal) _(opcional)_
  * **valorRenda:** valor da renda do terceiro (Decimal) _(opcional)_
* **camposCustomizados:** Define os valores da estrutura de [campos customizados](https://github.com/Varejonline/api/wiki/GET-Campos-Customizados) da base. _(opcional)_
  * **id:** id do terceiro associado aos valores informados (long)
  * **valoresPrimitivo:** valores dos campos customizados [primitivos](https://github.com/Varejonline/api/wiki/Tipos-de-Campos-Customizados) _(opcional)_
    * **id:** id do campo customizado (long)
    * **value:** valor do campo customizado (object - varia conforme tipagem do campo)
    * **type:** [tipo](https://github.com/Varejonline/api/wiki/Tipos-de-Campos-Customizados) do campo customizado (string)
  * **valoresComposicao:** valores dos campos customizados do [tipo](https://github.com/Varejonline/api/wiki/Tipos-de-Campos-Customizados) COMPOSICAO _(opcional)_
    * **id:** id do campo customizado (long)
    * **valores:** lista de valores primitivos 
      * **id:** id do campo customizado (long)
      * **value:** valor do campo customizado (object - varia conforme tipagem do campo) _(max para string 255 BYTE)_
      * **type:** [tipo](https://github.com/Varejonline/api/wiki/Tipos-de-Campos-Customizados) do campo customizado (string)
  * **valoresLista:** valores dos campos customizados do [tipo](https://github.com/Varejonline/api/wiki/Tipos-de-Campos-Customizados) LISTA _(opcional)_
    * **campoId:** id do campo customizado retornado pela lista (long)
    * **valoresPrimitivo:** lista de valores primitivos 
      * **id:** id do campo customizado (long)
      * **value:** valor do campo customizado (object - varia conforme tipagem do campo) _(max para string 255 BYTE)_
      * **type:** [tipo](https://github.com/Varejonline/api/wiki/Tipos-de-Campos-Customizados) do campo customizado (string)
    * **valoresComposicao:** valores dos campos customizados do [tipo](https://github.com/Varejonline/api/wiki/Tipos-de-Campos-Customizados) COMPOSICAO
      * **id:** id do campo customizado (long)
      * **valores:** lista de valores primitivos 
        * **id:** id do campo customizado (long)
        * **value:** valor do campo customizado (object - varia conforme tipagem do campo)  _(max para string 255 BYTE)_
        * **type:** [tipo](https://github.com/Varejonline/api/wiki/Tipos-de-Campos-Customizados) do campo customizado (string) 
* **marcas:** lista de marcas do terceiro, contendo: _(opcional)_
  * **autorizaReceberSms:** (boolean) _(opcional, padrão: false)_
  * **autorizaReceberEmail:** (boolean) _(opcional, padrão: false)_
  * **autorizaReceberWhatsapp:** (boolean) _(opcional, padrão: false)_
  * **marca:** informações da marca
    * **id:** id da marca (long)
    * **nome:** nome da marca (string) _(max 255 char)_

### Exemplo de retorno:

_Sucesso:_
* HTTP STATUS 201 – CREATED
* Body:
```javascript
{
      "idRecurso": 1,
      "codigoMensagem": 0,
      "mensagem": "Operação realizada com sucesso."
}
```

_Requisição inválida:_
* HTTP STATUS 400 – BAD REQUEST
* Body: 
```javascript
{
      "idRecurso": 0,
      "codigoMensagem": 1,
      "mensagem": "Terceiro com documento inválido"
}
```

### Exemplo

> POST https://integrador.varejonline.com.br/apps/api/terceiros

'Content-Type'='application/json'

```javascript
{
   "nome":"Nome do terceiro",
   "documento":"023.168.132-00",
   "emails":[
      "terceiro.teste@gmail.com",
      "terceiro.teste@hotmail.com"
   ],
   "rg":"42.943.412-1",
   "dataNascimento":"12-08-1980",
   "enderecos":[
      {
         "tipo":"AVENIDA",
         "logradouro":"9 de Julho",
         "numero":"900",
         "bairro":"CENTRO",
         "uf":"SP",
         "complemento":"APTO 1",
         "cep":"12000111",
         "codigoIBGECidade":"3554102",
         "tipoEndereco":"ENDERECO_COBRANCA"
      },
      {
         "tipo":"RUA",
         "logradouro":"15 de Novembro",
         "numero":"1020",
         "bairro":"JD. MARIA",
         "uf":"SP",
         "complemento":"APTO 1",
         "cep":"12600123",
         "codigoIBGECidade":"3554102",
         "tipoEndereco":"ENDERECO_SEDE"
      }
   ],
   "telefones":[
      {
         "ddi":"55",
         "ddd":"12",
         "numero":"12341234",
         "tipoTelefone":"RESIDENCIAL"  
      },
      {
         "ddi":"0",
         "ddd":"31",
         "numero":"12340000",
         "ramal":"1234",
         "tipoTelefone":"CELULAR"  
      }
   ],
   "classes":[
      "SOCIO_PROPRIETARIO",
      "FUNCIONARIO"
   ],
   "categoria": "CLIENTES VIP",
   "autorizaReceberEmail": false,
   "autorizaReceberSms": true,
   "marcas": [
        {
            "autorizaReceberSms": false,
            "autorizaReceberEmail": false,
            "autorizaReceberWhatsapp": true,
            "marca": {
                "id": 283,
                "nome": "TESTE"
            }
        },
        {
            "autorizaReceberSms": true,
            "autorizaReceberEmail": false,
            "autorizaReceberWhatsapp": false,
            "marca": {
                "id": 0,
                "nome": "SEM MARCA"
            }
        }
   ]
}
```