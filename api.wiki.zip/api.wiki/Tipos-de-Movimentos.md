Listagem dos possíveis tipos de movimentos.

<table>
<tr><th>Tipo</th><th>Operação</th></tr>
<tr><td>PEDIDO_VENDA</td><td>SAIDA</td></tr>
<tr><td>SAIDA_DIVERSA</td><td>SAIDA</td></tr>
<tr><td>ENTRADA_PRODUTOS</td><td>ENTRADA</td></tr>
<tr><td>ENTRADA_DIVERSA</td><td>ENTRADA</td></tr>
<tr><td>DEVOLUCAO_VENDA</td><td>ENTRADA</td></tr>
<tr><td>SALDO_INICIAL</td><td>ENTRADA</td></tr>
<tr><td>PRODUTO_COMPOSTO</td><td>AMBOS</td></tr>
<tr><td>BAIXA_COMPONENTES</td><td>SAIDA</td></tr>
<tr><td>ATENDIMENTO_REQUISICAO</td><td>SAIDA</td></tr>
<tr><td>TRANSFERENCIA</td><td>AMBOS</td></tr>
<tr><td>DEVOLUCAO_COMPRA</td><td>SAIDA</td></tr>
<tr><td>AJUSTE_ESTOQUE</td><td>AMBOS</td></tr>
<tr><td>SAIDA_PRODUTOS</td><td>SAIDA</td></tr>
<tr><td>NOTA_SUBSTITUTIVA</td><td>SAIDA</td></tr>
<tr><td>COMPRAS</td><td>ENTRADA</td></tr>
<tr><td>ENTRADA_PRODUTOS_IMPORTACAO</td><td>ENTRADA</td></tr>
</table>