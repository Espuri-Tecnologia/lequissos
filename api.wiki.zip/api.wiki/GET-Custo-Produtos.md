### URLs

> GET https://integrador.varejonline.com.br/apps/api/custo-mercadoria

### Parâmetros

* **produtos:** lista de ids dos produtos cujos saldos se deseja obter, separados por vírgula
* **entidades:** [Veja como Funciona este Filtro](https://github.com/Varejonline/api/wiki/Filtro-de-Entidades)
* **data:** data do custo desejado, no formato dd-mm-aaaa HH:mm:ss (opcional)
* **alteradoApos:** [Entenda a Coleta de Alterações](https://github.com/Varejonline/api/wiki/Filtro-de-Data-Alteração) (opcional)

### Retorno

* **produto:** dados do [produto](https://github.com/Varejonline/api/wiki/GET-Produtos) (objeto complexo)
    * **id:** (Long)
    * **descricao:** (string)
    * **codigoSistema:** (string)
    * **codigoInterno:** (string)
    * **codigoBarras:** (string)
* **entidade:** dados [entidade](https://github.com/Varejonline/api/wiki/GET-entidades)
  * **id:** (Long)
  * **nome:** (string)
  * **documento:** CNPJ formatado da loja associada (string)
* **custoMedio:** custo médio do produto na entidade e data retornada (decimal)
* **custoUltimaCompra:** custo da última compra do produto na entidade e data retornada (decimal)
* **data:** data do custo (string)
* **dataAlteracao:** data em que o registro foi calculado ou atualizado (string)

### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/custo-mercadoria

```javascript
[
    {
        "entidade":{  
            "id":1,
            "nome":"NOME DA ENTIDADE",
            "documento":"21.097.764/0001-45"
         },
         "produto":{  
            "id":5299,
            "descricao":"PRODUTO 1",
            "codigoBarras":"78970859143465",
            "codigoInterno":"AAAAAA",
            "codigoSistema":"0001"
        },
        "custoMedio": 88.78,
        "custoUltimaCompra": 109.90,
        "data": "20-02-2018",
        "dataAlteracao": "06-01-2018 14:13:38"
    },
    {
        "entidade":{  
            "id":1,
            "nome":"NOME DA ENTIDADE",
            "documento":"21.097.764/0001-45"
         },
         "produto":{  
            "id":5300,
            "descricao":"PRODUTO 2",
            "codigoBarras":"78970859143464",
            "codigoInterno":"",
            "codigoSistema":"0001"
        },
        "custoMedio": 79.4,
        "custoUltimaCompra": 109.90,
        "data": "20-02-2018",
        "dataAlteracao": "27-09-2017 20:17:07"
    }
]
```