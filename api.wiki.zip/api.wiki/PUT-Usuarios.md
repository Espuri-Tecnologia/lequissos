### URL

> PUT https://integrador.varejonline.com.br/apps/api/usuarios/:id
### Parâmetros

Envie um JSON no corpo da requisição, contendo:
* **terceiro:** terceiro que será associado ao usuário _(obrigatório)_
   * **id:** id do terceiro _(opcional)_
   * **documento:** documento do terceiro, com/sem formatação _(opcional)_
* **email:** quando informado um email, ele será o email principal do terceiro. O email principal antigo irá para a lista de emails secundários (string) _(opcional)_
* **entidades:**  lista de ids de [entidades](https://github.com/Varejonline/api/wiki/GET-entidades) que o usuário possuirá acesso (array) _(obrigatório)_
* **permissao:** id da [permissão de usuário](https://github.com/Varejonline/api/wiki/GET-Permissao-usuario) (long) _(obrigatório)_
* **exibirComoComprador:** marcar o usuário como comprador nas rotinas do sistema (boolean) _(opcional, padrão: false)_
* **ativo:** status do usuário (boolean) _(opcional, padrão: true)_
* **login:** login do usuário, 3-50 dígitos, único, sem espaços (string) _(opcional, padrão: documento do terceiro, sem formatação)_

### Exemplo de retorno:

_Sucesso:_
* HTTP STATUS 201 – CREATED
* Body:
```javascript
{
      "idRecurso": 1,
      "codigoMensagem": 0,
      "mensagem": "Operação realizada com sucesso."
}
```

### Exemplo

> PUT https://integrador.varejonline.com.br/apps/api/usuarios/7
'Content-Type'='application/json'

```javascript
{
    "terceiro":{
        "id": 0
        "documento": "000.000.000-00"
    },
    "email": "teste@email.com",
    "entidades": [1,2],
    "permissao": "3",
    "exibirComoComprador": true,
    "ativo": false,
    "login": "teste"
}
```