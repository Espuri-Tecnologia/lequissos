### URLs

> GET https://integrador.varejonline.com.br/apps/api/unidades

> GET https://integrador.varejonline.com.br/apps/api/unidades/:id

### Parâmetros

* **inicio:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **quantidade:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **alteradoApos:** [Entenda a Coleta de Alterações](https://github.com/Varejonline/api/wiki/Filtro-de-Data-Alteração)

### Retorno

* **id:** id da categoria de produto (long)
* **nome:** nome da unidade (string)
* **sigla:** sigla da unidade (string)
* **ativo:** indica se a unidade está ativa ou não (boolean)
* **dataAlteracao:** última data de alteração da unidade, no formato dd-mm-aaaa hh:mi:ss (string)

### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/unidades

```javascript
[
   {
      "id":1002,
      "nome":"UNIDADE TESTE",
      "sigla":"UT",
      "ativo": true,
      "dataAlteracao":"20-01-2013 11:44:45"
   },
   {
      "id":1122,
      "nome":"TESTE UNIDADE",
      "sigla":"TU",
      "ativo": false,
      "dataAlteracao":"20-01-2013 11:44:45"
   }
]
```