### Códigos de totalizadores de redução Z

* **"I1":** Isento de Tributação tipo 1 de ICMS.
* **"F1":** Substituição Tributária tipo 1 de ICMS.
* **"N1":** Não - Tributável tipo 1 de ICMS.
* **"IS1":** Isento de Tributação tipo 1 de ISSQN.
* **"FS1":** Substituição Tributária tipo 1 de ISSQN.
* **"NS1":** Não – Tributável tipo 1 de ISSQN.

### Códigos de totalizadores de redução Z onde é tributado ICMS

Para cada aliquota diferente encontrada onde houve tributação de ICMS, em cada redução Z, é gerado um código com um sequêncial que é incrementado a cada alíquota diferente encontrada durante a redução Z, um T que indica que houve tributacao ICMS seguido pela alíquota utilizada. Por exemplo:

ReduçãoZ 1, onde há registros tributados no ICMS com 3 alíquotas diferentes:

* **"01T1800":** Código de totalizador parcial onde houve tributação a 18% de ICMS
* **"02T1700":**Código de totalizador parcial onde houve tributação a 17% de ICMS
* **"03T1200":** Código de totalizador parcial onde houve tributação a 12% de ICMS

ReduçãoZ 2, onde só foram encontrados registros tributados no ICMS com uma alíquota:

* **"01T1700":** Código de totalizador parcial onde houve tributação a 17% de ICMS.