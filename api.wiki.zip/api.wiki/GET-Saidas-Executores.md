### URLs

> GET https://integrador.varejonline.com.br/apps/api/saidas

> GET https://integrador.varejonline.com.br/apps/api/saidas/:id

### Parâmetros

* **entidades:** [Veja como Funciona este Filtro](https://github.com/Varejonline/api/wiki/Filtro-de-Entidades)
* **inicio:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **quantidade:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **alteradoApos:** [Entenda a Coleta de Alterações](https://github.com/Varejonline/api/wiki/Filtro-de-Data-Alteração)
* **desde:** [Veja o Filtro de Datas](https://github.com/Varejonline/api/wiki/Filtro-de-Datas)
* **ate:** [Veja o Filtro de Datas](https://github.com/Varejonline/api/wiki/Filtro-de-Datas)
* **ignorarSimplesFaturamento:** indica se lançamentos de simples faturamento devem ser ignorados (boolean)

### Retorno
    
* **id:** identificador da saída (long)
* **dataAlteracao:** data em que a saída foi efetuada, no formato dd-mm-aaaa hh:mi:ss (string)
* **cancelado:** indicador se a saida esta cancelada sim ou não (booleano)
* **entidade:** [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) onde ocorreu a saída  (objeto complexo)
    * **id:** id da entidade (long)
    * **nome:** nome da entidade (string)
    * **documento:** documento da entidade (string)
* **terceiro:** [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros) associado com o documento de saída (objeto complexo)
    * **id:**  id do terceiro (long)
    * **nome:** nome do terceiro (string)
    * **documento:** documento do terceiro (string)
* **tipoSaida:** identificador do [tipo](https://github.com/Varejonline/api/wiki/Tipos-de-Movimentos) da saída (string)
* **data:** data em que a saida foi efetuada, no formato dd-mm-aaaa hh:mi:ss (string)
* **dataEmissao:** data de emissão do documento de saídano formato dd-mm-aaaa hh:mi:ss (string)
* **numeroDocumento:** número do documento associado à saída (string)
* **valorTotal:** valor total da saida(decimal)
* **idPedido:** [id do pedido](https://github.com/Varejonline/api/wiki/GET-pedidos) de venda associado à saída (long)
* **idProvisao:** id da [provisão](https://github.com/Varejonline/api/wiki/GET-contas-receber) a receber associada a saída (long)
**tipoSaida** for "DEVOLUCAO_COMPRA"
* **mercadorias:** lista de itens disponíveis da saida, cada um contendo:
	* **id:** id único do item vendido (long)
	* **produto:** dados do produto devolvido (objeto complexo)
		* **id:** id da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos)
		* **descricao:** id da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos)
		* **codigoSistema:** Código Sistema da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos)
		* **codigoInterno:** Código Interno da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos)
		* **codigoBarras:** Código de Barras da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos)
	* **unidade:** unidade utilizada na venda (string)
	* **quantidade:** quantidade vendida do produto na unidade informada (decimal)
	* **valorTotal:** valor total do item (decimal)
	* **valorCusto:** custo da mercadoria vendida (decimal)
	* **idRepresentante:** [vendedor](https://github.com/Varejonline/api/wiki/GET-representantes) associado ao item vendido (long)
	* **tabelaPrecoId:** [tabela de preço](https://github.com/Varejonline/api/wiki/GET-tabelas-preco) aplicada na venda do item (long)
	* **valorTotalDesconto:** valor total do desconto do item (decimal)
	* **descontoDetalhes:** lista de detalhes do desconto, contendo:
	  * **observacao:** observação do desconto (string)
	  * **valor:** valor do desconto (decimal)
	  * **origemDesconto:** [origem](https://github.com/Varejonline/api/wiki/Origens-de-detalhe-de-Desconto) do desconto 
	  * **idReferencia:** id da tabela origem do desconto, por exemplo se a origem do desconto for TABELA_PRECO, será o id da tabela (long)
	  * **descricao:** Nome original de referência (Ex, nome da **tabela de preço** ou nome da **ação promocional** )
	* **valorDescontoItem:** valor do desconto concedido no item (decimal)
	* **valorDescontoRateado:** valor do desconto total da venda rateado no item (decimal)
	* **valorTotalPis:** valor pis (decimal)
	* **valorTotalCofins:** valor cofins (decimal)
	* **valorTotalFrete:** valor do frete rateado no item (decimal)
	* **valorTotalSeguro:** valor do seguro rateado no item (decimal)
	* **valorTotalOutros:** valor outros rateado no item (decimal)
	* **valorTotalAcrescimo:** valor total do acréscimo no item (decimal)
	* **valorTotalIcmsSt:** valor icms st (decimal)
	* **valorTotalIcms:** valor icms (decimal)
	* **valorTotalIpi:** valor ipi (decimal)
	* **itemDevolucao:** dados do item na entrada que foi devolvida, quando tipoSaida for "DEVOLUCAO_COMPRA"
	    * **idEntradaDevolvida:** id da [entrada](https://github.com/Varejonline/api/wiki/GET-entradas) onde consta o item devolvido (long)
	    * **idItemDisponivelDevolvido:** id do item devolvido (long)
	    * **idItemNaoEstocavelDevolvido:** id do item devolvido (long)
	* **operacao:** Operação do movimento (long)
	    * **descricao:** descrição da operação (string)
	    * **idOperacao:** id da operação (long)
* **servicos:** lista de serviços prestados na saída, cada um contendo:
	* **id:** id único do serviço vendido (long)
	* **idServico:** id do serviço (long)
	* **executores:** lista de [terceiros](https://github.com/Varejonline/api/wiki/GET-terceiros) executores do serviço
	  * **id:**  id do terceiro (opcional) (long)
	  * **documento:** documento do terceiro (string)
	  * **nome:** nome do terceiro (string)
	* **unidade:** unidade utilizada na venda (string)
	* **quantidade:** quantidade vendida do serviço na unidade informada (decimal)
	* **valorTotal:** valor total do item (decimal)
	* **idRepresentante:** [vendedor](https://github.com/Varejonline/api/wiki/GET-representantes) associado ao serviço vendido (long)
	* **valorTotalDesconto:** valor total do desconto do serviço (decimal)
	* **valorTotalPis:** valor pis (decimal)
	* **valorTotalCofins:** valor cofins (decimal)
	* **valorTotalIss:** valor iss (decimal)
	* **valorTotalRetencao:** valor total em retenções (decimal)
	* **valorTotalAcrescimo:** valor total do acréscimo no item (decimal)
	* **operacao:** Operação do movimento (long)
	    * **descricao:** descrição da operação (string)
	    * **idOperacao:** id da operação (long)
* **reservarEstoque:** boolean indicando se a saída possui [reservas de estoque](https://github.com/Varejonline/api/wiki/GET-Reserva-Estoque)

### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/saidas?entidades=1

```javascript
[
    {
        "id": 1,
        "dataAlteracao": "01-01-2013",
        "cancelado": false,
        "tipoSaida": "VENDA_PRODUTOS",
        "dataSaida": "01-01-2013 00:00:00",
        "dataEmissao": "01-01-2013 00:00:00",
        "entidade": {
            "id": 3,
            "nome": "Entidade teste",
            "documento": "00.000.000/0000-00"
        },
        "terceiro": {
            "id": 1,
            "nome": "DIVERSOS",
            "documento": "000.000.000-00"
        },
        "numeroDocumento": "124578",
        "valorTotal": 500,
        "idPedido": 38,
        "idProvisao":13547,
        "mercadorias": [
            {
                "id": 215,
                "produto": {
                    "id":9342,
                    "descricao":"BLUSA MALHA PRETA GG",
                    "codigoSistema":"0001.0001",
                    "codigoInterno":"",
                    "codigoBarras":""
                },
                "valorTotal": 15.8,
                "quantidade": 1,
                "valorCusto": 8.14,
                "unidade": "UN",
                "idRepresentante": 9,
                "tabelaPrecoId": 1,
                "valorTotalDesconto": 0,
                "valorDescontoItem": 0,
                "valorDescontoRateado": 0,
                "valorTotalPis": 0,
                "valorTotalCofins": 0,
                "valorTotalFrete": 0,
                "valorTotalSeguro": 0,
                "valorTotalOutros": 0,
                "valorTotalAcrescimo": 0,
                "operacao": {
                    "descricao": "Venda no módulo offline",
                    "idOperacao": 2
                },
                "valorTotalIcmsSt": 0,
                "valorTotalIcms": 2.84,
                "valorTotalIpi": 0
            }
        ],
        "servicos": [
            {
                "id": 32,
                "idServico": 64,
                "valorTotal": 120,
                "quantidade": 1,
                "unidade": "SV",
                "idRepresentante": 8,
                "valorTotalDesconto": 0,
                "valorTotalPis": 1.98,
                "valorTotalCofins": 9.12,
                "valorTotalIss": 2.4,
                "valorTotalAcrescimo": 0,
                "operacao": {
                    "descricao": "Prestação de serviço ISSQN",
                    "idOperacao": 27
                },
                "valorTotalRetencao": 0
            }
        ],
        "reservarEstoque":false
    }
]
```