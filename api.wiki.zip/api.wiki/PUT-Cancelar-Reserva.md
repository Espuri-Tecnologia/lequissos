Endpoint para cancelamento de reservas de estoque associadas a orçamentos de venda.

### URL

> PUT https://integrador.varejonline.com.br/apps/api/reserva-estoque/cancelar/:id_orcamento

Enviar uma requisição PUT ao endereço informando o id do [orçamento](https://github.com/Varejonline/api/wiki/GET-Orcamentos) de venda com estoque reservado.

Reservas canceladas serão marcadas como excluídas no sistema, viabilizando a coleta de reservas atualizadas pelo endpoint de [reservas de estoque](https://github.com/Varejonline/api/wiki/GET-Reserva-Estoque)