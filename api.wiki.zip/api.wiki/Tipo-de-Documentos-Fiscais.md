Listagem dos possíveis tipos de notas fiscais.

<table>
<tr><th>Tipo</th></tr>
<tr><td>MERCADORIA</td></tr>
<tr><td>SERVICO</td></tr>
<tr><td>AGUA</td></tr>
<tr><td>ENERGIA_ELETRICA</td></tr>
<tr><td>GAS</td></tr>
<tr><td>COMUNICACAO</td></tr>
<tr><td>TELECOMUNICACAO</td></tr>
<tr><td>CT</td></tr>
<tr><td>CONSUMIDOR</td></tr>
</table>