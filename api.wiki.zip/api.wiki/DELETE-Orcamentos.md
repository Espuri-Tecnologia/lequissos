Endpoint para exclusão de orçamentos e suas reservas de estoque, quando aplicável.

### URLs

DELETE https://integrador.varejonline.com.br/apps/api/orcamentos/:id

### Parâmetros

* **id:** Id do orçamento que deve ser excluído (Long - Path Param)

### Retorno

Retorna um Json com informações do resultado da operação realizada, contendo:
 * **idRecurso:** id do orçamento alterado.
 * **codigoMensagem:** Código de identificação da operação realizada. [veja a lista de Códigos](https://github.com/Varejonline/api/wiki/Retorno-API)
 * **mensagem:** Mensagem da operação realizada