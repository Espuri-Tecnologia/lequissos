### Operações

* **19:** Compra p/ industrialização.
* **20:** Compra p/ comercialização.
* **22:** Compra de bem p/ o ativo imobilizado.
* **23:** Compra de material p/ uso e consumo.
* **1011:** Compra p/ comercialização - Regime ST.
* **1012:** Compra de bem p/ o ativo imobilizado - Regime ST.
