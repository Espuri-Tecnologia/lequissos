### URL

> POST https://integrador.varejonline.com.br/apps/api/categorias-servico

### Parâmetros

Envie um JSON no corpo da requisição, contendo:
* **nome:** nome da categoria de serviços(string) _(obrigatório)_
* **classificacao:** classificação a ser sugerida aos serviços desta categoria, que indica se é incidido ICMS ou ISS sobre o serviço prestado. Pode assumir um dos seguintes valores: SERVICO_ISS, SERVICO_ICMS (string) _(obrigatório)_
* **unidade:** sigla da unidade de medida utilizada padrão pelo serviço(string) (obrigatório)

### Retorno

Sucesso:
* HTTP STATUS 200 – OK
* Body: id da categoria gerada

Requisição inválida: 
* HTTP STATUS 400 – BAD REQUEST
* Body: mensagem de erro

### Exemplo

> POST https://integrador.varejonline.com.br/apps/api/categorias-servico

'Content-Type'='application/json'

```javascript
   {
      "nome":"CATEGORIA SERVIÇO",
      "classificacao":"SERVICO_ISS",
      "unidade":"HR"
   }
```