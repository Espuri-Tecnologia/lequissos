Alguns serviços da API retornam recursos que estão relacionados a entidades específicas.

Entidades são subdivisões dentro de uma empresa. São elas os objetos que fazem relacionamento com os movimentos, saldos de mercadorias, lançamentos contábeis, etc.

Um exemplo é o recurso Pedido, neste existe o campo idEntidade no objeto de retorno, portanto são retornados apenas os pedidos das entidades informadas como parâmetro da requisição. Neste caso, o filtro de entidades está influenciando quais recursos são retornados e não o conteúdo destes.

Para informar as entidades desejadas em uma requisição, basta informar um parâmetro:

* **entidades:** lista de ids de entidades desejadas, separados por vírgula.

Por padrão, se não for informado o parâmetro, o Varejonline assumirá que se deseja obter os recursos relativos a todas as entidades às quais o usuário logado tem permissão de acesso.

### Exemplos de uso

> GET https://integrador.varejonline.com.br/apps/api/pedidos/?entidades=3,4,5
>Essa busca trará os pedidos das entidades 3, 4 e 5 apenas.
