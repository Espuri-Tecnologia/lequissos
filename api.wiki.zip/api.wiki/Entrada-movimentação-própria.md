### URL

> POST https://integrador.varejonline.com.br/apps/api/entradas/movimentacao-propria

### Parâmetros

Envie um JSON no corpo da requisição, contendo:

* **entidade:** id da [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) utilizada (long)
* **fornecedor:** id to [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros) utilizado (long)
* **dataEmissao:** data de emissão do documento (string dd-MM-yyyy)
* **dataEntrada:** data de entrada do documento (string dd-MM-yyyy)
* **operacao:** id da [operação](https://github.com/Varejonline/api/wiki/Tipo-de-operação-em-itens-movimentados) (long)
* **tipoDocumento:** id do [tipo de documento](https://github.com/Varejonline/api/wiki/Tipos-de-Documentos-Financeiros) (long)
* **contaCredito:** id da [conta contabil](https://github.com/Varejonline/api/wiki/GET-Contas-Contábeis) da operação (long)
* **remessa:** id da remessa (long) (opcional)
* **observacao:** observação da entrada (string) (opcional)
* **itens:** lista de itens do pedido, contendo:
  * **idProduto:** id do [produto](https://github.com/Varejonline/api/wiki/GET-Produtos) (long)
  * **codigoSistema:** código de sistema do produto. (string)
  * **quantidade:** quantidade do item (decimal)
  * **valorUnitario:** valor unitário do item (decimal)
* **pagamento:** detalhes do pagamento da entrada  (opcional):
  * **planoPagamento:** id do [plano de pagamento](https://github.com/Varejonline/api/wiki/GET-planos-pagamento-compras) (long)
  * **contaDebito:** id da conta [conta contabil](https://github.com/Varejonline/api/wiki/GET-Contas-Contábeis) de débito(long)
  * **contaCredito:** id da conta [conta contabil](https://github.com/Varejonline/api/wiki/GET-Contas-Contábeis) de crédito (long)
  * **parcelas:** lista de parelas da entrada, contendo:
    * **dataVencimento:** data de vencimento da parcela (string dd-MM-yyyy)
    * **dataPagamento:** data de pagamento da parcela (string dd-MM-yyyy)
    * **valor:** valor da parcela (decimal)
    * **linhaDigitavel:** linha digital da fatura (sting) (opcional)

### Retorno

Sucesso HTTP 201 CREATED:

Retorna um Json com informações do resultado da operação realizada, contendo:

* **idRecurso:** id do pedido gerado.
* **codigoMensagem:** Código de identificação da operação realizada. [veja a lista de Códigos](https://github.com/Varejonline/api/wiki/Retorno-API)
* **mensagem:** Mensagem da operação realizada

Requisição inválida: 
* HTTP STATUS 400 – BAD REQUEST
* Body: mensagem de erro

### Exemplo

> POST https://integrador.varejonline.com.br/apps/api/saidas/movimentacao-propria

'Content-Type'='application/json'
```javascript
{
    "fornecedor": 192,
    "entidade": 3,
    "dataEmissao": "04-02-2022",
    "dataEntrada": "04-02-2022",
    "operacao": 1155,
    "tipoDocumento": 35,
    "contaCredito": 295,
    "remessa": null,
    "observacao": "TESTE OBS",
    "itens": [{
            "idProduto": 24,
            "codigoSistema": "",
			"quantidade": 2,
            "valorUnitario": 20.00
        }
    ],
    "pagamento": {
        "planoPagamento": 1,
        "contaDebito": 6,
        "contaCredito": 138,
        "parcelas": [{
                "dataVencimento": "04-02-2022",
                "dataPagamento": "04-02-2022",
                "valor": 20,
                "linhaDigitavel": "(string)"
            }, {
                "dataVencimento": "04-03-2022",
                "dataPagamento": "04-03-2022",
                "valor": 20,
                "linhaDigitavel": "(string)"
            }
        ]
    }
}
```