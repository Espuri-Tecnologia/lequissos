### URLs

DELETE https://integrador.varejonline.com.br/apps/api/notas-fiscal-devolucao/:id

### Parâmetros

* **id**: ID da nota fiscal devolução que deve ser excluída (Long - Path Param)

### Retorno

* **Sucesso**  HTTP 200 OK:

Retorna um Json com informações do resultado da operação realizada, contendo:

**codigoMensagem**: Código de identificação da operação realizada. [veja a lista de Códigos](https://github.com/Varejonline/api/wiki/Retorno-API)

**mensagem**: Mensagem da operação realizada

* **id**:
 * **id** da nota excluida

**Requisição inválida:**

HTTP STATUS 400 – BAD REQUEST

* **Body**: mensagem de erro



