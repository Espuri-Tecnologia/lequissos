### URLs

> GET https://integrador.varejonline.com.br/apps/api/planos-gerenciais

> GET https://integrador.varejonline.com.br/apps/api/planos-gerenciais/:id

### Parâmetros

* **inicio:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **quantidade:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)

### Retorno

* **id:** id do plano gerencial (long)
* **nome:** nome do plano gerencial (string)

### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/planos-gerenciais

```javascript
[
   {
      "id":1,
      "nome":"FLUXO DE CAIXA HORIZONTAL"
   },
   {
      "id":2,
      "nome":"RELATÓRIO DE DESPESAS"
   }
]
```