
<table>
<tr><th>Objetivo da ação promocional</th></tr>
<tr><td>EXPERIMENTACAO_NOVO_PRODUTO_SERVICO</td></tr>
<tr><td>ELEVAR_VENDAS_CURTO_PRAZO</td></tr>
<tr><td>BAIXAR_EXCESSO_ESTOQUE</td></tr>
<tr><td>LIQUIDAR_ESTOQUE_OBSOLETO</td></tr>
<tr><td>ENFATIZAR_INOVACOES_NOVIDADES</td></tr>
<tr><td>ESTIMULAR_NOVOS_CANAIS_VENDA</td></tr>
<tr><td>ESTIMULAR_CONVENIOS_TERCEIROS</td></tr>

</table>