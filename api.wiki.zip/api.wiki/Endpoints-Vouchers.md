# Funcionamento dos Endpoints

Para manutenção de vouchers, são disponibilizados alguns endpoints. Cada endpoint possui particularidades e funções específicas.

> Observação: Existem dois tipos de vouchers (Promocionais ou Nominais), no objeto de criação e edição existem duas propriedades com os respectivos nomes, nunca pode ser enviado um voucher com ambos os tipos preenchidos, do contrário o request será recusado.

<br />

# APIs para manutenção do cadastro do voucher

## [GET Vouchers](https://github.com/Varejonline/api/wiki/GET-Vouchers) - Api para obtenção dos vouchers

## [POST Voucher](https://github.com/Varejonline/api/wiki/POST-Voucher) - Criação de um voucher

## [PUT Voucher](https://github.com/Varejonline/api/wiki/PUT-Voucher) - Editar um voucher criado anteriormente

## [DELETE Voucher](https://github.com/Varejonline/api/wiki/DELETE-Voucher) - Deletar um voucher criado anteriormente

## [GET Saldo Vouchers](https://github.com/Varejonline/api/wiki/GET-Saldo-Vouchers) - Api para obtenção dos saldos de vouchers
