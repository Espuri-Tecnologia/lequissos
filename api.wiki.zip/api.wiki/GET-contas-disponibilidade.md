### URL

> GET https://integrador.varejonline.com.br/apps/api/contas-disponibilidade

### Parâmetros

* **entidades:** [Veja como Funciona este Filtro](https://github.com/Varejonline/api/wiki/Filtro-de-Entidades)
* **inicio:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **quantidade:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **data:** Situação da conta na data especificada (String). Data no formato dd-mm-aaaa.

### Retorno

* **codigo:** código identificador da conta (string)
* **idEntidade:** id da [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) à qual a conta pertence (Long)
* **nome:** nome da conta (string)
* **valor:** valor disponível na conta (decimal)
* **tipo:** tipo da conta (string). Os tipos existentes são CAIXA, BANCO e APLIC FINANCEIRA

### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/contas-disponibilidade?entidades=1,2

```javascript
[
   {
      "codigo":"6-1",
      "idEntidade":1,
      "nome":"CAIXA PRINCIPAL",
      "valor":30306.29,
      "tipo":"CAIXA"
   },
   {
      "codigo":"6-2",
      "idEntidade":2,
      "nome":"CAIXA",
      "valor":2987.34,
      "tipo":"CAIXA"
   },
   {
      "codigo":"198-2",
      "idEntidade":2,
      "nome":"C/C - BANCO SANTANDER BANESPA - 2181 - 130170",
      "valor":17231.08,
      "tipo":"BANCO"
   }
   {
      "codigo":"137-2",
      "idEntidade":2,
      "nome":"APLIC - APLICAÇÃO BB",
      "valor":100.0,
      "tipo":"APLIC FINANCEIRA"
   }
]
```