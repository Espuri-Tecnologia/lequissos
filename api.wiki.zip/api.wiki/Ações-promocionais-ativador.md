produto e categoriasProduto são mutuamente exclusivos.

* **produto:** [produto](https://github.com/Varejonline/api/wiki/GET-Produtos). _(Obrigatório um identificador para o produto)_
  * **id:**
  * **codigoSistema:**
  * **codigoInterno:**
  * **codigoBarras:**
* **categoriasProduto:** Lista de ids de [categorias](https://github.com/Varejonline/api/wiki/GET-categorias-produto) (List(Long))