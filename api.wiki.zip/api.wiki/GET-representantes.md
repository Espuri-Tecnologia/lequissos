### Definição

Vendedores cadastrados no Varejonline.

### URLs

> GET https://integrador.varejonline.com.br/apps/api/representantes

    Obtém todos os vendedores com retorno paginado

> GET https://integrador.varejonline.com.br/apps/api/representantes/:id

    Obtém o vendedor pelo seu id

> GET https://integrador.varejonline.com.br/apps/api/representantes/do-usuario/:id_usuario

    Obtém o vendedor associado ao cadastro de um usuário do sistema

### Parâmetros

* **entidades:** [Veja como Funciona este Filtro](https://github.com/Varejonline/api/wiki/Filtro-de-Entidades)
* **inicio:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **quantidade:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **alteradoApos:** [Entenda a Coleta de Alterações](https://github.com/Varejonline/api/wiki/Filtro-de-Data-Alteração)
* **representantes:** Lista de IDs de [Representantes](https://github.com/Varejonline/api/wiki/GET-Representantes), separados por vírgula

### Retorno

* **id:** id do vendedor (long)
* **entidades:** ids das [entidades](https://github.com/Varejonline/api/wiki/GET-entidades) do vendedor (array)
* **nome:** nome do vendedor (string)
* **dataAlteracao:** última data de alteração do vendedor, no formato dd-mm-aaaa hh:mi:ss (string)
* **ativo:** indica se o vendedor está ativo sim ou não (booleano)
* **perfilVendedor:** define o perfil do vendedor, representando seu nível de acesso. Tipos: VENDEDOR, GERENTE, CAIXA (String)
* **terceiroId:** id do [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros) vinculado ao usuário associado ao vendedor.
* **maximoDesconto:** % de desconto máximo que o vendedor pode conceder (decimal)
* **permiteVender:** boolean que indica se o vendedor está liberado para realizar vendas

### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/representantes

```javascript
[
   {
      "id":1,
      "ativo":true,
      "entidades":[2, 3],
      "nome":"Primeiro Representate da Silva",
      "dataAlteracao":"20-01-2013 11:44:45",
      "perfilVendedor":"GERENTE",
      "terceiroId":102,
      "maximoDesconto":99.99,
      "permiteVender":true
   },
   {
      "id":2,
      "ativo":true,
      "entidades":[5, 6, 8, 10],
      "nome":"Segundo da Silva",
      "dataAlteracao":"20-01-2013 18:36:22",
      "perfilVendedor":"CAIXA",
      "terceiroId":102,
      "maximoDesconto":10,
      "permiteVender":true
   }
]
```