## [GET unidades](/Varejonline/api/wiki/GET-unidades)
## [POST unidades](/Varejonline/api/wiki/POST-unidades)
## [PUT unidades](/Varejonline/api/wiki/PUT-unidades)