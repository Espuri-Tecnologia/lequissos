### URLs

> GET https://integrador.varejonline.com.br/apps/api/lancamentos-padroes

> GET https://integrador.varejonline.com.br/apps/api/lancamentos-padroes/:id

### Parâmetros

* **tipo:** tipo de provisão desejada (string). Veja os tipos possíveis na descrição do retorno abaixo.
* **entidades:** [Veja como Funciona este Filtro](https://github.com/Varejonline/api/wiki/Filtro-de-Entidades)
* **inicio:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **quantidade:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
### Retorno

* **id:** id do lançamento padrão (long)
* **nome:** nome do lançamento padrão (string)
* **tipo:** tipo das provisões geradas a partir deste lançamento padrão  (string). Os tipos possíveis são: PROVISAO_PAGAMENTO e PROVISAO_RECEBIMENTO.
* **tipoDocumento:** tipo de documento associado às provisões (string)
* **numeroParcelas:** número de parcelas das provisões (integer)
* **diaVencimento:** dia do mês em que cada parcela irá vencer (integer)
* **contasDebito:** lista de contas debitadas pelas provisões (string)
* **contasCredito:** lista de contas creditadas pelas provisões (string)
* **idsEntidades:** lista de ids das [entidades](https://github.com/Varejonline/api/wiki/GET-entidades) às quais o lançamento padrão pertence (long)
* **idTerceiro:** id do [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros) a quem se destina a provisão (long)

### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/lancamentos-padroes?tipo=PROVISAO_PAGAMENTO

```javascript
[
   {
      "id":1,
      "nome":"ENERGIA ELÉTRICA",
      "tipo":"PROVISAO_PAGAMENTO",
      "tipoDocumento":"BOLETO",
      "numeroParcelas":1,
      "diaVencimento":6,
      "contasDebito":[
         "61420 - ENERGIA ELÉTRICA FÁBRICA"
      ],
      "contasCredito":[
         "21101 - FORNECEDORES DIVERSOS"
      ],
      "idsEntidades":[ 2, 1 ],
      "idTerceiro":119
   },
   {
      "id":4,
      "nome":"VEICULOS",
      "tipo":"PROVISAO_PAGAMENTO",
      "tipoDocumento":"BOLETO",
      "numeroParcelas":1,
      "diaVencimento":18,
      "contasDebito":[
         "61504 - MANUTENÇÃO DE VEÍCULOS"
      ],
      "contasCredito":[
         "21101 - FORNECEDORES DIVERSOS"
      ],
      "idsEntidades":[ 2, 1 ],
      "idTerceiro":1
   }
]
```