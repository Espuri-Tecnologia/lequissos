### URL

> POST https://integrador.varejonline.com.br/apps/api/adiantamentos-pagos

### Parâmetros

Envie um JSON no corpo da requisição, contendo:
* **data:** data de criação do adiantamento (string) _(obrigatório)_
* **idTerceiro:** id do [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros) do adiantamento (long) _(obrigatório)_
* **codigoContaDisponibilidade:** código da disponibilidade do adiantamento (string) _(obrigatório)_
* **valor:** valor do adiantamento (decimal) _(obrigatório)_

### Retorno

Sucesso:
* HTTP STATUS 201 – CREATED
* Body: id da adiantamento gerado

Requisição inválida: 
* HTTP STATUS 400 – BAD REQUEST
* Body: mensagem de erro

### Exemplo

> POST https://integrador.varejonline.com.br/apps/api/adiantamentos-pagos

'Content-Type'='application/json'

```javascript
{
   "data":"05-11-2012",
   "idTerceiro": 1,
   "codigoContaDisponibilidade": "6-1",
   "valor":99.0
}
```