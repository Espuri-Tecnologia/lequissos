### URLs

> GET https://integrador.varejonline.com.br/apps/api/adiantamentos-recebidos

> GET https://integrador.varejonline.com.br/apps/api/adiantamentos-recebidos/:id

### Parâmetros

* **entidades:** [Veja como Funciona este Filtro](https://github.com/Varejonline/api/wiki/Filtro-de-Entidades)
* **inicio:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **quantidade:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **desde:** [Veja o Filtro de Datas](https://github.com/Varejonline/api/wiki/Filtro-de-Datas)
* **ate:** [Veja o Filtro de Datas](https://github.com/Varejonline/api/wiki/Filtro-de-Datas)
* **terceiro:** parâmetro de filtragem de adiantamentos por [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros) (long)

### Retorno

* **id:** id do adiantamento (long)
* **idEntidade:** id da [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) do adiantamento (long)
* **idTerceiro:** id do [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros) do adiantamento (long)
* **disponivel:** chave para verificar se o adiantamento pode ser utilizado (boolean)
* **excluido:** chave para verificar se o adiantamento foi excluído (boolean)
* **valorTotal:** valor total (valor de criação) do adiantamento (decimal)
* **valorDisponivel:** valor disponível (diferença entre o valor total e o já utilizado) do adiantamento (decimal)
* **tipo:** Tipo do adiantamento recebido (1 - Cliente, 2 - Fornecedor, 3 - Funcionário, 4 - Sócio) (int)
* **dataAdiantamento:** data em que o adiantamento foi gerado, no formato dd-mm-aaaa (string).

### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/adiantamentos-recebidos

```javascript
[
   {
      "id":10,
      "idEntidade":2,
      "idTerceiro":12,
      "disponivel":true,
      "excluido":false,
      "valorTotal":947.5,
      "valorDisponivel":510,
      "dataAdiantamento":"26-02-2015",
      "tipo":3
   },
   {
      "id":12,
      "idEntidade":1,
      "idTerceiro":12,
      "disponivel":false,
      "excluido":true,
      "valorTotal":437.5,
      "valorDisponivel":0,
      "dataAdiantamento":"26-02-2015",
      "tipo":3
   }
]
```