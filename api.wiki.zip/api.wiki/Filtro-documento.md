Permite filtrar objetos pelo seu documento, como CPF ou CNPJ.

Para utilizar o filtro informa o parâmetro abaixo na URL, conforme exemplo.

* **documento:** número do documento do [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros).

## Exemplos de uso

> GET [https://integrador.varejonline.com.br/apps/api/terceiros?documento=64.033.248/0001-31](https://integrador.varejonline.com.br/apps/api/terceiros?documento=64.033.248/0001-31)