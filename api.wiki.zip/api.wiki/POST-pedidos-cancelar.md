### URL

> POST https://integrador.varejonline.com.br/apps/api/pedidos/:id/cancelar

### Retorno

Sucesso:
* HTTP STATUS 200 – OK
* Body: vazio

Requisição inválida: 
* HTTP STATUS 400 – BAD REQUEST
* Body: mensagem de erro

### Exemplo

> POST https://integrador.varejonline.com.br/apps/api/pedidos/398/cancelar