### URLs

> GET https://integrador.varejonline.com.br/apps/api/entradas

> GET https://integrador.varejonline.com.br/apps/api/entradas/:id

### Parâmetros

* **entidades:** [Veja como Funciona este Filtro](https://github.com/Varejonline/api/wiki/Filtro-de-Entidades)
* **inicio:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **quantidade:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **desde:** [Veja o Filtro de Datas](https://github.com/Varejonline/api/wiki/Filtro-de-Datas)
* **ate:** [Veja o Filtro de Datas](https://github.com/Varejonline/api/wiki/Filtro-de-Datas)
* **alteradoApos:** [Entenda a Coleta de Alterações](https://github.com/Varejonline/api/wiki/Filtro-de-Data-Alteração)

### Retorno
    
* **id:** identificador da entrada (long)
* **entidade:** [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) onde ocorreu a entrada (objeto complexo)
    * **id:** id da entidade  (long)
    * **nome:** nome da entidade (string)
    * **documento:** documento da entidade (string)
* **terceiro:** [emitente](https://github.com/Varejonline/api/wiki/GET-terceiros) da nota (objeto complexo)
    * **id:**  id do emitente (long)
    * **nome:** nome do emitente (string)
    * **documento:** documento do emitente (string)
* **tipoEntrada:** identificador do [tipo](https://github.com/Varejonline/api/wiki/Tipos-de-Movimentos) da entrada (string)
* **data:** data em que a entrada foi efetuada (string dd-mm-aaaa hh:mm:ss)
* **dataAlteracao:** data em que a entrada sofreu a última alteração no sistema (string dd-mm-aaaa hh:mm:ss)
* **numeroDocumento:** número do documento associado com a entrada (string)
* **valorTotal:** valor total da entrada(decimal)
* **idProvisao:** id da [provisão](https://github.com/Varejonline/api/wiki/GET-contas-pagar) a pagar associada a entrada (long)
* **operacao:** dados da operação do movimento
    * **descricao:** descrição da operação
    * **idOperacao:** id da operação
* **notasFiscais:**  lista de notas fiscais vinculadas a entrada, cada uma contendo:
  * **status:** [status](https://github.com/Varejonline/api/wiki/Status-Documentos-Fiscais) da nota fiscal (string).
  * **idNotaFiscal:** id da [nota fiscal](https://github.com/Varejonline/api/wiki/GET-notas-mercadoria) (long)
  * **tipoNotaFiscal:** tipo da nota fiscal (string)
* **itensDisponiveis:** lista de itens disponíveis da entrada, cada um contendo:
    * **id:** identificador do item disponível na entrada (long)
    * **produto:** dados do produto devolvido (objeto complexo)
        * **id:** id da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos)
        * **descricao:** id da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos)
        * **codigoSistema:** Código Sistema da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos)
        * **codigoInterno:** Código Interno da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos)
        * **codigoBarras:** Código de Barras da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos)
    * **unidade:** unidade utilizada na venda (string)
    * **quantidade:** quantidade vendida do produto na unidade informada (decimal)
    * **valorTotal:** valor produto x quantidade + valorTotalIpi + valorTotalIcmsSt + valorTotalOutrosCustos (decimal)
    * **valorTotalIcms:** valor total ICMS (decimal)
    * **valorTotalIpi:** valor total IPI (decimal)
    * **valorTotalFcpSt:** valor total FCPST (decimal)
    * **valorTotalOutrosCustos:** valor total outros custos (decimal)
    * **valorTotalCofins:** valor total COFINS (decimal)
    * **valorTotalPis:** valor total PIS (decimal)
    * **valorTotalIcmsSt:** valor total ICMSST (decimal)
    * **valorTotalDesconto:** valor total desconto (decimal)
* **itensIndisponiveis:** lista de itens disponíveis da entrada, cada um contendo:
    * **id:** identificador do item indisponível na entrada (long)
    * **produto:** dados do produto devolvido (objeto complexo)
        * **id:** id da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos)
        * **descricao:** id da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos)
        * **codigoSistema:** Código Sistema da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos)
        * **codigoInterno:** Código Interno da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos)
        * **codigoBarras:** Código de Barras da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos)
    * **unidade:** unidade utilizada na venda (string)
    * **quantidade:** quantidade vendida do produto na unidade informada (decimal)
    * **valorTotal:** valor produto x quantidade + valorTotalIpi + valorTotalIcmsSt + valorTotalOutrosCustos (decimal)
    * **valorTotalIcms:** valor total ICMS (decimal)
    * **valorTotalIpi:** valor total IPI (decimal)
    * **valorTotalOutrosCustos:** valor total outros custos (decimal)
    * **valorTotalCofins:** valor total COFINS (decimal)
    * **valorTotalPis:** valor total PIS (decimal)
    * **valorTotalIcmsSt:** valor total ICMSST (decimal)
    * **valorTotalDesconto:** valor total desconto (decimal)
* **itensNaoEstocaveis:** lista de itens disponíveis da entrada, cada um contendo:
    * **id:** identificador do item não estocável na entrada (long)
    * **produto:** dados do produto devolvido (objeto complexo)
        * **id:** id da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos)
        * **descricao:** id da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos)
        * **codigoSistema:** Código Sistema da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos)
        * **codigoInterno:** Código Interno da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos)
        * **codigoBarras:** Código de Barras da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos)
    * **unidade:** unidade utilizada na venda (string)
    * **quantidade:** quantidade vendida do produto na unidade informada (decimal)
    * **valorTotal:** valor produto x quantidade + valorTotalIpi + valorTotalIcmsSt + valorTotalOutrosCustos (decimal)
    * **valorTotalIcms:** valor total ICMS (decimal)
    * **valorTotalIpi:** valor total IPI (decimal)
    * **valorTotalOutrosCustos:** valor total outros custos (decimal)
    * **valorTotalCofins:** valor total COFINS (decimal)
    * **valorTotalPis:** valor total PIS (decimal)
    * **valorTotalIcmsSt:** valor total ICMSST (decimal)
    * **valorTotalDesconto:** valor total desconto (decimal)
* **idDevolucaoOnline:** Id da [devolução de venda](https://github.com/Varejonline/api/wiki/GET-devolucoes) online vinculada
* **idDevolucaoOffline:** Id da [devolução de venda](https://github.com/Varejonline/api/wiki/GET-devolucoes) offline vinculada

### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/entradas?entidades=1

```javascript
[
   {
      "id":1,
      "entidade": {
          "id": 3,
          "nome": "Entidade teste",
          "documento": "00.000.000/0000-00"
      },
      "terceiro": {
          "id": 1,
          "nome": "DIVERSOS",
          "documento": "000.000.000-00"
      },
      "notasFiscais":[{  
          "status":"EMITIDO",
          "idNotaFiscal":193306,
          "tipoNotaFiscal":"MERCADORIA"
      }],
      "tipoEntrada": "COMPRA",
      "data":”01-01-2013 23:59:59”,
      "dataAlteracao": "21-11-2017 16:19:54",
      "nomeDocumento":”Nota Fiscal”,
      "numeroDocumento":”124578”,
      "idProvisao":13547,
      "operacao": {
            "descricao": "Compra p/ comercialização",
            "idOperacao": 20
      },
      "itensDisponiveis":[{
            "id":1,
            "produto": {
                "id":9342,
                "descricao":"BLUSA MALHA PRETA GG",
                "codigoSistema":"0001.0001",
                "codigoInterno":"",
                "codigoBarras":""
            },
            "unidade":"Unidade",
            "quantidade":5.00,
            "valorTotal":10.00,
            "valorTotalIcms":1.70,
            "valorTotalIpi":0.00,
            "valorTotalOutrosCustos":0.00,
            "valorTotalCofins":0.00,
            "valorTotalPis":0.00,
            "valorTotalIcmsSt":0.00,
            "valorTotalDesconto":0.00
      }],
      "itensIndisponiveis":[{
            "id":1,
            "produto": {
                "id":9342,
                "descricao":"BLUSA MALHA PRETA GG",
                "codigoSistema":"0001.0001",
                "codigoInterno":"",
                "codigoBarras":""
            },
            "unidade":"Unidade",
            "quantidade":3.00,
            "valorTotal":10.00,
            "valorTotalIcms":1.70,
            "valorTotalIpi":0.00,
            "valorTotalOutrosCustos":0.00,
            "valorTotalCofins":0.00,
            "valorTotalPis":0.00,
            "valorTotalIcmsSt":0.00,
            "valorTotalDesconto":0.00
      }],
      "itensNaoEstocaveis":[{
            "id":1,
            "produto": {
                "id":9342,
                "descricao":"BLUSA MALHA PRETA GG",
                "codigoSistema":"0001.0001",
                "codigoInterno":"",
                "codigoBarras":""
            },
            "unidade":"Unidade",
            "quantidade":4.00,
            "valorTotal":10.00,
            "valorTotalIcms":1.70,
            "valorTotalIpi":0.00,
            "valorTotalOutrosCustos":0.00,
            "valorTotalCofins":0.00,
            "valorTotalPis":0.00,
            "valorTotalIcmsSt":0.00,
            "valorTotalDesconto":0.00
      }]
   },   
   {
      "id":3,
      "entidade": {
          "id": 3,
          "nome": "Entidade teste",
          "documento": "00.000.000/0000-00"
      },
      "terceiro": {
          "id": 1,
          "nome": "DIVERSOS",
          "documento": "000.000.000-00"
      },
      "notasFiscais":[{  
          "status":"EMITIDO",
          "idNotaFiscal":193303,
          "tipoNotaFiscal":"MERCADORIA"
      }],
      "data":”15-12-2012 23:59:59”,
      "dataAlteracao": "21-11-2017 16:19:54",
      "tipoEntrada": "TRANSFERENCIA",
      "nomeDocumento":”Nota Fiscal”,
      "numeroDocumento":”456789”,
      "idProvisao":13548,
      "operacao": {
            "descricao": "Compra p/ comercialização",
            "idOperacao": 20
      },
      "itensDisponiveis":[{
            "id":3,
            "produto": {
                "id":9342,
                "descricao":"BLUSA MALHA PRETA GG",
                "codigoSistema":"0001.0001",
                "codigoInterno":"",
                "codigoBarras":""
            },
            "unidade":"Unidade",
            "quantidade":5.00,
            "valorTotal":10.00,
            "valorTotalIcms":1.70,
            "valorTotalIpi":0.00,
            "valorTotalOutrosCustos":0.00,
            "valorTotalCofins":0.00,
            "valorTotalPis":0.00,
            "valorTotalIcmsSt":0.00,
            "valorTotalDesconto":0.00
      }],
      "itensIndisponiveis":[{
            "id":3,
            "produto": {
                "id":9342,
                "descricao":"BLUSA MALHA PRETA GG",
                "codigoSistema":"0001.0001",
                "codigoInterno":"",
                "codigoBarras":""
            },
            "unidade":"Unidade",
            "quantidade":3.00,
            "valorTotal":10.00,
            "valorTotalIcms":1.70,
            "valorTotalIpi":0.00,
            "valorTotalOutrosCustos":0.00,
            "valorTotalCofins":0.00,
            "valorTotalPis":0.00,
            "valorTotalIcmsSt":0.00,
            "valorTotalDesconto":0.00
      }],
      "itensNaoEstocaveis":[{
            "id":3,
            "produto": {
                "id":9342,
                "descricao":"BLUSA MALHA PRETA GG",
                "codigoSistema":"0001.0001",
                "codigoInterno":"",
                "codigoBarras":""
            },
            "unidade":"Unidade",
            "quantidade":4.00,
            "valorTotal":10.00,
            "valorTotalIcms":1.70,
            "valorTotalIpi":0.00,
            "valorTotalOutrosCustos":0.00,
            "valorTotalCofins":0.00,
            "valorTotalPis":0.00,
            "valorTotalIcmsSt":0.00,
            "valorTotalDesconto":0.00
      }]
   }
]
```