### URL

POST https://integrador.varejonline.com.br/apps/api/notas-fiscal-devolucao

### Parâmetros

Envie um JSON no corpo da requisição, contendo:

* **fornecedor:** [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros) fornecedor da nota (objeto complexo)
   * **id**: id do fornecedor da nota
    * **documento:** documento da entidade (opcional) (string)

* **entidade:** [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) utilizada (obrigatório) (objeto complexo)
    * **id:** id da entidade (opcional) (long)
    * **documento:** documento da entidade (opcional) (string)
  
* **numeroNotaFiscal**: numero da nota fiscal (long)

* **serieNotaFiscal**: série da nota (string)

* **chaveNotaFiscal**: numero da chave da nota fiscal (string)

* **dataEmissão**: data de emissão da nota (string dd-MM-yyyy)

* **idUsuario**: id do usuario (long)

* **valorTotalProduto**: valor total dos produtos da nota (decimal)

* **valorFrete**: valor do frete da nota (decimal)

* **valorSeguro**: valor do seguro da nota (decimal)

* **valorOutros**: outros valores contido na nota (decimal)

* **valorDesconto**: valor do desconto da nota (decimal)

* **valorTotalIpi**: valor total do ipi da nota (decimal)

* **valorIpiDevolvido**: valor ipi devolvido (decimal)

* **valorTotalPis**: valor total do pis da nota (decimal)

* **valorTotalCofins**: valor total do cofins da nota (decimal)

* **valorTotalII**: valor total II da nota (decimal)

* **valorTotalIof**: valor total Iof da nota (decimal)

* **valorTotalDespesasAduaneiras**: valor das despesas aduaneiras da nota (decimal)

* **valorTotalFcpSt**: valor total do FcpSt da nota (decimal)

* **valorIcmsDesoneracao**: valor total do icms desoneração da nota (decimal)

* **valorFcpStRest**: valor total do FcpStRest da nota (decimal)

* **valorFcp**: valor total do Fcp da nota (decimal)

* **valorTotalNota**: valor total da nota (decimal)

* **produtos**: lista de produtos da nota

  * **produto**:(obrigatório informar um dos critérios para a busca do produto. Utiliza-se o primeiro critério da ordem)

    * **id**: id do [produto](https://github.com/Varejonline/api/wiki/GET-Produtos)

    * **codigoSistema**: código de sistema do [produto](https://github.com/Varejonline/api/wiki/GET-Produtos)
   
  * **valorProduto**: valor do produto (decimal)

  * **quantidade**: quantidades de produtos da nota original (long)

  * **quantidadeDevolvida**: quantidade de itens disponíveis para devolver (long)

  * **valorUnitario**: valor unitário do produto (decimal)

  * **origemProduto**: origem do produto (long)

  * **cstCofins**: [CST de Cofins](https://github.com/Varejonline/api/wiki/CST-Cofins) (string)

  * **valorBaseCalculoCofins**: valor base de calculo cofins (decimal)

  * **percentualCofins**: percentual cofins (decimal)

  * **valorCofins**: valor cofins (decimal)

  * **percentualReducaoCofins**: percentual redução cofins da nota (decimal)

  * **cstIcms**: [CST de Icms](https://github.com/Varejonline/api/wiki/CST-ICMS) (string)

  * **valorBaseCalculoIcms**: valor base Calculo icms (decimal)

  * **percentualReducaoIcms**: percentual redução icms (decimal)

  * **percentualIcms**: percentual icms (decimal)

  * **valorIcms**: valor icms (decimal)

  * **valorIcmsDesoneracao**: valor icms desoneração (decimal)

  * **aliquotaIcmsSn**: aliquota icmsSn (decimal)

  * **valorIcmsSn**: valor do icms sn (decimal)

  * **valorBaseCalculoIcmsSt**: valor de base de cálculo do icms st (decimal)

  * **valorPercentualIva**: valor percentual Iva (decimal)

  * **percentualIcmsSt**: percentual icms st (decimal)

  * **valorIcmsSt**: valor do icms st (decimal)

  * **cstIpi**: [CST de Ipi](https://github.com/Varejonline/api/wiki/CST-Ipi) (string)

  * **valorBaseCalculoIpi**: valor base de calculo ipi (decimal)

  * **percentualIpi**: percentual ipi (decimal)

  * **valorIpi**: valor ipi (decimal)

  * **valorIpiDevolvido**: valor ipi devolvido (decimal)

  * **cstPis**: [CST de Pis](https://github.com/Varejonline/api/wiki/CST-PIS) (string)

  * **valorBaseCalculoPis**: valor base de calculo pis (decimal)

  * **percentualPis**: percentual pis (decimal)

  * **valorPis**: valor pis (decimal)

  * **aliquotaFcp**: aliquota Fcp (decimal)

  * **aliquotaFcpSt**: aliquota FcpSt (decimal)

  * **aliquotaInterestadual**: aliquota interestadual (decimal)

  * **valorBaseCalculoFcpSt**: valor base de calculo FcpSt (decimal)

  * **valorFcp**: valor fcp (decimal)

  * **valorFcpSt**: valor FcpSt (decimal)

  * **valorFcpStRest**: valor FcpStRest (decimal)

  * **percentualPartilha**: percentual partilha (decimal)

  * **valorIcmsDiferido**: valor do icms diferido (decimal)

  * **percentualIcmsDiferido**: percentual icms diferido (decimal)

  * **valorBaseCalculoII**: valor de base de cálculo do II (decimal)

  * **valorII**: valor II (decimal)

  * **ordemItemNota**: sequencia do item na nota (long)


### Observações

 Formatos aceitos na string de data: "dd-mm-aaaa" ou "dd-mm-aaaa hh:mm:ss".

### Retorno

 * **Sucesso**:

HTTP STATUS 201 – CREATED
* **Body**: id do pedido de compra gerado

Requisição inválida:

HTTP STATUS 400 – BAD REQUEST
* **Body**: mensagem de erro

### Exemplo

``` javascript

{
    "fornecedor": {
        "id": 199
    },
    "entidade": {
        "id": 2,
    },
    "numeroNotaFiscal": 398051,
    "serieNotaFiscal": "1",
    "chaveNotaFiscal": "13181017921427000125650010000000309887251170",
    "dataEmissao": "25-07-2024",
    "idUsuario": 1,
    "valorTotalProduto": 1992.25,
    "valorFrete": 0.00,
    "valorSeguro": 0.00,
    "valorOutros": 0.00,
    "valorDesconto": 0.00,
    "valorTotalIpi": 0.00,
    "valorIpiDevolvido": 0.00,
    "valorTotalPis": 26.36,
    "valorTotalCofins": 0.00,
    "valorTotalII": 0.00,
    "valorTotalIof": 0.00,
    "valorTotalDespesasAduaneiras": 0.00,
    "valorTotalFcpSt": 0.00,
    "valorIcmsDesoneracao": 129.55,
    "valorFcpStRest": 0.00,
    "valorFcp": 0.00,
    "valorTotalNota": 1992.25,
    "produtos": [
        {
            "produto": {
                "id": 24
            },
            "valorProduto": 2.00,
            "quantidade": 1,
            "quantidadeDevolvida": 1,
            "valorUnitario": 20.00,
            "origemProduto": 1,
            "cstCofins": "OP_TRIB_ALIQ_BASICA",
            "valorBaseCalculoCofins": 1850.55,
            "percentualCofins": 0.00,
            "valorCofins": 0.00,
            "percentualReducaoCofins": 9.9,
            "cstIcms": "TRIBUTADA_INTEGRALMENTE",
            "valorBaseCalculoIcms": 0.00,
            "percentualReducaoIcms": 0.00,
            "percentualIcms": 7.00,
            "valorIcms": 0.00,
            "valorIcmsDesoneracao": 129.55,
            "aliquotaIcmsSn": 0.00,
            "valorIcmsSn": 0.00,
            "valorBaseCalculoIcmsSt": 0.00,
            "valorPercentualIva": 0.00,
            "percentualIcmsSt": 0.00,
            "valorIcmsSt": 0.00,
            "cstIpi": "ENTRADA_RECUPERACAO_CREDITO",
            "valorBaseCalculoIpi": 0.00,
            "percentualIpi": 0.00,
            "valorIpi": 0.00,
            "valorIpiDevolvido": 0.00,
            "cstPis": "OP_TRIB_ALIQ_BASICA",
            "valorBaseCalculoPis": 0.00,
            "percentualPis": 0.00,
            "valorPis": 0.00,
            "aliquotaFcp": 0.00,
            "aliquotaFcpSt": 0.00,
            "aliquotaInterestadual": 0.00,
            "valorBaseCalculoFcpSt": 0.00,
            "valorFcp": 0.00,
            "valorFcpSt": 0.00,
            "valorFcpStRest": 0.00,
            "percentualPartilha": 0.00,
            "valorIcmsDiferido": 0.00,
            "percentualIcmsDiferido": 0.00,
            "valorBaseCalculoII": 0.00,
            "valorII": 0.00,
            "ordemItemNota": 1
        }
    ]
}
```
