### URLs

GET https://integrador.varejonline.com.br/apps/api/notas-fiscal-devolucao

GET https://integrador.varejonline.com.br/apps/api/notas-fiscal-devolucao/:id

### Parâmetros

* **entidades**: [Veja como Funciona este Filtro](https://github.com/Varejonline/api/wiki/Filtro-de-Entidades)

* **inicio**: [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Pagina%C3%A7%C3%A3o-de-resultados)

* **quantidade**: [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Pagina%C3%A7%C3%A3o-de-resultados)

* **alteradoApos**: [Entenda a Coleta de Alterações](https://github.com/Varejonline/api/wiki/Filtro-de-Data-Altera%C3%A7%C3%A3o)

* **desde**: [Veja o Filtro de Datas](https://github.com/Varejonline/api/wiki/Filtro-de-Datas)

* **ate**: [Veja o Filtro de Datas](https://github.com/Varejonline/api/wiki/Filtro-de-Datas)

### Retorno

* **id**: id da nota (long)

* **numeroNotaFiscal**: número do documento fiscal da nota de mercadoria. (long)

* **chaveNotaFiscal**: chave da nota de mercadoria. (string)

* **fornecedor:** [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros) fornecedor da nota (objeto complexo)
   * **id**: id do fornecedor da nota

* **entidade:** [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) utilizada (obrigatório) (objeto complexo)
    * **id:** id da entidade (opcional) (long)
    * **documento:** documento da entidade (opcional) (string)

* **documento**: documento do emitente(string)

* **valorTotalProdutos**: valor total da nota (decimal)

* **valorTotalCofins**: valor total cofins da nota (decimal)

* **valorTotalFcpSt**: valor total FcpSt da nota (decimal)

* **valorTotalNota**: valor total da nota (decimal)

* **valorTotalII**: valor total II da nota (decimal)

* **valorTotalIof**: valor total Iofda nota (decimal)

* **dataCadastro**: data cadastro da nora (string)

* **idUsuario**: id so usuario (long)

* **valorTotalPis**: valor total Pis da nota (decimal)

* **valorTotalIpi**: valor total Ipi da nota (decimal)

* **valorIcmsDesoneracao**: valor total do icms desoneração da nota (decimal)

* **valorFcpStRest**: valor total do FcpStRest da nota (decimal)

* **valorFcp**: valor total do Fcp da nota (decimal)

* **serieNotaFiscal**: série da nota (string)

* **itens**: lista de itens da nota

  * **produto**: dados do produto (objeto complexo)

    * **id**: id da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos)

    * **descricao**: id da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos)

    * **codigoSistema**: Código Sistema da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos)
  
    * **codigoInterno**: Código Interno da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos)

    * **codigoBarras**: Código de Barras da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos)

    * **cstPis**: [CST de Pis](https://github.com/Varejonline/api/wiki/CST-PIS) (string)

    * **quantidade**: quantidade do produto (decimal)

    * **valorUnitario**: valor unitário do produto na nota (decimal)

    * **valorFrete**: valor de frete do item (decimal)

    * **valorOutros**: outros valores do item (decimal)

    * **valorSeguro**: valor de seguro do item (decimal)

    * **valorUnitario**: valor unitario do item (decimal)

    * **valorDesconto**: valor do desconto do item (decimal)

    * **percentualIpi**: valor percentual do ipi (decimal)

    * **cstIcms**: [CST de Icms](https://github.com/Varejonline/api/wiki/CST-ICMS) (string)

    * **cstCofins**: [CST de Cofins](https://github.com/Varejonline/api/wiki/CST-Cofins) (string)

    * **cstIpi**: [CST de Ipi](https://github.com/Varejonline/api/wiki/CST-Ipi) (string)

    * **valorFcpSt**: valorFcpSt da nota (decimal)

    * **valorIcms**: valorIcms da nota (decimal)

    * **aliquotaFcpSt**: aliquotaFcpSt da nota (decimal)

    * **percentualPartilha**: percentualPartilha da nota (decimal)

    * **percentualIpi**: percentualIpi da nota (decimal)

    * **origemProduto**: numero de origem do produto na nota (long)

    * **valorFcp**: valorFcp da nota (decimal)

    * **percentualPis**: percentualPis da nota (decimal)

    * **valorII**: valorII da nota (decimal)

    * **percentualReducaoCofins**: percentualReducaoCofins da nota  decimal)

    * **percentualIcms**: percentualIcms da nota  (decimal)

    * **quantidadeDevolvida**: quantidade já devolvida do item (long)

    * **percentualReducaoIcms**: percentualReducaoIcms da nota (decimal)

    * **valorPercentualIva**: valorPercentualIva da nota  (decimal)

    * **valorBaseCalculoCofins**: valorBaseCalculoCofins da nota (decimal)

    * **valorBaseCalculoIpi**: valorBaseCalculopi da nota (decimal)

    * **valorFcpStRest**: valorFcpStRest da nota (decimal)

    * **valorBaseCalculoFcpSt**: valorBaseCalculoFcpSt da nota (decimal)

    * **aliquotaIcmsSn**: aliquotaIcmsSn da nota (decimal)

    * **valorIcmsDesoneracao**: valorIcmsDesinaracao da nota (decimal)

    * **valorBaseCalculoPis**: valorBaseCalculoPis da nota (decimal)

    * **aliquotaInterestadual**: aliquotaInterestadual da nota (decimal)
              
    * **valorPis**: valorPis da nota valorPis (decimal)

    * **valorCofins**: valorConfins da nota (decimal)

    * **valorIpiDevolvido**: valor do ipi devolvido (decimal)

    * **valorIcmsSt**: valor do icms st (decimal)

    * **valorIcmsSn**: valor do icms sn (decimal)

    * **valorIcmsDiferido**: valor do icms diferido (decimal)

    * **valorBaseCalculoIcmsSt**: valor de base de cálculo do icms st (decimal)

    * **valorBaseCalculoII**: valor de base de cálculo do II (decimal)

    * **percentualIcmsSt**: percentual icms st (decimal)

    * **percentualIcmsDiferido**: percentual icms diferido (decimal)

    * **percentualCofins**: percentual cofins (decimal)

    * **ordemItemNota**: sequencia do item na nota (long)

### EXEMPLO

``` javascript


{
        "numeroNotaFiscal": 398051,
        "valorTotalProdutos": 1992.25,
        "valorTotalCofins": 0,
        "valorTotalFcpSt": 0,
        "id": 9,
        "entidade": {
            "id": 2,
            "nome": "LOJA NFCE - LUCRO PRESUMIDO"
        },
        "valorTotalNota": 1992.25,
        "valorTotalII": 0,
        "valorTotalIof": 0,
        "dataCadastro": "10-10-2024",
        "emitente": {
            "id": 2,
            "nome": "EMPRESA SIMPLES NACIONAL",
            "documento": "24208642000149"
        },
        "idUsuario": 1,
        "valorTotalPis": 26.36,
        "valorTotalIpi": 0,
        "produtos": [
            {
                "cstPis": "OP_TRIB_ALIQ_BASICA",
                "cstCofins": "OP_TRIB_ALIQ_BASICA",
                "cstIpi": "ENTRADA_RECUPERACAO_CREDITO",
                "valorProduto": 2,
                "cstIcms": "TRIBUTADA_INTEGRALMENTE",
                "valorFcpSt": 0,
                "valorIpi": 0,
                "aliquotaFcpSt": 0,
                "valorIcms": 0,
                "percentualPartilha": 0,
                "percentualIpi": 0,
                "origemProduto": 1,
                "valorFcp": 0,
                "percentualPis": 0,
                "aliquotaFcp": 0,
                "valorII": 0,
                "percentualReducaoCofins": 9.9,
                "percentualIcms": 7,
                "quantidadeDevolvida": 1,
                "percentualReducaoIcms": 0,
                "valorPercentualIva": 0,
                "valorBaseCalculoCofins": 1850.55,
                "valorBaseCalculoIpi": 0,
                "valorFcpStRest": 0,
                "valorBaseCalculoFcpSt": 0,
                "aliquotaIcmsSn": 0,
                "valorIcmsDesoneracao": 129.55,
                "valorBaseCalculoPis": 0,
                "aliquotaInterestadual": 0,
                "quantidade": 1,
                "valorPis": 0,
                "valorUnitario": 20,
                "valorCofins": 0,
                "produto": {
                    "id": 24
                }
            },
            {
                "cstPis": "OP_TRIB_ALIQ_BASICA",
                "cstCofins": "OP_TRIB_ALIQ_BASICA",
                "cstIpi": "ENTRADA_RECUPERACAO_CREDITO",
                "valorProduto": 2,
                "cstIcms": "TRIBUTADA_INTEGRALMENTE",
                "valorFcpSt": 0,
                "valorIpi": 0,
                "aliquotaFcpSt": 0,
                "valorIcms": 0,
                "percentualIpi": 0,
                "origemProduto": 1,
                "valorFcp": 0,
                "percentualPis": 0,
                "aliquotaFcp": 0,
                "percentualReducaoCofins": 9.9,
                "percentualIcms": 7,
                "quantidadeDevolvida": 1,
                "valorPercentualIva": 0,
                "valorBaseCalculoCofins": 1850.55,
                "valorBaseCalculoIpi": 0,
                "valorFcpStRest": 0,
                "valorBaseCalculoFcpSt": 0,
                "aliquotaIcmsSn": 0,
                "valorIcmsDesoneracao": 129.55,
                "valorBaseCalculoPis": 0,
                "aliquotaInterestadual": 0,
                "quantidade": 1,
                "valorPis": 0,
                "valorUnitario": 20,
                "valorCofins": 0,
                "produto": {
                    "id": 24
                }
            }
        ],
}
```


