### Descrição

Obtém o limite disponível de crédito para um determinado terceiro

### URLs

> GET https://integrador.varejonline.com.br/apps/api/terceiros/:id/limites_credito/disponivel

### PATH PARAMS

Id do [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros) a ter seu limite consultado

### Retorno

Valor decimal no body

### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/terceiros/10/limites_credito/disponivel

```javascript
39.90
```
