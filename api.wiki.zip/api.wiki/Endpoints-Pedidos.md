## [GET pedidos](/Varejonline/api/wiki/GET-pedidos)
## [POST pedido](/Varejonline/api/wiki/POST-pedidos)
## [POST cancelar](/Varejonline/api/wiki/POST-pedidos-cancelar)
<br>

## [GET Status pedido](/Varejonline/api/wiki/GET-Status-Pedido-Venda)
## [POST Alterar status](/Varejonline/api/wiki/POST-pedidos-alterar-status)
<br>

## [POST ajustar-data-entrega](/Varejonline/api/wiki/POST-pedidos-ajustar-data-de-entrega)
## [POST adicionar-observacao-entrega](/Varejonline/api/wiki/POST-pedidos-adicionar-observacao-entrega)
## [POST atribuir-url-etiqueta](/Varejonline/api/wiki/POST-pedidos-atribuir-url-etiqueta)
<br>

### Operação em lote (Assíncrona)
## [GET Lote de Pedidos](/Varejonline/api/wiki/GET-Lote-de-Pedidos)
## [POST Lote de Pedidos](/Varejonline/api/wiki/POST-Lote-de-Pedidos)

## Integração de pedidos de ecommerce

Documentação completa: [Roteiro de integração com Ecom](https://github.com/Varejonline/api/wiki/Roteiro-de-integra%C3%A7%C3%A3o-com-Ecom)

Caro parceiro, para realizar a integração de pedidos de ecom, algumas recomendações são indicadas. Separamos esse tópico para auxiliar na orientação desses itens.

**Ponto 1:** Para facilitar o rastreio do usuário e o controle na integração, sugerimos a utilização do atributo **numeroPedidoCliente**, onde o integrador deve informar o nr do pedido no ecommerce. Com isso, facilmente o usuário consegue encontrar o pedido no sistema e a integração, antes de tentar uma retransmissão de pedido por falha de comunicação, pode consultar no [GET Pedidos](https://github.com/Varejonline/api/wiki/GET-pedidos) se o pedido com o respectivo já existe ou não no sistema.

**Ponto 2:** Para facilitar os controles operacionais sobre os fluxos de Picking e Packing dos pedidos, orientamos que sejam informados os valores apropriados nos campos **origem**, **intermediador** e **tipo**. Com isso o operador saberá se o cliente irá retirar o produto em loja ou se o produto deve ser despachado via entregador, saberá também a origem do pedido para clientes com múltiplas origens de venda online.

**Ponto 3:** Se o fluxo do seu cliente prevê esse recurso, é possível solicitar ao sistema a emissão automática da nota assim que o pedido é integrado, para isso, basta informar no atributo **emitirNotaFiscal** o valor true. Se todas as informações necessárias estiverem devidamente informadas, a nota será emitida. Com isso será eliminado um processo manual do cliente. Caso o pedido sejá um presente, ainda é possível marcar o atributo **emitirNotaFiscalPresente** como true, permitindo que uma nota simplifica seja automaticamente emitida para que seja entregue ao destinatário.

**Ponto 4:** Informe o endereço de entrega da mercadoria (Atributo **enderecoEntrega**), quando aplicável. Muitas vezes o recebedor não é o mesmo que o comprador de um pedido.

**Ponto 5:** É possível importar para dentro do sistema a URL contendo a etiqueta de transporte da mercadoria. Muitos sistema de TMS publicam um link para geração da etiqueta de transporte. Informe a url no atributo **urlEtiqueta** ou por meio de um [POST Adicional](https://github.com/Varejonline/api/wiki/POST-pedidos-atribuir-url-etiqueta) posterior a entrada do pedido no sistema.

## Pedidos com itens que são Kits de produtos

Para integrar vendas contendo Kits, é necessário quebrar o kit nos seus componentes, rateando o valor do kit vendido entre os itens do kit.

### Como fazer?

Encontre a forma mais apropriada de identificar que o item é um Kit. Isso pode ser feito lendo cada item do pedido na [API de produtos](https://github.com/Varejonline/api/wiki/GET-Produtos) do VO, observando o atributo **componentes**. Um produto com componentes dentro dele, é um KIT. 

Em seguida, com os componentes conhecidos, implemente o rateio monetário. Segue um exemplo:

Kit vendido por 99 reais no ecom contendo 3 componentes no seu cadastro
1. Componente A com um preço de venda de 25 reais na tabela 1 e quantidade 2 dentro do kit.
2. Componente B com um preço de venda de 30 reais na tabela 1 e quantidade 3 dentro do kit.

Soma total dos componentes
1. Componente A: 25 reais * 2 qtde = 50 reais
2. Componente B: 30 reais * 3 qtde = 90 reais
3. Total dos componentes na tabela padrão: 140 reais

Como informar os componentes no pedido
1. Total do Componente A: 50/140 = 36% do valor do KIT (99 * 36 / 100) = 35,64
2. Total do Componente B: 90/140 = 64% do valor do KIT (99 * 64 / 100) = 63,36

Em seguida, obter os valores unitário:
1. Unitário do Componente A (35,64 / 2) = 17,82
2. Unitário do Componente B (63,36 / 3) = 21,12

Então informar no pedido, 2 quantidades do produto A, com unitário de 17,82 + 3 quantidades do produto B com unitário de 21,12.

**Informação importante:** Por se tratar de um rateio e em função do sistema arredondar os valores para o nr de casas decimais parametrizados na operação do cliente (Normalmente 2 casas), eventualmente a soma das quantidades * unitários de todos os componentes pode gerar um valor superior ou inferior ao valor do kit vendido (Alguns centavos). Orientamos então o integrador a já arredondar os valores unitários para duas casas, somar o resultado e distribuir as dízimas entre os itens. Por exemplo: Se o total gerou 1 centavo a mais, remova 1 centavo de algum item com quantidade 1 no KIT. Caso não seja possível distribuir a dízima, como em casos onde o kit tem apenas produtos com mais de uma quantidade e a diferença foi de apenas 1 centavo, orientamos a aplicar um desconto na capa do pedido ou no pior cenário, aumentar em 1 centavo o total do pedido e do pagamento para evitar bloqueios de gravação do pedido. Infelizmente esses são problemas insolúveis e que precisam ter um bypass implementado.






