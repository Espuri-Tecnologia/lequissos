### URLs

> GET https://integrador.varejonline.com.br/apps/api/boletos

> GET https://integrador.varejonline.com.br/apps/api/boletos/:id


### Parâmetros

* **inicio:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **quantidade:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **alteradoApos:** [Entenda a Coleta de Alterações](https://github.com/Varejonline/api/wiki/Filtro-de-Data-Alteração)
* **idCarteiraCobranca:** id da carteira de cobrança utilizada para emitir o boleto
* **idContaReceber:** id do conta a receber para o qual o boleto foi emitido

### Retorno

* **id:** id do boleto (long)
* **dataCriacao:** data de criação do boleto, no formato dd-mm-aaaa hh:mi:ss (string)
* **dataAlteracao:** última data de alteração do boleto, no formato dd-mm-aaaa hh:mi:ss (string)
* **dataVencimento:** data de vencimento do boleto, no formato dd-mm-aaaa (string)
* **banco:** código do banco(string)
* **agencia:** código da agência(string)
* **contaCorrente:** código da Conta Corrente(string)
* **nossoNumero:** nosso número utilizado no boleto(string)
* **cedente:** cedente (string)
* **sacado:** sacado (string)
* **valor:** valor do boleto (decimal)
* **idCarteiraCobranca:** id da carteira de cobrança utilizada para emitir o boleto (long)
* **idContaReceber:** id do conta a receber utilizado para emitir o boleto (long)
* **status:** status do boleto, podendo assumir os valores "EMITIDO", "CANCELADO" e "PAGO" (string)

### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/boletos

```javascript
[
   {
      "id":1,
      "dataCriacao":"01-01-2014 14:00:00",
      "dataAlteracao":"01-01-2014 14:00:00",
      "dataVencimento":"01-03-2014",
      "banco":"033",
      "agencia":"144",
      "contaCorrente": "111001",
      "nossoNumero": "00050001",
      "cedente": "CALÇADOS ABC COMÉRCICO",
      "sacado": "MARIA EUGENIA DA SILVA",
      "valor": 100.0,
      "idCarteiraCobranca": 2,
      "idContaReceber": 15435,
   },
   {
      "id":2,
      "dataCriacao":"01-01-2014 14:32:00",
      "dataAlteracao":"01-01-2014 14:32:00",
      "dataVencimento":"15-02-2014",
      "banco":"237",
      "agencia":"0076",
      "contaCorrente": "413324",
      "nossoNumero": "00050002",
      "cedente": "LOJAS AQUI COMÉRCIO",
      "sacado": "LUIZ ANTÔNIO PEREIRA",
      "valor": 550.0,
      "idCarteiraCobranca": 1,
      "idContaReceber": 54354,
   }
]```