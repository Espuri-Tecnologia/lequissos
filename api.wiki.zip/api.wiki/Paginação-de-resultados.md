Todos os serviços que retornam listas são paginados. Esta função é controlada por meio de dois parâmetros:
* **inicio:** posição do primeiro registro desejado. A posição 0 representa o primeiro registro existente.
* **quantidade:** número máximo de registros que se deseja receber. O valor máximo deste parâmetro é 300.

Por padrão, se não forem informados os parâmetros de paginação, o Varejonline assumirá os seguintes valores:
* **inicio:** 0 (primeiro registro da lista)
* **quantidade:** 300 (quantidade máxima aceita)

A quantidade de registros retornados pela API pode ser alterada sem aviso prévio.

## Exemplos de uso
Busca da primeira página

> GET https://integrador.varejonline.com.br/apps/api/produtos/?inicio=0&quantidade=10

>Essa busca trará os 10 primeiros produtos.

Busca da segunda página

> GET https://integrador.varejonline.com.br/apps/api/produtos/?inicio=10&quantidade=10

>Essa busca trará 10 produtos, pulando os 10 primeiros.

Busca da última página

> GET https://integrador.varejonline.com.br/apps/api/produtos/?inicio=20&quantidade=10

>Supondo que existam apenas 28 produtos, essa busca trará 8 produtos, pulando os 20 primeiros.

Busca sem informar parâmetros

> GET https://integrador.varejonline.com.br/apps/api/produtos

>Como não foram informados os parâmetros de paginação, o Varejonline assumirá os valores padrão: inicio = 0 e quantidade = 300.

## **Nota Importante:** 

É possível que sejam solicitados X registros em uma requisição e uma quantidade inferior seja retornada, mesmo existindo mais registros em página posteriores. Isso ocorre em função da camada ORM da aplicação normalizar os dados consultados após a paginação a nível de banco ter sido realizada.

Essa informação é importante para que seu critério de parada na consulta de itens paginados seja buscar até que a página retorne zero elementos e não um valor inferior ao solicitado.