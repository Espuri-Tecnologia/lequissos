### URL

> POST https://integrador.varejonline.com.br/apps/api/pedidos

### Parâmetros

Envie um JSON no corpo da requisição, contendo:

* **numeroPedidoCliente:** número do referência do pedido de venda utilizado pelo cliente (string) _(opcional)_
* **idOrcamento:** id do [orçamento](https://github.com/Varejonline/api/wiki/GET-orcamentos) vinculado. _Se informado orçamento, o status do orçamento será ajustado para VIROU_PEDIDO e caso existam reservas de estoque vinculadas ao orçamento serão canceladas._
* **data:** data de criação do pedido (string dd-MM-yyyy)
* **horario:** horário de criação do pedido, no formato hh:mm:ss (string)
* **entidade:** [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) utilizada (obrigatório) (objeto complexo)
    * **id:** id da entidade (opcional) (long)
    * **documento:** documento da entidade (opcional) (string)
* **terceiro:** Informar o id ou documento do cliente (obrigatório) (objeto complexo)
    * **id:**  id do [cliente](https://github.com/Varejonline/api/wiki/GET-terceiros) (long)
    * **documento:** documento do [cliente](https://github.com/Varejonline/api/wiki/GET-terceiros) (string)
* **plano:** (Informar o id e/ou descrição do plano) (Esta propriedade será ignorada caso sejam informados pagamentos) 
  * **id** do [plano de pagamento](https://github.com/Varejonline/api/wiki/GET%20planos-pagamento) utilizado (long).
  * **descricao** do [plano de pagamento](https://github.com/Varejonline/api/wiki/GET%20planos-pagamento) utilizado (string).
* **representante:** (Informar o id e/ou nome do vendedor)
  * **id** do [vendedor](https://github.com/Varejonline/api/wiki/GET-representantes) utilizado (long)
  * **nome** do [vendedor](https://github.com/Varejonline/api/wiki/GET-representantes) utilizado (string)
* **valorDesconto:** valor do desconto aplicado no total do pedido (decimal)
* **descontoDetalhes:** lista de detalhes do desconto, contendo:
  * **observacao:** observação do desconto (string)
  * **valor:** valor do desconto (decimal)
  * **origemDesconto:** [origem](https://github.com/Varejonline/api/wiki/Origens-de-detalhe-de-Desconto) do desconto 
* **observacao:** observações do pedido (string) (opcional)
* **valorFrete:** valor de frete do pedido (decimal)
* **valorOutros:** valor de outros do pedido (decimal)
* **valorSeguro:** valor de seguro do pedido (decimal)
* **vendaConsumidorFinal:** indica se a venda é para consumidor final. Se não informado, será considerado true. (boolean) (opcional)
* **itens:** lista de itens do pedido, contendo:
  * **produto:** (obrigatório se existir itens. Informar um dos critérios para busca do produto. Utiliza-se o primeiro critério da ordem)
       * **id:** id do [produto](https://github.com/Varejonline/api/wiki/GET-Produtos) (long)
       * **codigoSistema:** código de sistema do produto. (string)
       * **codigoInterno:** código interno do produto. (string)
       * **codigoBarras:** código de barras do produto. (string)
  * **quantidade:** quantidade do item (decimal)
  * **valorDesconto:** valor de desconto do item (decimal)
  * **valesPresentes:** lista de vales presentes contendo:
    * **numeroValePresente:** número do vale presente (string)
    * **emailValePresente:** email do vale presente (string)
    * **formatoValePresente:** formato do vale presente (string) (FISICO, DIGITAL, AMBOS)
    * **nomePresenteado:** nome do presenteado (string)
    * **usoValePresente:** uso do vale presente (string) (PROPRIO, PRESENTE)
  * **descontoDetalhes:** lista de detalhes do desconto, contendo:
    * **observacao:** observação do desconto (string)
    * **valor:** valor do desconto (decimal)
    * **origemDesconto:** [origem](https://github.com/Varejonline/api/wiki/Origens-de-detalhe-de-Desconto) do desconto 
  * **valorUnitario:** valor unitário do item antes de ser aplicado desconto (decimal)
  * **operacao:** id da [operação](https://github.com/Varejonline/api/wiki/Tipo-de-operação-em-itens-movimentados) utilizada para o item (long)
  * **reservarEstoque:** indica se deverá ser criada uma reserva de estoque para o item (boolean opcional - Apenas para operação de simples faturamento).
  * **dataEntrega:** indica a data em que será entregue o item ao cliente (Opcional - Apenas para operação de simples faturamento, formato dd-MM-yyyy)
  * **numerosValesPresentes:** lista de string separada por virgula contendo os números de vales presentes do item
  * **amostraGratis:** determina se o item é amostra grátis (boolean opcional, padrão: false)
* **servicos:** lista de serviços do pedido, contendo:
  * **servico:** Informar um dos critérios para busca do serviço. Utiliza-se o primeiro critério da ordem
       * **id:** id do [produto](https://github.com/Varejonline/api/wiki/GET-Servicos) (long)
       * **codigoSistema:** código de sistema do serviço (string)
       * **codigoInterno:** código interno do serviço (string)
  * **quantidade:** quantidade do serviço (long)
  * **valorDesconto:** valor de desconto do serviço (decimal)
  * **descontoDetalhes:** lista de detalhes do desconto, contendo:
    * **observacao:** observação do desconto (string)
    * **valor:** valor do desconto (decimal)
    * **origemDesconto:** [origem](https://github.com/Varejonline/api/wiki/Origens-de-detalhe-de-Desconto) do desconto
  * **valorUnitario:** valor unitário do serviço antes de ser aplicado desconto (decimal)

* **emitirNotaFiscal:** indica se a emissão da nota será feita automaticamente (boolean opcional)
* **emitirNotaFiscalPresente:** indica se a emissão da nota de presente será feita automaticamente (boolean opcional, só funciona se emitirNotaFiscal também for true pois a nota de presente depende da nota de venda para referência)
* **enviarEmailNota:** indica se após autorização da nota, será enviado Email com Danfe e XML ao destinatário (boolean opcional) (se não informado irá seguir padrão configurado pelo cliente)
* **origem:** origem da venda (ECOMMERCE, MARKETPLACE, LOJA_FISICA) (string opcional)
* **tipo:** tipo da venda (NORMAL, SHIP_FROM_STORE, CLICK_COLLECT) (string opcional)
* **intermediador:** intermediador da venda (informar id ou documento) (opcional)
  * **id:** id do [intermediador](https://github.com/Varejonline/api/wiki/GET-terceiros) (Long)
  * **documento:** documento do intermediador (string)
* **transporte:** dados de transporte
  * **modalidade:** [Modalidade do transporte](/Varejonline/api/wiki/Modalidade-transporte) (enum)
  * **transportador:** (não pode ser informado na modalidade PROPRIO_DESTINATARIO. Obrigatório ID ou Documento para outras modalidades)
    * **id:** id do [transportador](https://github.com/Varejonline/api/wiki/GET-terceiros) (Long)
    * **documento:** documento do transportador (string)
  * **codigoANTT:** Código ANTT do transporte (string)
  * **placaVeiculo:** Placa do veiculo de transporte (string)
  * **estadoVeiculo:** Sigla do estado do veiculo de transporte (string)
  * **quantidade:** quantidade do volume transportado (long)
  * **especie:** espécie do volume transportado (string)
  * **marca:** marca do volume transportado (decimal)
  * **numero:** número do volume transportado (decimal)
  * **pesoBruto:** peso bruto transportado (decimal)
  * **pesoLiquido:** peso líquido transportado  (decimal)
* **enderecoEntrega:** dados do endereço de entrega
   * **logradouro:** nome do logradouro (string)
   * **numero:** número do endereço (string)
   * **bairro:** bairro do endereço (string)
   * **complemento:** complemento do endereço (string)
   * **cep:** CEP do endereço sem máscara (string)
   * **cidade:** Nome da cidade (string)
   * **uf:** Sigla do estado (string)
   * **receptorEntrega:** Nome da pessoa que receberá a entrega (string)
   * **receptorEntregaDocumento:** Documento da pessoa que receberá a entrega (string)
* **pagamento:** dados de pagamento
  * **valorDinheiro:** valor pago em dinheiro (decimal)
  * **cartoes:** lista de valores pagos em cartões
    * **valor:** valor da transação (decimal)
    * **autorizacao:** número de autorização da transação
    * **quantidadeParcelas:** quantidade de parcelas da transação
    * **nsu:** NSU da transação
    * **negociacao:** id da [negociacao](https://github.com/Varejonline/api/wiki/GET-negociacoes-cartao) (obrigatório se não informados algum dos seguintes campos: operadoraNome, bandeiraNome, tipo e parcelamento)
    * **operadoraNome:** [nome da operadora](https://github.com/Varejonline/api/wiki/Cartao-operadoras) de cartão (obrigatório se não informado o campo negociacao)
    * **bandeiraNome:** [nome da bandeira](https://github.com/Varejonline/api/wiki/Cartao-bandeiras) do cartão (obrigatório se não informado o campo negociacao)
    * **tipo:** tipo da bandeira do cartão (obrigatório se não informado o campo negociacao. Opções: CREDITO ou DEBITO)
    * **parcelamento:** tipo do parcelamento (SEM_PARCELAMENTO, PARCELAMENTO_LOJISTA, PARCELAMENTO_OPERADORA) (obrigatório se não informado o campo negociacao)
  * **cheques:** lista de cheques
    * **titular:** id do [titular](https://github.com/Varejonline/api/wiki/GET-terceiros) (long)
    * **banco:** Número do banco (long)
    * **agencia:** Número da agencia (string)
    * **conta:** Número da conta (long)
    * **numero:** Número do cheque (long)
    * **valor:** Valor do cheque (decimal)
    * **vencimento:** Data de vencimento do cheque (string dd-MM-yyyy)
  * **vales:** lista de vales trocas
    * **numero:** Número do vale(long)
    * **valor:** Valor utilizado do vale(decimal)
  * **adiantamentos:** lista de adiantamentos
    * **numero:** id do [adiantamento](https://github.com/Varejonline/api/wiki/GET-adiantamentos-recebidos) (long)
    * **valor:** Valor utilizado do adiantamento(decimal)
  * **crediario:** dados para geração de crediario
    * **plano:** id do [plano de pagamento](https://github.com/Varejonline/api/wiki/GET%20planos-pagamento) utilizado (long).
    * **valor:** Valor utilizado do adiantamento(decimal)
    * **valorAcrescimo:** Valor utilizado do adiantamento (decimal)
    * **parcelas:** lista de parcelas do plano
      * **numero:** Número sequencia da parcela do crediário (long)
      * **valor:** valor da parcela (decimal)
      * **vencimento:** data de vencimento da parcela (string dd-MM-yyyy)
      > Atenção: no caso de venda com crediario com entrada, o valor total do crediario deve ser igual ao valor total da venda e o valor da primeira parcela deve ser igual ou superior à somatória das outras formas de pagamento, os valores de pagamento contidos nos outros campos de pagamentos serão abatidos da primeira parcela do crediário.
  * **boletos:** dados para geração de crediario
    * **valor** valor da parcela (decimal)
    * **identificacao** identificação interna para obtenção do boleto posteriormente (string)(sugestão: utilizar cód. de barra)
    * **dataVencimento** data de vencimento do boleto (string dd-MM-yyyy)
    * **dataPagamento** data de pagamento do boleto (string dd-MM-yyyy)
    * **codigoConta** código da [conta](https://github.com/Varejonline/api/wiki/GET-contas-disponibilidade) na qual o boleto será vínculado (string)
  * **vouchers:** lista de vouchers
    * **voucher:** voucher
       * **id:** id do [voucher](https://github.com/Varejonline/api/wiki/GET-vouchers) (long)
    * **valor:** Valor utilizado do voucher (decimal)
  * **pixes:** lista de pix
    * **dataPagamento** data de pagamento do boleto (string dd-MM-yyyy)
    * **valor** valor da parcela (decimal)
    * **nsu:** NSU da transação (string)
    * **autorizacao:** autorização da transação (string)
* **urlEtiqueta:** url de impressão da etiqueta (string) (opcional)

### Retorno

Sucesso HTTP 201 CREATED:

Retorna um Json com informações do resultado da operação realizada, contendo:

* **idRecurso:** id do pedido gerado.
* **codigoMensagem:** Código de identificação da operação realizada. [veja a lista de Códigos](https://github.com/Varejonline/api/wiki/Retorno-API)
* **mensagem:** Mensagem da operação realizada

Requisição inválida: 
* HTTP STATUS 400 – BAD REQUEST
* Body: mensagem de erro

### Exemplo

> POST https://integrador.varejonline.com.br/apps/api/pedidos

'Content-Type'='application/json'
```javascript
{
    "data": "04-09-2012",
    "horario": "15:28:05",
    "entidade": {
       "id": 1,
       "documento": "00.000.000/0000-00"
    },
    "terceiro": {
       "id": 1,
       "documento": "000.000.000-00"
    },
    "valorDesconto": 50,
    "descontoDetalhes": [
     {
       "observacao": "API-Produto",
       "valor": 50,
       "origemDesconto": "MANUAL"
      }
    ],
    "representante": {
        "nome": "NOME DO VENDEDOR",
        "id": 1
    },
    "plano": {
        "descricao": "CREDIÁRIO 1X",
        "id": 12
    },
    "observacao": "Novo pedido",
    "valorFrete": 23.80,
    "valorOutros": 10,
    "valorSeguro": 1.50,
    "vendaConsumidorFinal": true,
    "itens": [
        {
            "produto": {
                "id": 245
            },
            "quantidade": 1,
            "valorUnitario": 10.90,
            "valorDesconto": 0.90,
            "descontoDetalhes": [
               {
                  "observacao": "API-Produto",
                  "valor": 50,
                  "origemDesconto": "MANUAL"
               }
            ],
            "dataEntrega": "30-06-2020",
            "operacao": 1093,
            "reservarEstoque": true
        },
        {
            "produto": {
                "codigoSistema": "0001.0002"
            },
            "quantidade": 3,
            "valorUnitario": 34.05,
            "valorDesconto": 0,
            "operacao": 1
        }
    ],
    "servicos": [
        {
            "servico": {
                "codigoSistema": "00010002"
            },
            "quantidade": 10,
            "valorUnitario": 11.50,
            "valorDesconto": 0.10
        }
    ],
    "emitirNotaFiscal": false,
    "origem": "MARKETPLACE",
    "tipo": "NORMAL",
    "pagamento": {
        "valorDinheiro": 450,
        "cartoes": [
            {
                "operadoraNome": "STONE",
                "bandeiraNome": "ELO",
                "nsu": "12321321",
                "autorizacao": "1232321",
                "dataHora": "01-01-2022 08:50:50",
                "tipo": "CREDITO",
                "quantidadeParcelas": 2,
                "valor": 45.3,
                "parcelamento": "PARCELAMENTO_LOJISTA"
            },
            {
                "negociacao": 33,
                "nsu": "12321321",
                "autoriacao": "1232321",
                "dataHora": "01-01-2022 08:50:50",
                "quantidadeParcelas": 2,
                "valor": 49.3
            }
        ],
        "cheques": [
            {
                "titular": 2,
                "banco": "1",
                "agencia": "2",
                "conta": "313",
                "numero": "635",
                "valor": "48.3",
                "vencimento": "01-01-2022"
            }
        ],
        "vales": [
            {
                "numero": "29-2010",
                "valor": 2
            }
        ],
        "adiantamentos": [
            {
                "id": 131,
                "valor": 10
            }
        ],
        "crediario": {
            "plano": 103,
            "valor": 20,
            "valorAcrescimo": 0,
            "parcelas": [
                {
                    "numero": 1,
                    "valor": 28.3,
                    "vencimento": "18-01-2022"
                },
                {
                    "numero": 2,
                    "valor": 20,
                    "vencimento": "24-01-2022"
                }
            ]
        },
        "boletos": [
            {
                "valor": 48.3,
                "identificacao": "XPTO",
                "dataVencimento": "07-02-2022 08:50:50",
                "dataPagamento": "07-02-2022 08:50:50",
                "codigoConta": "1138-40"
            }
        ],
	"vouchers": [
	   {
		"voucher": {
		   "id": 1001
		},
		"valor": 10
	   },
	   {
		"voucher": {
		   "id": 1002
		},
		"valor": 14
	   }
	],
        "pixes": [
            {
                "valor": 1,
                "dataPagamento": "07-02-2022 08:50:50",
                "nsu": "15000000",
                "autorizacao": "111111"

            }
        ]
    },
    "cnpj": "",
    "enderecoEntrega": {
        "logradouro": "Rua iririu",
        "numero": "1777",
        "complemento": "Em cima do bradesco",
        "bairro": "Iririu",
        "cep": "89227-000",
        "cidade": "Joinville",
        "uf": "SC",
        "receptorEntrega": "Maria",
        "receptorEntregaDocumento": "000.000.000-00"
    },
    "intermediador": {
        "id": 1
    },
    "transporte": {
        "modalidade": "EMITENTE",
        "transportador": {
            "id": 1
        },
        "codigoANTT": "ABC1777",
        "placaVeiculo": "AFE8B87",
        "estadoVeiculo": "SC",
        "quantidade": "2",
        "especie": "CAIXA",
        "marca": "ASD",
        "numero": "23",
        "pesoBruto": 50,
        "pesoLiquido": 40
    }
}