Negociações de Cartão são qualquer negociação feita com a operadora de cartão cadastradas no sistema.

### URLs

> GET https://integrador.varejonline.com.br/apps/api/negociacoes-cartao

> GET https://integrador.varejonline.com.br/apps/api/negociacoes-cartao/:id

### Parâmetros

* **inicio:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **quantidade:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **tipoCartao:** tipo de cartão desejado, podendo assumir valores entre CREDITO,DEBITO ou OUTROS.
* **bandeiraCartao:** [bandeira](https://github.com/Varejonline/api/wiki/Bandeiras-de-Cartão) desejada.
* **alteradoApos:** [Entenda a Coleta de Alterações](https://github.com/Varejonline/api/wiki/Filtro-de-Data-Alteração)

### Retorno

* **id**: id da negociação do cartão (long)
* **ativo:** indica se a negociação do cartão está ativo ou não (boolean)
* **dataAlteração:** última data de alteração da negociação do cartão, no formato dd-mm-aaaa hh:mi:ss 
* **descricao:** descrição da negociação do cartão (string)
* **operadora:** nome da [operadora](https://github.com/Varejonline/api/wiki/Operadoras-de-Cartão) de cartão associado a negociação de cartão (string)
* **bandeira:** nome da [bandeira](https://github.com/Varejonline/api/wiki/Bandeiras-de-Cartão) do cartão associado a negociação de cartão (string)
* **tipoCartao:** tipo do cartão cadastrado na negociação de cartão (string). Os valores disponíveis são: CREDITO, DEBITO, OUTROS.
* **terceiro:** [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros) a negociação do cartão  (objeto complexo)
    * **id:**  id do terceiro (long)
    * **nome:** nome do terceiro (string)
    * **documento:** documento do terceiro (string)
* **entidades:** ids das [entidades](https://github.com/Varejonline/api/wiki/GET-entidades) da negociação do cartão (array)
* **vigencias:** lista as vigências cadastrados na negociação do cartão
    * **dataVigencia:** data de vigência da negociação do cartão, no formato dd-mm-aaaa hh:mi:ss 
    * **tarifaOperacao:** valor tarifa operacional da vigência (decimal)
    * **prazoRecebimento:** prazo de recebimento da vigência (string), recebendo os valores "FIXO" ou "VARIAVEL"
    * **tipoPrazoRecebimento:** tipo do prazo de recebimento da vigência (string)
    * **codeContaBancaria:** [conta disponibilidade](https://github.com/Varejonline/api/wiki/GET-contas-disponibilidade) onde ocorre o depósito da operadora
    * **listaTaxas:** lista as taxas da negociação do cartão referentes ao número de parcelas
        * **taxa:** taxa da negociação do cartão para determinado número de parcelas (decimal)
        * **numeroMinimoParcelas:** número mínimo de parcelas da negociação do cartão para esta taxa (long)
        * **numeroMaximoParcelas:** número máximo de parcelas da negociação do cartão para esta taxa (long)

### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/negociacoes-cartao?tipoCartao=DEBITO

```javascript
[
   {
      "id":7,
      "ativo":true,
      "dataAlteracao":"12-05-2010 12:05:56",
      "descricao":"VISA DEBITO",
      "operadora":"CIELO",
      "bandeira":"VISA",
      "tipoCartao":"DEBITO",
      "vigencias":[
         {
            "dataVigencia":"01-01-2012 08:50:00",
            "tarifaOperacao":0,
            "prazoRecebimento":2,
            "tipoPrazoRecebimento":"VARIAVEL",
            "codeContaBancaria": "935-2",
            "listaTaxas":[
               {
                  "taxa":1.8,
                  "numeroMaximoParcelas":12,
                  "numeroMinimoParcelas":1
               }
            ]
         }
      ],
      "entidades":[1,2,5,10],
      "terceiro": {
          "id": 1,
          "nome": "DIVERSOS",
          "documento": "000.000.000-00"
      }
   },
   {
      "id":6,
      "ativo":true,
      "dataAlteracao":"12-04-2010 11:45:20",
      "descricao":"MASTER DEBITO",
      "operadora":"CIELO",
      "bandeira":"MASTERCARD",
      "tipoCartao":"DEBITO",
      "vigencias":[
         {
            "dataVigencia":"01-09-2013 10:00:00",
            "tarifaOperacao":1.5,
            "prazoRecebimento":10,
            "tipoPrazoRecebimento":"FIXO",
            "codeContaBancaria": "935-2",
            "listaTaxas":[
               {
                  "taxa":2.5,
                  "numeroMaximoParcelas":3,
                  "numeroMinimoParcelas":1
               },
               {
                  "taxa":3.5,
                  "numeroMaximoParcelas":10,
                  "numeroMinimoParcelas":4
               }
            ]
         }
      ],
      "entidades":[1,3],
      "terceiro": {
          "id": 1,
          "nome": "DIVERSOS",
          "documento": "000.000.000-00"
      }
   }
]
```