Endpoint para coleta de contas contábeis.

### URLs

> GET https://integrador.varejonline.com.br/apps/api/conta-contabil/:acesso

Informar o número do acesso da conta desejada.

### Parâmetros

* **acessoSubConta:** Obter a conta específica associada ao número da sub conta (long).

### Retorno

* **id**: id da conta contábil (long)
* **nome:** nome da conta contábil (string)
* **classificador:** classificador completo da conta (string)
* **acesso:** número de acesso da conta contábil (string)
* **natureza:** natureza da conta contábil (string "CREDITO" ou "DEBITO")
* **tipoConta:** ANALITICA, SINTETICA, SUBCONTA (string)
* **contaAcessoExterna:** número de acesso da conta externa (string)

### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/conta-contabil/13802

```javascript
{
    "id": 721,
    "nome": "13802 CRÉDITOS C/C ENTIDADES",
    "acesso": "13802",
    "natureza": "CREDITO",
    "tipoConta": "SINTETICA",
    "classificador": "1.01.20.80.02.00.00",
    "contaAcessoExterna" "99-55"
}
```