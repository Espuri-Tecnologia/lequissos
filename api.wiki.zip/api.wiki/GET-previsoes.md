### URL

> GET https://integrador.varejonline.com.br/apps/api/previsoes

### Parâmetros

* **entidades:** [Veja como Funciona este Filtro](https://github.com/Varejonline/api/wiki/Filtro-de-Entidades)
* **desde:** [Veja o Filtro de Datas](https://github.com/Varejonline/api/wiki/Filtro-de-Datas)
* **ate:** [Veja o Filtro de Datas](https://github.com/Varejonline/api/wiki/Filtro-de-Datas)

### Retorno

* **entidade:** [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) à qual a previsão pertence  (objeto complexo)
    * **id:** id da entidade (long)
    * **nome:** nome da entidade (string)
    * **documento:** documento da entidade (string)
* **terceiro:** [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros) relacionado à previsão  (objeto complexo)
    * **id:**  id do terceiro (long)
    * **nome:** nome do terceiro (string)
    * **documento:** documento do terceiro (string)
* **valor:** valor da previsão (decimal)
* **data:** data da previsão (string)
* **tipoDocumento:** tipo de documento da previsão (string)
* **realizada:** indica se esta previsão foi realizada (boolean)
* **tipoOperacao:** indica se a operação é de "PAGAMENTO" ou "RECEBIMENTO"  (string)
* **contaContabilPrevisao:** conta contábil utilizada na previsão (string)
* **classificacoesContabeis:** classificações contábeis que indicam como a conta está distribuida.
   * **contaContabil:** conta contábil onde foi realizado o lançado(string)
   * **porcentagemApropriada:** porcentagem a ser apropriado na conta contábil(string)

### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/previsoes?desde=01-01-2013&ate=30-04-2013

```javascript
[
   {
      "entidade": {
          "id": 3,
          "nome": "Entidade teste",
          "documento": "00.000.000/0000-00"
      },
      "terceiro": {
          "id": 1,
          "nome": "teste",
          "documento": "000.000.000-00"
      },
      "valor":4500.0,
      "data":"20-02-2013",
      "tipoDocumento":"NOTA FISCAL",
      "tipoOperacao":"PAGAMENTO",
      "realizada":false,
      "contaContabilPrevisao":"13102 - CONTAS A RECEBER DIVERSAS",
      "classificacoesContabeis":[
          {
              "contaContabil":"41201 - VENDAS DE PRODUTOS",
              "valorApropriado":100.0
          }
      ]
   }
]
```