Balanço de estoque é o aferimento da quantidade em estoque físico real com a quantidade demonstrada no inventário do Varejonline.

### URLs

> POST https://integrador.varejonline.com.br/apps/api/balancos-estoque

> ATENÇÃO: ENDPOINT OBSOLETO

### Parâmetros

* **id:** identificador do balanço de estoque (long)
* **contagens:** lista de produtos relacionados ao balanço de estoque, contendo:
    * **idProduto:** id do [produto](https://github.com/Varejonline/api/wiki/GET-Produtos) (long)
    * **quantidade:** quantidade da contagem de mercadorias realizadas (decimal)

### Retorno

Sucesso:
* HTTP STATUS 201 – CREATED
* Body: id do balanço gerado

Requisição inválida: 
* HTTP STATUS 400 – BAD REQUEST
* Body: mensagem de erro


### Exemplo

> POST https://integrador.varejonline.com.br/apps/api/balancos-estoque

```javascript
[
   {
      "id":1,
      "contagens":[
      {
          "idProduto":7,
          "quantidade":1000.00,
      },
      {
          "idProduto":8,
          "quantidade":100.00,
      }
     ]
   }
]

```