Endpoint para geração de provisões e parcelas a pagar ou receber.

A definição do tipo de provisão (pagar ou receber) é estabelecida pela configuração do lançamento padrão utilizado.
Caso seja informado um [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros) para a provisão, o [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros) do lançamento padrão será desconsiderado. Da mesma forma, caso sejam informadas parcelas ou tipo de documento para a provisão, será desconsiderada a configuração presente no lançamento padrão.

### URL

> POST https://integrador.varejonline.com.br/apps/api/provisoes-contas

### Parâmetros

Envie um JSON no corpo da requisição, contendo:
* **idLancamentoPadrao:** id do lançamento padrão em que esta provisão será baseada (long) _(obrigatório)_
* **tipoDocumento:** objeto com opções de identificadores para o [tipoDocumento](https://github.com/Varejonline/api/wiki/Tipos-de-Documentos-Financeiros) 
     * **id:** id do [tipoDocumento](https://github.com/Varejonline/api/wiki/Tipos-de-Documentos-Financeiros) (long)
     * **nome:** nome do [tipoDocumento](https://github.com/Varejonline/api/wiki/Tipos-de-Documentos-Financeiros) (string)
* **numeroDocumento:** número do documento da provisão. Obrigatório de acordo com o [tipoDocumento](https://github.com/Varejonline/api/wiki/Tipos-de-Documentos-Financeiros) informado (string)
* **entidade:** objeto da [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) para a qual esta provisão será feita _(obrigatório)_
     * **id:** id da [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) (long)
* **terceiro:** Objeto com opções de identificadores para o [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros) a quem se destina a provisão. Obrigatório caso não informado no lançamento padrão
     * **id:** id do [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros) (long)
     * **documento:** documento do [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros) com/sem formatação (string)
* **data:**  data da provisão 'dd-mm-aaaa' (string) _(obrigatório)_
* **valor:**  valor da provisão (decimal) _(obrigatório)_
* **historico:** Histórico de controle para os lançamentos contábeis (string)
* **parcelas:** definição das parcelas da provisão (Quando definido, não é usada a configuração do lançamento padrão)
     * **numero:** Número da parcela (long) _(obrigatório)_
     * **valor:** Valor da parcela (decimal) _(obrigatório)_
     * **dataVencimento:** Data de vencimento da parcela 'dd-mm-aaaa' (string) _(obrigatório)_


### Retorno

Sucesso:
* HTTP STATUS 201 – CREATED
* Body: id da provisão gerada

Requisição inválida: 
* HTTP STATUS 400 – BAD REQUEST
* Body: mensagem de erro

### Exemplo

> POST https://integrador.varejonline.com.br/apps/api/provisoes-contas

'Content-Type'='application/json'

```javascript
{
    "data": "03-04-2017",
    "idLancamentoPadrao": 1009,
    "numeroDocumento": "111-1",
    "valor" : 20.0,
    "tipoDocumento" :{
        "id": "20",
        "nome": "BOLETO"
    },
    "entidade" :{
        "id": "1"
    },
     "terceiro" :{
        "id": "1",
        "documento": "99999999999"
    },
    "historico" : "Criacao de Provisao a Pagar com parcelas definidas",
    "parcelas" : [
        {
            "numero" : 1,
            "valor" : 10.00,
            "dataVencimento" : "03/05/2017"
        },
        {
            "numero" : 2,
            "valor" : 10.00,
            "dataVencimento" : "03/06/2017"
        }
    ]
}
```