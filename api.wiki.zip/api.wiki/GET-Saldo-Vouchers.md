### URLs

> GET https://integrador.varejonline.com.br/apps/api/vouchers/consultar

### Parâmetros

* **ids:** ids dos [vouchers](https://github.com/Varejonline/api/wiki/GET-Vouchers) (long) (obrigatório)


### Retorno

Sucesso HTTP 200 OK:

Retorna uma lista JSONs com informações do resultado da operação realizada, contendo:
* **id:** id do [voucher](https://github.com/Varejonline/api/wiki/GET-Vouchers) (long)
* **valorDisponivel:** valor disponível para consumo do voucher (long)
* **observacao:** observação do voucher (long)
* **valorUtilizadoCliente:** valor consumido do voucher (float)
* **podeConsumir:** indica se o voucher aind apode ser consumido (booleano)
* **historicoUtilizacao:** histórico de consumos do voucher
  * **data:** data da utilização
  * **valor:** valor do item (produto ou serviço) que consumiu o voucher
  * **nomeItem:** nome do item (produto ou serviço) que consumiu o voucher
  * **codigoItem:** código do item (produto ou serviço) que consumiu o voucher
  * **quantidade:** quantidade do item (produto ou serviço) que consumiu o voucher
  * **loja:** nome da entidade

Requisição inválida: 
* HTTP STATUS 400 – BAD REQUEST
* Body: mensagem de erro

### Exemplos

> GET https://integrador.varejonline.com.br/apps/api/vouchers/consultar?ids=41,42

```[
  {
    "id": 41,
    "valorDisponivel": 0,
    "observacao": "Voucher sem saldo disponível",
    "valorUtilizadoCliente": 500,
    "podeConsumir": false,
    "historicoUtilizacao": [
      {
        "data": "18-09-2024 09:01:10",
        "valor": 500,
        "nomeItem": "CAMISETA AZUL LOLI",
        "codigoItem": "POIUY.LO",
        "quantidade": 1,
        "loja": "Calçadão"
      }
    ]
  }
]
```