### URLs

> GET https://integrador.varejonline.com.br/apps/api/categorias-produto

> GET https://integrador.varejonline.com.br/apps/api/categorias-produto/:id

### Parâmetros

* **inicio:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **quantidade:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **alteradoApos:** [Entenda a Coleta de Alterações](https://github.com/Varejonline/api/wiki/Filtro-de-Data-Alteração)
* **nomeCategoria:** Busca de uma categoria específica a partir do nome da categoria (String)
* **nomeNivel:** Busca de uma categoria específica a partir nome do nível da categoria buscada (String)


### Retorno

* **id:** id da categoria de produto (Long)
* **ativo:** indica se a categoria de produto está ativa ou não (boolean)
* **dataAlteracao:** última data de alteração da categoria de produto, no formato dd-mm-aaaa hh:mm:ss (String)
* **nome:** nome da categoria de produto (String)
* **origem:** número de 0 a 7 que representa a origem do produto segundo a receita federal (Long) [veja a lista de Origens] (Origens)
* **unidade:** sigla da unidade de venda sugerida aos produtos associados com a categoria (String)
* **metodoControle:** método de controle de estoque do produto, podendo assumir um dos seguintes valores: ESTOCAVEL, LOTE, SERIE, NAO_ESTOCAVEL (String)
* **classificacao:** classificacao da categoria a ser sugerida a seus produtos, que indica a finalidade para a qual o produto será utilizado. Pode assumir um dos seguintes valores: PRODUCAO_PROPRIA, REVENDA, ATIVO_IMOBILIZADO, CONSUMO, SERVICO_ISS, SERVICO_ICMS, INSUMO (String)
* **nivel:** número no nível da categoria de produto (Long)

### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/categorias-produto

```javascript
[
   {
      "id":1,
      "nome":"CALÇADOS",
      "origem":0,
      "metodoControle":"ESTOCAVEL",
      "classificacao":"REVENDA",
      "unidade":"UN",
      "ativo": true,
      "dataAlteracao": "31-07-2013 11:13:04",
      "nivel": 1
   },
   {
      "id":2,
      "nome":"SANDÁLIAS",
      "origem":0,
      "metodoControle":"ESTOCAVEL",
      "classificacao":"REVENDA",
      "unidade":"UN",
      "ativo": true,
      "dataAlteracao": "31-07-2011 10:10:00",
      "nivel": 2
   },
   {
      "id":3,
      "nome":"TÊNIS",
      "origem":0,
      "metodoControle":"ESTOCAVEL",
      "classificacao":"REVENDA",
      "unidade":"UN",
      "ativo": false,
      "dataAlteracao": "01-01-2013 02:55:14",
      "nivel": 2
   },
   {
      "id":4,
      "nome":"NIKE",
      "origem":1,
      "metodoControle":"LOTE",
      "classificacao":"REVENDA",
      "unidade":"UN",
      "ativo": true,
      "dataAlteracao": "01-01-2013 02:55:13",
      "nivel": 3
   },
   {
      "id":5,
      "nome":"MERCEARIA",
      "origem":0,
      "metodoControle":"ESTOCAVEL",
      "classificacao":"REVENDA",
      "unidade":"UN",
      "ativo": true,
      "dataAlteracao": "01-01-2011 01:01:15",
      "nivel": 1
   }
]
```