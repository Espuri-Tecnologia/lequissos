O Varejonline suporta operações com cartão de crédito realizadas com diversos tipos de operadoras. Os tipos disponíveis podem ser identificados nos endpoints da API por meio dos seguintes valores:

* VERO
* CONDUCTOR
* CIELO
* REDECARD
* AMEX
* GETNET
* ELAVON
* PAYPAL
* SERVILOJA
* SENFF
* PAGSEGURO
* ALEGRIA
* CREDSYSTEM
* STONE
* GETNETLAC
* SANTANDER
* MULTIPLUS
* VOUCHER TRIP
* SAFRAPAY
* GLOBAL PAYMENTS
* BANRISUL
* BANESE
* SIPAG
* CALCARD
* BIN