Esta API traz informações sobre o usuário logado e sobre a empresa, cliente da Varejonline, na qual ele logou.

### URL

> GET https://integrador.varejonline.com.br/apps/api/dados-login

### Retorno

* **usuario:** 
   * **id:** id do usuário (long)
   * **login:** login do usuário (string)
   * **nome:** nome do usuário (string)
   * **admin:** indica se o usuário é o adminstrador da empresa (boolean)
   * **idTerceiro:** id do [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros) relacionado ao usuário (long)
   * **idRepresentante:** id do [vendedor](https://github.com/Varejonline/api/wiki/GET-representantes), informado apenas se o usuário logado for um [vendedor](https://github.com/Varejonline/api/wiki/GET-representantes) (long)
* **empresa:** 
   * **cnpj:** CNPJ da empresa em que o usuário logou (string)
   * **nomeFantasia:** nome fantasia da empresa em que o usuário logou (string)

### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/dados-login

```javascript
{
   "usuario":{
      "id":1,
      "login":"admin",
      "nome":"Administrador dos Santos",
      "admin":true,
      "idTerceiro":25,
      "idRepresentante":38
   },
   "empresa":{
      "cnpj":"69000888000144",
      "nomeFantasia":"Lojas XYZ"
   }
}
```