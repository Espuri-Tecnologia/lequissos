Estas são as contas de consumo, como, por exemplo, contas de água, energia elétrica e gás. 

### URLs

> GET https://integrador.varejonline.com.br/apps/api/notas-consumo

> GET https://integrador.varejonline.com.br/apps/api/notas-consumo/:id

### Parâmetros

* **inicio:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **quantidade:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)

### Retorno

* **id:** id da nota (long)
* **tipo:** tipo da nota (string). Os valores possíveis são: ENTRADA e SAIDA
* **modelo:** [Modelo](https://github.com/Varejonline/api/wiki/Tipo-de-Documentos-Fiscais) da nota fiscal.
* **serie:** número de série associado com o documento de nota de consumo. (string)
* **numeroNotaConsumo:** número do documento de nota de consumo. (string)
* **data:** data de emissão da conta (string)
* **entidade:** [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) da nota (objeto complexo)
    * **id:** id da entidade (long)
    * **nome:** nome da entidade (string)
    * **documento:** documento da entidade (string)
* **remetente:** [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros) remetente da nota (objeto complexo)
    * **id:**  id do remetente (long)
    * **nome:** nome do remetente (string)
    * **documento:** documento do remetente (string)
* **destinatario:** [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros) destinatário da nota (objeto complexo)
    * **id:**  id do destinatário (long)
    * **nome:** nome do destinatário (string)
    * **documento:** documento do destinatário (string)
* **status:** status da nota (string). [veja os valores de status de documentos  fiscais] (Status-Documentos-Fiscais)
* **cfop:** código CFOP da operação (integer)
* **valorTotal:** valor total da nota (decimal)
* **valorDesconto:** valor do desconto da nota (decimal)
* **icms:** dados do ICMS aplicado à nota (segue a estrutura comum abaixo)
* **cofins:** dados do COFINS aplicado à nota (segue a estrutura comum abaixo)
* **pis:** dados do PIS aplicado à nota (segue a estrutura comum abaixo)

Estrutura comum para tributos:
   * **base:** valor da base de cálculo do tributo (decimal)
   * **aliquota:** valor da alíquota aplicada (decimal)
   * **valor:** valor do tributo (decimal)
   * **cst:** código de situação tributária (string)

### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/notas-consumo

```javascript
[
   {
      "id":757,
      "tipo":"ENTRADA",
      "modelo":"ENERGIA_ELETRICA",
      "serie":"100",
      "numeroNotaConsumo":9999,
      "data":"19-06-2012",
      "remetente": {
          "id": 6,
          "nome": "remetente",
          "documento": "00.000.000/0000-00"
      },
      "destinatario": {
          "id": 9,
          "nome": "destinatario",
          "documento": "000.000.000-00"
      },
      "entidade": {
          "id": 2,
          "nome": "Entidade teste",
          "documento": "00.000.000/0000-00"
      },
      "cfop":2503,
      "valorTotal":1000,
      "valorDesconto":0,
      "icms":{
         "base":990,
         "aliquota":18,
         "valor":178.2,
         "cst":"20"
      },
      "cofins":{
         "base":1000,
         "aliquota":0,
         "valor":0,
         "cst":"06"
      },
      "pis":{
         "base":1000,
         "aliquota":0,
         "valor":0,
         "cst":"06"
      }
   },
   {
      "id":424,
      "tipo":"ENTRADA",
      "modelo":"COMUNICACAO",
      "serie":"100",
      "numeroNotaConsumo":9998,
      "remetente": {
          "id": 6,
          "nome": "remetente",
          "documento": "00.000.000/0000-00"
      },
      "destinatario": {
          "id": 9,
          "nome": "destinatario",
          "documento": "000.000.000-00"
      },
      "entidade": {
          "id": 2,
          "nome": "Entidade teste",
          "documento": "00.000.000/0000-00"
      },
      "cfop":2303,
      "valorTotal":5000,
      "valorDesconto":0,
      "icms":{
         "base":0,
         "aliquota":0,
         "valor":0,
         "cst":null
      },
      "cofins":{
         "base":1600,
         "aliquota":7.6,
         "valor":121.6,
         "cst":"02"
      },
      "pis":{
         "base":1600,
         "aliquota":1.56,
         "valor":24.96,
         "cst":"01"
      }
   }
]
```