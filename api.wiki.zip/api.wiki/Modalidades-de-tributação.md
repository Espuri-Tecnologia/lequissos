Listagem das possíveis modalidades de tributação

* Lucro Presumido
* Simples Nacional
* Lucro Real
* Isento e Não Tributado
* Pessoa Física
* Lucro Arbitrado
* Imune