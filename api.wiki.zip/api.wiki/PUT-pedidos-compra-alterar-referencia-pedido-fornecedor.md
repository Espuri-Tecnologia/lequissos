### URL

> PUT https://integrador.varejonline.com.br/apps/api/pedidos-compra/:id/alterar-observacao

### Parâmetros

Envie um JSON no corpo da requisição, contendo:

* **referenciaPedidoFornecedor:** número da referência do pedido no fornecedor (string) (max. 50 chars)

### Exemplo

> PUT https://integrador.varejonline.com.br/apps/api/pedidos-compra/100/alterar-referencia-pedido-fornecedor

'Content-Type'='application/json'
```javascript
{
   "referenciaPedidoFornecedor":"REF-123"
}
```
