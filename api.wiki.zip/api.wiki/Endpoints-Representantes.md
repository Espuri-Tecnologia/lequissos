## [GET representantes](/Varejonline/api/wiki/GET-Representantes)
## [POST representantes](/Varejonline/api/wiki/POST-Representantes)
## [PUT representantes](/Varejonline/api/wiki/PUT-Representantes)
## [DELETE representantes](/Varejonline/api/wiki/DELETE-Representantes)

