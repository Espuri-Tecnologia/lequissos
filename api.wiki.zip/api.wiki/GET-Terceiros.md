### Descrição

Terceiros são quaisquer pessoas físicas ou jurídicas cadastradas no sistema. Estão neste grupo os clientes, funcionários, fornecedores e todas pessoas com as quais a empresa tem relação.

### URLs

> GET https://integrador.varejonline.com.br/apps/api/terceiros

> GET https://integrador.varejonline.com.br/apps/api/terceiros/:id

### Parâmetros

* **inicio:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **quantidade:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **status:** filtra pelo status do terceiro (enum: ATIVO, INATIVO, EXCLUIDO), separados por vírgula
* **classes:** lista de [classes](https://github.com/Varejonline/api/wiki/Classes-de-Terceiro) de terceiro desejadas, separadas por vírgula.
* **desde:** filta por registros criados/alterados desde uma data específica (String no formato dd/mm/yyyy ou dd/mm/yyyy hh:mm:ss)
* **ate:**  filta por registros criados/alterados até uma data específica (string no formato dd/mm/yyyy ou dd/mm/yyyy hh:mm:ss)
* **filtroData:** pode ser informado para ser combinado com o filtro desde-ate. Aceita-se "dataAlteracao" ou "dataCriacao" _(padrão: dataAlteracao)_
* **alteradoApos:** [Entenda a Coleta de Alterações](https://github.com/Varejonline/api/wiki/Filtro-de-Data-Alteração)
* **documento:** [Veja este Filtro](https://github.com/Varejonline/api/wiki/Filtro-documento)
* **nome:** filtra pelo nome do terceiro (string)
* **orderBy:** Tipo da ordenação de resultados desejada (string)
  * **id**  ordenação crescente pelo id dos registros (Valor padrão caso não informado)
  * **dataAlteracao** ordenação crescente pela data de alteração dos registros
  * **dataCriacao** ordenação crescente pela data de criação dos registros
  * **documentoTerceiro** ordenação crescente pelo documento CPF ou CNPJ do terceiro
  * **nome** ordenação crescente pelo nome do terceiro
* **[integrados](https://github.com/Varejonline/api/wiki/Controle-de-registros-integrados):** Filtro de controle de integração de registros (boolean)
  * **1** retorna apenas registros já marcados como coletados pelo integrador
  * **0** retorna apenas registros não marcados como coletados pelo integrador
* **[integrador](https://github.com/Varejonline/api/wiki/Controle-de-registros-integrados):** Nome utilizado pelo integrador para registrar o registro como integrado (String)
* **carregarCamposCustomizados:** indica se os campos customizados devem ser exibidos no retorno (boolean)

### Retorno

* **id**: id do terceiro (long)
* **ativo:** indica se o terceiro está ativo ou não (boolean)
* **excluido:** indica se o terceiro foi excluído (boolean)
* **dataAlteracao:** última data de alteração do terceiro (string) (dd-mm-aaaa hh:mi:ss)
* **nome:** nome do terceiro Pessoa Física ou Razão Social da Pessoa Jurídica (string) _(max 255 char)_
* **nomeFantasia:** nome fantasia do terceiro. Retornado apenas para terceiros Pessoa Jurídica (string) _(max 255 char)_
* **padraoNome:** indica qual é o campo de nome usando na apresentação do cliente em tela. Opções: "NOME_FANTASIA" ou "RAZAO_SOCIAL" (string)
* **documento:** cpf ou cnpj do terceiro formatado (string) _(max 255 char)_
* **entidadeCadastro:** [Entidade](https://github.com/Varejonline/api/wiki/GET-entidades) na qual o terceiro foi cadastrado (long)
* **emails:** emails do terceiro (List string) _(max 255 char)_
* **rg:** número do RG do terceiro. Retornado apenas para terceiros Pessoa Física, se existir (string) _(max 50 char)_
* **tipoPessoa:** Define se a Pessoa é Física (PF), Jurídica (PJ), Física Estrangeiro (PF_ESTRANGEIRO) ou Jurídica Estrangeiro (PJ_ESTRANGEIRO)
* **dataNascimento:** data de nascimento do terceiro. Retornado apenas para terceiros Pessoa Fisica, no formato dd-mm-aaaa hh:mi:ss.
* **ie:** número da Inscrição Estadual do terceiro. Retornado apenas para terceiros Pessoa Jurídica, se existir (string) _(max 255 char)_
* **inscricaoMunicipal:** número da inscrição municipal do terceiro. Retornado apenas para terceiros Pessoa Jurídica, se existir (string) _(max 255 char)_
* **modalidadeTributacao:** indica qual é a [modalidade de tributação](https://github.com/Varejonline/api/wiki/Modalidades-de-tributa%C3%A7%C3%A3o) do terceiro, aplicado apenas para Pessoa Jurídica, se existir (string)
* **enderecos:** lista de endereços do terceiro, contendo:
  * **tipo:** tipo do logradouro (string). Exemplos: RUA, AVENIDA, RODOVIA. [Veja a lista completa](Tipos-de-Logradouro)
  * **logradouro:** logradouro do endereço (string) _(max 255 char)_
  * **numero:** número do endereço (string) _(max 400 char)_
  * **complemento:** complemento do endereço (string) _(max 255 char)_
  * **bairro:** bairro do endereço (string) _(max 255 char)_
  * **cep:** CEP do endereço (string)
  * **cidade:** cidade do endereço (string) _(max 255 char)_
  * **siglaEstado:** UF do endereço (string)
  * **pais:** [País do Endereço](https://github.com/Varejonline/api/wiki/Paises) (string).
  * **tipoEndereco:** [Tipo do Endereço](https://github.com/Varejonline/api/wiki/Tipos-de-endereço) (string)
  * **codigoIBGECidade:** Código da cidade conforme tabela IBGE (Long).
* **telefones:** lista de telefones do terceiro, contendo:
  * **ddd:** Código do DDD (integer) _(max 10 char)_
  * **ddi:** Código do DDI (integer) _(max 10 char)_
  * **numero:** Número do telefone (string) _(max 255 char)_
  * **ramal:** Número do ramal (string) _(max 10 char)_
  * **tipoTelefone:** Opções: CELULAR, RESIDENCIAL, COMERCIAL, RECADO (string)
* **classes:** lista de [classes](https://github.com/Varejonline/api/wiki/Classes-de-Terceiro) às quais o terceiro pertence. 
* **categoria:** Define a categorização do terceiro no Varejonline (string)
* **autorizaReceberEmail:** Opt-in do terceiro autorizando ou não a comunicação por email (boolean)
* **autorizaReceberSms:** Opt-in do terceiro autorizando ou não a comunicação por sms (boolean)
* **autorizaReceberWhatsapp:** Opt-in do terceiro autorizando ou não a comunicação por whatsapp (boolean)
* **limiteCredito:** Define os valores de limite de crédito para o terceiro (objeto complexo).
  * **valorTotal:** limite de crédito total (long)
  * **valorMensal:** limite de crédito mensal (long)
  * **valorRenda:** valor da renda do terceiro (long)
* **camposCustomizados:** Define os valores da estrutura de [campos customizados](https://github.com/Varejonline/api/wiki/GET-Campos-Customizados) da base.
  * **id:** id do terceiro associado aos valores informados (long)
  * **valoresPrimitivo:** valores dos campos customizados [primitivos](https://github.com/Varejonline/api/wiki/Tipos-de-Campos-Customizados)
    * **id:** id do campo customizado (long)
    * **value:** valor do campo customizado (object - varia conforme tipagem do campo)
    * **type:** [tipo](https://github.com/Varejonline/api/wiki/Tipos-de-Campos-Customizados) do campo customizado (string)
  * **valoresComposicao:** valores dos campos customizados do [tipo](https://github.com/Varejonline/api/wiki/Tipos-de-Campos-Customizados) COMPOSICAO
    * **id:** id do campo customizado (long)
    * **valores:** lista de valores primitivos 
      * **id:** id do campo customizado (long)
      * **value:** valor do campo customizado (object - varia conforme tipagem do campo) _(max para string 255 BYTE)_
      * **type:** [tipo](https://github.com/Varejonline/api/wiki/Tipos-de-Campos-Customizados) do campo customizado (string)
  * **valoresLista:** valores dos campos customizados do [tipo](https://github.com/Varejonline/api/wiki/Tipos-de-Campos-Customizados) LISTA 
    * **campoId:** id do campo customizado retornado pela lista (long)
    * **valoresPrimitivo:** lista de valores primitivos 
      * **id:** id do campo customizado (long)
      * **value:** valor do campo customizado (object - varia conforme tipagem do campo) _(max para string 255 BYTE)_
      * **type:** [tipo](https://github.com/Varejonline/api/wiki/Tipos-de-Campos-Customizados) do campo customizado (string)
    * **valoresComposicao:** valores dos campos customizados do [tipo](https://github.com/Varejonline/api/wiki/Tipos-de-Campos-Customizados) COMPOSICAO
      * **id:** id do campo customizado (long)
      * **valores:** lista de valores primitivos 
        * **id:** id do campo customizado (long)
        * **value:** valor do campo customizado (object - varia conforme tipagem do campo) _(max para string 255 BYTE)_
        * **type:** [tipo](https://github.com/Varejonline/api/wiki/Tipos-de-Campos-Customizados) do campo customizado (string)
* **marcas:** lista de marcas do terceiro, contendo:
  * **autorizaReceberSms:** limite de crédito total (boolean)
  * **autorizaReceberEmail:** limite de crédito total (boolean)
  * **autorizaReceberWhatsapp:** limite de crédito total (boolean)
  * **marca:** informações da marca
    * **id:** id da marca (long)
    * **nome:** nome da marca (string) _(max 255 char)_
* **dependentes**: lista de dependentes do terceiro, contendo:
  * **observacao**: (string) _(max 255 byte)_
  * **nome**: (string)  _(max 100 byte)_
  * **documento**: documento formatado (string)
  * **parentesco**: (string)  _(max 100 byte)_
  * **dataNascimento**: (string) (dd-mm-aaaa hh:mm:ss)


### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/terceiros?classes=PRESTADOR_SERVICO,CLIENTE

```javascript
[
   {
      "id":1,
      "ativo":true,
      "excluido":false,
      "dataAlteracao":"21-01-2013 15:28:05",
      "nome":"Empresa Exemplo",
      "nomeFantasia":"Nome Fantasia da Empresa"
      "documento":"12.123.123/0001-12",
      "tipoPessoa":"PJ",
      "padraoNome": "RAZAO_SOCIAL",
      "entidadeCadastro":1,
      "emails":[
         "contato@empresaexemplo.com.br",
         "comercial@empresaexemplo.com.br"
      ],
      "ie":"493.656.191.721",
      "enderecos":[
         {
            "tipo":"AVENIDA",
            "logradouro":"Lineu de Moura",
            "numero":"900",
            "complemento":"Sala 45",
            "bairro":"Chácara Condomínio Eucaliptos",
            "cep":"32600134",
            "cidade":"São José dos Campos",
            "siglaEstado":"SP",
            "pais":"Brasil",
            "tipoEndereco":"ENDERECO_CORRESPONDENCIA",
            "codigoIBGECidade":"3554102"
         }
      ],
      "telefones":[
         {
            "ddd":12,
            "ddi":55,
            "numero":"99998888",
            "ramal":"1002",
            "tipoTelefone":"CELULAR"           
         }
      ],
      "classes":[
         "PRESTADOR_SERVICO"
      ],
      "categoria":"PADRÃO",
      "marcas": [
        {
            "autorizaReceberSms": false,
            "autorizaReceberEmail": false,
            "autorizaReceberWhatsapp": true,
            "marca": {
                "id": 283,
                "nome": "TESTE"
            }
        },
        {
            "autorizaReceberSms": true,
            "autorizaReceberEmail": false,
            "autorizaReceberWhatsapp": false,
            "marca": {
                "id": 0,
                "nome": "SEM MARCA"
            }
        }
      ],
      "dependentes": [
        {
            "observacao": "obs",
            "nome": "dependente 1 ",
            "documento": "402.325.670-69",
            "parentesco": "parentesco",
            "dataNascimento": "04-09-1999 00:00:00"
        },
        {
            "observacao": "obs",
            "nome": "dependente 2",
            "documento": "523.792.490-59",
            "parentesco": "parentesco",
            "dataNascimento": "01-07-2000 00:00:00"
        }
    ]
   },
   {
      "id":2,
      "ativo":true,
      "excluido":false,
      "nome":"Cliente Exemplo",
      "documento":"123.123.123-12",
      "tipoPessoa":"PF",
      "padraoNome": "NOME_FANTASIA",
      "entidadeCadastro":1,
      "emails":[
         "cliente@exemplo.com.br",
         "clienteexemplo@teste.com.br"
      ],
      "rg":"91.122.534-1",
      "dataNascimento":"12-08-1980 00:00:00",
      "enderecos":[
         {
            "tipo":"AVENIDA",
            "logradouro":"São João",
            "numero":"2045",
            "complemento":"Apto 203",
            "bairro":"Jardim Colinas",
            "cep":"32600134",
            "cidade":"São José dos Campos",
            "siglaEstado":"SP",
            "pais":"Brasil",
            "tipoEndereco":"ENDERECO_CORRESPONDENCIA",
            "codigoIBGECidade":"3554102"
         }
      ],
      "telefones":[
         {
            "ddd":12,
            "ddi":55,
            "numero":"88888888",
            "ramal":"1002",
            "tipoTelefone":"CELULAR" 
         }
      ],
      "classes":[
         "CLIENTE",
         "OUTROS"
      ],
      "categoria":"PADRÃO",
      "autorizaReceberEmail": false,
      "autorizaReceberSms": true,
      "camposCustomizados": {
        "id": 3702,
        "valoresPrimitivo": [],
        "valoresLista": [
            {
                "valoresPrimitivo": [],
                "valoresComposicao": [
                    {
                        "id": 27,
                        "valores": [
                            {
                                "value": "BOB",
                                "id": 21,
                                "type": "TEXTO"
                            },
                            {
                                "value": "24/05/2018 00:00:00",
                                "id": 23,
                                "type": "DATA"
                            },
                            {
                                "value": "M",
                                "id": 22,
                                "type": "OPCIONAL"
                            },
                            {
                                "value": "SHIH TZU",
                                "id": 25,
                                "type": "OPCIONAL"
                            },
                            {
                                "value": "CAES",
                                "id": 24,
                                "type": "OPCIONAL"
                            },
                            {
                                "value": "GRANDE",
                                "id": 26,
                                "type": "OPCIONAL"
                            }
                        ]
                    }
                ],
                "campoId": 28
            }
        ],
        "valoresComposicao": []
      }
   },
   {
      "classes": [
          "CLIENTE"
      ],
      "id": 3,
      "website": "DELETADO",
      "entidadeCadastro": 2,
      "categoriasAdicionais": [],
      "dataAlteracao": "30-10-2020 11:27:33",
      "excluido": true,
      "ativo": false,
      "tipoPessoa": "PF",
      "padraoNome": "NOME_FANTASIA",
      "emails": [],
      "enderecos": [],
      "telefones": [],
      "nome": "DELETADO",
      "dataCriacao": "30-10-2020 11:15:55",
      "documento": "999.999.999-99",
      "nomeContato": "DELETADO",
      "observacao": "DELETADO",
      "camposCustomizados": {
          "id": 6670,
          "valoresComposicao": [],
          "valoresPrimitivo": [],
          "valoresLista": []
      },
      "autorizaReceberEmail": false,
      "participaProgramaFidelidade": false,
      "autorizaReceberSms": false,
      "categoria": "PADRÃO"
    }
]
```

### URL de controle de registro integrado

> POST https://integrador.varejonline.com.br/apps/api/terceiros/registro/integracao/{integrador}

Onde {integrador} deve ser substituído pelo nome de integrador utilizado no controle de registros integrados

No corpo da mensagem, enviar um array com os ids a serem marcados como integrados pelo integrador: 

```javascript
{
    "objectIds": [
        1,
        2,
        ....
    ]
}