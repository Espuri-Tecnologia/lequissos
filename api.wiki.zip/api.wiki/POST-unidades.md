### URL

> POST https://integrador.varejonline.com.br/apps/api/unidades

### Parâmetros

Envie um JSON no corpo da requisição, contendo:
* **nome:** nome da unidade (string) _(obrigatório)_
* **sigla:** sigla da unidade (string) _(obrigatório)_

### Retorno

Retorna um Json com informações do resultado da operação realizada, contendo:
 * **idRecurso:** id da categoria gerada.
 * **codigoMensagem:** Código de identificação da operação realizada. [veja a lista de Códigos] (Retorno-API)
 * **mensagem:** Mensagem da operação realizada

### Exemplo

> POST https://integrador.varejonline.com.br/apps/api/unidades

'Content-Type'='application/json'

```javascript
   {
      "nome":"NOVA UNIDADE",
      "sigla":"NU"
   }
```

### Exemplo de retorno:

_Sucesso:_
* HTTP STATUS 201 – CREATED
* Body:
```javascript
{
      "idRecurso": 1,
      "codigoMensagem": 0,
      "mensagem": "Operação realizada com sucesso."
}
```

_Requisição inválida:_
* HTTP STATUS 400 – BAD REQUEST
* Body: 
```javascript
{
      "idRecurso": 0,
      "codigoMensagem": 0,
      "mensagem": "Unidade inválida"
}
```
