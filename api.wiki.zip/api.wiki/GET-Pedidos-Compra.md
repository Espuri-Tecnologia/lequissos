### URLs

> GET https://integrador.varejonline.com.br/apps/api/pedidos-compra

> GET https://integrador.varejonline.com.br/apps/api/pedidos-compra/:id

### Parâmetros

* **entidades:** [Veja como Funciona este Filtro](https://github.com/Varejonline/api/wiki/Filtro-de-Entidades)
* **inicio:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **quantidade:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **desde:** [Veja o Filtro de Datas](https://github.com/Varejonline/api/wiki/Filtro-de-Datas)
* **ate:** [Veja o Filtro de Datas](https://github.com/Varejonline/api/wiki/Filtro-de-Datas)
* **alteradoApos:** [Entenda a Coleta de Alterações](https://github.com/Varejonline/api/wiki/Filtro-de-Data-Alteração)
* **referenciaPedidoFornecedor:** informar o número de referência do pedido de venda do fornecedor referente ao pedido de compra que deseja buscar
* **numeroPedido:** informar o número do pedido de compra que deseja buscar
* **usuarios:** informar o id do usuário do pedido de compra que deseja buscar, se for vários usuários informar os ids separado por vírgula.
* **fornecedor:** informar o id do fornecedor do pedido de compra que deseja buscar
* **cnpjFornecedor:** informar o cnpj do fornecedor do pedido de compra que deseja buscar
* **status:** [Status](https://github.com/Varejonline/api/wiki/Status-de-pedido-de-compra) do pedido de compras (lista string separada por virgula)

### Retorno
    
* **id:** id do pedido (long)
* **numeroPedidoCompra:** número do pedido de compras (string)
* **dataPedidoCompra:** data do pedido de compras (string)
* **dataAlteracao:** última data de alteração do pedido, no formato dd-mm-aaaa hh:mi:ss (string)
* **status:** [Status](https://github.com/Varejonline/api/wiki/Status-de-pedido-de-compra) do pedido de compras (string)
* **previsaoEntrega:** data de previsão de entrega do pedido, no formato dd-mm-aaaa (string)
* **limiteEntrega:** data de limite de entrega do pedido, no formato dd-mm-aaaa (string)
* **entidade:** entidade do pedido 
  * **id:** id da [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) à qual o pedido pertence (long)
  * **nome:** nome da [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) do pedido de compra (string)
  * **documento:** documento da [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) do pedido de compra (string)
* **fornecedor:** fornecedor do pedido 
  * **id:** id do [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros) fornecedor do pedido de compra (long)
  * **documento:** documento do [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros) fornecedor do pedido de compra (string)
  * **nome:** nome do [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros) fornecedor do pedido de compra (string)
* **idUsuario:** id do usuário do pedido de compra (long)
* **nomeUsuario:** nome do usuário do pedido de compra (string)
* **observacao:** observações incluídas no pedido de compra (string)
* **valorSeguro:** valor do seguro do pedido de compra (decimal)
* **valorFrete:** valor do frete do pedido de compra (decimal)
* **valorOutros:** valor do outros do pedido de compra (decimal)
* **valorTotal:** valor líquido total do pedido de compra (decimal)
* **itens:** lista de itens do pedido, cada um contendo:
   * **produto:**
       * **id:** id do [produto](https://github.com/Varejonline/api/wiki/GET-Produtos)
       * **codigoSistema:** código de sistema do produto.
       * **codigoBarras:** código de barras do produto.
       * **codigoInterno:** código interno do produto.
       * **descricao:** descrição do produto.
   * **codigo:** código do produto levando em consideração a lógica de precedência (string)
   * **quantidade:** quantidade total do produto solicitada no pedido de compras, na unidade informada (decimal)
   * **unidade:** unidade do produto comprado (decimal)
   * **valorUnitario:** valor unitário do item (decimal)
   * **valorDesconto:** valor de desconto oferecido no item (decimal)
   * **valorProdutos:** valor total dos produtos (decimal)
   * **valorIPI:** valor do IPI aplicado ao item (decimal)
   * **valorICMS:** valor do ICMS aplicado ao item (decimal)
   * **valorICMSST:** valor do ICMS ST aplicado ao item (decimal)
   * **valorPis:** valor do PIS aplicado ao item (decimal)
   * **valorCofins:** valor do cofins aplicado ao item (decimal)
   * **idOperacao:** valor que indica o id operação de compra do produto, conforme a lista a seguir (long) [veja a lista de operações] (Operações de Compra)
   * **quantidadeRecebida:** quantidade que já foi recebida deste produto no pedido de compras (decimal)
   * **epcs:** lista de epcs vinculados ao item (lista de string)
* **parcelas:** lista de parcelas do pagamento do pedido de compras:
   * **numeroParcela:** numero da parcel (long)
   * **dataVencimento:** data de vencimento da parcela de pagamento do pedido de compras (string)
   * **valor:** valor da parcela (decimal)

### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/pedidos-compra

```javascript
[
    {
        "id": 141,
        "numeroPedidoCompra": "9-21/1",
        "status": "ABERTO",
        "fornecedor": {
            "id": 175,
            "nome": "MEGATRONIC MARCIA S N ELETRONICOS",
            "documento": "06023838000187"
        },
        "idEntidade": 1,
        "nomeEntidade": "ENTIDADE SIMPLES NACIONAL",
        "idUsuario": 1,
        "nomeUsuario": "EQUIPE QA",
        "valorTotal": 50,
        "valorSeguro": 0,
        "valorFrete": 0,
        "valorOutros": 0,
        "observacao": "Detalhe adicional",
        "dataAlteracao": "07-05-2021 16:16:46",
        "dataPedidoCompra": "07-05-2021 00:00:00",
        "previsaoEntrega": "07-06-2021",
        "limiteEntrega": "07-07-2021",
        "itens": [
            {
                "idProduto": 43,
                "codigo": "2541.004",
                "descricao": "REGATA CETIM BASICA CINZA 42",
                "quantidade": 10,
                "quantidadeRecebida": 0,
                "unidade": "UN",
                "produto": {
                    "id": 43,
                    "codigoSistema": "0082.0005",
                    "descricao": "REGATA CETIM BASICA CINZA 42"
                },
                "idOperacao": 20,
                "valorUnitario": 5,
                "valorDesconto": 0,
                "valorProdutos": 50,
                "valorIPI": 0,
                "valorICMSST": 0,
                "valorICMS": 6,
                "valorPis": 0,
                "valorCofins": 0,
                "valorCusto": 50,
                "epcs": [
                    "ZX0000000000000000000001",
                    "XX0000000000000000000002"
                ]
            }
        ],
        "parcelas": [
            {
                "numeroParcela": 1,
                "valor": 25,
                "dataVencimento": "07-06-2021 00:00:00"
            },
            {
                "numeroParcela": 2,
                "valor": 25,
                "dataVencimento": "07-07-2021 00:00:00"
            }
        ],
        "idPlanoPagamento": 2,
        "referenciaPedidoFornecedor": "REF. PEDIDO 1",
        "geradoEntregaFutura": false
    }
]
```