### URLs

> GET https://integrador.varejonline.com.br/apps/api/servicos

> GET https://integrador.varejonline.com.br/apps/api/servicos/:id

### Parâmetros

* **inicio:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **quantidade:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **categoria:** id da [categoria](https://github.com/Varejonline/api/wiki/GET-categorias-servico) de serviço
* **alteradoApos:** [Entenda a Coleta de Alterações](https://github.com/Varejonline/api/wiki/Filtro-de-Data-Alteração)
* **codigoSistema:** Busca o serviço vinculado ao código sistema informado.

### Retorno 

* **id:** id único do serviço (long)
* **descricao:** nome do serviço (string)
* **codigoInterno:** código interno do lojista (string)
* **descontoMaximo:** percentual máximo de desconto do serviço (decimal)
* **comissaoVenda:** percentual máximo de comissão do serviço (decimal)
* **tempoExecucaoMinimo:** tempo de execução mínimo do serviço (long)
* **tipoServicoJson:** serviço de acordo com a tabela federal
    * **id:** Id do tipo do serviço (long)
    * **codigo:** código do serviço na tabela federal (string)
    * **descricao:** descrição do serviço na tabela federal (string)
* **tipoServicoMunicipioJson:** serviço de acordo com a tabela municipal
    * **id:** Id do tipo do serviço (long)
    * **codigo:** código do serviço na tabela municipal (string)
    * **descricao:** descrição do serviço na tabela municipal (string)
* **ativo:** status do serviço (boolean)
* **unidade:** unidade de venda do serviço (string) 
* **codigoSistema:** código de negócio único do serviço (string)
* **classificacao:** classificação do serviço (ISS/ICMS) (string)
* **especificacao:** detalhamento do serviço (string)
* **precoVariavel:** define se possui preço de tabela (false) ou é escolhido no momento da venda (true) (boolean)
* **categorias:** [categorias](https://github.com/Varejonline/api/wiki/GET-categorias-servico) do serviço, lista de:
    * **id:** id da categoria (long)
    * **nivel:** nível da categoria (long)
    * **codigoSistema:** código da categoria (string)
    * **nome:** nome da categoria (long)
* **precoVenda:** valor de venda (decimal)

### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/servicos

```javascript
[{
    "id": 42,
    "tipoServicoMunicipioJson": {
        "id": 478,
        "codigo": 8648,
        "descricao": "Guarda, tratamento, amestramento, embelezamento, alojamento e congêneres, relativos a animais."
    },
    "tipoServicoJson": {
        "id": 50,
        "codigo": "5.08",
        "descricao": "Guarda, tratamento, amestramento, embelezamento, alojamento e congêneres."
    },
    "codigoInterno": "10014",
    "ativo": true,
    "precoVariavel": false,
    "categorias": [
        {
            "id": 14,
            "nivel": 1,
            "nome": "BANHO E TOSA",
            "codigoSistema": 2985
        },
        {
            "id": 17,
            "nivel": 2,
            "nome": "BANHO CAO",
            "codigoSistema": 2988
        }
    ],
    "descricao": "BANHO PORTE MEDIO PELO LONGO",
    "categoria": {
        "id": 17,
        "nivel": null,
        "nome": "BANHO CAO",
        "codigoSistema": 2988
    },
    "classificacao": "SERVICO_ISS",
    "codigoSistema": "251.0015",
    "comissaoVenda": 99.99,
    "unidade": "SV",
    "isFromESB": false,
    "descontoMaximo": 90,
    "precoVenda": 0.01
}]
```