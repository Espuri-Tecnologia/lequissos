### URL

> PUT https://integrador.varejonline.com.br/apps/api/orcamentos

### Parâmetros

Envie um JSON no corpo da requisição, contendo:

* **id:** id do orçamento (long obrigatório) 
* **validade:** dias de validade para o vencimento do orçamento (long obrigatório)
* **entidade:** [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) utilizada (obrigatório) (objeto complexo)
    * **id:** id da entidade (opcional) (long)
    * **documento:** documento da entidade (opcional) (string)
* **terceiro:** [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros) utilizado (obrigatório) (objeto complexo)
    * **id:**  id do terceiro (opcional) (long)
    * **documento:** documento do terceiro (opcional) (string)
* **itens:** lista de itens do orçamento, contendo:
   * **produto:** (obrigatório se existir itens)
       * **id:** id do [produto](https://github.com/Varejonline/api/wiki/GET-Produtos)
       * **codigoSistema:** código de sistema do produto.
   * **quantidade:** quantidade do item (decimal obrigatório se existir itens)
   * **valorUnitario:** valor unitário do item do orçamento (decimal obrigatório se existir itens)
   * **operacao:** id da [operação](https://github.com/Varejonline/api/wiki/Tipo-de-operação-em-itens-movimentados) utilizada para o item (long)
* **servicos:** lista de serviços do orçamento, contendo:
   * **servico:** (obrigatório se existir itens)
       * **id:** id do [serviço](https://github.com/Varejonline/api/wiki/GET-servicos)
       * **codigoSistema:** código de sistema do serviço.
   * **quantidade:** quantidade do serviço (decimal obrigatório se existir serviços)
   * **valorUnitario:** valor unitário do serviço do orçamento (decimal obrigatório se existir serviços)
* **valorFrete:** valor de frete do orçamento (decimal opcional)
* **valorSeguro:** valor de seguro do orçamento (decimal opcional)
* **valorOutros:** valor de outros do orçamento (decimal opcional)
* **numeroPedidoCliente:** Número do pedido que originou o orçamento (string opcional)
* **plano:** (Informar o id e/ou descrição do plano) 
  * **id** do [plano de pagamento](https://github.com/Varejonline/api/wiki/GET%20planos-pagamento) utilizado (long).
  * **descricao** do [plano de pagamento](https://github.com/Varejonline/api/wiki/GET%20planos-pagamento) utilizado (string).
* **representante:** (Informar o id e/ou nome do vendedor)
  * **id** do [vendedor](https://github.com/Varejonline/api/wiki/GET-representantes) utilizado (long)
  * **nome** do [vendedor](https://github.com/Varejonline/api/wiki/GET-representantes) utilizado (string)
* **observacao:** observações do orçamento (string opcional)
* **vendaConsumidorFinal:** indica se o orçamento é para consumidor final (boolean obrigatório)
* **reservarEstoque:** indica se deverá ser criada/atualizada a reserva de estoque para os itens do orçamento (boolean opcional).

### Retorno

Retorna um Json com informações do resultado da operação realizada, contendo:
 * **idRecurso:** id do orçamento alterado.
 * **codigoMensagem:** Código de identificação da operação realizada. [veja a lista de Códigos](https://github.com/Varejonline/api/wiki/Retorno-API)
 * **mensagem:** Mensagem da operação realizada

### Exemplo

> PUT https://integrador.varejonline.com.br/apps/api/orcamentos

'Content-Type'='application/json'
```javascript
{
   "validade":15,
   "entidade": {
      "id": 1,
      "documento": "00.000.000/0000-00"
   },
   "terceiro": {
      "id": 1,
      "documento": "000.000.000-00"
   },
   "itens":[
      {
         "produto": {
             "id" : 245,
             "codigoSistema" : "0001.0001" 
         },
         "quantidade":8, 
         "valorUnitario":10,
         "operacao":1
      }
   ],
   "servicos":[
      {
         "servico": {
             "id" : 245,
             "codigoSistema" : "S001.0099" 
         },
         "quantidade":1, 
         "valorUnitario":20
      }
   ],
   "valorFrete":2,
   "valorSeguro":6,
   "valorOutros":4,
   "numeroOrcamento" : "1 - 1",
   "numeroPedidoCliente" : "111-12",
   "representante": {
      "nome": "NOME DO VENDEDOR",
      "id": 1
   },
   "plano" : {
      "descricao": "CREDIÁRIO 1X",
      "id": 12
   },
   "observacao":"Ref. 007",
   "vendaConsumidorFinal":true,
   "reservarEstoque":true
}
```