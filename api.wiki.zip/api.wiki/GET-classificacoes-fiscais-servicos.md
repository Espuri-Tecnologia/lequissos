### URLs

> GET https://integrador.varejonline.com.br/apps/api/classificacoes-fiscais/servicos

### Parâmetros

* **entidades:**  [veja como funciona este filtro] (Filtro-de-Entidades)
* **inicio:** [veja o filtro de paginação] (Paginação de resultados)
* **quantidade:** [veja o filtro de paginação] (Paginação de resultados)
* **uf:** filtro para buscar apenas classificações fiscais associadas com participantes de um estado específico (sigla)
* **idServico:** filtro para buscar apenas as classificações relacionadas a um serviço específico
* **idOperacao:** filtro para buscar apenas as classificações relacionadas a um operação de entrada ou saída específica

### Retorno

* **idEntidade:** id da [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) para qual se aplica a classificação fiscal (long)
* **uf:** sigla do estado do participante (remetente ou destinatário) onde se aplica a carga tributária retornada na clasisficação fiscal (string)
* **idServico:** id do serviço para qual se aplica a classificação fiscal (long)
* **cfop:** código CFOP da operação (integer)
* **idOperacao:** id da operação de entrada ou saída para qual se aplica a carga tributária retornada na classificação fiscal (long)
* **pis:** dados do PIS aplicado ao item (segue a estrutura comum abaixo)
* **cofins:** dados do COFINS aplicado ao item (segue a estrutura comum abaixo)
* **iss:** dados do ISS aplicado ao item - existe somente ser a classificação fiscal for de um serviço (segue a estrutura comum abaixo)

Estrutura comum para os tributos das classificações fiscais:
   * **cst:** código de situação tributária (string)
   * **base:** valor da base de cálculo do tributo (decimal)
   * **aliquota:** valor da alíquota aplicada (decimal)


### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/classificacoes-fiscais-servicos

```javascript
[
	{
		"idEntidade":1,
		"uf": "RJ",
		"idServico":244,
		"cfop": "1102 - Vendas de mercadorias",
		"idOperacao": 1,
		"iss":
		[
			{
				"cidade": "256759 - São José dos Campos"
				"base":100,
				"aliquota":6
			},
			{
				"cidade": "256758 - São Paulo"
				"base":100,
				"aliquota":6.5
			}	
		],
		"pis":
		{
			"cst": "00"
			"base":100,
			"aliquota":0.65,
		},
		"cofins":
		{
			"cst": "00"
			"base":100,
			"aliquota":7,
		}
	}
]
```