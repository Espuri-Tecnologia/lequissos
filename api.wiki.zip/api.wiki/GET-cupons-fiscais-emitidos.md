# Atenção:
> Esse endpoint retorna apenas cupons do modelo ECF (Antiga impressora fiscal Lacrada).
> São raros os casos onde essa modalidade ainda é utilizada, considere verificar se o endpoint correto seria o GET-notas-mercadoria.
> Se as notas que deseja coletar são NF-e, NFC-e, SAT ou CFe, deve usar o endpoint GET-notas-mercadoria.


Lista todos os cupons fiscais emitidos pela empresa. 

### URLs

> GET https://integrador.varejonline.com.br/apps/api/cupons-fiscais-emitidos

> GET https://integrador.varejonline.com.br/apps/api/cupons-fiscais-emitidos/:id

### Parâmetros

* **desde:** [Veja o Filtro de Datas](https://github.com/Varejonline/api/wiki/Filtro-de-Datas)
* **ate:** [Veja o Filtro de Datas](https://github.com/Varejonline/api/wiki/Filtro-de-Datas)
* **inicio:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **quantidade:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **alteradoApos:** [Entenda a Coleta de Alterações](https://github.com/Varejonline/api/wiki/Filtro-de-Data-Alteração)

### Retorno

* **id:** id do cupom fiscal. É o mesmo id do [pedido de venda](https://github.com/Varejonline/api/wiki/GET-pedidos) (long)
* **modelo:** modelo do cupom fiscal (string). Os modelos existentes são: 2B, 2C e 2D.
* **data:** data de emissão do cupom (string)
* **idEntidade:** id da [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) à qual o cupom pertence (long)
* **idRepresentante:** id do [vendedor](https://github.com/Varejonline/api/wiki/GET-representantes) da empresa na venda (long)
* **idTerceiroCliente:** id do [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros) que foi o cliente na venda (long)
* **plano:** Dados do plano de pagamento utilizado
  * **id:** id do [plano de pagamento](https://github.com/Varejonline/api/wiki/GET-planos-pagamento) utilizado na venda (string)
  * **descricao:** nome do [plano de pagamento](https://github.com/Varejonline/api/wiki/GET-planos-pagamento) utilizado na venda (string)
* **coo:** número COO do cupom fiscal (long)
* **valorTotal:** valor total do cupom fiscal (decimal)
* **cancelado:** indica se o cupom foi cancelado (boolean)
* **numeroSerieECF:** número de série da ECF (string)
* **itens:** lista de itens do cupom fiscal
  * **produto:** dados do produto (objeto complexo)
      * **id:** id da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos)
      * **descricao:** id da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos)
      * **codigoSistema:** Código Sistema da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos)
      * **codigoInterno:** Código Interno da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos)
      * **codigoBarras:** Código de Barras da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos) 
  * **cfop:** código CFOP da operação (integer)
  * **quantidade:** quantidade do [produto](https://github.com/Varejonline/api/wiki/GET-Produtos) (decimal)
  * **valorUnitario:** valor unitário do [produto](https://github.com/Varejonline/api/wiki/GET-Produtos) na venda (decimal)
  * **valorFrete:** valor de frete do item (decimal)
  * **valorOutros:** outros valores do item (decimal)
  * **valorSeguro:** valor de seguro do item (decimal)
  * **valorTotal:** valor total do item (decimal)
  * **valorDesconto:** valor do desconto do item (decimal)
  * **icms:** dados do ICMS aplicado ao item (segue a estrutura comum abaixo)
  * **cofins:** dados do COFINS aplicado ao item (segue a estrutura comum abaixo)
  * **pis:** dados do PIS aplicado ao item (segue a estrutura comum abaixo)
  * **icmssn:** dados do ICMSSN aplicado ao item (segue a estrutura comum abaixo)
  * **icmsst:** dados do ICMSST aplicado ao item (segue a estrutura comum abaixo)
* **nomeTerminal:** nome do terminal
* **parcelas:** lista das parcelas do pedido, cada uma contendo:
  * **id:** id da [parcela](https://github.com/Varejonline/api/wiki/GET-contas-receber) (long)
  * **dataVencimento:** data de vencimento da parcela (string)
  * **valor:** valor total da parcela (decimal)
* **valeTrocaGerado:** Vale trocas gerados durante a venda (Venda com troca de mercadorias)
  * **numeroValeTroca:** numero do vale troca gerado na troca de mercadorias (string)
  * **idDevolucaoGerada:** id da [devolução de venda](https://github.com/Varejonline/api/wiki/GET-devolucoes) gerada na troca (decimal)
* **valeTrocasUtilizados:** lista de valores de vale trocas utilizados no pagamento do pedido
  * **valorUtilizado:** valor utilizado no pagamento (decimal)

Estrutura comum para tributos:
   * **base:** valor da base de cálculo do tributo (decimal)
   * **aliquota:** valor da alíquota aplicada (decimal)
   * **valor:** valor do tributo (decimal)
   * **cst:** código de situação tributária (string)

### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/cupons-fiscais-emitidos

```javascript
[
   {
      "id":3500,
      "modelo":"2D",
      "data":"04-12-2012",
      "idEntidade":90,
      "idRepresentante":1,
      "idTerceiroCliente":1,
      "plano": {
            "id": 1,
            "descricao": "A VISTA"
      },
      "coo":4794,
      "valorTotal":1120,
      "cancelado":true,
      "numeroSerieECF":9812,
      "itens":[
         {
            "produto": {
                "id":9342,
                "descricao":"BLUSA MALHA PRETA GG",
                "codigoSistema":"0001.0001",
                "codigoInterno":"",
                "codigoBarras":""
            },
            "cfop":5102,
            "quantidade":1,
            "valorUnitario":1000.0000,
            "valorFrete":0,
            "valorOutros":0,
            "valorSeguro":0,
            "valorTotal":1000,
            "valorDesconto":0,
            "icms":{
               "base":1120,
               "valor":134.4,
               "aliquota":12,
               "cst":"00"
            },
            "cofins":{
               "base":1000,
               "valor":30,
               "aliquota":3,
               "cst":"01"
            },
            "pis":{
               "base":1000,
               "valor":6.5,
               "aliquota":0.65,
               "cst":"01"
            },
            "icmssn":{
               "base":0,
               "valor":0,
               "aliquota":0,
               "cst":"00"
            },
            "icmsst":{
               "base":0,
               "valor":0,
               "aliquota":0,
               "cst":"00"
            }
         }
      ],
      "parcelas":[
         {
            "id":6,
            "valor":28,
            "dataVencimento":"19-06-2012"
         }
      ],
      "valeTrocaGerado": {
            "numeroValeTroca": "7-6448",
            "idDevolucaoGerada": 6478
      },
      "valeTrocasUtilizados": [
            {
                "valorUtilizado": 43
            }
      ]
   }
]
```