### URLs

> POST https://integrador.varejonline.com.br/apps/api/produtos

_**API Synchronized**: Garante consistência na integracão concorrente de grades de produtos._

### Parâmetros
Envie um JSON no corpo da requisição, contendo:

* **descricao:** descrição do produto (string) _(obrigatório)_
* **classificacao:** classificação que indica a finalidade para a qual o produto será utilizado. Pode assumir um dos seguintes valores: PRODUCAO_PROPRIA, REVENDA, ATIVO_IMOBILIZADO, CONSUMO, SERVICO_ISS, SERVICO_ICMS, INSUMO (string) _(obrigatório)_
* **origem:** número de 0 a 7 que representa a [origem](https://github.com/Varejonline/api/wiki/Origens-de-Mercadoria) a ser sugerida aos produtos da categoria, segundo a tabela da receita federal (long) _(obrigatório)_
* **fci:**  número de controle da Ficha de Conteúdo de Importação (string) _(obrigatório para origens 3, 5 e 8)_
* **codigoCest:** Código Especificador da Substituição Tributária. (String) _(opcional)_
* **urlsFotosProduto:** lista com as URLs das fotos do produto (lista - string) (opcional)
* **disponivelEcommerce:** Define se o produto pode ser disponibilizado no ecommerce (boolean) _(opcional)_
* **disponivelMarketplace:** Define se o produto pode ser disponibilizado no marketplace (boolean) _(opcional)_
* **codigoNcm:** código do NCM( Nomenclatura Comum Mercosul) que identifica a natureza do produto (string) _(obrigatório)_
* **metodoControle:** ESTOCAVEL, NAO_ESTOCAVEL, LOTE, SERIE (string) _(obrigatório)_
* **unidade:** sigla da unidade de medida utilizada pelo produto, por exemplo "UN" ou "KG" (string) _(obrigatório)_
* **unidadesProporcao:** Lista de Unidades Proporcionais da Mercadoria _(opcional)_
  * **unidade:** Sigla da unidade proporcional (string) _(obrigatório)_
  * **proporcao:** Proporção da unidade sobre a unidade principal (decimal) _(obrigatório)_
* **custoReferencial:** valor referencial de qual é o custo do produto (decimal) _(obrigatório)_
* **listCustoReferencial:** Lista de preço de Custo por Entidade _(opcional)_
  * **entidade:** Id da [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) (long) _(obrigatório)_
  * **precoCusto:** Custo do produto na [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) (decimal) _(obrigatório)_
* **cnpjFornecedores:** lista com o CNPJ dos [terceiros](https://github.com/Varejonline/api/wiki/GET-terceiros) que são fornecedores do produto  (lista de string) _(opcional)_
        
      O fornecedor deve estar previamente cadastrado no sistema.
* **especificacao:** texto contendo uma especificação para o produto (string) _(opcional)_
* **codigoBarras:** código de barras do produto (string) _(opcional)_
* **codigoInterno:** código interno do produto na empresa (string) _(opcional)_
* **codigoSistema:** Deve ser informado quando a empresa utiliza geração de código manual (string) _(obrigatório apenas em bases com geração de código manual)_
* **tags:** Strings concatenadas por vírgula que permitem consulta de produtos no sistema (string) _(opcional)_
* **estoqueMaximo:** quantidade máxima de estoque produto (decimal) _(opcional)_
* **estoqueMinimo:** quantidade mínima de estoque do produto (decimal) _(opcional)_
* **peso:** peso do produto (decimal) _(opcional)_
* **altura:** altura do produto (decimal) _(opcional)_
* **comprimento:** comprimento do produto (decimal) _(opcional)_
* **largura:** largura do produto (decimal) _(opcional)_
* **custoUnitarioRoyalties:** custo unitário em royalties do produto (decimal) _(opcional)_
* **dadosPorEntidade:** Lista de Configurações por Entidade do Produto _(opcional)_
  * **entidade:** Id da [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) (long) _(obrigatório)_
  * **estoqueMinimo:** Estoque mínimo referencial do produto na entidade (decimal) _(obrigatório)_
  * **estoqueMaximo:** Estoque máximo referencial do produto na entidade (decimal) _(obrigatório)_
* **produtoBase:** Dados do produto pai do SKU que será criado. _(Obrigatório para itens de grade.)_
  * **id:** id do produto pai (Long) _(opcional se codigoSistema for informado)_
  * **codigoSistema:** Código do sistema para o produto pai (string)_(opcional se id for informado)_
  * **nome:** Nome do produto pai (string) _(obrigatório)_
* **valorAtributos:** combinação de atributos da grade que geraram este produto. Obrigatório para itens de grade. _(opcional)_
  * **nome:** nome do atributo da grade (string) _(obrigatório)_
  * **valor:** valor do atributo para este produto (string) _(obrigatório)_
  * **codigo:** código do valor do atributo (string) _(opcional)_
* **componentes:** Dados dos itens que compõem a ficha técnica do produto _(opcional)_
  * **produto:** Produto presente na ficha técnica _(obrigatório)_
    * **id:** id do produto (long) _(opcional se codigoSistema for informado)_
    * **codigoSistema:** Código sistema do produto (string) _(opcional se id for informado)_
  * **quantidade:** Quantidade de peças do item na ficha técnica (decimal) _(obrigatório)_
  * **unidade:** Sigla da unidade de medida que representa a quantidade (string) _(obrigatório)_

* **categorias:** Lista com os dados das categorias que definem a estrutura mercadológica do produto. _(obrigatório)_
  * **nivel:** **Nome** do [nível](https://github.com/Varejonline/api/wiki/GET-niveis-categoria) onde está localizada a categoria (string) _(obrigatório)_
  * **nome:** Nome da Categoria no nível (string) _(obrigatório)_

    Deve ser informada uma categoria para cada nível de categoria cadastrado [nível de categoria cadastrado](https://github.com/Varejonline/api/wiki/GET-niveis-categoria).

Caso a classificação do produto seja INDUSTRIALIZACAO_PROPRIA ou COMERCIALIZACAO_REVENDA, os campos abaixo podem ser preenchidos. 
Caso não seja, os mesmos não devem ser preenchidos com qualquer valor diferente de zero. 

* **descontoMaximo:** porcentagem máxima de desconto que pode ser oferecida na venda do produto (decimal) _(opcional)_
* **comissao:** comissão percentual recebida pelo [vendedor](https://github.com/Varejonline/api/wiki/GET-representantes) na venda do produto (decimal) OPCIONAL
* **preco:** preço padrão do produto (decimal) OPCIONAL
* **precoVariavel:** Define se o preço de venda do produto é definido somente no momento da venda (boolean) _(obrigatório)_

### Retorno

Retorna um Json com informações do resultado da operação realizada, contendo:
 * **idRecurso:** id do produto gerado.
 * **codigoMensagem:** Código de identificação da operação realizada. [veja a lista de Códigos](https://github.com/Varejonline/api/wiki/Retorno-API)
 * **mensagem:** Mensagem da operação realizada

### Exemplo

> POST https://integrador.varejonline.com.br/apps/api/produtos

Criação de um produto simples ou base de grade:

```javascript
   {
      "cnpjFornecedores":["25.348.796/0001-07"],
      "descricao":"GRANOLA 20G",
      "especificacao":"GRANOLA 20G SACHE",
      "metodoControle":"ESTOCAVEL",
      "codigoNcm": "2313.23.23",	
      "origem":0,
      "codigoBarras":"6445662344598",
      "codigoInterno":"12322",
      "codigoSistema":"0001",
      "tags":"000192,camisalarga,ponta de estoque",
      "unidade":"UNIDADE",
      "classificacao":"CONSUMO",
      "custoReferencial":30,
      "custoUnitarioRoyalties":10.00,
      "listCustoReferencial":[
         {
            "entidade":1,
            "precoCusto":29.85
         },
         {
            "entidade":2,
            "precoCusto":32.02
         }
      ],
      "preco":65,
      "precoVariavel": false,
      "descontoMaximo":10.0,
      "comissao":0,
      "estoqueMaximo":700,
      "estoqueMinimo":100,
      "peso":100,
      "altura":100,
      "comprimento":100,
      "largura":100,
      "disponivelEcommerce": true,
      "disponivelMarketplace": true,
      "categorias": [
         {
             "nome":"Natural",
             "nivel":"DEPARTAMENTO",
         },
         {
             "nome":"Graos",
             "nivel":"SETOR",
         }
      ]
   }

```

Criação de um item de grade. Nesse caso, caso exista no sistema um produto base (produtoBase) com o nome e codigoSistema informados, será utilizado para a geração do SKU, caso contrário, será criado um produto base com os dados do SKU e este será vinculado ao produto base, formando uma grade com 1 item de grade. Nas demais requisições da grade, o produto base gerado será reutilizado.

```javascript
   {
      "cnpjFornecedores":["25.348.796/0001-07", "90.837.241/0001-82"],
      "descricao":"CAMISETA POLO AZUL P",
      "especificacao":"CAMISETA POLO",
      "metodoControle":"ESTOCAVEL",
      "codigoNcm": "2313.23.23",	
      "origem":3,
      "fci":"B01F70AF-10BF-4B1F-848C-65FF57F616FE",
      "codigoCest":"22.001.00",
      "codigoBarras":"6465464654567",
      "codigoInterno":"12002",
      "codigoSistema":"0002.0001",
      "tags":"000192,camisalarga,ponta de estoque",
      "unidade":"UNIDADE",
      "classificacao":"REVENDA",
      "custoReferencial":28.20,
      "custoUnitarioRoyalties":10.00,
      "listCustoReferencial":[
         {
            "entidade":1,
            "precoCusto":31.85
         },
         {
            "entidade":2,
            "precoCusto":22.02
         }
      ],
      "preco":40.50,
      "precoVariavel": false,
      "descontoMaximo":0,
      "comissao":5.0,
      "estoqueMaximo":100,
      "estoqueMinimo":10,
      "produtoBase": {
          "id":239,
          "codigoSistema":"0002",
          "nome":"CAMISETA POLO"
      },
      "valorAtributos":[
         {
            "nome":"COR",
            "valor":"AZUL",
            "codigo":"123"
         },
         {
            "nome":"TAMANHO",
            "valor":"P",
            "codigo":"456"
         }
      ],
      "categorias": [
         {
             "nome":"Vestuario",
             "nivel":"DEPARTAMENTO",
         },
         {
             "nome":"Esporte Fino",
             "nivel":"SETOR",
         }
      ]
   }
```


### Exemplo de retorno:

_Sucesso:_
* HTTP STATUS 201 – CREATED
* Body:
```javascript
{
      "idRecurso": 1,
      "codigoMensagem": 0,
      "mensagem": "Operação realizada com sucesso."
}
```

_Requisição inválida:_
* HTTP STATUS 400 – BAD REQUEST
* Body: 
```javascript
{
      "idRecurso": 0,
      "codigoMensagem": 10,
      "mensagem": "Produto sem descrição"
}
```