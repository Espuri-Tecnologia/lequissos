### URLs

> GET https://integrador.varejonline.com.br/apps/api/tabelas-preco/:id_tabela_preco/produtos

> GET https://integrador.varejonline.com.br/apps/api/tabelas-preco/:id_tabela_preco/produtos/:id

### Parâmetros

* **inicio:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **quantidade:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **alteradoApos:** [Entenda a Coleta de Alterações](https://github.com/Varejonline/api/wiki/Filtro-de-Data-Alteração)
* **getHistorico:** Indica se deve ser incluído no JSON o histórico de alterações de preço (boolean opcional)
* **produtos:** lista de ids dos produtos a serem filtrados, separados por vírgula
* **arredondar:** Indica se deve ser retornado o valor considerando o arredondamento comercial configurado no sistema (boolean opcional)

### Retorno

* **idProduto:** id do [produto](https://github.com/Varejonline/api/wiki/GET-Produtos) (long)
* **produto:** dados do produto devolvido (objeto complexo)
    * **id:** id da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos)
    * **descricao:** id da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos)
    * **codigoSistema:** Código Sistema da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos)
    * **codigoInterno:** Código Interno da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos)
    * **codigoBarras:** Código de Barras da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos)
* **preco:** preço do produto na tabela de preços (decimal)
* **ativo:** indica se o preço do produto está ativo (boolean)
* **dataAlteracao:** última data de alteração da tabela de preço, no formato dd-mm-aaaa hh:mi:ss (string)

### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/tabelas-preco/425/produtos?getHistorico=true...

```javascript
[
   {
      "id":245,
      "dataAlteracao":"13-11-2017 14:38:58",
      "preco":26.9,
      "historico":[
         {
            "dataAlteracao":"02-12-2016 01:11:21",
            "preco":25.9,
            "ativo":true
         },
         {
            "dataAlteracao":"11-08-2017 20:52:04",
            "preco":26.9,
            "ativo":true,
            "terceiroAlteracao":3
         }
      ],
      "ativo":true,
      "idProduto":245,
      "produto": {
            "id":245,
            "descricao":"BLUSA MALHA PRETA GG",
            "codigoSistema":"0001.0001",
            "codigoInterno":"",
            "codigoBarras":""
      },
      "nomeTabelaPreco":"PADRÃO",
      "isFromESB":false,
      "idTabelaPreco":1
   },
   {
      "id":243,
      "dataAlteracao":"13-11-2017 14:38:58",
      "preco":26.9,
      "historico":[
         {
            "dataAlteracao":"02-12-2016 01:11:11",
            "preco":25.9,
            "ativo":true
         },
         {
            "dataAlteracao":"11-08-2017 20:52:04",
            "preco":26.9,
            "ativo":true,
            "terceiroAlteracao":3
         }
      ],
      "ativo":true,
      "idProduto":243,
      "produto": {
            "id":243,
            "descricao":"BLUSA MALHA PRETA P",
            "codigoSistema":"0001.0002",
            "codigoInterno":"",
            "codigoBarras":""
      },
      "nomeTabelaPreco":"PADRÃO",
      "isFromESB":false,
      "idTabelaPreco":1
   }
]
```


> GET https://integrador.varejonline.com.br/apps/api/tabelas-preco/237/produtos?alteradoApos=01/01/2013 12:00:00

```javascript
[
   {
      "idProduto":19,
      "produto": {
            "id": 19,
            "descricao":"BLUSA MALHA PRETA M",
            "codigoSistema":"0001.0004",
            "codigoInterno":"",
            "codigoBarras":""
      },
      "preco":926.5,
      "ativo":true,
      "dataAlteracao":"09-10-2013 19:13:16"
   }
]
```