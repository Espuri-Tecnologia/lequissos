### URL

> POST https://integrador.varejonline.com.br/apps/api/servicos

### Parâmetros

Envie um JSON no corpo da requisição, contendo:

* **descricao:** nome do serviço (string) (obrigatório)
* **codigoInterno:** código interno do lojista (string)
* **descontoMaximo:** percentual máximo de desconto do serviço (decimal)
* **comissaoVenda:** percentual máximo de comissão do serviço (decimal)
* **tempoExecucaoMinimo:** tempo de execução mínimo do serviço (long)
* **tipoServicoJson:** serviço de acordo com a tabela federal
    * **id:** Id do tipo do serviço (long)
    * **codigo:** código do serviço na tabela federal (string)
    * **descricao:** descrição do serviço na tabela federal (string)
* **tipoServicoMunicipioJson:** serviço de acordo com a tabela municipal
    * **id:** Id do tipo do serviço (long)
    * **codigo:** código do serviço na tabela municipal (string)
    * **descricao:** descrição do serviço na tabela municipal (string)
* **ativo:** status do serviço (boolean)
* **unidade:** unidade de venda do serviço (string) (obrigatório)
* **codigoSistema:** código de negócio único do serviço (string) (obrigatório em bases com geração de código manual)
* **classificacao:** classificação do serviço (ISS/ICMS) (string)
* **especificacao:** detalhamento do serviço (string)
* **precoVariavel:** define se possui preço de tabela (false) ou é escolhido no momento da venda (true) (boolean)
* **categorias:** [categorias](https://github.com/Varejonline/api/wiki/GET-categorias-servico) do serviço, lista de: (obrigatório)
    * **id:** id da categoria (long)
    * **codigoSistema:** código da categoria (long) (obrigatório)
    * **nome:** nome da categoria (long) (obrigatório)
* **precoVenda:** valor de venda (decimal)

### Retorno
Sucesso:
* HTTP STATUS 201 – CREATED
* Body: id do serviço gerado

Requisição inválida: 
* HTTP STATUS 400 – BAD REQUEST
* Body: mensagem de erro

### Exemplo

> POST https://integrador.varejonline.com.br/apps/api/servicos

```javascript
    {
        "descricao": "BANHO INTEGRADO T2",
        "codigoInterno": "9999.0001",
        "descontoMaximo": 99,
        "comissaoVenda": 99,
        "tempoExecucaoMinimo": 30,
        "tipoServicoJson": {
            "id": 55,
            "descricao": "Banhos, duchas, sauna, massagens e congêneres.",
            "codigo": "6.03"
        },
        "tipoServicoMunicipioJson": {
            "id": 472,
            "descricao": "Banhos, duchas, sauna, massagens e congêneres.",
            "codigo": 8532
        },
        "ativo": true,
        "unidade": "SV",
        "codigoSistema": "251.0054",
        "classificacao": "SERVICO_ISS",
        "especificacao": "BANHO INTEGRADO VIA BARRAMENTO",
        "precoVariavel": false,
        "categorias": [{
            "id": 14,
            "nivel": 1,
            "nome": "BANHO E TOSA",
            "codigoSistema": 2985
        },
        {
            "id": 17,
            "nivel": 2,
            "nome": "BANHO CAO",
            "codigoSistema": 2988
        }],
        "precoVenda": 100
    }
```