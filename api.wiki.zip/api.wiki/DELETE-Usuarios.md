### URLs

> DELETE https://integrador.varejonline.com.br/apps/api/usuarios/:idUsuario

### Parâmetros

* **idUsuario:** ID do [Usuario](https://github.com/Varejonline/api/wiki/GET-Usuarios) que deve ser desativado (Long - Path Param)

### Retorno

Retorna um JSON com informações do resultado da operação realizada, contendo:

* **codigoMensagem:** Código de identificação da operação realizada. [Veja a lista de Códigos](https://github.com/Varejonline/api/wiki/Retorno-API)
* **mensagem:** Mensagem da operação realizada

Requisição inválida: 
* HTTP STATUS 400 – BAD REQUEST
* Body: mensagem de erro