### URL

> POST https://integrador.varejonline.com.br/apps/api/gestao-franquias/grupos-franquias

### Parâmetros

Envie um JSON no corpo da requisição, contendo:
* **nome:** nome do grupo de franquias (string)
* **ativo:** indica se o grupo está ativo (boolean)
* **franquias:** lista de [franquias](https://github.com/Varejonline/api/wiki/GET-franquias)
   * **id:** id da franquia (long)
   * **documento:** documento da franquia (string)

### Exemplo de retorno:

_Sucesso:_
* HTTP STATUS 201 – CREATED
* Body:
```javascript
{
      "idRecurso": 1,
      "codigoMensagem": 0,
      "mensagem": "Operação realizada com sucesso."
}
```

### Exemplo

> POST https://integrador.varejonline.com.br/apps/api/gestao-franquias/grupos-franquias

'Content-Type'='application/json'

```javascript
{
  "nome": "FRANQUIAS FG",
  "franquias": [
    {
      "id": 1596069,
      "documento": "35.910.952/0001-27"
    },
    {
      "id": 1596733,
      "documento": "17.622.696/0001-90"
    }
  ],
  "ativo": true
}
```