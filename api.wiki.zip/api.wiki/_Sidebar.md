### [Home](/Varejonline/api/wiki/)

### Introdução

* [Integrando com o Varejonline](/Varejonline/api/wiki/Cadastro)
* [Webhook](/Varejonline/api/wiki/Entenda-o-Webhook)
* [Limite de requisição (Rate Limit)](/Varejonline/api/wiki/Limite-de-requisição-(Rate-Limit))
* [Uso do Token](/Varejonline/api/wiki/OAuth-2.0#usando-o-token)

### Endpoints de Integração

Administrativo

 * [GET dados-login](/Varejonline/api/wiki/GET-dados-login)
 * [GET empresas](/Varejonline/api/wiki/GET-empresas)
 * [GET entidades](/Varejonline/api/wiki/GET-entidades)
 * [GET Grupo entidades](/Varejonline/api/wiki/Get-grupo-entidades)
 * [GET Campos Custom.](/Varejonline/api/wiki/GET-Campos-Customizados)
 * [Terceiros](/Varejonline/api/wiki/Endpoints-Terceiros)
 * [GET classificacoes-clientes](/Varejonline/api/wiki/GET-classificacoes-clientes)
 * [Usuários](/Varejonline/api/wiki/Endpoints-Usuarios)
 * [GET permissao-usuario](/Varejonline/api/wiki/GET-permissao-usuario)
 * [GET marcas](/Varejonline/api/wiki/GET-marcas)
 * [Franquias](/Varejonline/api/wiki/Endpoints-Franquias)

Comercial

 * [GET comissao](/Varejonline/api/wiki/GET-comissao)
 * [Vouchers](/Varejonline/api/wiki/Endpoints-Vouchers)
 * [Representantes](/Varejonline/api/wiki/Endpoints-Representantes)

Compras

 * [Pedidos de compra](/Varejonline/api/wiki/Endpoints-Pedidos-Compra)
 * [Planos de pagamento de compras](/Varejonline/api/wiki/Endpoints-planos-pagamento-compras)
 * [POST XML Entrada](/Varejonline/api/wiki/POST-XML-Entrada)
 * [POST vincular-epcs](/Varejonline/api/wiki/POST-vincular-epcs)

Financeiro

 * [Adiantamentos](/Varejonline/api/wiki/Endpoints-adiantamentos)
 * [POST baixas](/Varejonline/api/wiki/POST-baixas)
 * [POST estorno baixa](/Varejonline/api/wiki/POST-Estorno-Baixa)
 * [GET boletos](/Varejonline/api/wiki/GET-boletos)
 * [POST boletos](/Varejonline/api/wiki/POST-boletos)
 * [GET Impressao boletos](/Varejonline/api/wiki/GET-impressao)
 * [GET contas-disponibilidade](/Varejonline/api/wiki/GET-contas-disponibilidade)
 * [GET contas-pagar](/Varejonline/api/wiki/GET-contas-pagar)
 * [GET contas-receber](/Varejonline/api/wiki/GET-contas-receber)
 * [GET lancamentos-padroes](/Varejonline/api/wiki/GET-lancamentos-padroes)
 * [GET negociacoes-cartao](/Varejonline/api/wiki/GET-negociacoes-cartao)
 * [GET planos-gerenciais](/Varejonline/api/wiki/GET-planos-gerenciais)
 * [GET plano-contabil](/Varejonline/api/wiki/GET-demonstrativo-contabil)
 * [GET planos-financeiro](/Varejonline/api/wiki/GET-demonstrativo-financeiro)
 * [GET previsoes](/Varejonline/api/wiki/GET-previsoes)
 * [POST provisoes](/Varejonline/api/wiki/POST-provisoes)
 * [DELETE Provisão](https://github.com/Varejonline/api/wiki/DELETE-Provisão)
 * [POST reneg. receber](/Varejonline/api/wiki/Renegociação-Contas-Receber)
 * [POST reneg. pagar](https://github.com/Varejonline/api/wiki/Renegociação-Contas-Pagar)
 * [PUT transacao-cartao](https://github.com/Varejonline/api/wiki/PUT-Ajuste-Transações-de-Cartão)

Controle de crédito

 * [GET limite-credito](https://github.com/Varejonline/api/wiki/GET-limite-dispon%C3%ADvel)
 * [PUT limites-credito](https://github.com/Varejonline/api/wiki/PUT-Limites-Cr%C3%A9dito)

Fiscal

 * [GET Classificação produtos](/Varejonline/api/wiki/GET-classificacoes-fiscais-produtos)
 * [GET Conhecim. transporte](/Varejonline/api/wiki/GET-conhecimentos-transporte)
 * [GET Notas consumo](/Varejonline/api/wiki/GET-notas-consumo)
 * [GET Notas mercadoria](/Varejonline/api/wiki/GET-notas-mercadoria)
 * [GET XML Notas mercadoria](/Varejonline/api/wiki/GET-XML-notas-mercadoria)
 * [GET DANFE Notas mercadoria](/Varejonline/api/wiki/GET-DANFE-notas-mercadoria)
 * [GET Inutilização Notas mercadoria](/Varejonline/api/wiki/GET-notas-mercadoria-inutilizacao)
 * [GET Notas serviço](/Varejonline/api/wiki/GET-notas-servico)
 * [GET Reducoes-z](/Varejonline/api/wiki/GET-reducoes-z)
 * [Notas fiscais devolução](/Varejonline/api/wiki/Endpoints-nota‐fiscal‐devolucao)

Contábil

 * [GET lancamentos](https://github.com/Varejonline/api/wiki/GET-Lançamentos-Contábeis)
 * [POST lancamentos](https://github.com/Varejonline/api/wiki/POST-Lançamentos-Contábeis)
 * [GET contas](https://github.com/Varejonline/api/wiki/GET-Contas-Contábeis)

Operacional

 * [Produtos](/Varejonline/api/wiki/Endpoints-Produtos)
 * [Serviços](/Varejonline/api/wiki/Endpoints-Servicos)
 * [Estoque/saldo e reserva de estoque de produtos](/Varejonline/api/wiki/Endpoints-Estoque-e-Reservas)
 * [Pedidos de venda](/Varejonline/api/wiki/Endpoints-Pedidos)
 * [Orçamentos](/Varejonline/api/wiki/Endpoints-Orcamentos)
 * [Tabelas e preços](/Varejonline/api/wiki/Endpoints-Precos)
 * [Ações promocionais](/Varejonline/api/wiki/Endpoints-acoes-promocionais)
 * [Níveis e categorias](/Varejonline/api/wiki/Endpoints-Categorias)
 * [Unidades](/Varejonline/api/wiki/Endpoints-Unidades)
 * [GET canais-digitais](/Varejonline/api/wiki/GET-canais-digitais)
 * [GET conferencias-caixa](/Varejonline/api/wiki/GET-conferencias-caixa)
 * [GET custo-produtos](/Varejonline/api/wiki/GET-Custo-Produtos)
 * [GET devolucoes](/Varejonline/api/wiki/GET-devolucoes)
 * [GET entradas](/Varejonline/api/wiki/GET-entradas)
 * [POST entradas](/Varejonline/api/wiki/POST-entradas)
 * [GET planos-pagamento](/Varejonline/api/wiki/GET-planos-pagamento)
 * [GET atendimentos](/Varejonline/api/wiki/GET-Atendimentos)
 * [GET saidas](/Varejonline/api/wiki/GET-saidas)
 * [POST entrada movimentação própria](/Varejonline/api/wiki/Entrada-movimentação-própria)
 * [POST saída movimentação própria](/Varejonline/api/wiki/Saída-movimentação-própria)
 * [POST transferencia](/Varejonline/api/wiki/POST-Transferencia)
 * [GET atributos de produto](/Varejonline/api/wiki/GET-atributos-de-produtos)

### Dicas Gerais

 * [Integração com Ecom](https://github.com/Varejonline/api/wiki/Roteiro-de-integra%C3%A7%C3%A3o-com-Ecom)
 * [Coleta de Alterações](/Varejonline/api/wiki/Filtro-de-Data-Alteração)
 * [Paginação de Resultados](/Varejonline/api/wiki/Paginação-de-resultados)
 * [Obter Pagamento de Vendas](/Varejonline/api/wiki/Capturar-Pagamento-de-Vendas)
 * [Nota de Devolução de Venda](/Varejonline/api/wiki/Nota-fiscal-de-devolu%C3%A7%C3%A3o-venda)

### Filtros Padrões

 * [Filtro de Datas](/Varejonline/api/wiki/Filtro-de-Datas)
 * [Filtro de Entidades](/Varejonline/api/wiki/Filtro-de-Entidades)
 * [Filtro de CPF ou CNPJ](/Varejonline/api/wiki/Filtro-documento)
 * [Filtro de Representantes](/Varejonline/api/wiki/Filtro-de-Representantes)
 * [Filtro de Terceiro](/Varejonline/api/wiki/Filtro-de-Terceiro)
 * [Filtro de Integração](/Varejonline/api/wiki/Controle-de-registros-integrados)

### Tabelas Padrões

 * [Tipos de Docs Financeiros](https://github.com/Varejonline/api/wiki/Tipos-de-Documentos-Financeiros)
 * [Origens de Mercadorias](https://github.com/Varejonline/api/wiki/Origens-de-Mercadoria)
 * [Tipos de Escrituração](https://github.com/Varejonline/api/wiki/Tipos-de-Escrituração)
 * [Tipos de Campos Custom.](https://github.com/Varejonline/api/wiki/Tipos-de-Campos-Customizados)
 * [Classe de Terceiro](https://github.com/Varejonline/api/wiki/Classes-de-Terceiro)
 * [Modelos de Docs Fiscais](https://github.com/Varejonline/api/wiki/Modelos-de-Notas-Fiscais)
 * [Tipos de Docs Fiscais](https://github.com/Varejonline/api/wiki/Tipo-de-Documentos-Fiscais)
 * [Tipos de Movimento](https://github.com/Varejonline/api/wiki/Tipos-de-Movimentos)
 * [Códigos de Retorno](https://github.com/Varejonline/api/wiki/Retorno-API)
 * [Status de venda](https://github.com/Varejonline/api/wiki/Status-de-venda)
 * [Status ped. compras](https://github.com/Varejonline/api/wiki/Status-de-pedido-de-compra)

### Atualizações

* [Change Log](https://github.com/Varejonline/api/wiki/Change-Log)