### URL

> POST https://integrador.varejonline.com.br/apps/api/transferencia

### Parâmetros
Envie um JSON no corpo da requisição, contendo:

* **remetente:** [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) remetente utilizada (objeto complexo)
    * **id:**  id do remetente (long)
* **destinatario:** [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) destinatário utilizada (objeto complexo)
    * **id:**  id do destinatário (long)
* **idOperacaoEntrada:** valor que indica o id de operação de entrada (long)
* **idOperacaoSaida:** valor que indica o id de operação de saída (long)
* **tipoValor:** CUSTO (custo médio), VENDA (preço de venda) ou ULTIMA_COMPRA (string)
* **produtos:** lista de itens a serem transferidos, contendo:
  * **produto:** (obrigatório informar o id e/ou código sistema do item)
       * **id:** id do [produto](https://github.com/Varejonline/api/wiki/GET-Produtos) (long)
       * **codigoSistema:** código de sistema do produto (string)
  * **unidade:** [unidade](https://github.com/Varejonline/api/wiki/GET-unidades) de medida usada na quantidade o item informada (string)
  * **quantidade:** quantidade do item (long)

### Retorno:
Sucesso:
* HTTP STATUS 201 - CREATED

Retorna um Json com informações do resultado da operação realizada, contendo:
* **idRecurso:** id da tranferência.
* **codigoMensagem:** Código de identificação da operação realizada. [veja a lista de Códigos](https://github.com/Varejonline/api/wiki/Retorno-API)
* **mensagem:** Mensagem da operação realizada

Requisição inválida: 
* HTTP STATUS 400 – BAD REQUEST
* Body: mensagem de erro

### Exemplo

> POST https://integrador.varejonline.com.br/apps/api/transferencia

```javascript
{
  "remetente": {
      "id": 6
  },
  "destinatario": {
      "id": 9
  },
  "idOperacaoEntrada": 1017,
  "idOperacaoSaida": 1024,
  "tipoValor": "VENDA",
  "produtos": [
    {
      "produto": { 
        "id": 112767
      },
      "unidade": "CX",
      "quantidade": 1
    },
    {
      "produto": {
        "codigoSistema": "0001.0002"
       },
       "unidade": "PC",
       "quantidade": 1
     }
  ]
}

```