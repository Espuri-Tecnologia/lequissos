O saldo de uma mercadoria representa a quantidade disponível em estoque de um produto para uma certa entidade. 

### URLs

> GET https://integrador.varejonline.com.br/apps/api/saldos-mercadorias

### Parâmetros

* **produtos:** lista de ids dos produtos cujos saldos se deseja obter, separados por vírgula
* **entidades:** [Veja como Funciona este Filtro](https://github.com/Varejonline/api/wiki/Filtro-de-Entidades)
* **inicio:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **quantidade:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **alteradoApos:** [Entenda a Coleta de Alterações](https://github.com/Varejonline/api/wiki/Filtro-de-Data-Alteração)
* **data:** data de referência para o saldo. Se não for informada, será retornado o saldo na data atual.
* **somenteEcommerce:** Permite filtrar somente produtos integráveis no ecommerce (true) ou todos (false) (Boolean Opcional)
* **somenteMarketplace:** Permite filtrar somente produtos integráveis no marketplace (true) ou todos (false) (Boolean Opcional)

**Observações**

Os parâmetros **alteradoApos** e **data** são mutuamente exclusivos, ou seja, usando um deles o outro não será utilizado. Por regra de precedência, caso os dois sejam informados, será criada uma consulta por data de alteração.

Quando não informado o parâmetro **alteradoApos**, a API retorna os saldos consolidados do produto por entidade. Esse é o mesmo comportamento da busca utilizando o parâmetro **data**. Será retornado apenas um registro de saldo por entidade onde o saldo retornado será o total disponível da mercadoria naquela loja.

Quando o parâmetro **data** não for informado nem o parâmetro **alteradoApos**, será utilizada a data atual para consulta consolidada de saldos por loja.

### Retorno

* **entidade:** [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) à qual o saldo se refere  (objeto complexo)
    * **id:** id da entidade (long)
    * **nome:** nome da entidade (string)
    * **documento:** documento da entidade (string)
* **produto:** dados do produto devolvido (objeto complexo)
    * **id:** id da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos)
    * **descricao:** id da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos)
    * **codigoSistema:** Código Sistema da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos)
    * **codigoInterno:** Código Interno da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos)
    * **codigoBarras:** Código de Barras da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos)
* **quantidade:** quantidade em estoque do produto (decimal)
* **dataAlteracao:** última data de alteração do saldo, no formato dd-mm-aaaa hh:mi:ss 
* **data:** data de referência do saldo, no formato dd-mm-aaaa 

### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/saldos-mercadorias?produtos=11,4,5&entidades=1,2,3

```javascript
[
   {
      "entidade": {
          "id": 3,
          "nome": "Entidade teste",
          "documento": "00.000.000/0000-00"
      },
      "quantidade":500,
      "dataAlteracao": "12/12/2012 23:30:00",
      "produto": {
            "id":9342,
            "descricao":"BLUSA MALHA PRETA GG",
            "codigoSistema":"0001.0001",
            "codigoInterno":"",
            "codigoBarras":""
      },
      "data": "12/12/2012"
   },
   {
      "entidade": {
          "id": 3,
          "nome": "Entidade teste",
          "documento": "00.000.000/0000-00"
      },
      "quantidade":0,
      "dataAlteracao": "12/12/2012 23:30:00",
      "produto": {
            "id":9343,
            "descricao":"BLUSA MALHA PRETA P",
            "codigoSistema":"0001.0002",
            "codigoInterno":"",
            "codigoBarras":""
      },
      "data": "12/12/2012"
   }
]
```