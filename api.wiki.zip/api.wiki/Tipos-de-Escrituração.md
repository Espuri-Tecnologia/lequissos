### NAO_ESCRITURADA

Notas não escrituradas no sistema.

### ESCRITURADA_EXTERNO

Notas escrituradas automaticamente.

### ESCRITURADA_INTERNO

Notas escrituradas pela escrituração manual.   