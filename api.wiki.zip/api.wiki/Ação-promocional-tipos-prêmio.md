<table>
<tr><th>Tipos de prêmio</th></tr>
<tr><td>BRINDE</td></tr>
<tr><td>DESCONTO</td></tr>
<tr><td>DESCONTO_PRODUTO</td></tr>
<tr><td>DESCONTO_ITENS_ACAOPROMOCIONAL</td></tr>
<tr><td>DESCONTO_NO_ITEM_DE</td></tr>
</table>
