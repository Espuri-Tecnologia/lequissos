API para consulta de apurações de comissão. Somente são retornados registros gerados com tipo de apuração: por vendedor.

### URLs

> GET https://integrador.varejonline.com.br/apps/api/comissao

### Parâmetros

* **desde:** [Veja o Filtro de Datas](https://github.com/Varejonline/api/wiki/Filtro-de-Datas) (Obrigatório)
* **ate:** [Veja o Filtro de Datas](https://github.com/Varejonline/api/wiki/Filtro-de-Datas) (Obrigatório)
* **representantes:** [Lista de Vendedores](https://github.com/Varejonline/api/wiki/Filtro-de-Representantes) que realizaram as vendas associadas à apuração 
* **entidades:** [Lista de Entidades](https://github.com/Varejonline/api/wiki/Filtro-de-Entidades) onde foram realizadas as vendas associadas à apuração 

### Retorno

* **representanteId** id do [vendedor](https://github.com/Varejonline/api/wiki/GET-representantes) associado à comissão (long).
* **entidadeId** id da [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) onde a comissão foi gerada (long).
* **numeroComissao** número da apuração da comissão (string).
* **dataComissao** data em que a apuração foi realizada, no formato dd-mm-aaaa (string).
* **valorComissao** valor da comissão calculada (BigDecimal).
* **dataVencimento** data do primeiro vencimento para pagamento da comissão ao [vendedor](https://github.com/Varejonline/api/wiki/GET-representantes), no formato dd-mm-aaaa (string).
* **itens:** itens de venda considerados no cálculo da comissão
   * **idProduto:** id do produto/serviço vendido considerado na apuração da comissão (long)
   * **idPedido:** id do pedido de venda onde está o item vendido (long)
   * **dataPedido** data do pedido de venda onde está o item vendido, no formato dd-mm-aaaa (string)
   * **valorUnitario:** valor unitário do produto/serviço vendido (BigDecimal)
   * **porcentagemComissao:** percentual de comissão aplicado sobre o valor líquido do item na venda (decimal)
   * **valorRealizado:** valor da comissão realizada (pendente de pagamento ao [vendedor](https://github.com/Varejonline/api/wiki/GET-representantes)) (decimal)
   * **valorFaturado:** valor da comissão faturado (decimal)

### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/comissao?desde=01/03/2015&ate=31/03/2015

```javascript
[
   {
      "dataVencimento":"10-03-2015",
      "itens":[
         {
            "idProduto":3219,
            "valorUnitario":83.2000,
            "porcentagemComissao":20,
            "valorFaturado":85.280000,
            "valorRealizado":0,
            "idPedido":2577,
            "dataPedido":"10-03-2015",
         }
      ],
      "entidadeId":16,
      "numeroComissao":"00042-15",
      "valorComissao":17.06,
      "dataComissao":"25-03-2015",
      "representanteId":13
   }
]
```