Esta API tem como intuito facilitar a manutenção em lote para vários clientes.

Você também pode inserir o limite de crédito de forma indivual diretamente no cadastro do cliente (terceiro) pelos endpoints de cadastro e edição de terceiros:
## [POST Terceiros](/Varejonline/api/wiki/POST-terceiros)
## [PUT Terceiros](/Varejonline/api/wiki/PUT-terceiros)

### URL

> POST https://integrador.varejonline.com.br/apps/api/limites-creditos/lote

### Parâmetros

Envie um JSON no corpo da requisição, contendo:
* **limites:** lista de limites _(obrigatório)_
    * **terceiro:** [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros) utilizado (obrigatório) (objeto complexo)
        * **id:**  id do terceiro (opcional) (long)
        * **documento:** documento do terceiro (opcional) (string)
    * **limite:** Define os valores de limite de crédito para o terceiro (objeto complexo).
        * **valorTotal:** limite de crédito total (long)
        * **valorMensal:** limite de crédito mensal (long)
        * **valorRenda:** valor da renda do terceiro (long)

### Exemplo

> PUT https://integrador.varejonline.com.br/apps/api/limites-creditos/lote

'Content-Type'='application/json'

```javascript
{
    "limites": [
        {
            "terceiro": {
                "documento": "603.262.490-01"
            },
            "limite": {
                "valorTotal": 900,
                "valorMensal": 300,
                "valorRenda": 0
            }
        }
    ]
}
```

_Requisição inválida:_
* HTTP STATUS 400 – BAD REQUEST
* Body: 
```javascript
{
      "idRecurso": 0,
      "codigoMensagem": 1,
      "mensagem": "A configuração de crédito não permite limite total."
}
```