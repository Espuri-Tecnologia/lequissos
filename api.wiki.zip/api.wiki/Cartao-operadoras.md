Listagem das possíveis operadoras nas transações com cartão

<table>
<tr><th>Operadora</th></tr>
<tr><td>ADYEN</td></tr>
<tr><td>ALEGRIA</td></tr>
<tr><td>AMEX</td></tr>
<tr><td>Apple Pay</td></tr>
<tr><td>BANESE</td></tr>
<tr><td>BANRICOMPRAS</td></tr>
<tr><td>BANRISUL</td></tr>
<tr><td>BELLUNO</td></tr>
<tr><td>BIN</td></tr>
<tr><td>BLU</td></tr>
<tr><td>BONUSCRED</td></tr>
<tr><td>BR CARD</td></tr>
<tr><td>BRADESCO</td></tr>
<tr><td>Caixa</td></tr>
<tr><td>CALCARD</td></tr>
<tr><td>CIELO</td></tr>
<tr><td>CONDUCTOR</td></tr>
<tr><td>CONVCARD</td></tr>
<tr><td>CREDILOJA</td></tr>
<tr><td>CREDISHOP</td></tr>
<tr><td>CREDSYSTEM</td></tr>
<tr><td>C6 PAY</td></tr>
<tr><td>DACASA</td></tr>
<tr><td>DELTAPAG</td></tr>
<tr><td>ELAVON</td></tr>
<tr><td>FISERV</td></tr>
<tr><td>FORTBRASIL</td></tr>
<tr><td>FROGPAY</td></tr>
<tr><td>GETNET</td></tr>
<tr><td>GETNETLAC</td></tr>
<tr><td>GLOBAL PAYMENTS</td></tr>
<tr><td>gocap</td></tr>
<tr><td>Google Pay</td></tr>
<tr><td>GRANITO</td></tr>
<tr><td>INFINITE PAY</td></tr>
<tr><td>I9PAY</td></tr>
<tr><td>JUSTA</td></tr>
<tr><td>Listo.</td></tr>
<tr><td>MagaPay</td></tr>
<tr><td>MAXIPAGO</td></tr>
<tr><td>MAXX</td></tr>
<tr><td>MERCADOPAGO</td></tr>
<tr><td>MULTIPLUS</td></tr>
<tr><td>PAGAR.ME</td></tr>
<tr><td>PAGSEGURO</td></tr>
<tr><td>PARATI</td></tr>
<tr><td>PAYPAL</td></tr>
<tr><td>PICPAY</td></tr>
<tr><td>POP BANK</td></tr>
<tr><td>Rappi</td></tr>
<tr><td>REDECARD</td></tr>
<tr><td>SAFRAPAY</td></tr>
<tr><td>Samsung Pay</td></tr>
<tr><td>Samup</td></tr>
<tr><td>SANTANDER</td></tr>
<tr><td>SENFF</td></tr>
<tr><td>SERVILOJA</td></tr>
<tr><td>SICREDI</td></tr>
<tr><td>SIPAG</td></tr>
<tr><td>SOULPAY</td></tr>
<tr><td>STONE</td></tr>
<tr><td>TECBIZ</td></tr>
<tr><td>TKS</td></tr>
<tr><td>TON</td></tr>
<tr><td>UTIL card</td></tr>
<tr><td>VECELL CARD</td></tr>
<tr><td>VERO</td></tr>
<tr><td>Vindi</td></tr>
<tr><td>VOUCHER TRIP</td></tr>
<tr><td>Work 8</td></tr>
<tr><td>YESPAY</td></tr>
</table>