Este endpoint tem como intuito a recepção de uma lista com múltiplos pedidos e seu processamento é assíncrono.

### URL

> POST https://integrador.varejonline.com.br/apps/api/pedidos/lote

### Parâmetros

Envie um JSON no corpo da requisição, contendo:

* **codigo:** código gerencial para o lote (não obrigatório) (string)
* **pedidos:** lista de pedidos com as mesmas propriedades do [POST-Pedidos](https://github.com/Varejonline/api/wiki/POST-pedidos)

### Retorno

Sucesso HTTP 201 CREATED:

Retorna um Json com informações do resultado da operação realizada, contendo:

* **idRecurso:** id do lote gerado.
* **codigoMensagem:** Código de identificação da operação realizada. [veja a lista de Códigos](https://github.com/Varejonline/api/wiki/Retorno-API)
* **mensagem:** Mensagem da operação realizada

Requisição inválida: 
* HTTP STATUS 400 – BAD REQUEST
* Body: mensagem de erro

### Exemplo

> POST https://integrador.varejonline.com.br/apps/api/pedidos/lote

'Content-Type'='application/json'
```javascript
{
 "codigo": "PRS-152-Z",
 "pedidos": [
  {
      "data": "04-09-2012",
      "horario": "15:28:05",
      "entidade": {
         "id": 1,
         "documento": "00.000.000/0000-00"
      },
      "terceiro": {
         "id": 1,
         "documento": "000.000.000-00"
      },
      "valorDesconto": 50,
      "descontoDetalhes": [
       {
         "observacao": "API-Produto",
         "valor": 50,
         "origemDesconto": "MANUAL"
        }
      ],
      "representante": {
          "nome": "NOME DO VENDEDOR",
          "id": 1
      },
      "plano": {
          "descricao": "CREDIÁRIO 1X",
          "id": 12
      },
      "observacao": "Novo pedido",
      "valorFrete": 23.80,
      "valorOutros": 10,
      "valorSeguro": 1.50,
      "vendaConsumidorFinal": true,
      "itens": [
          {
              "produto": {
                  "id": 245
              },
              "quantidade": 1,
              "valorUnitario": 10.90,
              "valorDesconto": 0.90,
              "descontoDetalhes": [
                 {
                    "observacao": "API-Produto",
                    "valor": 50,
                    "origemDesconto": "MANUAL"
                 }
              ],
              "dataEntrega": "30-06-2020",
              "operacao": 1093,
              "reservarEstoque": true
          },
          {
              "produto": {
                  "codigoSistema": "0001.0002"
              },
              "quantidade": 3,
              "valorUnitario": 34.05,
              "valorDesconto": 0,
              "operacao": 1
          }
      ],
      "servicos": [
          {
              "idServico": 18,
              "quantidade": 10,
              "valorUnitario": 11.50,
              "valorDesconto": 0.10
          }
      ],
      "emitirNotaFiscal": false,
      "enviarEmailNota": false,
      "origem": "MARKETPLACE",
      "tipo": "NORMAL",
      "pagamento": {
          "valorDinheiro": 450,
          "cartoes": [
              {
                  "operadoraNome": "STONE",
                  "bandeiraNome": "ELO",
                  "nsu": "12321321",
                  "autorizacao": "1232321",
                  "dataHora": "01-01-2022 08:50:50",
                  "tipo": "CREDITO",
                  "quantidadeParcelas": 2,
                  "valor": 45.3,
                  "parcelamento": "PARCELAMENTO_LOJISTA"
              },
              {
                  "negociacao": 33,
                  "nsu": "12321321",
                  "autoriacao": "1232321",
                  "dataHora": "01-01-2022 08:50:50",
                  "quantidadeParcelas": 2,
                  "valor": 49.3
              }
          ],
          "cheques": [
              {
                  "titular": 2,
                  "banco": "1",
                  "agencia": "2",
                  "conta": "313",
                  "numero": "635",
                  "valor": "48.3",
                  "vencimento": "01-01-2022"
              }
          ],
          "vales": [
              {
                  "numero": "29-2010",
                  "valor": 2
              }
          ],
          "adiantamentos": [
              {
                  "id": 131,
                  "valor": 10
              }
          ],
          "crediario": {
              "plano": 103,
              "valor": 20,
              "valorAcrescimo": 0,
              "parcelas": [
                  {
                      "numero": 1,
                      "valor": 28.3,
                      "vencimento": "18-01-2022"
                  },
                  {
                      "numero": 2,
                      "valor": 20,
                      "vencimento": "24-01-2022"
                  }
              ]
          },
          "boletos": [
              {
                  "valor": 48.3,
                  "identificacao": "XPTO",
                  "dataVencimento": "07-02-2022 08:50:50",
                  "dataPagamento": "07-02-2022 08:50:50",
                  "codigoConta": "1138-40"
              }
          ],
  	"vouchers": [
  	   {
  		"voucher": {
  		   "id": 1001
  		},
  		"valor": 10
  	   },
  	   {
  		"voucher": {
  		   "id": 1002
  		},
  		"valor": 14
  	   }
  	],
          "pixes": [
              {
                  "valor": 1,
                  "dataPagamento": "07-02-2022 08:50:50",
                  "nsu": 15000000
              }
          ]
      },
      "cnpj": "",
      "enderecoEntrega": {
          "logradouro": "Rua iririu",
          "numero": "1777",
          "complemento": "Em cima do bradesco",
          "bairro": "Iririu",
          "cep": "89227-000",
          "cidade": "Joinville",
          "uf": "SC",
          "receptorEntrega": "Maria",
          "receptorEntregaDocumento": "000.000.000-00"
      },
      "intermediador": {
          "id": 1
      },
      "transporte": {
          "modalidade": "EMITENTE",
          "transportador": {
              "id": 1
          },
          "codigoANTT": "ABC1777",
          "placaVeiculo": "AFE8B87",
          "estadoVeiculo": "SC",
          "quantidade": "2",
          "especie": "CAIXA",
          "marca": "ASD",
          "numero": "23",
          "pesoBruto": 50,
          "pesoLiquido": 40
      }
  }
 ]
}
```