 ## [GET terceiros](/Varejonline/api/wiki/GET-terceiros)
 ## [POST terceiros](/Varejonline/api/wiki/POST-terceiros)
 ## [PUT terceiros](/Varejonline/api/wiki/PUT-terceiros)
