GET Acoes promocionais

### URLs

> GET https://integrador.varejonline.com.br/apps/api/acoes-promocionais

> GET https://integrador.varejonline.com.br/apps/api/acoes-promocionais/:id

### Parâmetros

* **entidades:** [Veja como Funciona este Filtro](https://github.com/Varejonline/api/wiki/Filtro-de-Entidades)
* **inicio:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **quantidade:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **alteradoApos:** [Entenda a Coleta de Alterações](https://github.com/Varejonline/api/wiki/Filtro-de-Data-Alteração)
* **descricao:** (String)
* **localizador:** (String)
* **vigenciaInicio:** deve ser usado junto com vigenciaFim (String dd-mm-yyyy ou dd/mm/yyyy)
* **vigenciaFim:** (String dd-mm-yyyy ou dd/mm/yyyy)
* **ativa:** true: ativas, false: inativas, null: todas (Boolean)
* **excluida:** true: excluídas, false: não excluídas, null: todas  (Boolean)
* **modalidades:** QUANTIDADE, VALOR ou COMBINACAO. Separados por vírgula (List String)
* **objetivos:** [objetivos](https://github.com/Varejonline/api/wiki/A%C3%A7%C3%B5es-promocionais-objetivos). Separados por vírgula (List String)


### Exemplo

Neste exemplo, a ação tem como alvo combinações de categorias de produtos, cada combinação possui seus prêmios.

> GET https://integrador.varejonline.com.br/apps/api/acoes-promocionais/?modalidades=COMBINACAO&quantidade=1

```javascript
{
    "id": 281,
    "descricao": "Exemplo combinação de itens com estrutura mercadológica",
    "ativa": true,
    "excluida": false,
    "considerarTodoEstoque": false,
    "integraRedeFranquia": false,
    "vigenciaInicial": "02-10-2023",
    "motivoDesconto": "exemplo desconto",
    "vigenciaFinal": "02-11-2023",
    "dataAlteracao": "26-09-2023 09:47:58",
    "dataCriacao": "26-09-2023 09:39:01",
    "localizador": "exemplo localizador",
    "objetivo": "BAIXAR_EXCESSO_ESTOQUE",
    "entidades": [
        {
            "id": 3,
            "nome": "DÉPOSITO CENTRAL",
            "documento": "00.000.000/0000-01"
        },
        {
            "id": 7,
            "nome": "TESTE AUTOMATIZADO - REAL",
            "documento": "00.000.000/0000-02"
        }
    ],
    "combinacoes": [
        {
            "combinacaoEstruturas": [
                {
                    "categoriasProduto": [1,11,7],
                    "quantidade": 1
                }
            ],
            "premios": [
                {
                    "desconto": 10,
                    "tipoConfiguracao": "MAIOR_VALOR_VENDA",
                    "pontoFidelidade": 0,
                    "tipoDesconto": "VALOR",
                    "tipoPremio": "DESCONTO_NO_ITEM_DE"
                }
            ]
        },
        {
            "combinacaoEstruturas": [
                {
                    "categoriasProduto": [1, 6],
                    "quantidade": 1
                },
                {
                    "categoriasProduto": [2, 8],
                    "quantidade": 2
                }
            ],
            "premios": [
                {
                    "produtos": [
                        {
                            "id": 24,
                            "descricao": "AGUA MINERAL SEM GÁS",
                            "codigoBarras": "7896451198143",
                            "codigoInterno": "102030",
                            "codigoSistema": "0042"
                        }
                    ],
                    "tipoConfiguracao": "PRODUTO",
                    "tipoPremio": "BRINDE"
                },
                {
                    "desconto": 5,
                    "tipoConfiguracao": "MENOR_VALOR_VENDA",
                    "tipoDesconto": "PERCENTUAL",
                    "tipoPremio": "DESCONTO_NO_ITEM_DE"
                }
            ]
        }
    ],
    "regra": {
        "modalidade": "COMBINACAO",
        "restricao": {
            "permiteAcumuloComOutrasAcoes": true,
            "documentoObrigatorio": false,
            "somentePagamentoDinheiro": false,
            "usoUnicoCliente": false,
            "utilizarAtivador": false
        }
    }
}
```

