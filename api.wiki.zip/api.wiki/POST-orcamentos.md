### URL

> POST https://integrador.varejonline.com.br/apps/api/orcamentos

### Parâmetros

Envie um JSON no corpo da requisição, contendo:

* **validade:** dias de validade para o vencimento do orçamento (long obrigatório)
* **entidade:** [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) utilizada (obrigatório) (objeto complexo)
    * **id:** id da entidade (opcional) (long)
    * **documento:** documento da entidade (opcional) (string)
* **terceiro:** [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros) utilizado (obrigatório) (objeto complexo)
    * **id:**  id do terceiro (opcional) (long)
    * **documento:** documento do terceiro (opcional) (string)
* **itens:** lista de itens do orçamento, contendo:
   * **produto:** (obrigatório se existir itens)
       * **id:** id do [produto](https://github.com/Varejonline/api/wiki/GET-Produtos)
       * **codigoSistema:** código de sistema do produto.
   * **quantidade:** quantidade do item (decimal obrigatório se existir itens)
   * **valorUnitario:** valor unitário bruto do item do orçamento (decimal obrigatório se existir itens)
   * **valorDesconto:** valor do desconto total do item no orçamento (decimal opcional)
   * **operacao:** id da [operação](https://github.com/Varejonline/api/wiki/Tipo-de-operação-em-itens-movimentados) utilizada para o item (long)
* **servicos:** lista de serviços do orçamento, contendo:
   * **servico:** (obrigatório se existir itens)
       * **id:** id do [serviço](https://github.com/Varejonline/api/wiki/GET-servicos)
       * **codigoSistema:** código de sistema do serviço.
   * **quantidade:** quantidade do serviço (decimal obrigatório se existir serviços)
   * **valorUnitario:** valor unitário bruto do serviço do orçamento (decimal obrigatório se existir serviços)
   * **valorDesconto:** valor do desconto total do serviço no orçamento (decimal opcional)
* **valorFrete:** valor de frete do orçamento (decimal opcional)
* **valorSeguro:** valor de seguro do orçamento (decimal opcional)
* **valorOutros:** valor de outros do orçamento (decimal opcional)
* **numeroPedidoCliente:** Número do pedido que originou o orçamento (string opcional)
* **plano:** (Informar o id e/ou descrição do plano) (objeto complexo, opcional. Padrão: À vista)
  * **id** do [plano de pagamento](https://github.com/Varejonline/api/wiki/GET%20planos-pagamento) utilizado (long).
  * **descricao** do [plano de pagamento](https://github.com/Varejonline/api/wiki/GET%20planos-pagamento) utilizado (string).
* **representante:** (Informar o id e/ou nome do vendedor)
  * **id** do [vendedor](https://github.com/Varejonline/api/wiki/GET-representantes) utilizado (long)
  * **nome** do [vendedor](https://github.com/Varejonline/api/wiki/GET-representantes) utilizado (string)
* **observacao:** observações do orçamento (string opcional)
* **vendaConsumidorFinal:** indica se o orçamento é para consumidor final (boolean obrigatório)
* **reservarEstoque:** indica se deverá ser criado uma reserva de estoque para os itens do orçamento (boolean opcional).

* **origem:** origem da venda (ECOMMERCE, MARKETPLACE, LOJA_FISICA) (string opcional)
* **tipo:** tipo da venda (NORMAL, SHIP_FROM_STORE, CLICK_COLLECT) (string opcional)
* **intermediador:** intermediador da venda (informar id ou documento) (opcional)
  * **id:** id do [intermediador](https://github.com/Varejonline/api/wiki/GET-terceiros) (long)
  * **documento:** documento do intermediador (string)
* **transporte:** dados de transporte
  * **modalidade:** modalidade do transporte (EMITENTE, DESTINATARIO_REMETENTE, TERCEIRO, PROPRIO_REMETENTE, PROPRIO_DESTINATARIO)
  * **transportador:**
    * **id:** id do [transportador](https://github.com/Varejonline/api/wiki/GET-terceiros) (long)
    * **documento:** documento do transportador (string)
  * **codigoANTT:** Código ANTT do transporte (string)
  * **placaVeiculo:** Placa do veiculo de transporte (string)
  * **estadoVeiculo:** Sigla do estado do veiculo de transporte (string)
  * **especie:** espécie do volume transportado
  * **marca:** marca do volume transportado (decimal)
  * **numero:** número do volume transportado (decimal)
  * **pesoBruto:** peso bruto transportado (decimal)
  * **pesoLiquido:** peso líquido transportado  (decimal)
* **enderecoEntrega:** dados do endereço de entrega
   * **logradouro:** nome do logradouro (string)
   * **numero:** número do endereço (string)
   * **bairro:** bairro do endereço (string)
   * **complemento:** complemento do endereço (string)
   * **cep:** CEP do endereço sem máscara (string)
   * **cidade:** Nome da cidade (string)
   * **uf:** Sigla do estado (string)
   * **receptorEntrega:** Nome da pessoa que receberá a entrega (string)
   * **receptorEntregaDocumento:** Documento da pessoa que receberá a entrega (string)

### Retorno

Retorna um Json com informações do resultado da operação realizada, contendo:
 * **idRecurso:** id do orçamento gerado.
 * **codigoMensagem:** Código de identificação da operação realizada. [veja a lista de Códigos](https://github.com/Varejonline/api/wiki/Retorno-API)
 * **mensagem:** Mensagem da operação realizada

### Exemplo

> POST https://integrador.varejonline.com.br/apps/api/orcamentos

'Content-Type'='application/json'
```javascript
{
   "validade":15,
   "entidade": {
      "id": 1,
      "documento": "00.000.000/0000-00"
   },
   "terceiro": {
      "id": 1,
      "documento": "000.000.000-00"
   },
   "representante": {
      "nome": "NOME DO VENDEDOR",
      "id": 1
   },
   "plano" : {
      "descricao": "CREDIÁRIO 1X",
      "id": 12
   },
   "itens":[
      {
         "produto": {
             "id" : 245,
             "codigoSistema" : "0001.0001" 
         },
         "quantidade":8, 
         "valorUnitario":10,
         "operacao":1
      }
   ],
   "servicos":[
      {
         "servico": {
             "id" : 245,
             "codigoSistema" : "S001.0099" 
         },
         "quantidade":1, 
         "valorUnitario":20
      }
   ],
   "valorFrete":2,
   "valorSeguro":6,
   "valorOutros":4,
   "numeroPedidoCliente" : "111-12",
   "observacao":"Ref. 007",
   "vendaConsumidorFinal":true,
   "reservarEstoque":true
}
```