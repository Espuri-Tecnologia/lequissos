### URL

> GET https://integrador.varejonline.com.br/apps/api/boletos/:id/impressao

### Parâmetros

Não há parâmetros para essa API. É utilizado apenas o ID do boleto a qual deseja-se obter a impressão pela  URL.

### Retorno

O retorno dessa API não um arquivo JSON. É retornado em bytes o PDF do boleto impresso.
