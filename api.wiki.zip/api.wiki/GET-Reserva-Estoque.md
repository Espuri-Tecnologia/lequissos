### Descrição

É possível criar reservas de estoque para orçamentos de venda realizados no sistema ou vendas com faturamento antecipado. 

Durante a operação do sistema, o saldo reservado ficará bloqueado para venda até que o orçamento seja convertido em pedido ou seja cancelado ou até que a entrega do faturamento antecipado, seja realizada.

### URLs

> GET https://integrador.varejonline.com.br/apps/api/reserva-estoque

    Busca todas as reservas de estoque com retorno paginado (1)

> GET https://integrador.varejonline.com.br/apps/api/reserva-estoque/orcamento/:id_orcamento

    Busca as reservas de estoque de um orçamento de venda

> GET https://integrador.varejonline.com.br/apps/api/reserva-estoque/saida/:id_saida

    Busca as reservas de estoque de um faturamento antecipado

### Parâmetros

* **inicio:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **quantidade:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **alteradoApos:** [Entenda a Coleta de Alterações](https://github.com/Varejonline/api/wiki/Filtro-de-Data-Alteração)
* **somenteAtivas:** Permite filtrar somente reservas ativas (true) ou todas (false) (Boolean Opcional)
* **somenteEcommerce:** Permite filtrar somente produtos integráveis no ecommerce (true) ou todos (false) (Boolean Opcional)
* **somenteMarketplace:** Permite filtrar somente produtos integráveis no marketplace (true) ou todos (false) (Boolean Opcional)
* **produtos:** lista de ids dos produtos cujos saldos se deseja obter, separados por vírgula. Funciona somente no GET de **busca paginada (1)**.

### Retorno

* **id**: id da reserva de estoque (long)
* **qtde:** quantidade reservada (decimal)
* **idEntidade:** [Entidade](https://github.com/Varejonline/api/wiki/GET-entidades) na qual foi registrada a reserva (long)
* **produto:** dados do produto devolvido (objeto complexo)
    * **id:** id da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos)
    * **codigoSistema:** Código Sistema da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos)
    * **codigoInterno:** Código Interno da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos)
    * **codigoBarras:** Código de Barras da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos)
* **dataAlteracao:** Última data de alteração da reserva de estoque, no formato dd-mm-aaaa hh:mi:ss
* **dataValidade:** Data de validade da reserva de estoque, no formato dd-mm-aaaa hh:mi:ss
* **ativo**: Indica se a reserva está ativa ou não (boolean)
* **deletado**: Indica se a reserva está deletada ou não (boolean)
* **tipoDocumento**: Define se a reserva é de um ORCAMENTO ou PEDIDO_VENDA
* **idDocumento**: número do documento vinculado (id [orçamento](https://github.com/Varejonline/api/wiki/GET-Orcamentos) ou da [saída](https://github.com/Varejonline/api/wiki/GET-saidas))
* **idDocumentoItem**: id do item dentro do orçamento ou da saída

### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/reserva-estoque

```javascript
[
   {
      "id":1,
      "qtde":2.0,
      "idEntidade": 2,
      "produto": {
          "id":9342,
          "codigoSistema":"0001.0001",
          "codigoInterno":"",
          "codigoBarras":""
      },
      "idDocumentoItem": 22345,
      "idDocumento": 1200,
      "dataAlteracao":"21-09-2018 15:28:05",
      "dataValidade":"21-10-2018 15:28:05",
      "ativo":true,
      "deletado":false,
      "tipoDocumento": "ORCAMENTO"
   }
]
```