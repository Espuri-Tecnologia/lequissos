Endpoint para ajuste de transações de cartão.

Por vezes as operadoras de cartão realizam a redistribuição de dízimas em uma parcela diferente da distribuição realizada no sistema, em outros casos, a data de recebimento prevista de uma transação ocorre em data diferente daquela calculada pelo sistema. Nesses casos, pode ser utilizado este endpoint para ajuste dos parâmetros de recebimento.

O endpoint permite que sejam ajustados os valores das parcelas e seus vencimentos, sendo assegurado o valor total da operação de pagamento.

Serão rejeitadas solicitações onde:

* Existam transações já baixadas/recebidas na operação.
* O número de parcelas da requisição for diferente do número de parcelas registradas no sistema.
* O valor total bruto da requisição não corresponda ao valor total bruto registrado no sistema.
* O valor total das parcelas não corresponda ao valor total da capa, tanto para líquido quanto para bruto. 
* Alguma parcela tenha valores bruto ou líquido inválidos: Menores ou iguais à zero
* Não tenha sido enviado algum campo obrigatório na requisição.
* Não seja encontrado no sistema uma operação de pagamento com os parâmetros informados: 

    * A busca será realizada com as seguintes chaves de consulta: 

        * entidade, bandeira, operadora, nsu, autorização e nr de parcelas.
        * entidade, bandeira, operadora, nsu, valor bruto e nr de parcelas (quando não informado autorização).
					
### URL

> PUT https://integrador.varejonline.com.br/apps/api/transacao-cartao/ajuste

### Parâmetros

Envie um JSON no corpo da requisição, contendo:
* **nsu:** NSU da operação de pagamento (string) _(obrigatório)_
* **autorizacao:** Número da autorização da operação de pagamento (string)
* **nrParcelas:** Número de parcelas da operação de pagamento (inteiro) _(obrigatório)_
* **idEntidade:** id da [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) onde foi realizado o pagamento (long) _(obrigatório)_
* **operadora:** nome da [operadora](https://github.com/Varejonline/api/wiki/Operadoras-de-Cartão) que roteou o pagamento (string) _(obrigatório)_
* **bandeira:** nome da [bandeira](https://github.com/Varejonline/api/wiki/Bandeiras-de-Cartão) do cartão utilizado no pagamento (string) _(obrigatório)_
* **valorBruto:** Valor Bruto total do pagamento (decimal) _(obrigatório)_
* **valorLiquido:** Valor Líquido total do pagamento (decimal) _(obrigatório)_
* **parcelas:**
    * **valorBruto:** Valor Bruto da parcela (decimal) _(obrigatório)_
    * **valorLiquido:** Valor Líquido da parcela (decimal) _(obrigatório)_
    * **dataPrevistaPagamento:** Data prevista na qual a operadora fará o pagamento (data dd/mm/yyyy) _(obrigatório)_
    * **nrParcela:** Número sequêncial da parcela no pagamento, iniciando em 1 (inteiro) _(obrigatório)_

### Retorno

Retorna um JSON espelho da requisição com os dados ajustados.

### Exemplo

> PUT https://integrador.varejonline.com.br/apps/api/transacao-cartao/ajuste

'Content-Type'='application/json'

```javascript
{
  "nsu": "415156",
  "nrParcelas": 3,
  "idEntidade": 1018,
  "operadora": "REDECARD",
  "bandeira": "MASTERCARD",
  "valorBruto": 192.5,
  "valorLiquido": 188,
  "parcelas": [
    {
      "valorBruto": 1.75,
      "valorLiquido": 1,
      "dataPrevistaPagamento": "01/09/2018",
      "nrParcela": 1
    },
    {
      "valorBruto": 95,
      "valorLiquido": 93.5,
      "dataPrevistaPagamento": "01/09/2018",
      "nrParcela": 2
    },
    {
      "valorBruto": 95.75,
      "valorLiquido": 93.5,
      "dataPrevistaPagamento": "01/09/2018",
      "nrParcela": 3
    }
  ]
}
```


### Exemplo de retorno:

_Sucesso:_
* HTTP STATUS 200 – OK
* Body:
```javascript
{
    "parcelas": [
        {
            "dataPrevistaPagamento": "01-09-2018 00:00:00",
            "valorLiquido": 1,
            "valorBruto": 1.75,
            "nrParcela": 1
        },
        {
            "dataPrevistaPagamento": "01-09-2018 00:00:00",
            "valorLiquido": 93.5,
            "valorBruto": 95,
            "nrParcela": 2
        },
        {
            "dataPrevistaPagamento": "01-09-2018 00:00:00",
            "valorLiquido": 93.5,
            "valorBruto": 95.75,
            "nrParcela": 3
        }
    ],
    "autorizacao": "29615",
    "valorLiquido": 188,
    "bandeira": "MASTERCARD",
    "nsu": "415156",
    "valorBruto": 192.5,
    "idEntidade": 1018,
    "operadora": "REDECARD",
    "nrParcelas": 3
}
```

_Requisição inválida:_
* HTTP STATUS 400 – BAD REQUEST
* Body: 
```javascript
texto explicativo com a mensagem de erro
```