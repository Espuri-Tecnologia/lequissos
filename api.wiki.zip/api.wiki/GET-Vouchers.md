### URLs

> GET https://integrador.varejonline.com.br/apps/api/vouchers/:id

> GET https://integrador.varejonline.com.br/apps/api/vouchers

### Parâmetros

* **entidades:** ids das [entidades](https://github.com/Varejonline/api/wiki/GET-entidades) (long) (opcional)
* **documentoCliente:** Para filtrar vouchers nominais pelo documento do cliente não formatado (string) (opcional)
* **codigoPromocional:** Para filtrar vouchers promocionais pelo código (string) (opcional)
* **numeroValePresente:** Para filtrar voucher de vale presente pelo número/código (string) (opcional)
* **somenteAtivos:** Para filtrar vouchers ativos, ou seja, não encerrados/excluídos/cancelados e que estão válidos na data atual (boolean) (opcional)
* **inicio:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **quantidade:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **alteradoApos:** [Entenda a Coleta de Alterações](https://github.com/Varejonline/api/wiki/Filtro-de-Data-Alteração)


### Retorno

Sucesso HTTP 200 OK:

Retorna uma lista JSONs com informações do resultado da operação realizada, contendo:
* **id:** id do voucher (long)
* **entidades:** lista de entidades cadastradas para o voucher
  * **id:** id da [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) (long)
  * **nome:** nome da [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) (string)
  * **documento:** CNPJ formatado da loja associada a [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) (string)
* **nominal:** informações referentes ao voucher do tipo nominal
  * **id:** id do voucher nominal (long)
  * **terceiros:** lista de terceiros cadastrados para o voucher nominal
    * **id:** id do [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros) (long)
    * **nome:** nome do [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros) (string)
    * **documento:** Número do documento formatado do [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros) (string)
  * **categoriasCliente:** lista de categorias de clientes cadastrados para o voucher nominal
    * **id:** id da categoria (long)
    * **nome:** nome da categoria (string)
  * **classesTerceiro:** lista de [classes](https://github.com/Varejonline/api/wiki/Classes-de-Terceiro) cadastrados para o voucher nominal.
* **promocional:** informações referentes ao voucher do tipo promocional
  * **id:** id do voucher promocional (long)
  * **codigo:** código promocional (string)
  * **clienteObrigatorio:** define se o voucher só pode ser aplicado a um cliente identificado na venda (boolean)
  * **quantidadeLimitada:** define se o voucher possui quantidade limitada para uso (boolean)
  * **quantidadeUsos:** quando o voucher possui quantidade limitada essa informação define a quantidade de uso permitido (integer)
* **valePresente:** informações referentes ao voucher do tipo vale presente
  * **id:** id do voucher vale presente (long)
  * **numero:** número referente ao cartão do vale presente (string)
  * **emailValePresente:** e-mail para envio do vale presente (string)
  * **formatoValePresente:** formato do vale presente (string) (FISICO, DIGITAL ou AMBOS)
  * **nomePresenteado:** nome do presenteado (string)
  * **usoValePresente:** uso do vale presente (string) (PROPRIO ou PRESENTE)
* **formaAplicacao:** Se o voucher é aplicado como pagamento ou desconto (enum: PAGAMENTO, DESCONTO)
* **tipoLancamento:** Define a forma em que o voucher foi criado no sistema (enum: MANUAL, CONFIGURACAO, AUTOMATICO, VENDA_ERP_PDV)
* **valor:** Valor configurado para o voucher (decimal)
* **tipoValor:** Define a configuração do valor, podendo ser unitário ou percentual (enum: PERCENTUAL, VALOR_UNITARIO)
* **valorCompraMinimo:** Define o valor de compra mínimo do pedido para poder consumir o voucher (decimal)
* **percentualUsoVenda:** Define o percentual de uso em venda para o voucher (decimal)
* **dataValidadeInicial:** Define a data de validade inicial para consumo no formato dd-mm-aaaa (string)
* **dataValidadeFinal:** Define a data de validade final para consumo no formato dd-mm-aaaa (string)
* **usoUnico:** Define se o voucher pode ser utilizado apenas uma única vez (boolean)
* **excluido:** Define se o voucher foi excluído (boolean)
* **encerrado:** Define se o voucher foi encerrado (boolean)
* **cancelado:** Referente ao vale presente. Define se o voucher foi cancelado (boolean)
* **observacoes:** Observações referente ao voucher (string)
* **somenteWeb:** Define se o voucher só pode ser utilizado em Ecommerce/Marketplace (boolean)
* **franquias:** lista de terceiros cadastrados para a integração
  * **id:** id do [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros) (long)
  * **nome:** nome do [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros) (string)
  * **documento:** Número do documento formatado do [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros) (string)

Requisição inválida: 
* HTTP STATUS 400 – BAD REQUEST
* Body: mensagem de erro

### Exemplos

> GET https://integrador.varejonline.com.br/apps/api/vouchers?entidades=1,2,3&somenteWeb=true&documentoCliente=92657392075&codigoPromocional=123456&somenteAtivos=true

```javascript
[
    {
        "formaAplicacao": "DESCONTO",
        "dataValidadeInicial": "29-07-2022",
        "dataValidadeFinal": "31-12-2022",
        "valor": 5,
        "tipoLancamento": "MANUAL",
        "usoUnico": false,
        "encerrado": false,
        "promocional": {
            "clienteObrigatorio": false,
            "quantidadeLimitada": false,
            "codigo": "654321",
            "id": 1002
        },
        "cancelado": false,
        "entidades": [],
        "excluido": false,
        "franquias": [],
        "somenteWeb": false,
        "tipoValor": "VALOR_UNITARIO",
        "id": 1002
    },
    {
        "formaAplicacao": "PAGAMENTO",
        "dataValidadeInicial": "29-07-2022",
        "dataValidadeFinal": "31-12-2022",
        "valor": 10,
        "tipoLancamento": "MANUAL",
        "usoUnico": false,
        "encerrado": false,
        "promocional": {
            "clienteObrigatorio": false,
            "quantidadeLimitada": false,
            "codigo": "123456",
            "id": 1001
        },
        "cancelado": false,
        "entidades": [],
        "excluido": false,
        "franquias": [],
        "somenteWeb": false,
        "tipoValor": "VALOR_UNITARIO",
        "id": 1001
    },
    {
        "formaAplicacao": "PAGAMENTO",
        "dataValidadeInicial": "03-08-2022",
        "dataValidadeFinal": "31-08-2022",
        "valor": 15.9,
        "tipoLancamento": "MANUAL",
        "usoUnico": true,
        "encerrado": false,
        "cancelado": false,
        "entidades": [
            {
                "nome": "DÉPOSITO CENTRAL",
                "documento": "45.433.924/0001-10",
                "id": 3
            }
        ],
        "excluido": false,
        "franquias": [],
        "nominal": {
            "categoriasCliente": [
                {
                    "nome": "VIP",
                    "id": 2
                }
            ],
            "classesTerceiro": [
                "CLIENTE"
            ],
            "terceiros": [
                {
                    "nome": "Alan Bahnia",
                    "documento": "057.159.029-30",
                    "id": 192
                }
            ],
            "id": 1021
        },
        "somenteWeb": false,
        "tipoValor": "VALOR_UNITARIO",
        "id": 1021
    }
]
```

> GET https://integrador.varejonline.com.br/apps/api/vouchers/1001

```javascript
{
        "formaAplicacao": "PAGAMENTO",
        "dataValidadeInicial": "29-07-2022",
        "dataValidadeFinal": "31-12-2022",
        "valor": 10,
        "tipoLancamento": "MANUAL",
        "usoUnico": false,
        "encerrado": false,
        "promocional": {
            "clienteObrigatorio": false,
            "quantidadeLimitada": false,
            "codigo": "123456",
            "id": 1001
        },
        "cancelado": false,
        "entidades": [],
        "excluido": false,
        "franquias": [],
        "somenteWeb": false,
        "tipoValor": "VALOR_UNITARIO",
        "id": 1001
}
```