## [POST Ajuste-estoque](/Varejonline/api/wiki/POST-Ajuste-de-estoque)

<br>

## [GET Estoque/saldo líquido de mercadorias](/Varejonline/api/wiki/GET-saldos-liquidos-mercadorias)
## [GET Estoque/saldo de mercadorias](/Varejonline/api/wiki/GET-saldos-mercadorias)

<br>

## [GET Reserva estoque](/Varejonline/api/wiki/GET-Reserva-Estoque)
## [PUT Cancelar Reserva](/Varejonline/api/wiki/PUT-Cancelar-Reserva)