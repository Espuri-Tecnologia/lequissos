### URL

> PUT https://integrador.varejonline.com.br/apps/api/pedidos-compra/:id/alterar-status

### Parâmetros

Envie um JSON no corpo da requisição, contendo:

* **status:** [Status](https://github.com/Varejonline/api/wiki/Status-de-pedido-de-compra) do pedido de compras (string)

### Exemplo

> PUT https://integrador.varejonline.com.br/apps/api/pedidos-compra/100/alterar-status

'Content-Type'='application/json'
```javascript
{
   "status":"BLOQUEADO_INTEGRACAO"
}
```
