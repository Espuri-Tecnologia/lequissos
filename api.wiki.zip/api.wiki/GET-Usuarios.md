### URLs

> GET https://integrador.varejonline.com.br/apps/api/usuarios

    Obtém todos os usuários com retorno paginado

> GET https://integrador.varejonline.com.br/apps/api/usuarios/logado

    Obtém as informações do usuário logado

> GET https://integrador.varejonline.com.br/apps/api/usuarios/:id

    Obtém as informações de um usuário por id


### Parâmetros

* **inicio:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **quantidade:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **alteradoApos:** [Entenda a Coleta de Alterações](https://github.com/Varejonline/api/wiki/Filtro-de-Data-Alteração)
* **entidades:** [Veja como Funciona este Filtro](https://github.com/Varejonline/api/wiki/Filtro-de-Entidades)
* **status:** filtra pelo status da entidade (enum: ATIVO, INATIVO), separados por vírgula

<em>Obs.: Usuários inativos são exibidos apenas se incluso o parâmetro status INATIVO.</em>

### Retorno

* **id:** id do usuário (long)
* **login:** login do usuário (String)
* **grupoEmpresarial:** grupo empresarial principal (String)
* **ativo:** indica se o usuário está ativo (boolean)
* **idsEntidadesPermitidas:** lista de ids de entidades, separados por vírgula, que o usuário possui acesso (array)
* **terceiro:** terceiro associado ao usuário
   * **id:** id do terceiro (long)
   * **documento:** documento do terceiro (String)
   * **nome:** nome do terceiro (string)

### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/usuarios?inicio=0&quantidade=2&status=ATIVO,INATIVO

```javascript
[
  {
        "id": 18,
        "terceiro": {
            "id": 228,
            "nome": "Nome do Terceiro",
            "documento": "000.000.000-01"
        },
        "idsEntidadesPermitidas": [
            9
        ],
        "ativo": true,
        "grupoEmpresarial": "TREINAMENTO",
        "login": "demo",
    },
    {
        "id": 22,
        "terceiro": {
            "id": 230,
            "nome": "Terceiro Teste",
            "documento": "999.999.999-99"
        },
        "idsEntidadesPermitidas": [
            9,
            10
        ],
        "ativo": false,
        "grupoEmpresarial": "TREINAMENTO",
        "login": "demo2",
    }
]
```