### URL

> POST https://integrador.varejonline.com.br/apps/api/saidas/movimentacao-propria

### Parâmetros

Envie um JSON no corpo da requisição, contendo:

* **entidade:** id da [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) utilizada (long)
* **terceiro:** id to [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros) utilizado (long)
* **dataEmissao:** data de criação do pedido (string dd-MM-yyyy)
* **operacao:** id da [operação](https://github.com/Varejonline/api/wiki/Tipo-de-operação-em-itens-movimentados) (long)
* **representante:** id do [representante](https://github.com/Varejonline/api/wiki/GET-representantes) utilizado (long)
* **custoMedio:** indica se a operação deve ser realizado com o custo médio. (boolean) (opcional)
* **custoReferencial:** indica se a operação deve ser realizado o com custo referencial. (boolean) (opcional)
* **custoInformado:** indica se a operação deve ser realizado com o custo informado. (boolean) (opcional)
* **consumidorFinal:** indica se a operação é com um consumidor final. (boolean) (opcional)
* **vendaPresencial:** indica se a operação é uma venda presencial. (boolean) (opcional)
* **contaDebito:** id da [conta contabil](https://github.com/Varejonline/api/wiki/GET-Contas-Contábeis) da operação (long)
* **observacao:** observação da saída. (string) (opcional)
* **itens:** lista de itens do pedido, contendo:
  * **idProduto:** id do [produto](https://github.com/Varejonline/api/wiki/GET-Produtos) (long)
  * **codigoSistema:** código de sistema do produto. (string)
  * **quantidade:** quantidade do item (decimal)
  * **cstIcms:** cst de icms do item (long)
  * **baseIcms:** base de icms do item (decimal)
  * **aliquotaIcms:** alíquota de icms do item (decimal)
  * **valorIcms:** valor de icms do item (decimal)
  * **cstIpi:** cst de ipi do item (long)
  * **baseIpi:** base de ipi do item (decimal)
  * **aliquotaIpi:** aliquota de ipi do item (decimal)
  * **valorIpi:** valor de ipi do item (decimal)
  * **valorTotal:** valor total do item (decimal)
* **chavesNfeReferencia:** lista de chaves de notas fiscais referenciadas (string)

### Retorno

Sucesso HTTP 201 CREATED:

Retorna um Json com informações do resultado da operação realizada, contendo:

* **idRecurso:** id do pedido gerado.
* **codigoMensagem:** Código de identificação da operação realizada. [veja a lista de Códigos](https://github.com/Varejonline/api/wiki/Retorno-API)
* **mensagem:** Mensagem da operação realizada

Requisição inválida: 
* HTTP STATUS 400 – BAD REQUEST
* Body: mensagem de erro

### Exemplo

> POST https://integrador.varejonline.com.br/apps/api/saidas/movimentacao-propria

'Content-Type'='application/json'
```javascript
{
    "entidade": 3,
    "terceiro": 192,
    "dataEmissao": "04-02-2022",
    "operacao": 1156,
    "representante": 6,
    "custoMedio": false,
    "custoReferencial": true,
    "custoInformado": false,
    "consumidorFinal": false,
    "vendaPresencial": false,
    "contaDebito": 6,
    "observacao": "TESTE OBS",
    "itens": [{
            "idProduto": 24,
            "codigoSistema": "",
			"quantidade": 2,
            "cstIcms": "99",
            "baseIcms": 0,
            "aliquotaIcms": 0,
            "valorIcms": 0,
            "cstIpi": "99",
            "baseIpi": 0,
            "aliquotaIpi": 0,
            "valorIpi": 0,
            "valorTotal": 20.00
        }
    ],
    "chavesNfeReferencia": [
        "50220230890507000129550010000000011630351462"
    ]
}
```