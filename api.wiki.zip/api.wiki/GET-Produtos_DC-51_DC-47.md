### URLs

> GET https://integrador.varejonline.com.br/apps/api/produtos

> GET https://integrador.varejonline.com.br/apps/api/produtos/:id

### Parâmetros

* **entidades:** [Veja como Funciona este Filtro](https://github.com/Varejonline/api/wiki/Filtro-de-Entidades)
* **inicio:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **quantidade:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **alteradoApos:** [Entenda a Coleta de Alterações](https://github.com/Varejonline/api/wiki/Filtro-de-Data-Alteração)
* **categoria:** id da [categoria do produto](https://github.com/Varejonline/api/wiki/GET-categorias-produto)
* **produtoBase:** Retorna os produtos que utilizam esse id de produto base.
* **descricao:** Retorna os produtos contém essa String na descrição.
* **codigoBarras:** Retorna o produto que utiliza esse Código de Barras.
* **codigoInterno:** Retorna o produto que utiliza esse Código Interno.
* **codigoSistema:** Retorna o produto que utiliza esse Código Sistema.
* **somenteAtivos:** Filtra somente produtos ativos (true) ou todos (false)
* **somenteComFotos:** Filtra somente produtos com fotos (true) ou todos (false)
* **somenteEcommerce:** Filtra somente produtos integráveis no ecommerce (true) ou todos (false)
* **somenteMarketplace:** Filtra somente produtos integráveis no marketplace (true) ou todos (false)

### Retorno 

* **id:** id do produto (long)
* **ativo:** indica se o produto está ativo ou não (boolean)
* **dataAlteracao:** última data de alteração do produto, no formato dd-mm-aaaa hh:mi:ss (string)
* **dataCriacao:** data em que o produto foi criado no sistema, no formato dd-mm-aaaa hh:mi:ss (string)
* **cnpjFornecedores:** Lista com o CNPJ dos fornecedores associados ao produto (String[]).
* **idFabricante:** lista com os id dos terceiros que fabrica o produto, se existir (long)
* **descricao:** descrição do produto, contendo nome e sigla da unidade (string)
* **especificacao:** especificação do produto (string)
* **peso:** peso do produto (decimal)
* **altura:** altura do produto (decimal)
* **comprimento:** comprimento do produto (decimal)
* **largura:** largura do produto (decimal)
* **codigoBarras:** código de barras do produto (string)
* **codigoInterno:** código interno do produto na empresa (string)
* **codigoSistema:** código do sistema gerado para o produto (string)
* **tags:** Strings concatenadas por vírgula que permitem consulta de produtos no sistema (string)
* **unidade:** sigla da unidade do produto (string)
* **unidadesProporcao:** Lista de Unidades Proporcionais da Mercadoria
  * **unidade:** Sigla da unidade proporcional (string)
  * **proporcao:** Proporção da unidade sobre a unidade principal (decimal)
* **classificacao:** Classificação do produto, que indica a finalidade para a qual o produto será utilizado. Pode assumir um dos seguintes valores: PRODUCAO_PROPRIA, REVENDA, ATIVO_IMOBILIZADO, CONSUMO, SERVICO_ISS, SERVICO_ICMS, INSUMO (string)
* **origem:** número de 0 a 7 que representa a [origem](https://github.com/Varejonline/api/wiki/Origens-de-Mercadoria) do produto segundo a receita federal (long)
* **fci:** número de controle da Ficha de Conteúdo de Importação. (string)
* **codigoCest:** Código Especificador da Substituição Tributária. (String)
* **codigoNcm:** código do NCM( Nomenclatura Comum Mercosul) que identifica a natureza do produto (string)
* **metodoControle:** método de controle de estoque do produto, podendo assumir um dos seguintes valores: ESTOCAVEL, LOTE, SERIE, NAO_ESTOCAVEL (string)
* **permiteVenda:** indica se o produto pode ser vendido através da API de pedidos. Esta regra está relacionada à classificação do produto (boolean)
* **listCustoReferencial:** Lista de preço de Custo por [entidade](https://github.com/Varejonline/api/wiki/GET-entidades).
   * **entidade:** Id da [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) (long)
   * **precoCusto:** Custo do produto na [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) (decimal)
* **preco:** Preço do Produto na tabela Padrão (decimal)
* **descontoMaximo:** Porcentagem máxima de desconto que pode ser oferecida na venda do produto (decimal)
* **comissao:** Comissão percentual recebida pelo [vendedor](https://github.com/Varejonline/api/wiki/GET-representantes) na venda do produto (decimal)
* **margemLucro:** Margem percentual de lucro obtida na venda do produto (decimal)
* **estoqueMaximo:** Quantidade referencial máxima de estoque do produto (decimal)
* **estoqueMinimo:** Quantidade referencial mínima de estoque do produto (decimal)
* **dadosPorEntidade:** Lista de Configurações por Entidade do Produto
  * **entidade:** Id da [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) (long)
  * **estoqueMinimo:** Estoque mínimo referencial do produto na entidade (decimal)
  * **estoqueMaximo:** Estoque máximo referencial do produto na entidade (decimal)
* **valorAtributos:** Valor dos atributos de grade configurados no SKU (Somente para itens de grade).
  * **nome:** nome do atributo da grade (string)
  * **valor:** valor do atributo para este produto (string)
  * **codigo:** código do valor do atributo (string)
* **categorias:** Lista com os dados das categorias que definem a estrutura mercadológica do produto.
  * **id:** Id da Categoria (long)
  * **nome:** Nome da Categoria (string)
  * **nivel:** **Nome** do [nível](https://github.com/Varejonline/api/wiki/GET-niveis-categoria) onde está localizada a categoria (string)
* **produtoBase:** Dados do produto pai do SKU listado.
  * **id:** id do produto pai (long)
  * **codigoSistema:** Código do sistema para o produto pai (string)
  * **nome:** Nome do produto pai (string)
* **urlsFotosProduto:** Lista com os endereços (https) das imagens associadas a mercadoria (Array String)
* **disponivelEcommerce:** Define se o produto pode ser disponibilizado no ecommerce (boolean)
* **disponivelMarketplace:** Define se o produto pode ser disponibilizado no marketplace (boolean)
* **custoUnitarioRoyalties:** custo unitário em royalties do produto (decimal)
* **precoVariavel:** Define se o preço de venda do produto é definido somente no momento da venda (boolean)
* **componentes:** Dados dos itens que compõem a ficha técnica do produto
  * **produto:** Produto presente na ficha técnica
    * **id:** id do produto (long)
    * **descricao:** Descricao do produto (string)
    * **codigoBarras:** Código de barras do produto (string)
    * **codigoInterno:** Código interno do produto (string)
    * **codigoSistema:** Código sistema do produto (string)
  * **quantidade:** Quantidade de peças do item na ficha técnica (decimal)
  * **unidade:** Sigla da unidade de medida que representa a quantidade (string)
* **descontoProgressivo:** Valores da configuração do desconto progressivo do produto
  * **qtde:** Quantidade de peças que ativa o desconto unitário (decimal)
  * **tipo:** Tipo do desconto. Pode ser PERCENTUAL ou VALOR_UNITARIO (string)
  * **desconto:** Valor do desconto a ser aplicado (string)
  * **ativo:** Indica se o desconto progressivo está ou não ativo (string)



### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/produtos

```javascript
[
   {
      "id":241,
      "ativo": false,
      "dataAlteracao":"27-01-2013 15:28:05",
      "dataCriacao":"21-01-2013 15:28:05",
      "cnpjFornecedores":["25.348.796/0001-07"],
      "idFabricante":155,
      "descricao":"GRANOLA 20G",
      "especificacao":"GRANOLA 20G SACHE",
      "peso":65.00,
      "altura":65.00,
      "comprimento":65.00,
      "largura":65.00,
      "codigoBarras":"6445662344598",
      "codigoInterno":"12322",
      "codigoSistema":"0001",
      "tags":"000192,camisalarga,ponta de estoque",
      "unidade":"UN",
      "unidadesProporcao": [
          {
             "unidade":"L",
             "proporcao": 0.02
          }
      ],
      "classificacao":"CONSUMO",
      "origem":3,
      "fci":"B01F70AF-10BF-4B1F-848C-65FF57F616FE",
      "codigoCest":"22.001.00",
      "metodoControle":"ESTOCAVEL",
      "codigoNCM":"9999.99.99",
      "permiteVenda":false,
      "preco":65,
      "precoVariavel":false,
      "descontoMaximo":10.0,
      "comissao":0,
      "margemLucro":30.0,
      "estoqueMaximo":700,
      "estoqueMinimo":100,
      "custoUnitarioRoyalties":10.00,
      "dadosPorEntidade":[
         {
            "entidade":1,
            "estoqueMinimo":450,
            "estoqueMaximo":550
         },
         {
            "entidade":2,
            "estoqueMinimo":250,
            "estoqueMaximo":400
         }
      ],
      "categorias": [
         {
             "id":"1",
             "nome":"Natural",
             "nivel":"DEPARTAMENTO",
         },
         {
             "id":"10",
             "nome":"Graos",
             "nivel":"SETOR",
         }
      ],
      "listCustoReferencial":[
         {
            "entidade":1,
            "precoCusto":29.85
         },
         {
            "entidade":2,
            "precoCusto":32.02
         }
      ],
      "urlsFotosProduto":[
         "https://uploader-vpsa-store.s3.amazonaws.com/df9b08f3-d441-44af-8684-a37813f18ee0.png",
         "https://uploader-vpsa-store.s3.amazonaws.com/b5afee84-ba5f-44d1-be4f-48856d7a65a7.png"
      ]
   },
   {
      "id":242,
      "ativo": true,
      "dataAlteracao":"22-01-2013 17:21:05",
      "dataCriacao":"21-01-2013 15:28:05",
      "cnpjFornecedores":["25.348.796/0001-07", "90.837.241/0001-82"],
      "descricao":"CAMISETA AZUL P",
      "especificacao":"CAMISETA POLO AZUL P",
      "peso":45.00,
      "altura":65.00,
      "comprimento":65.00,
      "largura":65.00,
      "codigoBarras":"6465464654567",
      "codigoInterno":"12002",
      "codigoSistema":"0002.0001",
      "tags":"000192,camisalarga,ponta de estoque",
      "unidade":"UN",
      "classificacao":"REVENDA",
      "origem":0,
      "metodoControle":"ESTOCAVEL",
      "codigoNCM":"9999.99.99",
      "permiteVenda":true,
      "preco":0,
      "precoVariavel":true,
      "descontoMaximo":0,
      "comissao":5.0,
      "codigoCest":"22.001.00",
      "margemLucro":60.0,
      "estoqueMaximo":100,
      "estoqueMinimo":10,
      "dadosPorEntidade":[
         {
            "entidade":1,
            "estoqueMinimo":120,
            "estoqueMaximo":150
         },
         {
            "entidade":2,
            "estoqueMinimo":30,
            "estoqueMaximo":40
         }
      ],
      "produtoBase": {
          "id":239,
          "codigoSistema":"0002",
          "nome":"CAMISETA POLO"
      },
      "categorias": [
         {
             "id":"5",
             "nome":"Vestuario",
             "nivel":"DEPARTAMENTO",
         },
         {
             "id":"35",
             "nome":"Esporte Fino",
             "nivel":"SETOR",
         }
      ],
      "valorAtributos":[
         {
            "nome":"COR",
            "valor":"AZUL",
            "codigo":"123"
         },
         {
            "nome":"TAMANHO",
            "valor":"P",
            "codigo":"456"
         }
      ],
      "listCustoReferencial":[
         {
            "entidade":1,
            "precoCusto":31.85
         },
         {
            "entidade":2,
            "precoCusto":22.02
         }
      ],
      "urlsFotosProduto":[
         "https://uploader-vpsa-store.s3.amazonaws.com/df9b08f3-d441-44af-8684-a37813f18ee0.png",
         "https://uploader-vpsa-store.s3.amazonaws.com/b5afee84-ba5f-44d1-be4f-48856d7a65a7.png"
      ]
   }
]
```