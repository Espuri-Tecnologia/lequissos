### URLs

> GET https://integrador.varejonline.com.br/apps/api/classificacoes-fiscais-produtos

### Parâmetros

* **produtos:** OBRIGATÓRIO - filtro para buscar apenas as classificações relacionadas a uma lista de produtos específicos. Máximo de 10 produtos por requisição.
* **entidades:** [Veja como Funciona este Filtro](https://github.com/Varejonline/api/wiki/Filtro-de-Entidades)
* **inicio:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **quantidade:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **alteradoApos:** [Entenda a Coleta de Alterações](https://github.com/Varejonline/api/wiki/Filtro-de-Data-Alteração)
* **uf:** filtro para buscar apenas classificações fiscais associadas com participantes de um estado específico (sigla)
* **idOperacao:** filtro para buscar apenas as classificações relacionadas a um operação de entrada ou saída específica. A operação VENDA tem id 1.

### Retorno

* **idEntidade:** id da [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) para qual se aplica a classificação fiscal (long)
* **uf:** sigla do estado do participante (remetente ou destinatário) onde se aplica a carga tributária retornada na clasisficação fiscal (string)
* **idProduto:** id do [produto](https://github.com/Varejonline/api/wiki/GET-Produtos) para qual se aplica a classificação fiscal (long)
* **cfop:** código CFOP da operação (integer)
* **idOperacao:** id da operação de entrada ou saída para qual se aplica a carga tributária retornada na classificação fiscal (long)
* **pis:** dados do PIS aplicado ao item (segue a estrutura comum abaixo)
* **cofins:** dados do COFINS aplicado ao item (segue a estrutura comum abaixo)
* **icms:** dados do ICMSST aplicado ao item  - existe saomente se a classificação for de uma mercadoria (segue a estrutura comum abaixo)
* **icmssn:**  dados do ICMSSN aplicado ao item - pode opcionalmente existir somente se a classificação for de uma mercadoria (segue a estrutura comum abaixo)
* **icmsst:** dados do ICMSST - pode opcionalmente existir somente se a classificação for de uma mercadoria 
   * **cst:** código de situação tributária  (string)
   * **base:** base de cálculo a ser aplicada na classificação fiscal do [produto](https://github.com/Varejonline/api/wiki/GET-Produtos) (decimal)
   * **aliquota:** alíquota a ser aplicada na classificação fiscal do [produto](https://github.com/Varejonline/api/wiki/GET-Produtos) (decimal)
   * **iva:** indica o índica de IVA do [produto](https://github.com/Varejonline/api/wiki/GET-Produtos) (decimal)
   * **pauta:**  indica se há valor de pauta de ICMSST ou não (boolean)

Estrutura comum para os tributos das classificações fiscais:
   * **cst:** código de situação tributária (string)
   * **base:** valor da base de cálculo do tributo (decimal)
   * **aliquota:** valor da alíquota aplicada (decimal)


### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/classificacoes-fiscais-produtos

```javascript
[
	{
		"idEntidade":1,
		"uf": "RJ",	
		"idProduto":1,
		"cfop": "1102 - Vendas de mercadorias",
		"idOperacao": 1,
		"icms":
		{
			"cst": "00",
			"base":100,
			"aliquota":18
		},
		"icmsst":
		{
			"cst": "00" ,
			"iva":55,
			"base":100,
			"aliquota":12,
			"pauta": false
		},
		"icmssn":
		{
			"cst": "00",
			"base":100,
			"aliquota":18	
		},
		"ipi":
		{
			"cst": "00"
			"base":100,
			"aliquota":10,
		},
		"pis":
		{
			"cst": "00"
			"base":100,
			"aliquota":0.65,
		},
		"cofins":
		{
			"cst": "00"
			"base":100,
			"aliquota":7,
		}
	},
	{
		"idEntidade":1,
		"uf": "SP",	
		"idProduto":1,
		"cfop": "1102 - Vendas de mercadorias",
		"idOperacao": 1,
		"icms":
		{
			"cst": "00",
			"base":100,
			"aliquota":12
		},
		"icmsst":
		{
			"cst": "00" ,
			"iva":55,
			"base":100,
			"aliquota":12,
			"pauta": false
		},
		"icmssn":
		{
			"cst": "00",
			"base":100,
			"aliquota":18	
		},
		"ipi":
		{
			"cst": "00"
			"base":100,
			"aliquota":10,
		},
		"pis":
		{
			"cst": "00"
			"base":100,
			"aliquota":0.65,
		},
		"cofins":
		{
			"cst": "00"
			"base":100,
			"aliquota":7,
		}
	}
]
```