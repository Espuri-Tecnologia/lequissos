Listagem dos CSTs:

<table>
<tr><th>Código</th><th>ENUM</th><th>Tipo de Operação</th></tr>
<tr><td>01</td><td>OP_TRIB_ALIQ_BASICA</td><td>SAÍDA</td></tr>
<tr><td>02</td><td>OP_TRIB_ALIQ_DIFERENCIADA</td><td>SAÍDA</td></tr>
<tr><td>03</td><td>OP_TRIB_ALIQ_P_UNID_MEDIDA_PROD</td><td>SAÍDA</td></tr>
<tr><td>04</td><td>OP_TRIB_MONO_REV_ALIQ_ZERO</td><td>SAÍDA</td></tr>
<tr><td>05</td><td>OP_TRIB_P_SUBST_TRIB</td><td>SAÍDA</td></tr>
<tr><td>06</td><td>OP_TRIB_ALIQ_ZERO</td><td>SAÍDA</td></tr>
<tr><td>07</td><td>OP_ISENTA_CONTRIBUICAO</td><td>SAÍDA</td></tr>
<tr><td>08</td><td>OP_SEM_INCIDENCIA_CONTRIBUICAO</td><td>SAÍDA</td></tr>
<tr><td>09</td><td>OP_SUSPENSAO_CONTRIBUICAO</td><td>SAÍDA</td></tr>
<tr><td>49</td><td>OUTRAS_OPERACOES_SAIDA</td><td>SAÍDA</td></tr>
<tr><td>50</td><td>OP_DIR_CRED_EXCLUSIVA_REC_TRIB_MERC_INT</td><td>ENTRADA</td></tr>
<tr><td>51</td><td>OP_DIR_CRED_EXCLUSIVA_REC_N_TRIB_MERC_INT</td><td>ENTRADA</td></tr>
<tr><td>52</td><td>OP_DIR_CRED_EXCLUSIVA_REC_EXPORT</td><td>ENTRADA</td></tr>
<tr><td>53</td><td>OP_DIR_CRED_REC_TRIB_E_N_MERC_MERC_INT</td><td>ENTRADA</td></tr>
<tr><td>54</td><td>OP_DIR_CRED_REC_TRIB_MERC_INT_E_EXPORT</td><td>ENTRADA</td></tr>
<tr><td>55</td><td>OP_DIR_CRED_REC_N_TRIB_MERC_INT_E_EXPORT</td><td>ENTRADA</td></tr>
<tr><td>56</td><td>OP_DIR_CRED_REC_TRIB_E_N_MERC_MERC_INT_E_EXPORT</td><td>ENTRADA</td></tr>
<tr><td>60</td><td>CRED_PRESU_OP_VINC_EXCLUSIVA_REC_TRIB_MERC_INT</td><td>ENTRADA</td></tr>
<tr><td>61</td><td>CRED_PRESU_OP_VINC_EXCLUSIVA_REC_N_TRIB_MERC_INT</td><td>ENTRADA</td></tr>
<tr><td>62</td><td>CRED_PRESU_OP_VINC_EXCLUSIVA_REC_EXPORT</td><td>ENTRADA</td></tr>
<tr><td>63</td><td>CRED_PRESU_OP_VINC_TRIB_E_N_MERC_MERC_INT</td><td>ENTRADA</td></tr>
<tr><td>64</td><td>CRED_PRESU_OP_VINC_TRIB_MERC_INT_E_EXPORT</td><td>ENTRADA</td></tr>
<tr><td>65</td><td>CRED_PRESU_OP_VINC_REC_N_TRIB_MERC_INT_E_EXPORT</td><td>ENTRADA</td></tr>
<tr><td>66</td><td>CRED_PRESU_OP_VINC_TRIB_E_N_MERC_MERC_INT_E_EXPORT</td><td>ENTRADA</td></tr>
<tr><td>67</td><td>CRED_PRESU_OUTRAS_OPERACOES</td><td>ENTRADA</td></tr>
<tr><td>70</td><td>OP_AQUIS_S_DIREITO_CRED</td><td>ENTRADA</td></tr>
<tr><td>71</td><td>OP_AQUIS_C_ISENCAO</td><td>ENTRADA</td></tr>
<tr><td>72</td><td>OP_AQUIS_C_SUSPENCAO</td><td>ENTRADA</td></tr>
<tr><td>73</td><td>OP_AQUIS_ALIQ_ZERO</td><td>ENTRADA</td></tr>
<tr><td>74</td><td>OP_AQUIS_S_INCID_CONTRIB</td><td>ENTRADA</td></tr>
<tr><td>75</td><td>OP_AQUIS_P_SUBS_TRIB</td><td>ENTRADA</td></tr>
<tr><td>98</td><td>OUTRAS_OPERACOES_ENTRADA</td><td>ENTRADA</td></tr>
<tr><td>99</td><td>OUTRAS_OPERACOES</td><td>AMBOS</td></tr>
</table>
