
### URL

> POST https://integrador.varejonline.com.br/apps/api/pedidos/alterar-status

### Parâmetros

Envie um JSON no corpo da requisição, contendo:

* **idPedido:** id do pedido que deseja ajustar (long) (obrigatório)
* **statusPedidoVenda:** novo status de pedido de venda utilizado (obrigatório)
  * **id:** id do novo status para o pedido (long) (opcional)
  * **nome:** nome do status que deseja ajustar (string) (opcional)

**Obs:** 
* O [novo status para o pedido](https://github.com/Varejonline/api/wiki/GET-Status-Pedido-Venda) precisa estar cadastrado no sistema para ser válido.
* As propriedades **id** e **nome** são opcionais, porém ao menos um identificador deve ser informado.

### Retorno

Sucesso HTTP 200 OK:

Retorna um Json com informações do resultado da operação realizada, contendo:

* **codigoMensagem:** Código de identificação da operação realizada. [veja a lista de Códigos](https://github.com/Varejonline/api/wiki/Retorno-API)
* **mensagem:** Mensagem da operação realizada

Requisição inválida: 
* HTTP STATUS 400 – BAD REQUEST
* Body: mensagem de erro

Status atual do pedido é igual ao novo status da requisição: 
* HTTP STATUS 409 – CONFLICT
* Body: mensagem de erro

### Exemplo

> POST https://integrador.varejonline.com.br/apps/api/pedidos/alterar-status

'Content-Type'='application/json'
```javascript
{
    "idPedido": 1,
    "status": "AGUARDANDO_ENTREGA",
    "statusPedidoVenda": {
        "id": 5,
        "nome": "Aguardando entrega"
    }
}
```