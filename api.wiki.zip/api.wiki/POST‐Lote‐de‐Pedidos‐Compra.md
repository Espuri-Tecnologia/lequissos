Este endpoint tem como intuito a recepção de uma lista com múltiplos pedidos de compra e seu processamento é assíncrono.

### URL

> POST https://integrador.varejonline.com.br/apps/api/pedidos-compra/lotes

### Parâmetros

Envie um JSON no corpo da requisição, contendo:

* **codigo:** código gerencial para o lote _(opcional, único)_ (string)
* **pedidosCompra:** lista de pedidos com as mesmas propriedades do [POST-Pedidos-compra](https://github.com/Varejonline/api/wiki/POST-pedidos-compra)
* **validarPedidosAntesDoProcessamento:** caso true: executa uma validação inicial em cada pedido de compra e, em caso de erro, o processamento não é executado. É retornado uma string com a descrição de cada erro. Caso false: O processamento dos pedidos é iniciado. Em caso de erros, o processamento dos pedidos seguintes não é interrompido. Após o processamento, a mensagem de erro poderá ser visualizada no [GET Lote de pedidos de compra](https://github.com/Varejonline/api/wiki/GET-Lote-de-Pedidos-compra) _(opcional, padrão: false)_
### Retorno

Sucesso HTTP 201 CREATED:

Retorna um Json com informações do resultado da operação realizada, contendo:

* **idRecurso:** id do lote gerado.
* **codigoMensagem:** Código de identificação da operação realizada. [veja a lista de Códigos](https://github.com/Varejonline/api/wiki/Retorno-API)


### Exemplo

> POST https://integrador.varejonline.com.br/apps/api/pedidos-compra/lotes

'Content-Type'='application/json'
```javascript
{
 "codigo": "PRS-152-Z",
 "pedidosCompra": [
  {
     "dataCompra":"07-05-2021",
     "dataLimiteEntrega":"07-07-2021",
     "entidade": {
       "id": 1,
       "documento": "00.000.000/0000-00"
     },
     "fornecedor": {
         "id": 1,
         "documento": "00000000000000"
     },
     "referenciaPedidoFornecedor":"REF. PEDIDO 1",
     "valorSeguro":0,
     "valorFrete":0,
     "valorOutros":0,
     "parcelas":[
      {
         "dataVencimento":"07-06-2021",
         "valor":25
      },
      {
         "dataVencimento":"07-07-2021",
         "valor":25
      }
     ],
     "observacao":"Detalhe adicional",
     "tipoPlanoPagamento": 2,
     "produtos":[
     {
         "produto": {
             "codigoSistema" : "0082.0005" 
         },
         "quantidade":10,
         "valorDesconto":0,
         "valorUnitario":5,
         "idOperacao":20
      }
     ],
     "dataPrevisaoEntrega":"07-06-2021"
  }
 ]
}
```

### Exemplo de retorno com erros ao usar a propriedade validarPedidosAntesDoProcessamento:

Requisição inválida: 
* HTTP STATUS 400 – BAD REQUEST

'Content-Type'='application/json'
```javascript
{
   "mensagem": "pedidosCompra[0]: Pedido sem fornecedor.\r\npedidosCompra[1]: Pedido sem data de compra.",
   "detalhes": "",
   "codigoMensagem": 1,
   "idRecurso": "0"

}
```
