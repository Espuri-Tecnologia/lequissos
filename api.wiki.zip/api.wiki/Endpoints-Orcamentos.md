 ## [GET Orcamentos](/Varejonline/api/wiki/GET-Orcamentos)

 ## [PUT Orcamentos](/Varejonline/api/wiki/PUT-Orcamentos)

 ## [POST Orcamentos](/Varejonline/api/wiki/POST-Orcamentos)

 ## [DELETE Orcamentos](/Varejonline/api/wiki/DELETE-Orcamentos)