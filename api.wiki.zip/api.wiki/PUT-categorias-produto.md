### URL

> PUT https://integrador.varejonline.com.br/apps/api/categorias-produto/:id_categoria_produto

### Parâmetros

Envie um JSON no corpo da requisição, contendo:
* **nome:** nome da categoria de produtos (string) _(obrigatório)_
* **unidade:** sigla da unidade de medida utilizada pelos produtos desta categoria (string) _(obrigatório)_
* **origem:** número de 0 a 7 que representa a origem a ser sugerida aos produtos da categoria, segundo a tabela da receita federal (long) _(obrigatório)_ [veja a lista de Origens] (Origens-de-Mercadoria)
* **categoriaPai:** lista de ids das categorias de produtos pai, caso a nova categoria a ser criada for uma subcategoria de outras categorias de produtos já existente(long) _(opcional)_
* **classificacao:** classificação a ser sugerida aos produtos desta categoria, que indica a finalidade para a qual eles serão utilizados. Pode assumir um dos seguintes valores: PRODUCAO_PROPRIA, REVENDA, ATIVO_IMOBILIZADO, CONSUMO, SERVICO_ISS, SERVICO_ICMS, INSUMO (string) _(obrigatório)_
* **metodoControle:** método de controle de estoque a ser sugerido aos produtos associados à categoria, podendo assumir um dos seguintes valores: ESTOCAVEL, LOTE, SERIE, NAO_ESTOCAVEL (string) _(obrigatório)_
* **ativo:** indica se a categoria de produto está ativa ou não. Se não for informado, é mantido o status atual do produto. (boolean) _(opcional)_

### Retorno

Retorna um Json com informações do resultado da operação realizada, contendo:
 * **idRecurso:** id da categoria atualizada.
 * **codigoMensagem:** Código de identificação da operação realizada. [veja a lista de Códigos] (Retorno-API)
 * **mensagem:** Mensagem da operação realizada

### Exemplo

> PUT https://integrador.varejonline.com.br/apps/api/categorias-produto/1

'Content-Type'='application/json'

```javascript
   {
      "nome":"CATEGORIA LIMPEZA",
      "classificacao":"REVENDA",
      "unidade":"CAIXA",
      "metodoControle":"ESTOCAVEL",
      "origem":0,
      "ativo":true
   }
```


### Exemplo de retorno:

_Sucesso:_
* HTTP STATUS 200 – OK
* Body:
```javascript
{
      "idRecurso": 1,
      "codigoMensagem": 0,
      "mensagem": "Operação realizada com sucesso."
}
```

_Requisição inválida:_
* HTTP STATUS 400 – BAD REQUEST
* Body: 
```javascript
{
      "idRecurso": 0,
      "codigoMensagem": 51,
      "mensagem": "Categoria sem nome"
}
```
