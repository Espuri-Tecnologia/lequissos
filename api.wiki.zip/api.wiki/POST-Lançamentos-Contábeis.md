Endpoint para criação de lançamentos contábeis.

### URLs

> POST https://integrador.varejonline.com.br/apps/api/lancamento-contabil

### Parâmetros

Envie um JSON no corpo da requisição, contendo:

* **idEntidade:** Entidade na qual será gerada a operação contábil (long)
* **data:** Data da operação contábil no formato dd/mm/yyyy hh:mm:ss (string)
* **lancamentoContabil:** Array de lançamentos da operação contábil (array)
    * **valor:** Valor do Lançamento (decimal)
    * **contaDebito:** id da conta débito do lançamento (long)
    * **contaCredito:** id da conta crédito do lançamento (long)
    * **numeroDoc:** Número de controle do lançamento (string)
    * **historico:** Histórico do Lançamento (string)
    * **terceiro:** id do [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros) associado ao lançamento (long)
    * **tipoDoc:** [Tipo do Documento](https://github.com/Varejonline/api/wiki/Tipos-de-Documentos-Financeiros) associado ao lançamento

### Retorno

### Exemplo de retorno:

_Sucesso:_
* HTTP STATUS 201 – CREATED
* Body:
Id da [Operação Contábil](https://github.com/Varejonline/api/wiki/GET-Lançamentos-Contábeis) Gerada

_Requisição inválida:_
* HTTP STATUS 400 – BAD REQUEST
* Body: String com o erro de validação

_Requisição bloqueada:_
* HTTP STATUS 403 – Forbidden
* Body: Mensagem de bloqueio

### Exemplo

> POST https://integrador.varejonline.com.br/apps/api/lancamento-contabil

```javascript
{
    "idEntidade": 1,
    "data": "05/10/2017 13:50:50",
    "lancamentoContabil": [
    	{
    		"valor": 10,
    		"contaDebito": 2451,
    		"contaCredito": 2450,
    		"numeroDoc": "10",
    		"historico": "Lançamento via API Nr 10",
    		"terceiro": 179,
    		"tipoDoc": 29
    	},
    	{
    		"valor": 10,
    		"contaCredito": 2451,
    		"contaDebito": 2450,
    		"numeroDoc": "10",
    		"historico": "Lançamento via API Nr 10",
    		"terceiro": 179,
    		"tipoDoc": 29
    	}
    ]
}
```