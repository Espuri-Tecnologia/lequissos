<table>
<tr><th>Id</th><th>Nome</th><th>Nr. Doc. Obrigatório</th><th>Tipo</th></tr>
<tr><td>1</td><td>FATURA</td><td>Sim</td><td>Contas Receber</td></tr>
<tr><td>2</td><td>CHEQUE</td><td>Não</td><td>Contas Receber</td></tr>
<tr><td>3</td><td>DARF</td><td>Não</td><td>Contas Receber</td></tr>
<tr><td>4</td><td>CUPOM FISCAL</td><td>Sim</td><td>Contas Receber</td></tr>
<tr><td>5</td><td>APÓLICE DE SEGURO</td><td>Não</td><td>Contas Pagar</td></tr>
<tr><td>6</td><td>CONHEC TRANSPORTE</td><td>Sim</td><td>Contas Receber</td></tr>
<tr><td>7</td><td>GARE</td><td>Não</td><td>Contas Pagar</td></tr>
<tr><td>8</td><td>GIA</td><td>Não</td><td>Contas Pagar</td></tr>
<tr><td>9</td><td>GUIA</td><td>Não</td><td>Contas Receber</td></tr>
<tr><td>10</td><td>PLAN COMPENSAÇÃO</td><td>Não</td><td>Contas Receber</td></tr>
<tr><td>11</td><td>PLAN CUSTO</td><td>Não</td><td>Contas Receber</td></tr>
<tr><td>12</td><td>RECIBO 13.SALÁRIO</td><td>Não</td><td>Contas Pagar</td></tr>
<tr><td>13</td><td>RECIBO DL</td><td>Não</td><td>Contas Pagar</td></tr>
<tr><td>14</td><td>RELATÓRIO KM</td><td>Não</td><td>Contas Receber</td></tr>
<tr><td>15</td><td>RESCISÃO CONTRATO</td><td>Não</td><td>Contas Pagar</td></tr>
<tr><td>16</td><td>CARTÃO</td><td>Não</td><td>Contas Receber</td></tr>
<tr><td>17</td><td>AVISO DE CRÉDITO</td><td>Não</td><td>Contas Receber</td></tr>
<tr><td>18</td><td>AVISO DE DÉBITO</td><td>Não</td><td>Contas Pagar</td></tr>
<tr><td>19</td><td>GPS</td><td>Não</td><td>Contas Receber</td></tr>
<tr><td>20</td><td>BOLETO</td><td>Não</td><td>Contas Receber</td></tr>
<tr><td>21</td><td>DIVERSOS</td><td>Não</td><td>Contas Receber</td></tr>
<tr><td>22</td><td>NOTA FISCAL</td><td>Sim</td><td>Contas Receber</td></tr>
<tr><td>23</td><td>RECIBO</td><td>Não</td><td>Contas Receber</td></tr>
<tr><td>24</td><td>RELATÓRIO</td><td>Não</td><td>Contas Receber</td></tr>
<tr><td>25</td><td>CARNÊ</td><td>Não</td><td>Contas Receber</td></tr>
<tr><td>26</td><td>CONTA MENSAL</td><td>Não</td><td>Contas Receber</td></tr>
<tr><td>27</td><td>DUPLICATA</td><td>Sim</td><td>Contas Receber</td></tr>
<tr><td>28</td><td>EXTRATO</td><td>Não</td><td>Contas Receber</td></tr>
<tr><td>29</td><td>FOLHA PAGTO</td><td>Não</td><td>Contas Pagar</td></tr>
<tr><td>30</td><td>GRFC</td><td>Não</td><td>Contas Receber</td></tr>
<tr><td>31</td><td>GFIP</td><td>Não</td><td>Contas Receber</td></tr>
<tr><td>32</td><td>PEDIDO DE COMPRA</td><td>Não</td><td>Contas Pagar</td></tr>
<tr><td>33</td><td>RECIBO FÉRIAS</td><td>Não</td><td>Contas Pagar</td></tr>
<tr><td>34</td><td>REQUIS MATERIAL</td><td>Não</td><td>Contas Pagar</td></tr>
<tr><td>35</td><td>PEDIDO</td><td>Não</td><td>Contas Receber</td></tr>
<tr><td>36</td><td>PROTOC ENTR MATERIAL</td><td>Não</td><td>Contas Pagar</td></tr>
<tr><td>37</td><td>DINHEIRO</td><td>Não</td><td>Contas Pagar</td></tr>
<tr><td>38</td><td>PROTOCOLO DE BAIXA</td><td>Não</td><td>Contas Pagar</td></tr>
<tr><td>39</td><td>BORDERÔ</td><td>Não</td><td>Contas Receber</td></tr>
<tr><td>40</td><td>TRANSFERÊNCIA</td><td>Não</td><td>Contas Receber</td></tr>
<tr><td>41</td><td>ROMANEIO</td><td>Não</td><td>Contas Receber</td></tr>
<tr><td>42</td><td>BALANÇO ABERTURA</td><td>Não</td><td>Contas Receber</td></tr>
<tr><td>43</td><td>PROTOCOLO DE RECLASSIFICAÇÃO</td><td>Não</td><td>Contas Receber</td></tr>
<tr><td>44</td><td>CONTA ÁGUA</td><td>Não</td><td>Contas Pagar</td></tr>
<tr><td>45</td><td>CONTA ENERGIA</td><td>Não</td><td>Contas Pagar</td></tr>
<tr><td>46</td><td>CONTA GÁS</td><td>Não</td><td>Contas Pagar</td></tr>
<tr><td>47</td><td>CONTA COMUNICAÇÃO</td><td>Não</td><td>Contas Pagar</td></tr>
<tr><td>48</td><td>CONTA TELECOMUNICAÇÃO</td><td>Não</td><td>Contas Pagar</td></tr>
<tr><td>49</td><td>PROTOCOLO DE TRANSFERÊNCIA</td><td>Não</td><td>Contas Receber</td></tr>
<tr><td>50</td><td>SINAL</td><td>Sim</td><td>Contas Receber</td></tr>
<tr><td>150</td><td>NOTA DE COBRANÇA</td><td>Sim</td><td>Contas Receber</td></tr>
<tr><td>192</td><td>PROTOCOLO DE AJUSTE</td><td>Não</td><td>Contas Receber</td></tr>
<tr><td>194</td><td>GARE ICMS</td><td>Sim</td><td>Contas Receber</td></tr>
<tr><td>195</td><td>PROTOCOLO DE DEVOLUÇÃO</td><td>Não</td><td>Contas Receber</td></tr>
<tr><td>196</td><td>APLIC FINANC</td><td>Não</td><td>Contas Receber</td></tr>
<tr><td>197</td><td>PGTO ELETRÔNICO</td><td>Não</td><td>Contas Receber</td></tr>
<tr><td>198</td><td>DOC</td><td>Não</td><td>Contas Receber</td></tr>
<tr><td>199</td><td>TED</td><td>Não</td><td>Contas Receber</td></tr>
<tr><td>200</td><td>VENDA D1</td><td>Sim</td><td>Contas Receber</td></tr>
<tr><td>300</td><td>DECLARAÇÃO DE IMPORTAÇÃO</td><td>Sim</td><td>Contas Receber
</table>