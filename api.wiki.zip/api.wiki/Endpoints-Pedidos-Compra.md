### [GET Pedidos de compra](/Varejonline/api/wiki/GET-pedidos-compra)
### [POST Pedido de compra](/Varejonline/api/wiki/POST-pedidos-compra)
### [PUT Pedido de compra](/Varejonline/api/wiki/PUT-pedidos-compra)
### [PUT Pedido de compra - Alterar observação](/Varejonline/api/wiki/PUT-pedidos-compra-alterar-observacao)
### [PUT Pedido de compra - Alterar referência pedido fornecedor](/Varejonline/api/wiki/PUT-pedidos-compra-alterar-referencia-pedido-fornecedor)
### [PUT Pedido de compra - Alterar status](/Varejonline/api/wiki/PUT-pedidos-compra-alterar-status)

<br>

##  EPCs

### [POST Vincular EPCs](/Varejonline/api/wiki/POST-vincular-epcs)

<br>

## Operação em lote 

Recomendado para criação de pedidos de compra quando a lista de produtos no pedido é extensa, pois nesse caso, na operação síncrona, o tempo para resposta pode ser bastante elevado.

### [GET Lote de Pedidos compra](/Varejonline/api/wiki/GET-Lote-de-Pedidos-compra)
### [POST Lote de Pedidos compra](/Varejonline/api/wiki/POST‐Lote‐de‐Pedidos‐Compra) (Assíncrona) 
