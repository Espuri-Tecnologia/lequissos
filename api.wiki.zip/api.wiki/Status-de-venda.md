Listagem dos tipos de status de venda existentes por padrão no sistema:

<table>
<tr><th>Status</th></tr>
<tr><td>PENDENTE</td></tr>
<tr><td>RECUSADO</td></tr>
<tr><td>CANCELADO</td></tr>
<tr><td>PREPARACAO</td></tr>
<tr><td>AGUARDANDO_ENTREGA</td></tr>
<tr><td>FINALIZADO</td></tr>
<tr><td>PEDIDO_CRIADO</td></tr>
<tr><td>COLETADO</td></tr>
<tr><td>DOCUMENTO_EMITIDO</td></tr>
<tr><td>SEPARADO</td></tr>
<tr><td>RETIRADO_CLIENTE</td></tr>
<tr><td>EM_ENTREGA</td></tr>
<tr><td>ENTREGUE</td></tr>
</table>

**Obs:** É possível excluir, editar e adicionar novos status de venda no sistema.