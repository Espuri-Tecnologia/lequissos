
<table>
<tr><th>Valor</th><th>Descricão</th></tr>
<tr><td>EMITENTE</td><td>Contratação do Frete por conta do Remetente (CIF)</td></tr>
<tr><td>DESTINATARIO_REMETENTE</td><td>Contratação do Frete por conta do destinatário/remetente (FOB)</td></tr>
<tr><td>TERCEIRO</td><td>Contratação do Frete por conta de terceiros</td></tr>
<tr><td>PROPRIO_REMETENTE</td><td>Transporte próprio por conta do remetente</td></tr>
<tr><td>PROPRIO_DESTINATARIO</td><td>Transporte próprio por conta do destinatário</td></tr>
</table>