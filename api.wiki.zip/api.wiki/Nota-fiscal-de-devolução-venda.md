# Necessidade

Por vezes é necessário coletar as notas fiscais da API e vincular os resultados com as operações gerenciais relacionadas.

No caso de devoluções de venda, por exemplo, isso é importante para encontrar os dados das vendas que foram devolvidas em cada devolução gerada (venda de origem devolvida).



## Coleta de nota fiscal por devolução de venda

Aqui vamos explicar como chegar na [nota fiscal](https://github.com/Varejonline/api/wiki/GET-notas-mercadoria) a partir de uma [devolução](https://github.com/Varejonline/api/wiki/GET-devolucoes).

Obtenha as [devoluções de venda](https://github.com/Varejonline/api/wiki/GET-devolucoes) pelo endpoint próprio e utilizando o valor do atributo "idEntradaGerada", faça um GET no endpoint de [notas de mercadorias](https://github.com/Varejonline/api/wiki/GET-notas-mercadoria) utilizando o filtro "idEntrada". Serão retornadas uma ou mais notas vinculadas à entrada informada. Se mais de uma nota for retornada, você perceberá que existirá apenas uma [nota emitida](https://github.com/Varejonline/api/wiki/Status-Documentos-Fiscais).