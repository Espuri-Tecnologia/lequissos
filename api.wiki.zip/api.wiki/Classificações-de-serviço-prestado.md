Listagem das possíveis Classificações de serviço prestado

<table>
<tr><th>ID</th><th>Nome</th></tr>
<tr><td>100000001</td><td>Limpeza, conservação ou zeladoria</td></tr>
<tr><td>100000002</td><td>Vigilância ou segurança</td></tr>
<tr><td>100000003</td><td>Construção civil</td></tr>
<tr><td>100000004</td><td>Serviços de natureza rural</td></tr>
<tr><td>100000005</td><td>Digitação</td></tr>
<tr><td>100000006</td><td>Preparação de dados para processamento</td></tr>
<tr><td>100000007</td><td>Acabamento</td></tr>
<tr><td>100000008</td><td>Embalagem</td></tr>
<tr><td>100000009</td><td>Acondicionamento</td></tr>
<tr><td>100000010</td><td>Cobrança</td></tr>
<tr><td>100000011</td><td>Coleta ou reciclagem de lixo ou de resíduos</td></tr>
<tr><td>100000012</td><td>Copa</td></tr>
<tr><td>100000013</td><td>Hotelaria</td></tr>
<tr><td>100000014</td><td>Corte ou ligação de serviços públicos</td></tr>
<tr><td>100000015</td><td>Distribuição</td></tr>
<tr><td>100000016</td><td>Treinamento e ensino</td></tr>
<tr><td>100000017</td><td>Entrega de contas e de documentos</td></tr>
<tr><td>100000018</td><td>Ligação de medidores</td></tr>
<tr><td>100000019</td><td>Leitura de medidores</td></tr>
<tr><td>100000020</td><td>Manutenção de instalações, de máquinas ou de equipamentos</td></tr>
<tr><td>100000021</td><td>Montagem</td></tr>
<tr><td>100000022</td><td>Operação de máquinas, de equipamentos e de veículos</td></tr>
<tr><td>100000023</td><td>Operação de pedágio ou de terminal de transporte</td></tr>
<tr><td>100000024</td><td>Operação de transporte de passageiros</td></tr>
<tr><td>100000025</td><td>Portaria, recepção ou ascensorista</td></tr>
<tr><td>100000026</td><td>Recepção, triagem ou movimentação de materiais</td></tr>
<tr><td>100000027</td><td>Promoção de vendas ou de eventos</td></tr>
<tr><td>100000028</td><td>Secretaria e expediente</td></tr>
<tr><td>100000029</td><td>Saúde</td></tr>
<tr><td>100000030</td><td>Telefonia ou telemarketing</td></tr>
<tr><td>100000031</td><td>Trabalho temporário na forma da Lei nº 6.019, de janeiro de 1974</td></tr>
</table>
