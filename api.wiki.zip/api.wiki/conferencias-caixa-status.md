Listagem dos possíveis status da conferência de caixa.

<table>
<tr><th>Status</th></tr>
<tr><td>NAO_CONFERIDO</td></tr>
<tr><td>CONFERIDO</td></tr>
<tr><td>CONFIRMADO</td></tr>
<tr><td>PROCESSANDO</td></tr>
<tr><td>CONCLUIDO</td></tr>
<tr><td>CONFERIDO_AUTOMATICAMENTE</td></tr>
<tr><td>ERRO</td></tr>
</table>