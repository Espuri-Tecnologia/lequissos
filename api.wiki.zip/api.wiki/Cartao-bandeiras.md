Listagem das possíveis bandeiras nas transações com cartão

<table>
<tr><th>Bandeira</th></tr>
<tr><td>Adyen</td></tr>
<tr><td>AgiPlan</td></tr>
<tr><td>Alegria</td></tr>
<tr><td>ALELO</td></tr>
<tr><td>AME</td></tr>
<tr><td>American Express</td></tr>
<tr><td>American Express POS</td></tr>
<tr><td>APPLE PAY</td></tr>
<tr><td>Aura</td></tr>
<tr><td>Banescard</td></tr>
<tr><td>Banescard POS</td></tr>
<tr><td>BaneseCard</td></tr>
<tr><td>Banpara</td></tr>
<tr><td>Banricard</td></tr>
<tr><td>Banricompras</td></tr>
<tr><td>Banrisul</td></tr>
<tr><td>Bndes</td></tr>
<tr><td>BONUSCRED</td></tr>
<tr><td>BR Card</td></tr>
<tr><td>Cabal</td></tr>
<tr><td>Cabal POS</td></tr>
<tr><td>CAIXA TEM</td></tr>
<tr><td>CalCard</td></tr>
<tr><td>CardSystem</td></tr>
<tr><td>CONVCARD</td></tr>
<tr><td>COOPER CARD</td></tr>
<tr><td>CREDILOJA</td></tr>
<tr><td>CrediShop</td></tr>
<tr><td>Crediz</td></tr>
<tr><td>CREDPAR</td></tr>
<tr><td>CredSystem</td></tr>
<tr><td>Credsystem POS</td></tr>
<tr><td>CUP</td></tr>
<tr><td>Diners Club</td></tr>
<tr><td>Diners Club POS</td></tr>
<tr><td>Discover</td></tr>
<tr><td>Ecommerce</td></tr>
<tr><td>Elo</td></tr>
<tr><td>Elo POS</td></tr>
<tr><td>Fortbrasil</td></tr>
<tr><td>GoodCard</td></tr>
<tr><td>Google Pay</td></tr>
<tr><td>Green Card</td></tr>
<tr><td>HIPER</td></tr>
<tr><td>Hipercard</td></tr>
<tr><td>Hipercard POS</td></tr>
<tr><td>IFOOD</td></tr>
<tr><td>Jcb</td></tr>
<tr><td>Justa</td></tr>
<tr><td>Mais</td></tr>
<tr><td>Master POS</td></tr>
<tr><td>MasterCard</td></tr>
<tr><td>MaxiPago</td></tr>
<tr><td>Megavale</td></tr>
<tr><td>Mercado Pago</td></tr>
<tr><td>Outros</td></tr>
<tr><td>Pagar.me</td></tr>
<tr><td>PagSeguro</td></tr>
<tr><td>PayPal</td></tr>
<tr><td>Personal Card</td></tr>
<tr><td>PicPay</td></tr>
<tr><td>PIX</td></tr>
<tr><td>RedeShop</td></tr>
<tr><td>SAMSUNG PAY</td></tr>
<tr><td>Senff</td></tr>
<tr><td>Serviloja</td></tr>
<tr><td>Sicredi</td></tr>
<tr><td>Sicredi POS</td></tr>
<tr><td>Sodexo</td></tr>
<tr><td>Sorocred</td></tr>
<tr><td>Sorocred POS</td></tr>
<tr><td>Stone</td></tr>
<tr><td>TECBIZ</td></tr>
<tr><td>Ticket</td></tr>
<tr><td>UnionPay</td></tr>
<tr><td>UP Brasil</td></tr>
<tr><td>UTIL card</td></tr>
<tr><td>VECELL CARD</td></tr>
<tr><td>VerdeCard</td></tr>
<tr><td>Visa</td></tr>
<tr><td>Visa POS</td></tr>
<tr><td>VISA VALE</td></tr>
<tr><td>VR Beneficios</td></tr>
</table>