### URL

> GET https://integrador.varejonline.com.br/apps/api/planos-gerenciais/:id/demonstrativo-financeiro

### Parâmetros

* **id:** id do plano gerencial do qual se deseja obter o demonstrativo (long)
* **desde:** [Veja o Filtro de Datas](https://github.com/Varejonline/api/wiki/Filtro-de-Datas)
* **ate:** [Veja o Filtro de Datas](https://github.com/Varejonline/api/wiki/Filtro-de-Datas)
* **terceiro:** [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros) a ser considerado no cálculo do valor financeiro (long)

### Retorno

* **nivel:** nível da conta do plano gerencial (string)
* **nome:** nome da conta do plano gerencial (string)
* **valor:** valor financeiro movimentado na conta no período solicitado (string)

### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/planos-gerenciais/1/demonstrativo-financeiro

```javascript
[
   {
      "nivel":"100.119",
      "nome":"ADIANTAMENTOS",
      "valor":-704.5
   },
   {
      "nivel":"100.119.164",
      "nome":"ADIANTAMENTOS DE CLIENTES DIVERSOS",
      "valor":243.0
   },
   {
      "nivel":"100.119.201",
      "nome":"DEVOL. ADTOS FORNECEDORES",
      "valor":-947.5
   }
]
```