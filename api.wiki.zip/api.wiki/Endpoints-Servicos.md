## [GET servicos](/Varejonline/api/wiki/GET-servicos)
## [POST servicos](/Varejonline/api/wiki/POST-serviços)
## [PUT servicos](/Varejonline/api/wiki/PUT-serviços)