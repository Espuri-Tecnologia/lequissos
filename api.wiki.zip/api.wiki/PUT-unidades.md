### URL

> PUT https://integrador.varejonline.com.br/apps/api/unidades/:id_unidade

### Parâmetros

Envie um JSON no corpo da requisição, contendo:
* **nome:** nome da unidade (string) _(obrigatório)_
* **sigla:** sigla da unidade (string) _(obrigatório)_

### Retorno

Retorna um Json com informações do resultado da operação realizada, contendo:
 * **idRecurso:** id da categoria atualizada.
 * **codigoMensagem:** Código de identificação da operação realizada. [veja a lista de Códigos] (Retorno-API)
 * **mensagem:** Mensagem da operação realizada

### Exemplo

> PUT https://integrador.varejonline.com.br/apps/api/unidades/1

'Content-Type'='application/json'

```javascript
   {
      "nome":"UNIDADE ALTERAR",
      "sigla":"UA"
   }
```


### Exemplo de retorno:

_Sucesso:_
* HTTP STATUS 200 – OK
* Body:
```javascript
{
      "idRecurso": 1,
      "codigoMensagem": 0,
      "mensagem": "Operação realizada com sucesso."
}
```

_Requisição inválida:_
* HTTP STATUS 400 – BAD REQUEST
* Body: 
```javascript
{
      "idRecurso": 0,
      "codigoMensagem": 0,
      "mensagem": "Unidade Inválida"
}
```

