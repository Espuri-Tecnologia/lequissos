### URLs

> GET https://integrador.varejonline.com.br/apps/api/configuracao-venda

> GET https://integrador.varejonline.com.br/apps/api/configuracao-venda/:id

### Parâmetros

* **inicio:** [veja o filtro de paginação] (Paginação de resultados)
* **quantidade:** [veja o filtro de paginação] (Paginação de resultados)
* **alteradoApos:** [veja como funciona este filtro] (Filtro-de-Data-Alteracao)

###Retorno 

Sucesso:
* **id:** id da configuração de venda(long)
* **inicio:** indica, caso exista, o início do período de vigência da configuração de venda no formato dd-mm-aaaa hh:mi:ss
* **fim:** indica, caso exista, o fim do período de vigência da configuração de venda no formato dd-mm-aaaa hh:mi:ss
* **entidades:** ids das [entidades](https://github.com/Varejonline/api/wiki/GET-entidades) para as quais a configuração de venda é válida (array)
* **classificacoesClientes:** ids das classificações de cliente para as quais a configuração de venda é válida (array)
* **planosPagamento:** ids dos planos de pagamento para os quais a configuração de venda é válida (array)
* **permanente:** indica se a configuração de venda é permanentemente válida, ou então se só é válida para um determinado período(boolean)
* **nome:** indica o nome da configuração de venda(string)
* **dataAlteracao:** indica a data da última alteração feita sobre a configuração de venda no formato dd-mm-aaaa hh:mi:ss
* **dataCriacao:** indica a data de criação da configuração de venda no formato dd-mm-aaaa hh:mi:ss
* **ativo:** indica se a configuração de venda está ativa(boolean)
* **deletado:** indica se a configuração de venda foi deletada(boolean)
* **limiteDesconto:** indica o limite de desconto definido para a configuração de venda(decimal)
* **descontoSugerido:** indica o desconto sugerido definido para a configuração de venda(decimal)
* **alterarPreco:** indica se a configuração de venda deve ou não alterar os preços dos produtos(boolean)
* **tabelaPreco:** id da tabela de preço para a qual a configuração de venda é válida (long)

Falha:
* **codigoErro:** Código de erro retornado pela aplicação (string)
* **descricaoErro:** Descrição do erro (string)

### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/configuracao-venda

```javascript
[
   {
      "id":1,
      "inicio":"09-10-2013 19:13:16",
      "fim":"09-10-2014 19:13:16",
      "entidades":[21, 11, 19],
      "classificacoesClientes":[31, 41, 50],
      "planosPagamento":[13, 12, 121],
      "permanente":true,
      "nome":"configuracao-xyz",
      "dataAlteracao":"23-12-2013 19:13:16",
      "dataCriacao":"09-12-2013 00:00:00",
      "ativo":true,
      "deletado":false,
      "limiteDesconto":1.25,
      "descontoSugerido":0.08,
      "alterarPreco":false,
      "tabelaPreco":1112
   }
]
```