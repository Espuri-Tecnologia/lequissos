### URLs

> PUT https://integrador.varejonline.com.br/apps/api/produtos/:id_produto

### Parâmetros

Envie um JSON no corpo da requisição, contendo:

* **descricao:** descrição do produto (string) _(obrigatório)_
* **classificacao:** classificação que indica a finalidade para a qual o produto será utilizado. Pode assumir um dos seguintes valores: PRODUCAO_PROPRIA, REVENDA, ATIVO_IMOBILIZADO, CONSUMO, SERVICO_ISS, SERVICO_ICMS, INSUMO (string) _(obrigatório)_
* **origem:** número de 0 a 8 que representa a [origem](https://github.com/Varejonline/api/wiki/Origens-de-Mercadoria), segundo a tabela da receita federal (long) _(obrigatório)_ 
* **fci:** número de controle da Ficha de Conteúdo de Importação. (string)
* **codigoCest:** Código Especificador da Substituição Tributária. (String)
* **codigoNcm:** código do NCM( Nomenclatura Comum Mercosul) que identifica a natureza do produto (string)
* **produtoEquivalente:** Id do produto que será vinculado como equivalente ao produto criado (long) _(opcional)_
* **produtoBaseSeminovo:** Id do produto original que será vinculado ao produto criado (long) _(opcional)_
* **metodoControle:** ESTOCAVEL, NAO_ESTOCAVEL, SERIE ou (LOTE `deprecated`: É aceito somente quando o método atual é LOTE. Não é possível alterar de LOTE para outro método de controle.) (string) _(obrigatório)_
* **unidade:** sigla da unidade de medida utilizada pelo produto, por exemplo "UN" ou "KG" (string) _(obrigatório)_
* **unidadesProporcao:** Lista de Unidades Proporcionais da Mercadoria _(opcional)_
  * **unidade:** Sigla da unidade proporcional (string)
  * **proporcao:** Proporção da unidade sobre a unidade principal (decimal)
* **custoReferencial:** valor referencial de qual é o custo do produto (decimal) _(obrigatório)_
* **listCustoReferencial:** Lista de preço de Custo por [entidade](https://github.com/Varejonline/api/wiki/GET-entidades)
  * **entidade:** Id da [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) (long) _(obrigatório)_
  * **precoCusto:** Custo do produto na [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) (decimal) _(obrigatório)_
* **cnpjFornecedores:** lista com o CNPJ dos [terceiros](https://github.com/Varejonline/api/wiki/GET-terceiros) que são fornecedores do produto  (lista - String) _(opcional)_ - O fornecedor deve estar previamente cadastrado no sistema.
* **fornecedores:** Lista de fornecedores com código
  * **cnpj:** CNPJ do fornecedor
  * **codigo:** Código do fornecedor
* **urlsFotosProduto:** lista com as URLs das fotos do produto (lista - string) _(opcional)_
* **disponivelEcommerce:** Define se o produto pode ser disponibilizado no ecommerce (boolean) _(opcional)_
* **disponivelMarketplace:** Define se o produto pode ser disponibilizado no marketplace (boolean) _(opcional)_
* **amostraGratis:** Define se o produto vai ser amostra gratis (boolean) _(opcional)_
* **especificacao:** texto contendo uma especificação para o produto (string) _(opcional)_
* **codigoBarras:** código de barras do produto (string) _(opcional)_
* **codigosBarraAdicionais:** lista de códigos de barras adicionais do produto (Lista de string) _(opcional)_
* **codigoInterno:** código interno do produto na empresa (string) _(opcional)_
* **tags:** Strings concatenadas por vírgula que permitem consulta de produtos no sistema (string) _(opcional)_
* **estoqueMaximo:** quantidade máxima de estoque produto (decimal) _(opcional)_
* **estoqueMinimo:** quantidade mínima de estoque do produto (decimal) _(opcional)_
* **peso:** peso do produto (decimal) _(opcional)_
* **altura:** altura do produto (decimal) _(opcional)_
* **comprimento:** comprimento do produto (decimal) _(opcional)_
* **largura:** largura do produto (decimal) _(opcional)_
* **dadosPorEntidade:** Lista de Configurações por Entidade do Produto _(opcional)_
  * **entidade:** Id da [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) (long)
  * **estoqueMinimo:** Estoque mínimo referencial do produto na entidade (decimal)
  * **estoqueMaximo:** Estoque máximo referencial do produto na entidade (decimal)
  * **codBeneficioFiscal:** Código do benefício fiscal do produto na entidade (string) _(opcional)_
  * **codBeneficioFiscalRbc:** Código do benefício fiscal RBC do produto na entidade (string) _(opcional)_
  * **codBeneficioFiscalCp:** Código do crédito presumido do produto na entidade (string) _(opcional)_
  * **percentualCreditoPresumido:** Percentual do crédito presumido do produto na entidade (decimal) _(opcional)_
* **modalidadeCalculoFiscalCreditoPresumido:** PERCENTUAL_FIXO ou CARGA_TRIBUTARIA_EFETIVA _(opcional)_
* **produtoBase:** Dados do produto pai do SKU que será atualizado. Obrigatório para itens de grade.
  * **id:** id do produto pai (Long) _(opcional)_
  * **codigoSistema:** Código do sistema para o produto pai (string)
  * **nome:** Nome do produto pai (string) _(obrigatório)_
* **valorAtributos:** combinação de atributos da grade que geraram este produto. Obrigatório para itens de grade.
  * **nome:** nome do atributo da grade (string) _(obrigatório)_
  * **valor:** valor do atributo para este produto (string) _(obrigatório)_
  * **codigo:** código do valor do atributo (string) _(opcional)_
* **ativo:** indica se o produto está ativo ou não (boolean) (caso não informado assume valor "true")
* **definirPrecoVendaPelaFichaTecnica:** se o preço de venda do produto é definido pelos componentes (boolean), _(opcional, padrão: false)_
* **componentes:** Dados dos itens que compõem a ficha técnica do produto _(opcional)_
  * **produto:** Produto presente na ficha técnica _(obrigatório)_
    * **id:** id do produto (long) _(opcional se codigoSistema for informado)_
    * **codigoSistema:** Código sistema do produto (string) _(opcional se id for informado)_
  * **quantidade:** Quantidade de peças do item na ficha técnica (decimal) _(obrigatório)_
  * **precoVenda:** preço de venda do componente (decimal) _(opcional, padrão: Preço na tabela padrão)_
  * **unidade:** Sigla da unidade de medida que representa a quantidade (string) _(obrigatório)_
* **custoUnitarioRoyalties:** custo unitário em royalties do produto (decimal) _(opcional)_
* **categorias:** Lista com os dados das categorias que definem a estrutura mercadológica do produto. Deve ser informada uma categoria para cada nível de categoria cadastrado [nível de categoria cadastrado](https://github.com/Varejonline/api/wiki/GET-niveis-categoria).
  * **nome:** Nome da Categoria (string) _(obrigatório)_
  * **nivel:** **Nome** do Nível onde está localizada a categoria (string) _(obrigatório)_
* **atributosProduto:** Lista com os dados dos atributos de produto _(opcional)_
  * **id:** id do atributo de produto (long) _(opcional, caso queira criar um novo valor)_
  * **nome:** nome do atributo para pesquisa no sistema (string) _(opcional)_ _(caso o id não seja informado será realizada a busca pelo nome, se não encontrado, será criado um atributo do tipo 'VALOR' utilizando este nome e vinculando ao campo informado)_
  * **campo:** id do campo que o atributo pertence (long) _(obrigatório)_ (consultar estrutura em: [atributos de produto](https://github.com/Varejonline/api/wiki/GET-atributos-de-produtos))

    É possível criar apenas atributos do tipo 'VALOR', e a estrutura deve estar completamente preenchida.

Caso a classificação do produto seja INDUSTRIALIZACAO_PROPRIA ou COMERCIALIZACAO_REVENDA, os campos abaixo podem ser preenchidos. 
Caso não seja, os mesmos não devem ser preenchidos com qualquer valor diferente de zero. 

* **descontoMaximo:** porcentagem máxima de desconto que pode ser oferecida na venda do produto (decimal) _(opcional)_
* **comissao:** comissão percentual recebida pelo [vendedor](https://github.com/Varejonline/api/wiki/GET-representantes) na venda do produto (decimal) OPCIONAL
* **preco:** preço padrão do produto (decimal) OPCIONAL
* **precoVariavel:** Define se o preço de venda do produto é definido somente no momento da venda (boolean) _(obrigatório)_

**Ajuste de preço da grade em lote:**

_Nos casos onde for necessário atualizar o preço de toda uma grade de produtos para um valor padrão, ao realizar o PUT de um **produto base**, é possível informar o atributo "replicarPrecoGrade", com os valores **true** ou **false**, sendo true para replicar para toda a grade o preço informado no produto base e false para não replicar (Default quando o parâmetro não é informado)_
### Retorno

Retorna um Json com informações do resultado da operação realizada, contendo:
 * **idRecurso:** id do produto atualizado.
 * **codigoMensagem:** Código de identificação da operação realizada. [veja a lista de Códigos](https://github.com/Varejonline/api/wiki/Retorno-API)
 * **mensagem:** Mensagem da operação realizada


### Exemplo

> PUT https://integrador.varejonline.com.br/apps/api/produtos/1

Atualização de um produto simples ou base de grade. No caso de um produto base de grade, os campos padrões serão replicados aos itens da grade (Todos exceto: codigoBarras, codigoInterno, ativo, preco, codigoSistema, custoReferencial, listCustoReferencial e urlsFotosProduto).
```javascript
   {
      "cnpjFornecedores":["25.348.796/0001-07"],
      "urlsFotosProduto":[
            "http://foto1.jpg",
            "http://foto2.jpg",
            "http://foto3.jpg"],
      "descricao":"GRANOLA 20G",
      "especificacao":"GRANOLA 20G SACHE",
      "metodoControle":"ESTOCAVEL",
      "codigoNcm": "2313.23.23",	
      "origem":3,
      "fci":"B01F70AF-10BF-4B1F-848C-65FF57F616FE",
      "codigoCest":"22.001.00",
      "codigoBarras":"6445662344598",
      "codigosBarraAdicionais": [
          "6445662344599",
          "6445662344580"
      ],
      "codigoInterno":"12322",
      "tags":"000192,camisalarga,ponta de estoque",
      "codigoSistema":"0001",
      "unidade":"UNIDADE",
      "classificacao":"CONSUMO",
      "custoReferencial":30,
      "custoUnitarioRoyalties":10.00,
      "listCustoReferencial":[
         {
            "entidade":1,
            "precoCusto":29.85
         },
         {
            "entidade":2,
            "precoCusto":32.02
         }
      ],
      "preco":65,
      "precoVariavel": false,
      "descontoMaximo":10.0,
      "comissao":0,
      "estoqueMaximo":700,
      "estoqueMinimo":100,
      "peso":100,
      "altura":100,
      "comprimento":100,
      "largura":100,
      "disponivelEcommerce": true,
      "disponivelMarketplace": true,
      "ativo":true,
      "categorias": [
         {
             "nome":"Natural",
             "nivel":"DEPARTAMENTO",
         },
         {
             "nome":"Graos",
             "nivel":"SETOR",
         }
      ],
      "atributosProduto": [
         {
             "nome": "Relógio",
	     "campo": 101,
	     "id": 103
         },
         {
             "nome": "Ano novo",
	     "campo": 121,
	     "id": 122
         },
         {
             "nome": "Smart",
	     "campo": 124,
	     "id": 125
         }
      ]
   }
```

Atualização de um item de grade. Somente serão atualizados os campos: codigoBarras, codigoInterno, ativo, preco, codigoSistema, custoReferencial, listCustoReferencial, peso, altura, comprimento, largura, disponivelEcommerce, disponivelMarketplace e urlsFotosProduto. Os demais serão utilizado apenas para validação.

> PUT https://integrador.varejonline.com.br/apps/api/produtos/2

```javascript
   {
      "cnpjFornecedores":["25.348.796/0001-07", "90.837.241/0001-82"],
      "urlsFotosProduto":[
            "http://foto1.jpg",
            "http://foto2.jpg",
            "http://foto3.jpg"],
      "descricao":"CAMISETA POLO AZUL P",
      "especificacao":"CAMISETA",
      "metodoControle":"ESTOCAVEL",
      "codigoNcm": "2313.23.23",	
      "origem":3,
      "fci":"B01F70AF-10BF-4B1F-848C-65FF57F616FE",
      "codigoCest":"22.001.00",
      "codigoBarras":"6465464654567",
      "codigoInterno":"12002",
      "codigoSistema":"0002.0001",
      "unidade":"UNIDADE",
      "classificacao":"REVENDA",
      "custoReferencial":28.20,
      "custoUnitarioRoyalties":10.00,
      "listCustoReferencial":[
         {
            "entidade":1,
            "precoCusto":31.85
         },
         {
            "entidade":2,
            "precoCusto":22.02
         }
      ],
      "preco":40.50,
      "precoVariavel": false,
      "descontoMaximo":0,
      "comissao":5.0,
      "estoqueMaximo":100,
      "estoqueMinimo":10,
      "peso":100,
      "altura":100,
      "comprimento":100,
      "largura":100,
      "disponivelEcommerce": true,
      "disponivelMarketplace": true,
      "ativo":true,
      "produtoBase": {
          "id":239,
          "codigoSistema":"0002",
          "nome":"CAMISETA POLO"
      },
      "valorAtributos":[
         {
            "nome":"COR",
            "valor":"AZUL",
            "codigo":"123"
         },
         {
            "nome":"TAMANHO",
            "valor":"P",
            "codigo":"456"
         }
      ],
      "categorias": [
         {
             "nome":"Vestuario",
             "nivel":"DEPARTAMENTO",
         },
         {
             "nome":"Esporte Fino",
             "nivel":"SETOR",
         }
      ]
   }
```


### Exemplo de retorno:

_Sucesso:_
* HTTP STATUS 200 – OK
* Body:
```javascript
{
      "idRecurso": 1,
      "codigoMensagem": 0,
      "mensagem": "Operação realizada com sucesso."
}
```

_Requisição inválida:_
* HTTP STATUS 400 – BAD REQUEST
* Body: 
```javascript
{
      "idRecurso": 0,
      "codigoMensagem": 10,
      "mensagem": "Produto sem descrição"
}
```