### URL

> PUT https://integrador.varejonline.com.br/apps/api/pedidos-compra/:id/alterar-observacao

### Parâmetros

Envie um JSON no corpo da requisição, contendo:

* **observacao:** observações do pedido de compra (string) (max. 4000 chars)


### Exemplo

> PUT https://integrador.varejonline.com.br/apps/api/pedidos-compra/100/alterar-observacao

'Content-Type'='application/json'
```javascript
{
   "observacao":"Esta é uma nova observação. Ela irá substituir a observação existente no pedido de compra."
}
```
