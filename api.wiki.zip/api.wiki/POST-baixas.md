### URL

> POST https://integrador.varejonline.com.br/apps/api/baixas

### Parâmetros

Envie um JSON no corpo da requisição, contendo:
* **idContaBaixar:** id da conta a pagar ou a receber que será alvo da baixa (long) _(obrigatório)_
* **tipoDoc:** [tipo da fatura](https://github.com/Varejonline/api/wiki/Tipos-de-Documentos-Financeiros). Será aplicado DIVERSOS ou EXTRATO caso não informado, variando de acordo com a conta disponibilidade informada.
* **codigoContaDisponibilidade:** código da [conta disponibilidade](/Varejonline/api/wiki/GET-contas-disponibilidade) na qual será efetuada a baixa (string)  _(obrigatório para pagamentos em dinheiro ou quando não informado o tipo de documento)_.
* **entidade:** [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) entidade _(obrigatório quando não informado a conta disponibilidade)_ (objeto complexo)
    * **id:** id da entidade onde será realizada a baixa (long) 
* **data:**  data da baixa (string) _(obrigatório)_
* **historico:**  quando não informado, será gerado automaticamente (string) _(opcional, max: 255 chars)_ 
* **formaPagamento:** indica como o pagamento será dividido entre cartão, cheque, dinheiro ou adiantamento
    * **dinheiro:** forma de pagamento em dinheiro 
        * **valor:** valor da baixa em dinheiro (decimal)
    * **cheques:** forma de pagamento em cheques
        * **idTerceiroTitular:** [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros) titular do cheque (long) 
        * **agencia:** agencia relacionado ao cheque  (string)
        * **nroBanco:** numero do banco relacionado ao cheque  (string)
        * **numeroCheque:** numero do cheque  (long)
        * **codigoCheque:** codigo do cheque  (string)
        * **contaCorrente:** numero de conta corrente relacionado ao cheque  (string)
        * **dataVencimento:** data de vencimento do cheque  (string)
        * **valor:** valor do cheque (decimal)
    * **cartoes:** forma de pagamento em cartões
        * **idNegociacao:** id da negociação do cartão a ser utilizado na baixa (long).
        * **numeroParcelas:** numero de parcelas da negociação de cartão (inteiro)
        * **valor:** valor a ser baixado em cartão (decimal)
        * **nsu:** nsu da transação em cartão (string)
        * **codAutorizacao:** código de autorização do pagamento em cartão (string)
    * **adiantamentos:** forma de pagamento em adiantamentos.
        * **idAdiantamento:** id do adiantamento a ser utilizado na baixa (long)
        * **valor:** valor pago em adiantamento (decimal)

### Retorno

Sucesso:
* HTTP STATUS 201 – CREATED
* Body: id da baixa gerada

Requisição inválida: 
* HTTP STATUS 400 – BAD REQUEST
* Body: mensagem de erro

### Exemplo

> POST https://integrador.varejonline.com.br/apps/api/baixas

'Content-Type'='application/json'

```javascript
{
   "idContaBaixar":6,
   "codigoContaDisponibilidade":"947-1",
   "data":"30-08-2013",
   "historico":"baixa API",
   "entidade": {
      "id": 3
   },
   "formaPagamento":{
      "dinheiro":{
         "valor":5
      },
      "cheques":[
         {
            "idTerceiroTitular":8395,
            "codigoCheque":"121324878946587",
            "dataVencimento":"31-08-2013",
            "valor":10
         },
         {
            "idTerceiroTitular":1,
            "agencia":"1231",
            "nroBanco":"57894",
            "numeroCheque":1,
            "contaCorrente":"546878",
            "dataVencimento":"31-08-2013",
            "valor":10
         }
      ],
      "cartoes":[
         {
            "idNegociacao":1,
            "numeroParcelas":1,
            "valor":10,
            "nsu":"999090053",
            "codAutorizacao":"090053"
         }
      ],
      "adiantamentos":[
         {
            "idAdiantamento":45,
            "valor":1
         }
      ]
   }
}
```