Lista os conhecimentos de transporte, tanto de entrada quanto de saída.

### URLs

> GET https://integrador.varejonline.com.br/apps/api/conhecimentos-transporte

> GET https://integrador.varejonline.com.br/apps/api/conhecimentos-transporte/:id

### Parâmetros

* **inicio:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **quantidade:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)

### Retorno

* **id:** id do conhecimento de transporte (long)
* **tipo:** tipo do conhecimento de transporte (string). Os valores possíveis são: ENTRADA e SAIDA
* **modelo:** modelo do conhecimento de transporte (string). Os modelos existentes são: CTE e IMPRESSO.
* **serie:** número de série associado com o documento do conhecimento de transporte. (string)
* **numeroConhecimentoTransporte:** número do documento do conhecimento de transporte. (long)
* **notaMercadoriaOriginaria:** id da nota de mercadoria originária do documento de conhecimento de transporte, que pode ser consultada no GET Notas Mercadoria
* **modalidadeFrete:** Modalidade de frete utilizado para o conhecimento de transporte que representa o responsável pelo transporte. (string) Os valores disponíveis são SEM_FRETE, POR_DESTINATARIO, POR_EMITENTE, POR_TERCEIRO.
* **data:** data de emissão do conhecimento de transporte (string)
* **idTerceiroRemetente:** id do [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros) remetente (long)
* **idTerceiroDestinatario:** id do [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros) destinatário (long)
* **status:** status do conhecimento de transporte (string). [veja os valores de status de documentos  fiscais] (Status-Documentos-Fiscais)
* **cfop:** código CFOP da operação (integer)
* **valorTotal:** valor total do conhecimento de transporte (decimal)
* **valorDesconto:** valor do desconto aplicado ao conhecimento de transporte (decimal)
* **icms:** dados do ICMS aplicado ao conhecimento de transporte (segue a estrutura comum abaixo)
* **cofins:** dados do COFINS aplicado ao conhecimento de transporte (segue a estrutura comum abaixo)
* **pis:** dados do PIS aplicado ao conhecimento de transporte (segue a estrutura comum abaixo)

Estrutura comum para tributos:
   * **base:** valor da base de cálculo do tributo (decimal)
   * **aliquota:** valor da alíquota aplicada (decimal)
   * **valor:** valor do tributo (decimal)
   * **cst:** código de situação tributária (string)

### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/conhecimentos-transporte

```javascript
[
   {
      "id":1,
      "tipo":"ENTRADA",
      "modelo":"IMPRESSO",
      "serie":"100",
      "modalidadeFrete":"SEM_FRETE",
      "numeroConhecimentoTransporte":6692,
      "data":"20-12-2012",
      "idTerceiroRemetente":383,
      "idTerceiroDestinatario":479,
      "status":"EMITIDO",
      "cfop":2116,
      "valorTotal":10,
      "valorDesconto":0,
      "icms":{
         "base":1120,
         "valor":134.4,
         "aliquota":12,
         "cst":"00"
      },
      "cofins":{
         "base":1000,
         "valor":30,
         "aliquota":3,
         "cst":"01"
      },
      "pis":{
         "base":1000,
         "valor":6.5,
         "aliquota":0.65,
         "cst":"01"
      }
   }
]
```