### URLs

> GET https://integrador.varejonline.com.br/apps/api/gestao-franquias/franquias

    Obtém todas as franquias

> GET https://integrador.varejonline.com.br/apps/api/gestao-franquias/franquias/:id

    Obtém as informações de uma franquia por id


### Parâmetros

* **cnpj:** cnpj da franquia que deseja filtrar

### Retorno

* **id:** id da franquia (long)
* **documento:** documento da franquia (string)
* **nome:** nome da franquia (string)

### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/gestao-franquias/franquias

```javascript
[
    {
      "id": 1596069,
      "documento": "35.910.952/0001-27",
      "nome": "FRANQUIA FG-659"
    },
    {
      "id": 1596733,
      "documento": "17.622.696/0001-90",
      "nome": "FRANQUIA FG-674"
    }
  ]
```