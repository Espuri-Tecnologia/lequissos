Endpoint para exclusão de vouchers e suas reservas de estoque, quando aplicável.

### URLs

DELETE https://integrador.varejonline.com.br/apps/api/vouchers/:id

### Parâmetros

* **id:** Id do voucher que deve ser excluído (Long - Path Param)

### Retorno

Retorna um Json com informações do resultado da operação realizada, contendo:
 * **idRecurso:** id do voucher deletado.
 * **codigoMensagem:** Código de identificação da operação realizada. [veja a lista de Códigos](https://github.com/Varejonline/api/wiki/Retorno-API)
 * **mensagem:** Mensagem da operação realizada