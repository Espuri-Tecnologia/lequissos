### URLs

> GET https://integrador.varejonline.com.br/apps/api/conferencias-caixa

> GET https://integrador.varejonline.com.br/apps/api/conferencias-caixa/:id

### Parâmetros

* **entidades:** [Veja como Funciona este Filtro](https://github.com/Varejonline/api/wiki/Filtro-de-Entidades)
* **inicio:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **quantidade:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **alteradoApos:** (considera-se o campo dataOperacao) [Entenda a Coleta de Alterações](https://github.com/Varejonline/api/wiki/Filtro-de-Data-Alteração)
* **desde:** [Veja o Filtro de Datas](https://github.com/Varejonline/api/wiki/Filtro-de-Datas)
* **ate:** [Veja o Filtro de Datas](https://github.com/Varejonline/api/wiki/Filtro-de-Datas)
* **representantes:** [Veja como Funciona este Filtro](https://github.com/Varejonline/api/wiki/Filtro-de-Representantes) 
* **instalacoes:**  lista de ids das instalações desejadas, separados por vírgula
* **operacoes:**  lista das possíveis operações: ABERTURA, SANGRIA, SUPRIMENTO ou FECHAMENTO. Separadas por vírgula

### Retorno

* **id:** identificador da conferência de caixa (long)
* **dataOperacao:** data em que a operação foi efetuada, no formato dd-mm-aaaa hh:mi:ss (string)
* **motivo:** motivo das operações SANGRIA ou SUPRIMENTO (string)
* **observacaoPDV:** observação realizada durante a operação no PDV (string)
* **observacaoERP:** observação feita na conferência de caixa no ERP (string)
* **valorDinheiro:** valor em dinheiro para as operações ABERTURA, SANGRIA ou SUPRIMENTO (decimal)
* **valorCheque:** valor em cheque para as operações ABERTURA, SANGRIA ou SUPRIMENTO (decimal)

* **entidade:** dados da entidade
  * **id:** id da [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) (long)
  * **nome:** nome da [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) (string)
  * **documento:** CNPJ formatado da loja associada a [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) (string)
* **representante:** dados da o representante 
  * **id:** id do [representante](https://github.com/Varejonline/api/wiki/GET-representantes) (long)
  * **nome:** nome do [representante](https://github.com/Varejonline/api/wiki/GET-representantes) (string)
  * **documento:** documento do [representante](https://github.com/Varejonline/api/wiki/GET-representantes) (string)
* **terminal:** nome do terminal (string)
* **operacao:** operação de caixa (ABERTURA, SANGRIA, SUPRIMENTO ou FECHAMENTO) (string)
* **instalacao:** id da instalação (long)
* **statusConferencia:** [status](https://github.com/Varejonline/api/wiki/conferencias-caixa-status) da conferência de caixa (string)
* **fechamentoCaixa:** informações da operação FECHAMENTO de caixa
  * **valoresInformados:** valores informados (classe com todas as propriedades tipo decimal)
    * **dinheiro:** valor informado em dinheiro
    * **pix:** valor informado em pix
    * **chequePrazo:** valor informado em cheque à prazo
    * **chequeAVista:** valor informado em cheque à vista 
    * **crediario:** valor informado em crediário 
    * **cartaoCredito:** valor informado cartão de crédito 
    * **cartaoDebito:** valor informado em cartão de débito 
    * **cartaoOutros:** valor informado em outros cartões 
    * **adiantamento:** valor informado em adiantamentos 
    * **valeTroca:** valor informado em vale troca 
  * **valoresCalculados:** valores calculados (classe com todas as propriedades tipo decimal)
    * **dinheiro:** valor calculado em dinheiro 
    * **pix:** valor calculado em pix 
    * **chequePrazo:** valor calculado em cheque à prazo 
    * **chequeAVista:** valor calculado em cheque à vista 
    * **crediario:** valor calculado em crediário 
    * **cartaoCredito:** valor calculado cartão de crédito 
    * **cartaoDebito:** valor calculado em cartão de débito 
    * **cartaoOutros:** valor calculado em outros cartões 
    * **adiantamento:** valor calculado em adiantamentos 
    * **valeTroca:** valor calculado em vale troca 



### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/conferencias-caixa

```javascript
{  
        "id": 1,
        "dataOperacao": "06/09/2017 10:39:50",
        "entidade": {
            "id": 1,
            "nome": "ENTIDADE EXEMPLO",
            "documento": "00.000.000/0001-11"
        },
        "representante": {
            "id": 1,
            "nome": "REPRESENTANTE EXEMPLO",
            "documento": "000.000.000-00"
        },
        "terminal": "PDV4",
        "operacao": "FECHAMENTO",
        "instalacao": 1,
        "statusConferencia": "CONFERIDO_AUTOMATICAMENTE",
        "observacaoPDV": "Observação pdv",
        "observacaoERP": "Observação erp",
        "fechamentoCaixa": {
            "valoresCalculados": {
                "adiantamento": 0,
                "dinheiro": 0,
                "pix": 0,
                "valeTroca": 0,
                "crediario": 0,
                "cartaoDebito": 0,
                "cartaoCredito": 0,
                "chequeAVista": 0,
                "chequePrazo": 0,
                "cartaoOutros": 0
            },
            "valoresInformados": {
                "adiantamento": 0,
                "dinheiro": 0,
                "pix": 0,
                "valeTroca": 0,
                "crediario": 0,
                "cartaoDebito": 0,
                "cartaoCredito": 0,
                "chequeAVista": 0,
                "chequePrazo": 0,
                "cartaoOutros": 0
            }
        }
 }
```