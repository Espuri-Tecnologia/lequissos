Listagem das possíveis modalidades de frete.

<table>
<tr><th>Modalidade</th></tr>
<tr><td>EMITENTE</td></tr>
<tr><td>DESTINATARIO_REMETENTE</td></tr>
<tr><td>TERCEIRO</td></tr>
<tr><td>PROPRIO_REMETENTE</td></tr>
<tr><td>PROPRIO_DESTINATARIO</td></tr>
<tr><td>SEM_FRETE</td></tr>
</table>