### URLs

> GET https://integrador.varejonline.com.br/apps/api/planos-pagamento-compras

> GET https://integrador.varejonline.com.br/apps/api/planos-pagamento-compras/:id


### Parâmetros

* **inicio:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **quantidade:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **desde:** [Veja o Filtro de Datas](https://github.com/Varejonline/api/wiki/Filtro-de-Datas)
* **ate:** [Veja o Filtro de Datas](https://github.com/Varejonline/api/wiki/Filtro-de-Datas)
* **alteradoApos:** [Entenda a Coleta de Alterações](https://github.com/Varejonline/api/wiki/Filtro-de-Data-Alteração)
* **descricao:** descricao do Plano de Pagamento


### Retorno
    
* **id:** id do plano de pagamento (Long)
* **descricao**: descrição do plano de pagamento (String)
* **acrescimo**: valor do acréscimo do plano (BigDecimal)
* **valorMinimo**: valor mínimo para o plano (BigDecimal)
* **padrao**: indica se o plano de pagamento é o padrão (boolean)
* **ativo**: indica se o plano de pagamento está ativo (boolean)
* **dataAlteracao:** última data de alteração do plano de pagamento, no formato dd-mm-aaaa hh:mi:ss (String)
* **dataCriacao**: indica a data de criação do plano de pagamento (String)
* **sugestaoVencimento**: indica se o vencimento do plano de pagamento deve ser sugerido (boolean)
* **tipo**: Tipo do plano de pagamento. Este parâmetro pode assumir um dos seguintes valores: AVULSO, AVISTA,	FIXO e VARIAVEL (String)
* **periodo**: Período do plano de pagamento. Este parâmetro pode assumir um dos seguintes valores: MENSAL, 
BIMESTRAL, TRIMESTRAL e ANUAL(String)
* **parcelas:** lista de parcelas do plano de pagamento:
	* **id:** numero da parcela (long)
	* **porcentagem:** porcentagem (BigDecimal )
	* **dia:** dia (Integer)
	* **quantidadeDias:** quantidade de dias (Integer)


### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/planos-pagamento-compras

```javascript
[
   {
        "id": 21,
        "descricao": "TESTE 001",
        "acrescimo": 10,
        "valorMinimo": 10,
        "numeroParcelas": 2,
        "padrao": false,
        "ativo": true,
        "dataAlteracao": "13-08-2014 18:11:28",
        "dataCriacao": "13-08-2014 18:11:28",
        "sugestaoVencimento": false,
        "tipo": "FIXO",
        "periodo": "MENSAL",
        "parcelas": [
            {
                "id": 1,
                "porcentagem": 10,
                "dia": 10,
                "quantidadeDias": 10
            },
            {
                "id": 2,
                "porcentagem": 11,
                "dia": 11,
                "quantidadeDias": 11
            }
        ]
    }
]
```