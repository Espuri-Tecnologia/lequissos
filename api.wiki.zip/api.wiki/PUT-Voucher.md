### URLs

> PUT https://integrador.varejonline.com.br/apps/api/vouchers/:id

Envie um JSON no corpo da requisição, contendo:
* **entidades:** lista de entidades cadastradas para o voucher
  * **id:** id da [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) (long)
  * **documento:** CNPJ formatado da loja associada a [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) (string)
* **nominal:** informações referentes ao voucher do tipo nominal (obrigatório se não informado **promocional**, não podem ser informados ambos no mesmo post)
  * **terceiros:** lista de terceiros cadastrados para o voucher nominal
    * **id:** id do [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros) (long)
    * **documento:** Número do documento formatado do [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros) (string)
  * **categoriasCliente:** lista de categorias de clientes cadastrados para o voucher nominal
    * **id:** id da categoria (long)
    * **nome:** nome da categoria (string)
  * **classesTerceiro:** lista de strings de [classes](https://github.com/Varejonline/api/wiki/Classes-de-Terceiro) cadastrados para o voucher nominal.
* **promocional:** informações referentes ao voucher do tipo promocional (obrigatório se não informado **nominal**, não podem ser informados ambos no mesmo post)
  * **codigo:** código promocional (string) (obrigatório)
  * **clienteObrigatorio:** define se o voucher só pode ser aplicado a um cliente identificado na venda (boolean)
  * **quantidadeLimitada:** define se o voucher possui quantidade limitada para uso (boolean)
  * **quantidadeUsos:** quando o voucher possui quantidade limitada essa informação define a quantidade de uso permitido (integer) (obrigatório se **quantidadeLimitada** for true e não permitido se **quantidadeLimitada** for false)
* **formaAplicacao:** Se o voucher é aplicado como pagamento ou desconto (PAGAMENTO, DESCONTO) (obrigatório)
* **tipoLancamento:** Define a forma em que o voucher foi criado no sistema (MANUAL, CONFIGURACAO, AUTOMATICO, VENDA_ERP_PDV)
* **valor:** Valor configurado para o voucher (decimal) (obrigatório)
* **tipoValor:** Define a configuração do valor, podendo ser unitário ou percentual (PERCENTUAL, VALOR_UNITARIO) (obrigatório)
* **valorCompraMinimo:** Define o valor de compra mínimo do pedido para poder consumir o voucher (decimal)
* **percentualUsoVenda:** Define o percentual de uso em venda para o voucher (decimal)
* **dataValidadeInicial:** Define a data de validade inicial para consumo no formato dd-mm-aaaa (string) (obrigatório)
* **dataValidadeFinal:** Define a data de validade final para consumo no formato dd-mm-aaaa (string) (obrigatório)
* **usoUnico:** Define se o voucher pode ser utilizado apenas uma única vez (boolean)
* **excluido:** Define se o voucher foi excluído (boolean)
* **encerrado:** Define se o voucher foi encerrado (boolean)
* **cancelado:** Referente ao vale presente. Define se o voucher foi cancelado (boolean)
* **observacoes:** Observações referente ao voucher (string)
* **somenteWeb:** Define se o voucher só pode ser utilizado em Ecommerce/Marketplace (boolean)

### Retorno

Sucesso HTTP 201 CREATED:

Retorna um JSON com informações do resultado da operação realizada, contendo:

* **idRecurso:** ID do voucher gerado.
* **codigoMensagem:** Código de identificação da operação realizada. [veja a lista de Códigos](https://github.com/Varejonline/api/wiki/Retorno-API)
* **mensagem:** Mensagem da operação realizada

Requisição inválida: 
* HTTP STATUS 400 – BAD REQUEST
* Body: mensagem de erro

### Exemplo

> POST https://integrador.varejonline.com.br/apps/api/vouchers/5

'Content-Type'='application/json'
```javascript
{
    "valor": 29.90,
    "promocional": {
        "codigo": "SUMMER-X5665ZY"
    },
    "formaAplicacao": "PAGAMENTO",
    "dataValidadeInicial": "01-09-2023",
    "dataValidadeFinal": "30-09-2023",
    "tipoValor": "VALOR_UNITARIO"
}
```