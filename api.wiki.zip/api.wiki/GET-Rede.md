### URLs

> GET https://apps.varejonline.com.br/gestor_integracao/api/external/networks/get-all

### Parâmetros

* **token:** token da base franqueadora (obrigatório)
* **propriedades:** lista de propriedades de pontos exibir
* **filtarPontosPropriedades:** lista de propriedades de pontos filtrar (exibe qualquer ponto que contenha ao menos uma das propriedades)
* **agruparCnpj:** evitar duplicação de cnpjs no retorno

Observações
- Um ponto refere-se a uma empresa/loja

### Retorno

Uma lista de objetos complexos com as seguintes propriedades

* **nome:** nome da rede
* **bases:** lista de bases
  * **token:** token da base (pode ser utilizado para consultar qualquer outra api)
  * **pontos:** lista de pontos dessa base
    * **dataCriacao:** data em que esse ponto foi cadastrado na rede
    * **cnpj:** cnpj da empresa
    * **nomeEmpresa:** nome da empresa
    * **empresaId:** id da [empresa](https://github.com/Varejonline/api/wiki/GET-empresas)
    * **empresaAtiva:** empresa ativa
    * **propriedades:** lista de propriedades desse ponto
      * **propriedade:** chave/nome da propriedade
      * **valor:** valor da propriedade
    * **entidades:** lista de entidades desse ponto
      * **id:** id da [entidade](https://github.com/Varejonline/api/wiki/GET-entidades)
      * **nome:** nome da entidade
      * **ativa:** entidade ativa