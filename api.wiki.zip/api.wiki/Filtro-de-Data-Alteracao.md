Alguns dos recursos disponíveis para consulta têm uma relação forte com a data em que eles foram alterados, para que as aplicações desenvolvidas possam buscar somente as mudanças efetuadas. Para resolver este problema, é possível filtrar o resultado de uma consulta de maneira a retornar apenas novos registros, ou registros alterados, a partir de uma data de referência.


Para informar o período desejado, basta incluir na requisição o seguintes parâmetro:

* **alteradoApos:** data de alteração mínima formato "dd-mm-aaaa hh:mi:ss"

Serão retornados registros que foram criados ou alterados com uma data (e horário) maior ou igual à informada.

###Exemplos de uso

> GET [https://integrador.varejonline.com.br/apps/api/pedidos/?alteradoApos=01/01/2013 12:00:00](https://integrador.varejonline.com.br/apps/api/pedidos/?alteradoApos=01/01/2013 12:00:00)

>Essa busca retornará apenas os pedidos de venda criados ou alterados (cancelados, por exemplo), a partir do meio dia de 01/01/2013, no horário de Brasília.
