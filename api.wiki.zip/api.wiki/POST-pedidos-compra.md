### URL

> POST https://integrador.varejonline.com.br/apps/api/pedidos-compra

### Parâmetros

Envie um JSON no corpo da requisição, contendo:
* **dataCompra:** data do pedido de compra (string) (obrigatório)
* **dataLimiteEntrega:** data de limite de entrega do pedido de compra (string) (obrigatório)
* **entidade:** [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) utlizada (obrigatório informar um dos critérios para a busca da entidade. Utiliza-se o primeiro critério da ordem)
  * **id:** id da [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) (long)
  * **documento:** documento da [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) (string)
* **fornecedor:** fornecedor do pedido (obrigatório informar um dos critérios para a busca do fornecedor. Utiliza-se o primeiro critério da ordem)
  * **id:** id do [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros) fornecedor do pedido de compra (long)
  * **documento:** documento do [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros) fornecedor do pedido de compra (string)
* **referenciaPedidoFornecedor:** número da referência do pedido no fornecedor (string) (opcional)
* **valorSeguro:** valor de seguro do pedido de compra (decimal) (obrigatório)
* **valorFrete:** valor de frete do pedido de compra (decimal) (obrigatório)
* **valorOutros:** valor de outros do pedido de compra (decimal) (obrigatório)
* **parcelas:** lista de parcelas do pedido de compra (obrigatório)
   * **dataVencimento:** data de vencimento da parcela (string) (obrigatório)
   * **valor:** valor da parcela (decimal) (obrigatório)
* **observacao:** observações do pedido de compra (string) (opcional)
* **tipoPlanoPagamento:**  id do [plano de pagamento](https://github.com/Varejonline/api/wiki/GET-planos-pagamento-compras) (long) (opcional)
* **produtos:** lista de produtos do pedido de compra (obrigatório)
   * **produto:** (obrigatório informar um dos critérios para a busca do produto. Utiliza-se o primeiro critério da ordem)
      * **id:** id do [produto](https://github.com/Varejonline/api/wiki/GET-Produtos)
      * **codigoSistema:** código de sistema do [produto](https://github.com/Varejonline/api/wiki/GET-Produtos)
   * **quantidade:** quantidade de produtos (decimal) (obrigatório)
   * **valorDesconto:** valor de desconto no produto (decimal) (opcional)
   * **valorUnitario:** valor unitário do produto (decimal) (obrigatório)
   * **idOperacao:** valor que indica o id da [operação](/Varejonline/api/wiki/Operações-de-Compra) de compra do produto. (obrigatório)
* **dataPrevisaoEntrega:** data de previsão de entrega do pedido de compra (string) (opcional)

### Observações 

Formatos aceitos na string de data: "dd-mm-aaaa" ou "dd-mm-aaaa hh:mm:ss".

É possível ajustar um parâmetro no ERP para rejeitar pedidos de compras duplicados, de acordo com a referenciaPedidoFornecedor e outros critérios.
Detalhes em: [Configuração de pedido de compra](https://varejonline.movidesk.com/kb/pt-br/article/187660/parametros-integracao).

### Retorno

Sucesso:
* HTTP STATUS 201 – CREATED
* Body: id do pedido de compra gerado

Requisição inválida: 
* HTTP STATUS 400 – BAD REQUEST
* Body: mensagem de erro

### Exemplo

> POST https://integrador.varejonline.com.br/apps/api/pedidos-compra

'Content-Type'='application/json'
```javascript
{
   "dataCompra":"07-05-2021",
   "dataLimiteEntrega":"07-07-2021",
   "entidade": {
       "id": 1,
       "documento": "00.000.000/0000-00"
   },
   "fornecedor": {
       "id": 1,
       "documento": "00000000000000"
   },
   "referenciaPedidoFornecedor":"REF. PEDIDO 1",
   "valorSeguro":0,
   "valorFrete":0,
   "valorOutros":0,
   "parcelas":[
      {
         "dataVencimento":"07-06-2021",
         "valor":25
      },
      {
         "dataVencimento":"07-07-2021",
         "valor":25
      }
   ],
   "observacao":"Detalhe adicional",
   "tipoPlanoPagamento": 2,
   "produtos":[
      {
         "produto": {
             "codigoSistema" : "0082.0005" 
         },
         "quantidade":10,
         "valorDesconto":0,
         "valorUnitario":5,
         "idOperacao":20
      }
   ],
   "dataPrevisaoEntrega":"07-06-2021"
}
```