### URL

> PUT https://integrador.varejonline.com.br/apps/api/tabelas-preco/:id_tabela_preco/produtos

Onde: 
* id_tabela_preco é o id da tabela de preço que está sendo atualizada

### Parâmetros

Envie um JSON no corpo da requisição, contendo:
* **produto:** dados do produto associado ao preço (Obrigatório ao menos um dos dois atributos)
  * **id:** id do [produto](https://github.com/Varejonline/api/wiki/GET-Produtos)
  * **codigoSistema:** código sistema do [produto](https://github.com/Varejonline/api/wiki/GET-Produtos)
* **preco:** preço do produto na tabela de preços (decimal)


### Exemplo

> PUT https://integrador.varejonline.com.br/apps/api/tabelas-preco/:id_tabela_preco/produtos

'Content-Type'='application/json'

```javascript
   {
       "produto": {
          "codigoSistema" : "0062.AAPS"
       },
      "preco":26.5
   }
```

### Retorno

_Sucesso:_
* HTTP STATUS 200 – OK
* Body:
```javascript
{
      "idRecurso": 1002,
      "codigoMensagem": 0,
      "mensagem": "Operação realizada com sucesso."
}
```

_Requisição inválida:_
* HTTP STATUS 400 – BAD REQUEST
* Body: 
```javascript
{
      "idRecurso": 0,
      "codigoMensagem": 10,
      "mensagem": "Descrição do erro"
}
```