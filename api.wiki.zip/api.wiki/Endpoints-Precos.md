 ## [GET tabelas-preco](/Varejonline/api/wiki/GET-tabelas-preco)
 ## [GET configuracoes-preco](/Varejonline/api/wiki/GET-configura%C3%A7%C3%B5es-preco)
 ## [POST tabelas-preco](https://github.com/Varejonline/api/wiki/POST-tabelas-preco)
 ## [PUT tabelas-preco](https://github.com/Varejonline/api/wiki/PUT-tabelas-preco)

<br>

 ## [GET preco-produtos](/Varejonline/api/wiki/GET-tabelas-preco-produtos)
 ## [PUT preco-produtos](/Varejonline/api/wiki/PUT-tabelas-preco-produtos)
 ## [GET preco-servicos](/Varejonline/api/wiki/GET-tabelas-preco-servicos)
 ## [PUT preco-servicos](/Varejonline/api/wiki/PUT-tabelas-preco-servicos)