### URLs

> GET https://integrador.varejonline.com.br/apps/api/niveis-categoria-produto

> GET https://integrador.varejonline.com.br/apps/api/niveis-categoria-produto/:id

### Parâmetros

* **inicio:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **quantidade:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **alteradoApos:** [Entenda a Coleta de Alterações](https://github.com/Varejonline/api/wiki/Filtro-de-Data-Alteração)

### Retorno

* **id:** id do nível categoria de produto (long)
* **ativo:** indica se o nível da categoria está ativa ou não (boolean)
* **dataAlteracao:** última data de alteração do nível da categoria, no formato dd-mm-aaaa hh:mi:ss (string)
* **nome:** nome do nível da categoria (string) 
* **nivel:** número no nível da categoria de produto (int)
* **compoeReferenciaBase:** indica se o nível compõe ou não a referência base
* **idNivelCategoriaProdutoPai:** id do nivel pai da categoria pesquisada


### Observações

Categorias inativas tem o nível = -1 (Pois não são consideradas na estrutura mercadológica dos produtos)


### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/niveis-categoria-produto

```javascript
[
    { 
    "id": 1, 
    "ativo": true, 
    "dataAlteracao": "01-01-2014 00:00:00" 
    "nivel": 1, 
    "nome": "MARCA", 
    "compoeReferenciaBasica": true, 
   }, 
  { 
    "id": 2, 
    "ativo": true, 
    "dataAlteracao": "01-01-2014 00:00:00" 
    "nivel": 2, 
    "idNivelCategoriaProdutoPai": 1, 
    "nome": "COLEÇÃO", 
    "compoeReferenciaBasica": true, 
   }
]
```