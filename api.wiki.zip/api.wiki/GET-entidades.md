### URLs

> GET https://integrador.varejonline.com.br/apps/api/entidades

> GET https://integrador.varejonline.com.br/apps/api/entidades/:id

### Parâmetros

* **inicio:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **quantidade:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **alteradoApos:** [Entenda a Coleta de Alterações](https://github.com/Varejonline/api/wiki/Filtro-de-Data-Alteração)
* **status:** filtra pelo status da entidade (enum: ATIVO, INATIVO, EXCLUIDO), separados por vírgula

<em>Obs.: Entidades excluídas são exibidas apenas se incluso o parâmetro status EXCLUIDO.</em>

### Retorno

* **id:** id da entidade (long)
* **nome:** nome da entidade (string)
* **principal:** indica se a entidade é a principal (boolean)
* **modalidadeTributacao:** modalidade de tributação da empresa (string). Pode assumir os seguintes valores: 
    * SIMPLES_NACIONAL
    * LUCRO_PRESUMIDO
    * LUCRO_REAL
    * LUCRO_ARBITRADO
    * IMUNE
    * PESSOA_FISICA
    * ISENTO
    * PESSOA_FISICA
* **ativa:** indica se a entidade está ativa (boolean)
* **excluida:** indica se a entidade foi excluída (boolean)
* **entidadeEcommerce:** indica se são os dados dessa entidade que estão associados aos faturamentos de ecom (boolean)
* **idEmpresa:** id da [empresa](https://github.com/Varejonline/api/wiki/GET-empresas) à qual a entidade pertence (long)
* **permiteVendaEstoqueNegativo:** boolean que indica se a entidade permite (true) ou não (false) a venda de produtos sem estoque
* **grupoEntidade:** nome do grupo em que está a entidade (string) `deprecated`
* **idGrupoEntidade:** id do grupo em que está a entidade (long) `deprecated`
* **grupos:** lista de grupos que esta entidade pertence. (array)
   * **id:** id do grupo de entidades (long)
   * **ativo:** indica se o grupo está ativo (boolean)
   * **nome:** nome do grupo de entidades (string)
* **marcaId:** Id da Marca vinculada a entidade (Integer)


### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/entidades?inicio=0&quantidade=4&status=ATIVO,INATIVO,EXCLUIDO

```javascript
[
  {
      "id": 1,
      "nome": "Varejonline LTDA",
      "principal": true,
      "modalidadeTributacao": "SIMPLES_NACIONAL",
      "ativa": true,
      "excluida": false,
      "entidadeEcommerce": false,
      "idEmpresa": 1,
      "permiteVendaEstoqueNegativo": true,
      "grupoEntidade": "GE2",
      "idGrupoEntidade": 2,
      "grupos": [
            {
                  "id": 2,
                  "ativo": true,
                  "nome": "GE2"
            }
      ]
  },
  {
      "id": 2,
      "nome": "Varejonline (LUCRO ARBITRADO)",
      "principal": false,
      "modalidadeTributacao": "LUCRO_ARBITRADO",
      "ativa": false,
      "excluida": false,
      "entidadeEcommerce": false,
      "idEmpresa": 1,
      "permiteVendaEstoqueNegativo": false,
      "grupoEntidade": "GE2",
      "idGrupoEntidade": 2,
      "grupos": [
            {
                  "id": 2,
                  "ativo": true,
                  "nome": "GE2"
            }
      ]
  },
  {
      "id": 3,
      "nome": "Varejonline (LUCRO PRESUMIDO)",
      "principal": false,
      "modalidadeTributacao": "LUCRO_PRESUMIDO",
      "ativa": true,
      "excluida": false,
      "entidadeEcommerce": false,
      "idEmpresa": 8,
      "permiteVendaEstoqueNegativo": true,
      "grupoEntidade":"GE2",
      "idGrupoEntidade": 2,
      "grupos": [
            {
                  "id": 2,
                  "ativo": true,
                  "nome": "GE2"
            },
            {
                  "id": 3,
                  "ativo": false,
                  "nome": "GE3"
            },
      ]
  },
  {
      "id": 4,
      "grupos": [],
      "ativa": false,
      "excluida": true,
      "entidadeEcommerce": false,
      "idEmpresa": 5,
      "nome": "ESTOQUE SP",
      "modalidadeTributacao": "LUCRO_PRESUMIDO",
      "principal": false,
      "permiteVendaEstoqueNegativo": false
  }
]
```