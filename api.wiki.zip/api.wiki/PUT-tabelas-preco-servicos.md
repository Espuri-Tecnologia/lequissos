### URL

> PUT https://integrador.varejonline.com.br/apps/api/tabelas-preco/:id_tabela_preco/servicos/:id_servico

### Parâmetros

Envie um JSON no corpo da requisição, contendo:
* **idServico:** id do serviço (long)
* **preco:** preço do serviço na tabela de preços (decimal)

### Exemplo

> PUT https://integrador.varejonline.com.br/apps/api/tabelas-preco/:id_tabela_preco/servicos

'Content-Type'='application/json'

```javascript
   {
      "idServico":23,
      "preco":780.0
   }
```

### Retorno

_Sucesso:_
* HTTP STATUS 200 – OK
* Body:
```javascript
{
      "idRecurso": 1002,
      "codigoMensagem": 0,
      "mensagem": "Operação realizada com sucesso."
}
```

_Requisição inválida:_
* HTTP STATUS 400 – BAD REQUEST
* Body: 
```javascript
{
      "idRecurso": 0,
      "codigoMensagem": 10,
      "mensagem": "Descrição do erro"
}
```