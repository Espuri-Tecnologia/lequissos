### URL

> POST https://integrador.varejonline.com.br/apps/api/pedidos/adicionar-observacao-entrega

### Parâmetros

Envie um JSON no corpo da requisição, contendo:

* **idPedido:** id do pedido (long) (obrigatório)
* **observacao:** observação sobre a entrega (string) (obrigatório)


### Retorno

Sucesso HTTP 200 OK:

Retorna um Json com informações do resultado da operação realizada, contendo:

* **codigoMensagem:** Código de identificação da operação realizada. [veja a lista de Códigos](https://github.com/Varejonline/api/wiki/Retorno-API)
* **mensagem:** Mensagem da operação realizada

Requisição inválida: 
* HTTP STATUS 400 – BAD REQUEST
* Body: mensagem de erro

### Exemplo

> POST https://integrador.varejonline.com.br/apps/api/pedidos/adicionar-observacao-entrega

'Content-Type'='application/json'
```javascript
{ 
    "idPedido": 32,
    "observacao": "Problemas com a entrega."
}
```