### URLs

> GET https://integrador.varejonline.com.br/apps/api/reducoes-z

> GET https://integrador.varejonline.com.br/apps/api/reducoes-z/:id

### Parâmetros

* **entidades:** [Veja como Funciona este Filtro](https://github.com/Varejonline/api/wiki/Filtro-de-Entidades)
* **inicio:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **quantidade:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **desde:** [Veja o Filtro de Datas](https://github.com/Varejonline/api/wiki/Filtro-de-Datas)
* **ate:** [Veja o Filtro de Datas](https://github.com/Varejonline/api/wiki/Filtro-de-Datas)
* **alteradoApos:** [Entenda a Coleta de Alterações](https://github.com/Varejonline/api/wiki/Filtro-de-Data-Alteração)

### Retorno 

Sucesso:
* **id:** id da redução z(long)
* **idEntidade:** id da [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) onde a impressora emitiu cupons (long)
* **cnpj:** CNPJ sem formatacão da [empresa](https://github.com/Varejonline/api/wiki/GET-empresas) onde a impressora emitiu cupons (string)
* **ativo:** indica se a redução z é válida(boolean)
* **dataAlteracao:** última data de alteração da redução z, no formato dd-mm-aaaa hh:mi:ss (string)
* **dataCriacao:** data de criação da redução z, no formato dd-mm-aaaa hh:mi:ss 
* **dataMovimento:** data do movimento, no formato dd-mm-aaaa hh:mi:ss 
* **dataReducaoZ:** data da redução z, no formato dd-mm-aaaa hh:mi:ss 
* **coo:** cco (string)
* **crz:** crz (string)
* **cro:** cro (string)
* **numeroSequencialECF:** número sequencial do ECF (string)
* **totalizadorGeral:** totalizador geral da redução (decimal)
* **cancelamentoICMS:** totalizador do cancelamento de ICMS (decimal)
* **descontoICMS:** totalizador do desconto de ICMS (decimal)
* **acrescimoICMS :** totalizador do acrescimo de ICMS (decimal)
* **totalISS:** totalizador do total de ISSQN (decimal)
* **cancelamentoISS:** totalizador do cancelamento de ISSQN (decimal)
* **descontoISS:** totalizador do desconto de ISSQN (string)
* **acrescimoISS:** totalizador do acrescimo de ISSQN (string)
* **vendaBrutaDiaria:** venda bruta diária (decimal)
* **numeroSerieECF:** número de série ECF (string)
* **totalizadores:** lista de totalizadores, contendo:
   * **codigo:** código do totalizador(string) [veja os códigos de totalizadores] (Totalizadores-Reducao-Z)
   * **valorAcumulado:** valor acumulado(decimal)

Falha:
* **codigoErro:** Código de erro retornado pela aplicação (string)
* **descricaoErro:** Descrição do erro (string)

### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/reducoes-z

```javascript
[
    {
        "ativo": true,
        "id": 1,
        "dataEmissao": "06-03-2020 00:00:00",
        "coo": "000033",
        "crz": "0002",
        "dataMovimento": "06-03-2020 00:00:00",
        "horaEmissao": "183154",
        "vendaBrutaDiaria": 1170.68,
        "dataReducaoZ": "06-03-2020 18:31:40",
        "numeroSerieECF": "BE112910111110043092",
        "totalizadores": [
            {
                "valorAcumulado": 629.79,
                "codigo": "01T1700"
            },
            {
                "valorAcumulado": 0,
                "codigo": "F1"
            },
            {
                "valorAcumulado": 0,
                "codigo": "I1"
            },
            {
                "valorAcumulado": 0,
                "codigo": "N1"
            },
            {
                "valorAcumulado": 0,
                "codigo": "FS1"
            },
            {
                "valorAcumulado": 0,
                "codigo": "IS1"
            },
            {
                "valorAcumulado": 0,
                "codigo": "NS1"
            }
        ],
        "cro": "0001",
        "numeroSequencialECF": "001",
        "totalizadorGeral": 1181.68,
        "cancelamentoICMS": 189.96,
        "descontoICMS": 350.93,
        "acrescimoICMS": 0,
        "cancelamentoISS": 0,
        "descontoISS": 0,
        "acrescimoISS": 0,
        "idEntidade": 5,
        "cnpj":"81365875000110",
        "dataCriacao": "07-03-2020 08:31:43",
        "dataAlteracao": "07-03-2020 08:31:43"
    }
]
```