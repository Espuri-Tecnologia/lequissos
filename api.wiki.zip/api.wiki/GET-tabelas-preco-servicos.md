### URLs

> GET https://integrador.varejonline.com.br/apps/api/tabelas-preco/:id_tabela_preco/servicos

> GET https://integrador.varejonline.com.br/apps/api/tabelas-preco/:id_tabela_preco/servicos/:id

### Parâmetros

* **inicio:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **quantidade:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **alteradoApos:** [Entenda a Coleta de Alterações](https://github.com/Varejonline/api/wiki/Filtro-de-Data-Alteração)

### Retorno

* **idServico:** id do serviço (long)
* **preco:** preço do serviço na tabela de preços (decimal)
* **ativo:** indica se o preço do serviço está ativo (boolean)
* **dataAlteracao:** última data de alteração da tabela de preço, no formato dd-mm-aaaa hh:mi:ss (string)

### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/tabelas-preco/425/servicos

```javascript
[
   {
      "idServico":23,
      "preco":780.0,
      "ativo":true,
      "dataAlteracao":"09-10-2013 19:13:16"
   },
   {
      "idServico":74,
      "preco":65.0,
      "ativo":false,
      "dataAlteracao":"09-10-2013 19:13:16"
   }
]
```