### URLs

> GET https://integrador.varejonline.com.br/apps/api/tabelas-preco

> GET https://integrador.varejonline.com.br/apps/api/tabelas-preco/:id

### Parâmetros

* **entidades:** [Veja como Funciona este Filtro](https://github.com/Varejonline/api/wiki/Filtro-de-Entidades)
* **inicio:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **quantidade:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **alteradoApos:** [Entenda a Coleta de Alterações](https://github.com/Varejonline/api/wiki/Filtro-de-Data-Alteração)

### Retorno

* **id:** id da tabela de preços (long). A tabela de ID "1" é sempre a tabela padrão do sistema.
* **nome:** nome da tabela de preço (String)
* **idsEntidades:** ids das [entidades](https://github.com/Varejonline/api/wiki/GET-entidades) para as quais a tabela de preços é válida (array). 
Quando vazio, significa que a tabela é válida para todas as entidades.
* **classificacoesCliente:** [classificações](https://github.com/Varejonline/api/wiki/GET-classificacoes-clientes) de cliente para as quais a tabela de preços é válida (array). Quando vazio, significa que é válida para todas as classificações.
* **disponivel:** indica se a tabela de preços está disponível para uso no momento da consulta. As tabelas de preços podem ter uma vigência configurável, podendo estar disponíveis apenas entre datas específicas ou durante um período específico do dia (boolean)
* **ativo:** indica se a tabela pode (true) ou não (false) ser aplicada (boolean).
* **permanente:** indica se a tabela é (true) ou não (false) permanente (boolean).
* **promocao:** indica se a tabela é (true) ou não (false) promocional (boolean).
* **excluido:** indica se a tabela foi (true) ou não (false) excluída no sistema (boolean).
* **inicioVigencia:** data inicial na qual a tabela pode ser aplicada, no formato dd-mm-aaaa hh:mi:ss (string).
* **fimVigencia:** data final na qual a tabela pode ser aplicada, no formato dd-mm-aaaa hh:mi:ss (string).
* **peso:** indica o peso para que a tabela seja aplicada, quando não informado, é usado o seguinte critério:
    * Tabela padrão: Peso 0
    * Tabela permanente não promocional sem classificação de cliente: Peso 1
    * Tabela com vigência não promocional sem classificação de cliente: Peso 2
    * Tabela permanente não promocional com classificação de cliente: Peso 3
    * Tabela com vigência não promocional com classificação de cliente: Peso 4
    * Tabela permanente promocional sem classificação de cliente: Peso 5
    * Tabela com vigência promocional sem classificação de cliente: Peso 6
    * Tabela permanente promocional com classificação de cliente: Peso 7
    * Tabela com vigência promocional com classificação de cliente: Peso 8

    * O maior peso define o preço que será aplicado na venda do item.
    * Deve ser informado um valor maior que 8 para que o peso informado tenha efeito.

### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/tabelas-preco

```javascript
[
   {
        "id": 2,
        "classificacoesCliente": [
            {
                "id": 1,
                "nome": "PADRÃO"
            }
        ],
        "nome": "PROMOCAO1",
        "disponivel": false,
        "idsEntidades": [
            17, 1, 2, 3, 18, 4, 5, 9, 10, 11, 15
        ],
        "ativo": false,
        "inicioVigencia": "31-03-2017 12:00:00",
        "fimVigencia": "19-02-2050 12:00:00",
        "excluido": false,
        "permanente": false,	
        "promocao": true,		
        "peso": 100
    },
    {
        "id": 1,
        "classificacoesCliente": [
            {
                "id": 1,
                "nome": "PADRÃO"
            }
        ],
        "nome": "PADRÃO",
        "disponivel": true,
        "idsEntidades": [],
        "ativo": true,
        "excluido": false,
        "permanente": true,	
        "promocao": false,		
        "peso": 0
    }
]
```