## [GET usuarios](/Varejonline/api/wiki/GET-Usuarios)
## [POST usuarios](/Varejonline/api/wiki/POST-Usuarios)
## [PUT usuarios](/Varejonline/api/wiki/PUT-Usuarios)
## [DELETE usuarios](/Varejonline/api/wiki/DELETE-Usuarios)



