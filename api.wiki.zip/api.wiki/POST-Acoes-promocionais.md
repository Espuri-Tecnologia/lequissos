> POST https://integrador.varejonline.com.br/apps/api/acoes-promocionais

### Parâmetros

Envie um JSON no corpo da requisição, contendo:

* **descricao:** (String) _(obrigatório)_
* **localizador:** (String) _(obrigatório)_
* **objetivo:** [objetivo](https://github.com/Varejonline/api/wiki/A%C3%A7%C3%B5es-promocionais-objetivos) da ação promocional (String) _(obrigatório)_
* **vigenciaInicial:** (string dd-MM-yyyy) _(obrigatório)_
* **vigenciaFinal:**  (string dd-MM-yyyy) _(obrigatório)_
* **considerarTodoEstoque:**  (boolean) _(opcional, padrão: false)_
* **entidades:**  Lista de objetos complexos das entidades que farão parte da ação _(obrigatório)_
  * **id:** id da [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) (Long) _(obrigatório)_
* **motivoDesconto:** (string) _(opcional)_
* **franquias:** A ação promocional será replicada para as franquias informadas (Lista de objetos complexos) _(opcional)_
  *   **id:** id do [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros) _(opcional)_
  *   **documento:** documento do [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros) com/sem formatação _(opcional)_
* **regra:** (objeto complexo) _(obrigatório)_
  * **modalidade:** QUANTIDADE, VALOR ou COMBINACAO (String) _(obrigatório)_
  * **restricao:** _(obrigatório)_
    * **documentoObrigatorio:** _(opcional, padrão: false)_
    * **somentePagamentoDinheiro:** _(opcional, padrão: false)_
    * **usoUnicoCliente:** possível true somente se documentoObrigatorio = true _(opcional, padrão: false)_
    * **utilizarAtivador:** _(opcional, padrão: false)_
    * **permiteAcumuloComOutrasAcoes:** _(opcional, padrão: false)_
  * _As propriedades faixaFixa e faixas são mutuamente exclusivas. Uma delas é obrigatória para modalidades QUANTIDADE e VALOR e não podem ser informadas quando COMBINACAO_ 
  * **faixaFixa:** objeto complexo
      * **valorBase:** (decimal)
      * **premios:** Lista de [prêmios](https://github.com/Varejonline/api/wiki/A%C3%A7%C3%B5es-promocionais-pr%C3%AAmio)
      * **ativador:** [ativador](https://github.com/Varejonline/api/wiki/A%C3%A7%C3%B5es-promocionais-ativador) _(obrigatório se utilizarAtivador = true)_
  * **faixas:** Lista de objetos complexos
    * **valorInicial:** (decimal) _(obrigatório)_
    * **valorFinal:** (decimal) _(obrigatório)_
    * **tipo:** MENOR_IGUAL_QUE, DE_ATE ou MAIOR_IGUAL_QUE _(obrigatório)_
    * **ativador:** [ativador](https://github.com/Varejonline/api/wiki/A%C3%A7%C3%B5es-promocionais-ativador) _(obrigatório se utilizarAtivador = true)_
    * **premios:** Lista de [prêmios](https://github.com/Varejonline/api/wiki/A%C3%A7%C3%B5es-promocionais-pr%C3%AAmio) _(obrigatório)_
* **item:** objeto complexo. Deve conter uma estrutura de categorias ou uma lista de produtos que irão ativar a ação promocional _(Obrigatório e usado somente quando a modalidade é QUANTIDADE ou VALOR). As propriedades produtos e estruturaCategorias são mutuamente exclusivas_  
  * **produtos:** Lista de [produtos](https://github.com/Varejonline/api/wiki/GET-Produtos). _(Obrigatório um identificador para cada produto)_
    * **id:**
    * **codigoSistema:**
    * **codigoInterno:**
    * **codigoBarras:** 
  * **estruturaCategorias:** Lista de uma lista de ids de [categorias](https://github.com/Varejonline/api/wiki/GET-categorias-produto). Uma categoria não pode ser repetida em uma lista. Cada lista deve ser única. (List(List(Long)))
* **combinacoes:** objeto complexo. Deve conter uma lista de combinação de estruturas ou uma lista de combinação de produtos que irão ativar a ação promocional e os prêmios de cada combinação _(Obrigatório e usado somente quando a modalidade é COMBINACAO). As propriedades combinacaoProdutos e combinacaoEstruturas são mutuamente exclusivas_
  * **combinacaoProdutos:** Lista de objetos complexos
    * **produtos:** Lista de [produtos](https://github.com/Varejonline/api/wiki/GET-Produtos). _(Obrigatório um identificador para cada produto)_
      * **id:**
      * **codigoSistema:**
      * **codigoInterno:**
      * **codigoBarras:** 
    * **quantidade:** (decimal) _(obrigatório)_
  * **combinacaoEstruturas:** Lista de objetos complexos
    * **categoriasProduto:** Lista de ids de [categorias](https://github.com/Varejonline/api/wiki/GET-categorias-produto) (List(Long)) _(obrigatório)_
    * **quantidade:** (decimal) _(obrigatório)_
  * **premios:** Lista de [prêmios](https://github.com/Varejonline/api/wiki/A%C3%A7%C3%B5es-promocionais-pr%C3%AAmio) _(obrigatório)_

### Exemplo 1

Neste exemplo, a ação tem como alvo combinações de categorias de produtos, cada combinação possui seus prêmios.

> POST https://integrador.varejonline.com.br/apps/api/acoes-promocionais

```javascript
{
    "descricao": "Exemplo combinação de itens com estrutura mercadológica",
    "entidades": [
        {
            "id": 3
        },
        {
            "id": 7
        }
    ],
    "considerarTodoEstoque": false,
    "vigenciaInicial": "01-09-2023",
    "motivoDesconto": "exemplo desconto",
    "vigenciaFinal": "02-09-2023",
    "franquias": [
        {
            "id": 111
        },
        {
            "documento": "00.000.000/0000-03"
        },
    ],
    "combinacoes": [
        {
            "combinacaoEstruturas": [
                {
                    "categoriasProduto": [1,11,7],
                    "quantidade": 1
                }
            ],
            "premios": [
                {
                    "desconto": 10,
                    "tipoConfiguracao": "MAIOR_VALOR_VENDA",
                    "pontoFidelidade": 0,
                    "tipoDesconto": "VALOR",
                    "tipoPremio": "DESCONTO_NO_ITEM_DE"
                }
            ]
        },
        {
            "combinacaoEstruturas": [
                {
                    "categoriasProduto": [1, 6],
                    "quantidade": 1
                },
                {
                    "categoriasProduto": [2, 8],
                    "quantidade": 2
                }
            ],
            "premios": [
                {
                    "produtos": [
                        {
                            "id": 24,
                            "descricao": "AGUA MINERAL SEM GÁS",
                            "codigoBarras": "7896451198143",
                            "codigoInterno": "102030",
                            "codigoSistema": "0042"
                        }
                    ],
                    "tipoConfiguracao": "PRODUTO",
                    "tipoPremio": "BRINDE"
                },
                {
                    "desconto": 5,
                    "tipoConfiguracao": "MENOR_VALOR_VENDA",
                    "tipoDesconto": "PERCENTUAL",
                    "tipoPremio": "DESCONTO_NO_ITEM_DE"
                }
            ]
        }
    ],
    "regra": {
        "modalidade": "COMBINACAO",
        "restricao": {
            "permiteAcumuloComOutrasAcoes": true,
            "documentoObrigatorio": false,
            "somentePagamentoDinheiro": false,
            "usoUnicoCliente": false,
            "utilizarAtivador": false
        }
    },
    "localizador": "exemplo localizador",
    "objetivo": "BAIXAR_EXCESSO_ESTOQUE"
}
```

### Exemplo 2
Neste exemplo, a ação tem como alvo uma lista de produtos, onde a cada 2 quantidades vendidas (faixa fixa), premia-se R$ 10,00 de desconto no total dos itens da ação promocional.

> POST https://integrador.varejonline.com.br/apps/api/acoes-promocionais

```javascript
 {
        "descricao": "Exemplo modalidade quantidade com faixa fixa",
        "objetivo": "ELEVAR_VENDAS_CURTO_PRAZO",
        "item": {
            "produtos": [
                {
                    "id": 25,
                    "descricao": "JOGO VIDEO GAME NOVO",
                    "codigoBarras": "7891033760398",
                    "codigoSistema": "0062"
                },
                {
                    "id": 26,
                    "descricao": "JOGO VIDEO GAME SEMINOVO",
                    "codigoBarras": "7891000248768",
                    "codigoSistema": "0063"
                }
            ]
        },
        "entidades": [
            {
                "id": 3
            }
        ],
        "considerarTodoEstoque": false,
        "integraRedeFranquia": false,
        "vigenciaInicial": "01-09-2023",
        "vigenciaFinal": "02-09-2023",
        "regra": {
            "modalidade": "QUANTIDADE",
            "restricao": {
                "permiteAcumuloComOutrasAcoes": true,
                "documentoObrigatorio": true,
                "somentePagamentoDinheiro": false,
                "usoUnicoCliente": true,
                "utilizarAtivador": false
            },
            "faixaFixa": {
                "valorBase": 2,
                "premios": [
                    {
                        "desconto": 10,
                        "tipoDesconto": "VALOR",
                        "tipoPremio": "DESCONTO_ITENS_ACAOPROMOCIONAL"
                    }
                ]
            }
        }
    }
```