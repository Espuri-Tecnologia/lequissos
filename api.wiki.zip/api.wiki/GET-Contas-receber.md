Estas são as contas a pagar da empresa. Estão aqui tanto as contas que a empresa já pagou quanto as que ela ainda não pagou.

### URLs

> GET https://integrador.varejonline.com.br/apps/api/contas-receber

> GET https://integrador.varejonline.com.br/apps/api/contas-receber/:id

### Parâmetros

* **entidades:** [Veja como Funciona este Filtro](https://github.com/Varejonline/api/wiki/Filtro-de-Entidades)
* **inicio:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **quantidade:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **desde:** [Veja o Filtro de Datas](https://github.com/Varejonline/api/wiki/Filtro-de-Datas)
* **ate:** [Veja o Filtro de Datas](https://github.com/Varejonline/api/wiki/Filtro-de-Datas)
* **alteradoApos:** [Entenda a Coleta de Alterações](https://github.com/Varejonline/api/wiki/Filtro-de-Data-Alteração)
* **filtroData:** especifica qual data será analizada pelos parâmetros desde e até. Este parâmetro é opcional, e pode receber os valores "dataVencimento", "dataEmissao" ou "dataBaixa". Se não for especificado o parâmetro com nenhum desses valores, por padrão o filtro desde a até será aplicado à data de vencimento da conta a receber.
* **idProvisao:** Lista de ids das provisões associadas às parcelas buscadas, separados por vírgula.
* **idLancamentoContabil:** Lista de ids dos lançamentos contábeis associados às parcelas buscadas, separados por vírgula.
* **documentoTerceiro:** Filtra apenas parcelas associadas ao [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros) do CPF ou CNPJ informado.
* **idLancamentoPadrao:** Filtra parcelas associadas aos ids de [lançamentos padrões](https://github.com/Varejonline/api/wiki/GET-lancamentos-padroes), separados por vírgula.
* **idsRenegociacoes:** Filtra parcelas associadas aos ids de renegociações (tanto parcelas originais dessa renegociação quanto as parcelas geradas a partir dela).
* **carregarLancamentoBaixa:** Indica se as contas contábeis da baixa devem ser exibidas no retorno (boolean).

### Retorno

* **id:** id da conta (long)
* **dataAlteração:** última data de alteração do conta a pagar, no formato dd-mm-aaaa hh:mi:ss (string)
* **idProvisao:** id da provisão associadas as parcelas
* **entidade:** [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) que será paga (objeto complexo)
    * **id:** id da entidade (long)
    * **nome:** nome da entidade (string)
    * **documento:** documento da entidade (string)
* **terceiro:** [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros) (objeto complexo)
    * **id:**  id do terceiro (long)
    * **nome:** nome do terceiro (string)
    * **documento:** documento do terceiro (string)
    * **endereco:** endereço do terceiro (string)
* **valor:** valor da conta (decimal)
* **dataVencimento:** data de vencimento da conta (string)
* **dataEmissao:** data de emissão da conta a receber (string)
* **numeroParcela:** número desta parcela (long)
* **totalParcelas:** número total de parcelas (long)
* **valorTotalParcelas:** valor total das parcelas(decimal) 
* **valorTotalRetencoes:** valor total das retenções (decimal) 
* **idOperacaoFinanceira:** número da operação financeira (long)
* **valorTotalParcelas:** valor total das parcelas(decimal) 
* **valorTotalRetencoes:** valor total das retenções (decimal) 
* **idOperacaoFinanceira:** número da operação financeira (long)
* **numeroDocumento:** número de documento da conta (string)
* **tipoDocumento:** [tipo de documento](https://github.com/Varejonline/api/wiki/Tipos-de-Documentos-Financeiros) da conta (string)
* **dataAlteracao:** Última manipulação da parcela no sistema (string dd-mm-yyyy h:mm:ss).
* **historico:** Histórico atribuída à parcela (String).
* **baixada:** indica se já foi dada a baixa da conta (boolean)
* **valorBaixado:** valor pago ao [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros), caso a conta esteja baixada (decimal)
* **dataBaixa:** data em que foi dada a baixa da conta (string)
* **composicaoValorBaixado:** mostra como o pagamento foi dividido entre cartão, cheque, dinheiro ou outras formas de pagamento
  * **dinheiro:** valor pago em dinheiro (decimal)
  * **cheque:** detalhes do pagamento em cheque
     * **valor:** valor pago com cheque (decimal)
     * **dataVencimento:** data de compensação do cheque, no formato 'dd-mm-aaaa' (string)
     * **numeroCheque:** número do cheque (string)
     * **agencia:** número da agência (string)
     * **conta:** número da conta (string)
     * **banco:** número do banco (string)
  * **pix:** detalhes do pagamento utilizando PIX. Lista de:
     * **valor:** valor pago em PIX (decimal)
     * **historico:** Histórico contendo o Número sequencial único do PIX (string)
     * **agencia:** número da agência (string)
     * **conta:** número da conta (string)
     * **banco:** número do banco (string)
  * **boleto:** detalhes do pagamento utilizando BOLETO. Lista de:
     * **valor:** valor pago em BOLETO(decimal)
     * **historico:** Histórico contendo a identificação do BOLETO (string)
     * **agencia:** número da agência (string)
     * **conta:** número da conta (string)
     * **banco:** número do banco (string)
  * **cartoes:** detalhes do pagamento em cartão. Lista de:
     * **valor:** valor pago com cartão (decimal)
     * **idNegociacao:** id da [negociação](https://github.com/Varejonline/api/wiki/GET-negociacoes-cartao) do cartão (long)
     * **numParcelas:** número de parcelas utilizada na transação do cartão com a operadora (long)
     * **recebimentoOperadoraCartao:** Lista de parcelas geradas no pagamento (parcelas à receber contra a operadora de cartão
         * **autorizacao:** Autorização do pagamento com cartão (string)
         * **nsu:** NSU do pagamento com cartão (string)
         * **valorBruto:** valor bruto da parcela (decimal)
         * **valorLiquido:** valor líquido da parcela (Bruto - Tarifas) (decimal)
         * **numeroParcela:** número sequencial da parcela no pagamento (inteiro)
         * **dataVencimento:** data prevista de pagamento pela operadora (string dd-mm-yyyy)
         * **idParcelaOperadoraCartao:** id da [parcela](https://github.com/Varejonline/api/wiki/GET-Contas-receber) gerada para recebimento da operadora (long)
  * **renegociacao:** valor baixado com renegociação (decimal) 
  * **idRenegociacao:** id da renegociação de baixa (long) 
  * **saldoDevedor:** valor de saldo devedor (decimal) 
  * **baixaContabil:** valor baixado como baixa contábil (decimal) 
  * **adiantamentoRecebido:** valor baixado com adiantamentos (decimal)
  * **voucher:** valor baixado com voucher (decimal) 
  * **valePresente:** valor baixado com vale presente (decimal) 
* **contaContabilCredito:** conta contabil que indica o pagamento da conta no passivo da empresa
* **classificacoesContabeis:** classificações contábeis que indicam como a conta a pagar está distribuida nas despesas ou custos da empresa.
   * **contaContabil:** conta contabil onde foi lançado a despesa/custo(string)
   * **porcentagemApropriada:** porcentagem da conta a pagar a ser apropriado na conta contábil(string)
* **juros:** porcentagem dos juros que será calculado com base nos dias de atraso do pagamento da parcela
* **multa:** porcentagem da multa que será calculada com base nos dias de atraso do pagamento da parcela
* **diasCarenciaJuros:** quantidade de dias de tolerância para aplicar os juros
* **diasCarenciaMulta:** quantidade de dias de tolerância para aplicar a multa
* **carenciaCalculo:** define se deve somar os dias de carência com os dias de atraso dos juros
* **aliqDescontoDiario:** porcentagem de desconto que será calculado com base nos dias adiantados no pagamento da parcela
* **descontoMaxParcela:** porcentagem máxima de desconto permitido para a parcela
* **idRenegociacao:** id da parcela de renegociação, caso esta seja uma parcela renegociada
* **idContaContabilDebito:** id da conta débito
* **idLancamentoPadrao:** id do lançamento padrão associado à parcela (long)
* **contasContabeisBaixa:** Contas contábeis que indicam como a conta a receber foi baixada.
   * **idContaContabilDebito:** id da conta contábil débito da baixa (long)
   * **contaContabilDebito:** nome da conta contábil débito da baixa (string)
   * **idContaContabilCredito:** id da conta contábil crédito da baixa (long)
   * **contaContabilCredito:** nome da conta contábil crédito da baixa (string)

### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/contas-receber

```javascript
[
   {
      "id":331,
      "dataAlteração":"19-06-2012 15:28:05",
      "idProvisao":33769,
      "entidade": {
          "id": 3,
          "nome": "Entidade teste",
          "documento": "00.000.000/0000-00"
      },
      "terceiro": {
          "id": 1,
          "nome": "DIVERSOS",
          "documento": "000.000.000-00",
          "endereco": "Rua teste endereço"
      },
      "valor":5734.72,
      "dataVencimento":"06-07-2012",
      "dataEmissao":"06-06-2012",
      "numeroParcela":1,
      "totalParcelas":2,
      "valorTotalParcelas":5834.72,
      "valorTotalRetencoes":0,
      "idOperacaoFinanceira":39,
      "numeroDocumento":"00332187300000002940",
      "tipoDocumento":"BOLETO",
      "dataAlteracao":"23-10-2018 11:09:58",
      "historico":"Parcela 1 de 1.",
      "baixada":true,
      "valorBaixado":5834.72,
      "dataBaixa":"05-07-2012",
      "composicaoValorBaixado":[
         "dinheiro":5000.00,
         "cheque":[
            {
               "valor":1000,
               "dataVencimento":"03-07-2013",
               "numeroCheque":"4296",
               "agencia":"3647",
               "conta":"0202975",
               "banco":"237"
            },
            {
               "valor":4000,
               "dataVencimento":"19-06-2013",
               "numeroCheque":"850030",
               "agencia":"6831",
               "conta":"93394",
               "banco":"001"
            }
         ],
         "renegociacao":0,
         "saldoDevedor":0,
         "baixaContabil":0,
         "adiantamentoRecebido":0,
         "voucher":0,
         "valePresente":0
      ],
      "contaContabilCredito":"22601 - CONTAS A PAGAR DIVERSAS",
      "classificacoesContabeis":[
         {
            "contaContabil":"11215 - CAIXA DESPESAS DIARIAS",
            "porcentagemApropriada":100.0
         }
      ],
      "juros":0.0,
      "multa":0.0,
      "diasCarenciaJuros":0,
      "diasCarenciaMulta":0,
      "carenciaCalculo":false,
      "idRenegociacao":0,
      "idContaContabilDebito":19,
      "descontoMaxParcela":0.0,
      "aliqDescontoDiario":0.0,
      "contasContabeisBaixa": {
            "idContaContabilDebito": 99,
            "contaContabilDebito": "13101 - CLIENTES",
            "idContaContabilCredito": 100,
            "contaContabilCredito": "22601 - CONTAS A PAGAR DIVERSAS"
      }
   },
   {
      "id":332,
      "dataAlteração":"24-02-2013 08:44:11",
      "idProvisao":33769,
      "entidade": {
          "id": 3,
          "nome": "Entidade teste",
          "documento": "00.000.000/0000-00"
      },
      "terceiro": {
          "id": 1,
          "nome": "DIVERSOS",
          "documento": "000.000.000-00",
          "endereco": "Rua teste endereço"
      },
      "valor":100.0,
      "dataVencimento":"06-08-2012",
      "dataEmissao":"01-01-2012",
      "numeroParcela":2,
      "totalParcelas":2,
      "valorTotalParcelas":5834.72,
      "valorTotalRetencoes":0,
      "idOperacaoFinanceira":39,
      "numeroDocumento":"248",
      "tipoDocumento":"NOTA FISCAL",
      "dataAlteracao":"23-10-2018 11:09:58",
      "historico":"Parcela 1 de 1.",
      "baixada":false,
      "contaContabilCredito":"22601 - CONTAS A PAGAR DIVERSAS",
      "classificacoesContabeis":[
         {
            "contaContabil":"11215 - CAIXA DESPESAS DIARIAS",
            "porcentagemApropriada":100.0
         }
      ],
      "juros":0.0,
      "multa":0.0,
      "diasCarenciaJuros":0,
      "diasCarenciaMulta":0,
      "carenciaCalculo":false,
      "idRenegociacao":0,
      "idContaContabilDebito":19,
      "descontoMaxParcela":0.0,
      "aliqDescontoDiario":0.0
   },
   {
      "id":291273,
      "entidade": {
          "id": 3,
          "nome": "Entidade teste",
          "documento": "00.000.000/0000-00"
      },
      "terceiro": {
          "id": 1,
          "nome": "DIVERSOS",
          "documento": "000.000.000-00",
          "endereco": "Rua teste endereço"
      },
      "valor":570.3,
      "numeroParcela":1,
      "baixada":true,
      "idProvisao":143484,
      "dataVencimento":"23-10-2018",
      "juros":0.0,
      "numeroDocumento":"1309/1",
      "dataBaixa":"23-10-2018",
      "descontoMaxParcela":0.0,
      "carenciaCalculo":false,
      "aliqDescontoDiario":0.0,
      "dataEmissao":"23-10-2018",
      "tipoDocumento":"CUPOM FISCAL",
      "dataAlteracao":"23-10-2018 11:09:58",
      "historico":"Parcela 1 de 1.",
      "multa":0.0,
      "totalParcelas":1,
      "diasCarenciaMulta":0,
      "diasCarenciaJuros":0,
      "idRenegociacao":0,
      "composicaoValorBaixado":{
         "dinheiro":0,
         "pix":[
            {
               "valor":20.9,
               "historico":"PIX 000550002",
               "agencia":"3176-1",
               "banco":"033",
               "conta":"8732482-5"
            }
         ],
         "boleto":[
            {
               "valor":10,
               "historico":"BOLETO 0000002",
               "agencia":"3176-1",
               "banco":"033",
               "conta":"8732482-5"
            }
         ],
         "cartoes":[
            {
               "valor":100.00,
               "nsu":"000230002",
               "idNegociacao":30,
               "codAutorizacao":"833204",
               "numParcelas":1,
               "recebimentoOperadoraCartao":[
                  {
                     "autorizacao":"833204",
                     "nsu":"000230002",
                     "valorBruto":100.00,
                     "numeroParcela":1,
                     "valorLiquido":109.19,
                     "dataVencimento":"24-10-2018",
                     "idParcelaOperadoraCartao":291274
                  }
               ]
            }
         ],
         "valorTotal":570.3,
         "baixaContabil":439.4,
         "renegociacao":0,
         "adiantamentoRecebido":0,
         "outros":439.4,
         "saldoDevedor":0,
         "voucher":0,
         "valePresente":0
      },
      "idOperacaoFinanceira":0,
      "valorTotalParcelas":570.3,
      "classificacoesContabeis":[
         {
            "contaContabil":"41301 - VENDAS DE MERCADORIAS",
            "porcentagemApropriada":72.78
         },
         {
            "contaContabil":"14201 - MERCADORIAS",
            "porcentagemApropriada":27.21
         }
      ],
      "valorBaixado":570.3,
      "valorTotalRetencoes":0,
      "idLancamentoPadrao":1,
      "contaContabilDebito":"13101 - CLIENTES",
      "idContaContabilDebito":19,
      "contasContabeisBaixa": {
            "idContaContabilDebito": 99,
            "contaContabilDebito": "13101 - CLIENTES",
            "idContaContabilCredito": 100,
            "contaContabilCredito": "22601 - CONTAS A PAGAR DIVERSAS"
      }
   }
]
```