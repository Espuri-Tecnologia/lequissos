### Definição

Atendimentos realizados pelos vendedores durante a operação da loja. 

Seu uso mais comum está no cálculo da taxa de conversão de vendas.

### URLs

> GET https://integrador.varejonline.com.br/apps/api/representantes/atendimentos

### Parâmetros

* **entidades:** [Veja como Funciona este Filtro](https://github.com/Varejonline/api/wiki/Filtro-de-Entidades)
* **inicio:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **quantidade:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **alteradoApos:** [Entenda a Coleta de Alterações](https://github.com/Varejonline/api/wiki/Filtro-de-Data-Alteração)
* **representantes:** Lista de IDs de [Representantes](https://github.com/Varejonline/api/wiki/GET-Representantes), separados por vírgula

### Retorno

* **id:** id único do registro de atendimentos (long)
* **representanteId:** id do [vendedor](/Varejonline/api/wiki/GET-representantes) associado aos atendimentos (long)
* **entidadeId:** id da [entidade](/Varejonline/api/wiki/GET-entidades) associada aos atendimentos (long)
* **dataAtendimento:** Data do movimento contabilizado no formato dd-mm-aaaa (string)
* **quantidadeAtendimento:** Quantidade de atendimentos realizados pelo vendedor na data do registro (long)

### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/representantes/atendimentos

```javascript
[
   {
      "id":1,
      "representanteId":1,
      "entidadeId":1,
      "dataAtendimento":"20-01-2013 11:44:45",
      "quantidadeAtendimento":10
   }
]
```