Ajuste de estoque é o endpoint utilizado para corrigir o saldo de um produto no sistema que esteja desencaixado com o estoque físico da operação.

### URLs

> POST https://integrador.varejonline.com.br/apps/api/ajuste-estoque

### Parâmetros

    Todos os campos são obrigatórios

* **data:** Data em que será aplicado o ajuste de saldo (string dd/mm/yyyy hh:mm:ss)
* **entidade:** (objeto complexo) 
    * **id:** id da [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) para a qual o saldo será aplicado (long)
* **descricao:** nome do ajuste (string) _(max 255 chars)_
* **contagens:** lista de produtos que serão ajustados, contendo para cada um:
    * **produto:** informar um dos critérios para identificar o [produto](https://github.com/Varejonline/api/wiki/GET-Produtos). Será considerado apenas o primeiro por ordem.
       * **id** 
       * **codigoSistema**
       * **codigoInterno**
       * **codigoBarras**
    * **quantidade:** quantidade a ser aplicada para a mercadoria na data e entidade informada (decimal) (zero ou maior)


### Observações

* Todos os ajustes serão realizados utilizando a unidade de medida padrão do cadastro dos produtos.
* Não é possível realizar ajuste de estoque de produtos com método de controle diferente de estocável.

### Retorno

Sucesso:
* HTTP STATUS 201 – CREATED
* Body: id do ajuste gerado

Requisição inválida: 
* HTTP STATUS 400 – BAD REQUEST
* Body: mensagem de erro


### Exemplo

> POST https://integrador.varejonline.com.br/apps/api/ajuste-estoque

```javascript
{
    "data": "26/04/2021 00:00:00",
    "entidade": {
       "id": 3
    },
    "descricao": "Ajuste teste A",
    "contagens": [
        {
            "quantidade": 20,
            "produto": {
                "codigoSistema": "2.70.55.0020"
            }
        },
        {
            "quantidade": 10,
            "produto": {
                "codigoSistema": "1.3.6.0008"
            }
        }
    ]
}

```