Endpoints acoes promocionais

## [GET Ações Promocionais](/Varejonline/api/wiki/GET-Acoes-promocionais)
## [POST Ações Promocionais](/Varejonline/api/wiki/POST-Acoes-promocionais)
## [PUT Ações Promocionais - Alterar status](/Varejonline/api/wiki/PUT-Acoes-promocionais-alterar-status)
## [PUT Ações Promocionais](/Varejonline/api/wiki/PUT-Acoes-promocionais)
## [DELETE Ações Promocionais](/Varejonline/api/wiki/DELETE-Acoes-promocionais)


# Material de apoio

* [Guia: Rotina de Ações promocionais no ERP](https://varejonline.movidesk.com/kb/article/235015/acoes-promocionais)
* [Vídeo: Como criar Ações promocionais no ERP](https://varejonline.movidesk.com/kb/article/339760/video-como-criar-acoes-promocionais)
* [Vídeo: Como consumir Ações promocionais no caixa](https://varejonline.movidesk.com/kb/article/320682/video-consumir-acoes-promocionais-no-caixa)