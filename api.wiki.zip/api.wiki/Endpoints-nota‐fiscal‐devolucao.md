**[POST nota-devolucao](https://github.com/Varejonline/api/wiki/POST-Nota-Fiscal-Devolu%C3%A7%C3%A3o)**

**[GET nota-devolucao](https://github.com/Varejonline/api/wiki/Get-Nota-Fiscal-Devolu%C3%A7%C3%A3o)**

**[PUT nota-devolucao](https://github.com/Varejonline/api/wiki/PUT-Nota-Fiscal-Devolu%C3%A7%C3%A3o)**

**[DELETE nota-devolucao](https://github.com/Varejonline/api/wiki/DELETE-Nota-fiscal-devolu%C3%A7%C3%A3o)**