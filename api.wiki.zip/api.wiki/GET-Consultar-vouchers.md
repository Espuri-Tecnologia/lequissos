### URLs

> GET https://integrador.varejonline.com.br/apps/api/vouchers/consultar

### Parâmetros

* **ids:** Lista de ids dos [Vouchers](https://github.com/Varejonline/api/wiki/GET-vouchers) (long - Path Param) 
* **documentoCliente:** Documento do cliente não formatado identificado na venda (string - Path Param) (opcional)

### Retorno

Sucesso HTTP 200 OK:

Retorna uma lista JSONs com informações do resultado da operação realizada, contendo:
* **id:** ID do Voucher (long)
* **valorVoucher:** Valor do voucher (decimal)
* **valorUtilizadoCliente:** Valor total utilizado pelo cliente (decimal)
* **valorReservadoCliente:** Valor total reservado para o cliente (decimal)
* **valorDisponivel:** Valor disponível para o voucher (decimal)
* **quantidadeUtilizada:** Quantidade utilizado para o voucher promocional (integer)
* **quantidadeReservada:** Quantidade reservada para o voucher promocional (integer)
* **quantidadeDisponivel:** Quantidade disponível para o voucher promocional (integer)
* **podeConsumir:** Informa se o voucher pode ser consumido/reservado (boolean)
* **observacao:** Informa o motivo em que o voucher não pode ser consumido/reservado (string)

Requisição inválida: 
* HTTP STATUS 400 – BAD REQUEST
* Body: mensagem de erro

### Exemplos

> GET https://integrador.varejonline.com.br/apps/api/vouchers/consultar?ids=1001,1002&documentoCliente=00759251502

```javascript
[
   {
        "id": 1001,
        "valorVoucher": 50,
        "valorUtilizadoCliente": 0,
        "valorReservadoCliente": 0,
        "valorDisponivel": 50,
        "podeConsumir": true
   },
   {
        "id": 1002,
        "valorVoucher": 50,
        "valorUtilizadoCliente": 25,
        "valorReservadoCliente": 25,
        "valorDisponivel": 0,
        "quantidadeUtilizada": 5,
        "quantidadeReservada": 5,
        "quantidadeDisponivel": 90,
        "podeConsumir": false,
        "observacao": "Voucher sem saldo disponível"
   }
]
```