### URL

> POST https://integrador.varejonline.com.br/apps/api/provisoes-contas

### Parâmetros

Envie um JSON no corpo da requisição, contendo:
* **idLancamentoPadrao:** id do lançamento padrão em que esta provisão será baseada (long) _(obrigatório)_
* **idEntidade:** id da [entidade](https://github.com/Varejonline/api/wiki/GET-entidades) para a qual esta provisão será feita (long) _(obrigatório)_
* **idTerceiro:** id do [terceiro](https://github.com/Varejonline/api/wiki/GET-terceiros) a quem se destina a provisão (long)
* **data:**  data da provisão (string) _(obrigatório)_
* **valor:**  valor da provisão (decimal) _(obrigatório)_
* **historico:**  (string)

### Retorno

Sucesso:
* HTTP STATUS 201 – CREATED
* Body: id da provisão gerada

Requisição inválida: 
* HTTP STATUS 400 – BAD REQUEST
* Body: mensagem de erro

### Exemplo

> POST https://integrador.varejonline.com.br/apps/api/provisoes-contas

'Content-Type'='application/json'

```javascript
{
   "idLancamentoPadrao":3,
   "idEntidade":1,
   "idTerceiro":15,
   "data":"21-10-2012",
   "valor":123.40,
   "historico":"histórico da provisão"
}
```