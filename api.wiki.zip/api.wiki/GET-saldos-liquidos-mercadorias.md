O saldo de uma mercadoria representa a quantidade disponível em estoque de um produto para uma certa entidade. 

### URLs

> GET https://integrador.varejonline.com.br/apps/api/saldos-mercadorias/liquido

### Parâmetros

* **produtos:** lista de ids dos produtos cujos saldos se deseja obter (Long, separados por vírgula)
* **codigosInternos:** lista de códigos internos dos produtos (String, separados por vírgula)
* **entidades:** [Veja como Funciona este Filtro](https://github.com/Varejonline/api/wiki/Filtro-de-Entidades)
* **inicio:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **quantidade:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **alteradoApos:** [Entenda a Coleta de Alterações](https://github.com/Varejonline/api/wiki/Filtro-de-Data-Alteração)  **(obrigatório)**
* **somenteEcommerce:** Permite filtrar somente produtos integráveis no ecommerce (true) ou todos (false) (Boolean Opcional)
* **somenteMarketplace:** Permite filtrar somente produtos integráveis no marketplace (true) ou todos (false) (Boolean Opcional)
* **carregarEstoqueEmTransito:** Indica se o estoque em trânsito deve ser carregado (boolean, padrão: true)
* **carregarEstoqueMinimoMaximo:** Indica se o estoque mínimo e máximo deve ser carregado (boolean, padrão: true)
* **carregarQuantidadeReservada:** Indica se quantidade reservada deve ser carregada (boolean, padrão: true)

**Observações**

O parâmetro **alteradoApos** é **obrigatório**.

**carregarEstoqueEmTransito**, **carregarEstoqueMinimoMaximo** e **carregarQuantidadeReservada** podem aumentar notadamente o tempo para o retorno. Considere carregar somente se necessário.

### Retorno

* **estoqueMinimo:** estoque mínimo da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos) (decimal)
* **estoqueMaximo:** estoque máximo da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos) (decimal)
* **saldoAtual:** saldo atual da mercadoria no sistema (decimal)
* **quantidadeEstoqueTransito:** quantidades em processo de recebimento por transferência (decimal) e pedidos de compras com status diferentes de CANCELADO, ENCERRADO e ATENDIDO
* **quantidadeReservada:** quantidades reservada (decimal)
* **produto:** dados do produto envolvido (objeto complexo)
    * **id:** id da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos)
    * **descricao:** id da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos)
    * **codigoSistema:** Código Sistema da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos)
    * **codigoInterno:** Código Interno da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos)
    * **codigoBarras:** Código de Barras da [mercadoria](https://github.com/Varejonline/api/wiki/GET-Produtos)
* **entidade:** entidade do saldo envolvido (objeto complexo)
    * **id:** id da [entidade](https://github.com/Varejonline/api/wiki/GET-Entidades)
    * **nome:** nome da [entidade](https://github.com/Varejonline/api/wiki/GET-Entidades)
    * **documento:** CNPJ da [empresa](https://github.com/Varejonline/api/wiki/GET-Empresas)

### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/saldos-mercadorias?alteradoApos=11/11/2021%2010:30:00&produtos=320&entidades=5

```javascript
[
    {
    "estoqueMinimo":0,
    "estoqueMaximo":0,
    "produto":{
        "id":320,
        "codigoBarras":"7909069669674",
        "codigoSistema":"0082.0003",
        "descricao":"TENIS REPLAY MASC KLIN 173.005000 CINZA CLARO  26",
        "codigoInterno":"164028"
    },
    "saldoAtual":1,
    "entidade":{
        "id":5,
        "nome":"3-AMERICO",
        "documento":"09191780000330"
    },
    "quantidadeEstoqueTransito":62,
    "quantidadeReservada":0
    }
]
```