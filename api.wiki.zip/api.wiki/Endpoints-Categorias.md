## Níveis de categorias

### [GET Níveis Categoria](/Varejonline/api/wiki/GET-niveis-categoria)
<br>

## Produto

### [GET categorias-produto](/Varejonline/api/wiki/GET-categorias-produto)
### [POST categorias-produto](/Varejonline/api/wiki/POST-categorias-produto)
### [PUT categorias-produto](/Varejonline/api/wiki/PUT-categorias-produto)

<br>

## Serviço

### [GET categorias-servico](/Varejonline/api/wiki/GET-categorias-servico)
### [POST categorias-servico](/Varejonline/api/wiki/POST-categorias-servico)
### [PUT categorias-servico](/Varejonline/api/wiki/PUT-categorias-servico)
