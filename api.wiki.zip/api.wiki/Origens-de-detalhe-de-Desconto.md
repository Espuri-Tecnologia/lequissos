Listagem das possíveis origens de detalhe de desconto.

<table>
<tr><th>Tipo</th></tr>
	<tr><td>MANUAL</td></tr>
	<tr><td>TABELA_PRECO</td></tr>
	<tr><td>DESCONTO_PROGRESSIVO</td></tr>
	<tr><td>ACAO_PROMOCIONAL</td></tr>
	<tr><td>CLASSE_TERCEIRO</td></tr>
	<tr><td>VOUCHER</td></tr>
	<tr><td>FIDELIDADE</td></tr>
	<tr><td>RATEIO</td></tr>
	<tr><td>OUTRO</td></tr>

</table>