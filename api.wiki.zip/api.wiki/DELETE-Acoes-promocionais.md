### URLs

> DELETE https://integrador.varejonline.com.br/apps/api/acoes-promocionais/:id

### Parâmetros

* **id:** ID da [Ação promocional](https://github.com/Varejonline/api/wiki/GET-ações-promocionais-dev) que deve ser excluída (Long - Path Param)

### Retorno

Sucesso HTTP 200 OK:

Retorna um Json com informações do resultado da operação realizada, contendo:

* **codigoMensagem:** Código de identificação da operação realizada. [veja a lista de Códigos](https://github.com/Varejonline/api/wiki/Retorno-API)
* **mensagem:** Mensagem da operação realizada

Requisição inválida: 
* HTTP STATUS 400 – BAD REQUEST
* Body: mensagem de erro

Status atual da ação é igual ao novo status da requisição: 
* HTTP STATUS 409 – CONFLICT
* Body: mensagem de erro
