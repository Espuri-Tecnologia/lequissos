### Descrição

Endpoint utilizado para obter os metadados associados à campos customizados da base do cliente.

Campos customizados são estruturas de dados dinâmicas, parametrizadas pelo cliente em sua base. Essas estruturas são transformadas em campos na tela e permitem que o cliente configure objetos com informações específicas do seu domínio de negócio, não absorvidas pelos campos padrões do sistema.

Listagem dos possíveis tipos de campos customizados:

<table>
<tr><th>Nome</th><th>Tipo</th></tr>
<tr><td>TEXTO</td><td>STRING Primitivo</td></tr>
<tr><td>NUMERO</td><td>INTEGER Primitivo</td></tr>
<tr><td>DECIMAL</td><td>DECIMAL Primitivo</td></tr>
<tr><td>DATA</td><td>CALENDAR Primitivo</td></tr>
<tr><td>EMAIL</td><td>STRING Primitivo</td></tr>
<tr><td>OPCIONAL</td><td>STRING Primitivo</td></tr>
<tr><td>COMPOSICAO</td><td>COMPOSITE Complexo</td></tr>
<tr><td>LISTA</td><td>LIST Complexo</td></tr>
</table>