### URLs

> GET https://integrador.varejonline.com.br/apps/api/notas-mercadoria/inutilizacao

> GET https://integrador.varejonline.com.br/apps/api/notas-mercadoria/inutilizacao/:id

### Parâmetros

* **inicio:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **quantidade:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **alteradoApos:** [Entenda a Coleta de Alterações](https://github.com/Varejonline/api/wiki/Filtro-de-Data-Alteração)
* **cnpj:** (string com/sem formatação)

### Material de apoio

[Inutilização de NF-e](https://varejonline.movidesk.com/kb/pt-br/article/17086/inutilizacao)


### Retorno

* **id:** id da inutilização (long)
* **ambiente:** Ambiente em que a inutilização foi realizada. Os valores possíveis são: PRODUCAO e HOMOLOGACAO
* **modelo:** Modelo do documento fiscal. Os valores possíveis são: NFe e NFCe
* **dataInutilizacao:** Data e hora da inutilização no formato dd-MM-yyyy HH:mm:ss
* **protocoloSefaz:** Código do protocolo retornado pela SEFAZ após homologação da inutilização (max 100 chars)
* **cnpj:** CNPJ do emitente que solicitou a inutilização
* **mensagemSefaz:** Mensagem retornada pela SEFAZ indicando o status da inutilização (max 255 chars)
* **entidade:** Id da entidade (long)
* **justificativa:** Motivo da inutilização (max 200 chars)
* **ano:** Ano da faixa de numeração inutilizada, no formato de dois dígitos
* **serie:** Série da nota fiscal cujo número foi inutilizado
* **numeroInicial:** Número inicial da faixa inutilizada (long)
* **numeroFinal:** Número final da faixa inutilizada (long)


### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/notas-mercadoria/inutilizacao

```javascript
[
    {
        "id": 1,
        "ambiente": "PRODUCAO",
        "dataInutilizacao": "24-01-2024 13:23:10",
        "protocoloSefaz": "000000000000000",
        "cnpj": "00000000000000",
        "mensagemSefaz": "102 - Inutilização de número homologado",
        "modelo": "NFe",
        "entidade": 1,
        "justificativa": "Houve uma instabilidade no sefaz. Todas as notas foram reemitidas e autorizadas com outra numeração.",
        "ano": "24",
        "serie": "9",
        "numeroInicial": 13206,
        "numeroFinal": 13227
    },
    {
        "id": 21,
        "ambiente": "HOMOLOGACAO",
        "dataInutilizacao": "11-12-2024 11:22:28",
        "protocoloSefaz": "000000000000000",
        "cnpj": "00000000000000",
        "mensagemSefaz": "102 - Inutilizacao de numero homologado",
        "modelo": "NFCe",
        "entidade": 2,
        "justificativa": "inutilização de nota em ambiente de homologação.",
        "ano": "24",
        "serie": "1",
        "numeroInicial": 2,
        "numeroFinal": 2
    }
]

```