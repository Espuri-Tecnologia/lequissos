### Integrando seu aplicativo com o Varejonline

1. Crie sua conta no [DevCenter](https://erp.varejonline.com.br/store/devcenter/aplicativos) e cadastre seu aplicativo.
1. Integre seu aplicativo [via OAuth 2.0](OAuth-2.0)
1. Acesse os dados do usuário através dos Endpoints Varejonline.
