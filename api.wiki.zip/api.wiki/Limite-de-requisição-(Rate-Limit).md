Nossos servidores de integração possuem uma política de aceitação de solicitações externas para evitar a exaustão de processamento que é finita, fornecendo um uptime maior à todos os nossos parceiros e clientes. Desta forma temos algumas regras que são definidas por IP e levam em conta todos os requests realizados à qualquer endpoint (i.e, essa limitação não é por cada rota, então deve-se levar em considerações todos os endpoints solicitados no tempo limitado).


***


**A regra atual da Varejonline para Rate Limit é de:**

30 requests a cada 2 segundos, por IP. Requests adicionais ao limite serão bloqueados por até 3 minutos contados a partir do inicio do bloqueio.

***

**Regra específica para endpoint de produtos:**

Incluindo o limite geral acima definido, o endpoint de atualização de produto possui um limite de 3 atualizações a cada 6 horas para um mesmo SKU (id de produto). Ao atualizar pela quarta vez o mesmo id de produtos dentro de 6 horas de janela, será retornado um erro "429 - Too Many Requests