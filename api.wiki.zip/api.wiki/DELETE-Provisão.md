Endpoint para exclusão de provisões.

Provisões oriundas de renegociação de parcelas, serão excluídas e as parcelas originais (provisão original) serão restauradas.

### URLs

DELETE https://integrador.varejonline.com.br/apps/api/provisoes-contas/:id

### Parâmetros

* **id:** Id da Provisão que deve ser excluída (Long - Path Param)

### Retorno

HTTP Status OK