## Adiantamentos Pagos

## [GET adiantamento-pagos](/Varejonline/api/wiki/GET-adiantamentos-pagos)
## [POST adiantamento-pagos](/Varejonline/api/wiki/POST-adiantamentos-pagos)
<br>


## Adiantamentos Recebidos

## [GET adiantamento-receb.](/Varejonline/api/wiki/GET-adiantamentos-recebidos)
## [POST adiantamento-receb.](/Varejonline/api/wiki/POST-adiantamentos-recebidos)
