Caso tipoPremio.BRINDE e tipoConfiguracao.PRODUTO, é obrigatório informar ou categoriasProduto, ou produtos ou combinacao.

* **tipoPremio:** [tipo de prêmio](https://github.com/Varejonline/api/wiki/A%C3%A7%C3%A3o-promocional-tipos-pr%C3%AAmio) _(obrigatório)_ (String)
* **tipoConfiguracao:** [tipo de configuração do prêmio](https://github.com/Varejonline/api/wiki/A%C3%A7%C3%A3o-promocional-configura%C3%A7%C3%A3o-tipo-pr%C3%AAmio) _(obrigatório)_ (String)
* **tipoDesconto:** PERCENTUAL, VALOR (String) _(obrigatório de acordo com o tipoPremio)_
* **desconto:** (decimal) _(obrigatório se tipoDesconto.VALOR)_
* **categoriasCliente:** (List<Long>)) _(Opcional)_
* **categoriasProduto:** Lista de ids de [categorias](https://github.com/Varejonline/api/wiki/GET-categorias-produto) (List(Long)) 
* **produtos:** Lista de [produtos](https://github.com/Varejonline/api/wiki/GET-Produtos). _(Obrigatório um identificador para o produto)_
    * **id:** (Long)
    * **codigoSistema:** (String)
    * **codigoInterno:** (String)
    * **codigoBarras:** (String)
* **combinacao:** 
  * **combinacoesProdutos:** Lista de objetos complexos
    * **produtos:** Lista de [produtos](https://github.com/Varejonline/api/wiki/GET-Produtos). _(Obrigatório um identificador para o produto)_
      * **id:** (Long)
      * **codigoSistema:** (String)
      * **codigoInterno:** (String)
      * **codigoBarras:** (String)
    * **quantidade:** (decimal) _(obrigatório)_