Listagem dos possíveis modelos de notas fiscais.

<table>
<tr><th>Chave</th><th>Tipo</th></tr>
<tr><td>NOTA_55</td><td>NFe</td></tr>
<tr><td>NOTA_59</td><td>SAT</td></tr>
<tr><td>NOTA_65</td><td>NFCe</td></tr>
<tr><td>CF</td><td>Cupom Fiscal</td></tr>
</table>