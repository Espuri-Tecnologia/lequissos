### URLs

> GET https://integrador.varejonline.com.br/apps/api/marcas

> GET https://integrador.varejonline.com.br/apps/api/marcas/:id

### Parâmetros

* **inicio:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **quantidade:** [Entenda a Coleta Paginada](https://github.com/Varejonline/api/wiki/Paginação-de-resultados)
* **alteradoApos:** [Entenda a Coleta de Alterações](https://github.com/Varejonline/api/wiki/Filtro-de-Data-Alteração)
* **apenasAtivos:** filtra apenas marcas ativas (default: true) (boolean)

### Retorno

* **id:** id da marca(long)
* **status:** status da marca (ATIVO, INATIVO)
* **nome:** nome da marca (string)
* **entidades:** lista de grupos que esta entidade pertence. (array)
   * **id:** id da entidade (long)
   * **nome:** nome da entidade (string)


### Exemplo

> GET https://integrador.varejonline.com.br/apps/api/marcas

```javascript
[
    {
        "id": 282,
        "status": "ATIVO",
        "nome": "TESTE",
        "entidades": [
            {
                "id": 2,
                "nome": "LOJA NFCE - LUCRO PRESUMIDO"
            }
        ]
    },
    {
        "id": 283,
        "status": "ATIVO",
        "nome": "TESTE 02",
        "entidades": [
            {
                "id": 3,
                "nome": "DÉPOSITO CENTRAL"
            }
        ]
    }
]
```