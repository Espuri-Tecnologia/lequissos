### Status disponíveis

* **EMITIDO:** Status que indica um documento fiscal já foi emitido e é um documento válido, e aceito pelo órgão responsável quando aplicável.

* **CANCELADO:** Status que indica que um documento fiscal foi cancelado e não é mais um documento válido.

* **ENVIAR:** Este status indica documentos fiscais que devem ser enviados eletrônicamente a um órgão responsável, como é o caso das Notas Fiscais eletrônicas enviadas a Receita Federal. Esse status é temporário, onde o  envio ainda está pendente e terá seu estado atualizado conforme o envio eletrônico para a receita federal ocorrer.

* **ENVIADO:** Estado que indica que o documento fiscal já foi enviado eletronicamente para o órgão responsável e está aguardando a finalização do processamento.

* **ERRO_ENVIO** Esse status indica que não foi possível estabelecionar uma conexão para enviar o documento fiscal eletrônico para o órgão responsável, mas o documento passará por uma avaliação para ser enviado novamente e ter seu estado corrigido.

* **ERRO:** Esse status indica que o documento fiscal recebido pelo órgão responsável foi rejeitado e possui erros em sua formação. Por mais que o documento fiscal tenha sido emitido, o órgão como a receita federal não aceitou este documento, portanto não é um documento fiscal válido.

