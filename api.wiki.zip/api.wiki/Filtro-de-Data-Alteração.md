## Definição 

O filtro de data de alteração permite a realização de buscas incrementais de registros a partir de uma data de referência.
Supondo que seu aplicativo realize coletas de dados do Varejonline de forma periódica, você pode utilizar este recurso para eliminar sincronizações completas de dados.

Para informar o período desejado, basta incluir na requisição o seguintes parâmetro:

* **alteradoApos:** data de alteração mínima formato "dd-mm-aaaa hh:mm:ss" ou "dd/mm/aaaa hh:mm:ss"

Serão retornados registros que foram criados ou alterados com uma data (e horário) maior ou igual à informada.

## Exemplos de uso

> GET https://integrador.varejonline.com.br/apps/api/produtos?alteradoApos=01/12/2016%2012:00:00

>A consulta retornará apenas os produtos criados ou modificados a partir do meio dia de 01/12/2016, no horário de Brasília.

### Dica para sincronização de dados:

Imaginando que você nunca sincronizou produtos da base do cliente Varejonline para seu aplicativo e vai iniciar o sincronismo dos dados às **00:00 horas do dia 12/12/2016**.

Na primeira sincronização, irá consultar com a seguinte composição de parâmetros:

* **Página 1**
   * dataAlteracao = 01/01/1900 00:00:00
   * inicio = 0
   * quantidade = 100

* **Página 2**
   * dataAlteracao = 01/01/1900 00:00:00
   * inicio = 100
   * quantidade = 100

* **Página 3**
   * dataAlteracao = 01/01/1900 00:00:00
   * inicio = 200
   * quantidade = 100

e assim por diante até finalizar às 02:00, quando o total de registros retornados na página for zero (critério de parada).

Quando terminar sua sincronização completa você deve armazenar como data de última sincronização: **12-12-2016 00:00**.

Na próxima sincronização de mercadorias, utilize a seguinte composição de parâmetros:

* **Página 1**
   * dataAlteracao = 12/12/2016 00:00:00
   * inicio = 0
   * quantidade = 100

* **Página 2**
   * dataAlteracao = 12/12/2016 00:00:00
   * inicio = 100
   * quantidade = 100

e assim por diante.

Qualquer registro que tenha sido alterado durante o primeiro sync será retornado nessa segunda sincronização, ou seja, não perderá nenhum registro, pois todas as alterações ocorreram após às 00:00.