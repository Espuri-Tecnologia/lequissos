Alguns serviços da API retornam recursos que estão relacionados a vendedores específicos.

Para informar os vendedores desejados em uma requisição, basta informar um parâmetro:

* **representantes:** lista de ids dos vendedores desejados, separados por vírgula.

Por padrão, se não for informado o parâmetro, o Varejonline assumirá que se deseja obter os recursos relacionados à todos os vendedores da base Varejonline.

### Exemplos de uso

> GET https://integrador.varejonline.com.br/apps/api/comissao/?representantes=1,3,6&desde=01/03/2015&ate=31/03/2015

Essa busca retornará as apurações de comissão associadas aos vendedores com ids 1, 3 e 6.
