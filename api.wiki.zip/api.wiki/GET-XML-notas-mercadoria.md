### URL

Para obter o xml autorizado da nota fiscal:
> GET https://integrador.varejonline.com.br/apps/api/notas-mercadoria/xml/:id

Para obter o xml associado ao evento de cancelamento da nota fiscal:
> GET https://integrador.varejonline.com.br/apps/api/notas-mercadoria/xml/cancelamento/:id

### Parâmetro na URL
* **id:** id da [nota de mercadoria](https://github.com/Varejonline/api/wiki/GET-notas-mercadoria)

### Retorno
* **xml:** XML da nota (string)

**Observações:**
* Só é possível obter o XML de notas modelo 55, 59 e 65.
* Só é possível obter o XML de notas:
   * Emitidas pelo sistema Varejonline
   * Recebidas via importação do XML do fornecedor.
* Só é possível obter o XML de notas autorizadas ou canceladas.