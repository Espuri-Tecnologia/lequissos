Endpoint utilizado para disponibilizar no Varejonline o XML para recebimentos de entradas via XML.

O endpoint fará a leitura do XML e avaliando o CNPJ do emitente e do destinatário da nota, fará a inclusão do XML no sistema. Para ser aceito, o emitente deve estar cadastrado como um fornecedor na base Varejonline e o destinatário, deve ser o CNPJ de uma das empresas da base.


### URL

> POST https://integrador.varejonline.com.br/apps/api/recebimentos/xml

### Parâmetros

Envie um JSON no corpo da requisição, contendo:
* **arquivo:** byte array do xml (byte[])

### Retorno

Sucesso:
* HTTP STATUS 201

Requisição inválida: 
* HTTP STATUS 500

### Exemplo

> POST https://integrador.varejonline.com.br/apps/api/recebimentos/xml

'Content-Type'='application/json'
```javascript
{
   "arquivo" : [60, 110, 102, 101, 80, 114, ..., 62]
}
```

Exemplo de Envio:

```java
public static void sendXml(byte[] xml) throws Exception {

    HttpPost httpPost = new HttpPost(new URL("https://integrador.varejonline.com.br/apps/api/recebimentos/xml?token=TOKEN_USER").toURI());

    String postObj = "{ \"arquivo\" : " + Arrays.toString(xml) + " }"; 
		
    StringEntity object = new StringEntity(postObj);
		
    httpPost.addHeader("Content-Type", "application/json");
    httpPost.setEntity(object);

    new ContentEncodingHttpClient().execute(httpPost);
}
```