### URL

> POST https://integrador.varejonline.com.br/apps/api/baixas/estornar/id_baixa


### Observações

Serão permitidos apenas estornos de baixas realizadas pelo módulo de baixas do ERP ou pela API.

Baixas de PDV não são permitidas porque envolvem fechamentos de caixa.


### Retorno
**Sucesso:**
* HTTP STATUS 200 – OK
* Body: Retorna um JSON com informações do resultado da operação realizada, contendo:
   * **idRecurso:** id do baixa que foi estornada.
   * **codigoMensagem:** Código de identificação da operação realizada. [veja a lista de Códigos](https://github.com/Varejonline/api/wiki/Retorno-API)
   * **mensagem:** Mensagem da operação realizada

**Requisição inválida:**
* HTTP STATUS 400 – BAD REQUEST
* Body: Retorna um JSON com o erro
   * **idRecurso:** id do baixa que foi estornada.
   * **codigoMensagem:** Código de identificação do erro. [veja a lista de Códigos](https://github.com/Varejonline/api/wiki/Retorno-API)
   * **mensagem:** Mensagem de erro