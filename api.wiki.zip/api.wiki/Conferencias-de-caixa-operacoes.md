Listagem das possíveis operações da conferência de caixa.

<table>
<tr><th>Operação</th></tr>
<tr><td>ABERTURA</td></tr>
<tr><td>FECHAMENTO</td></tr>
<tr><td>SANGRIA</td></tr>
<tr><td>SUPRIMENTO</td></tr>
</table>